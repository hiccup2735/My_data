var iframeContainer = document.getElementById("avaturn-container");
var canvas = document.querySelector("#unity-canvas");
var gameInstance;
