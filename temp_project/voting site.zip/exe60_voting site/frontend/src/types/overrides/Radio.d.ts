// eslint-disable-next-line
import * as Radio from '@mui/material/Radio';

declare module '@mui/material/Radio' {
  interface RadioPropsSizeOverrides {
    large;
  }
}
