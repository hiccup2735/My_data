// material-ui
// eslint-disable-next-line
import * as Color from '@mui/material';

declare module '@mui/material' {
  interface Color {
    0?: string;
    A50?: string;
    A800?: string;
  }
}
