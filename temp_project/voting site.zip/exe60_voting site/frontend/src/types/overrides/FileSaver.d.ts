
declare module 'file-saver';