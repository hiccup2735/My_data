
declare module 'exceljs/lib/doc/range';