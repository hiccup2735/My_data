// eslint-disable-next-line
import * as Badge from '@mui/material/Badge';

declare module '@mui/material/Badge' {
  interface BadgePropsVariantOverrides {
    light;
  }
}
