# Introduction

This is seed version of Mantis Theme. Seed is very minimal version of theme. It has just one authentication method with sample page in dashboard. Except mentioned above, all the unreferenced things has been removed. No extra packages, components, apis. Seed has been targeted for users who just need aesthetic and MUI from project, rest they wanted to manage their own like state, api and many other things.

# Getting Started

1. Installation process
   - run 'npm install / yarn'
   - start dev server run 'npm run start / yarn start'
2. Deployment process
   - Goto root directory and open package.json. Update homepage URL to the production URL
   - Goto root directory and run 'npm run build / yarn build'
