# スクリーンショット一覧

## ページ

### サインアップ

![img](__screenshots__/page/Signup/Default.png 'img')

### ログイン

![img](__screenshots__/page/Login/Default.png 'img')

### 試験一覧

![img](__screenshots__/page/ExamList/Default.png 'img')

### 試験詳細

![img](__screenshots__/page/ExamDetail/Info.png 'img')

### 回答画面

![img](__screenshots__/page/ExamDetail/Question.png 'img')

### 回答完了

![img](___screenshots__/page/ExamDetail/Finished.png 'img')

### 結果閲覧画面

![img](__screenshots__/page/ExamDetail/Infofinished.png 'img')

### ユーザー設定

![img](__screenshots__/page/Setting/Default.png 'img')

### メールアドレスの検証

![img](__screenshots__/page/VerifyEmail/Succeeded.png 'img')

### パスワードのリセット

![img](__screenshots__/page/ResetPassword/Default.png 'img')

## UI パーツ

### ヘッダ

![img](__screenshots__/ui/GlobalNav/Default.png 'img')
