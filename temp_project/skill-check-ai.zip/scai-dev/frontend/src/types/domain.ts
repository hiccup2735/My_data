import { components } from './api'

type ID = number

export type User = components['schemas']['User']

// ready/answering/finished/expired
export type ExaminationStatus =
  | 'ready'
  | 'answering'
  | 'finished'
  | 'expired'
  | 'before'
  | 'scoring'
export type Score = components['schemas']['Score']

export type CodeQuizResultType = 'OK' | 'NG' | 'ERR'

export type CodeQuizResult = {
  id: ID
  result: CodeQuizResultType
  score: string
  statistics: string
  code_quiz: {
    id: ID
    description: string
  }
  question: {
    id: ID
    name: string
    description: string
  }
}

type _Examination = Omit<
  components['schemas']['Examination'],
  'status' | 'questions'
> & {
  status: ExaminationStatus
  questions: Question[]
  code_quiz_results: CodeQuizResult[]
}
export type Examination = _Examination & {
  previous_data: _Examination | null
}
export type ExaminationSummary = Pick<
  Examination,
  | 'id'
  | 'name'
  | 'description'
  | 'status'
  | 'limit_min'
  | 'questions_count'
  | 'started_at'
  | 'available_at'
  | 'start_limit_at'
  | 'answer_limit_at'
>

export const codeQuizTypes = ['standard_io', 'file_io'] as const
export type CodeQuizType = typeof codeQuizTypes[number]

export const codeQuizFileTypes = [
  'input',
  'output',
  'ok_list',
  'ng_list',
  'setup',
] as const
export type CodeQuizFileType = typeof codeQuizFileTypes[number]

export type AdminCodeQuizFile = {
  id: ID
  code_quiz_id: ID
  type: CodeQuizFileType
  url: string
}

export const GroupNames = [
  '未設定', 
  '(GX)検定', 
  '(GX/DX)研修'
] as const

export type AdminCodeQuiz = {
  id: ID
  question_id: number
  sequence: number
  type: CodeQuizType
  description: string
  memory_limit: number
  time_limit: number
  criteria: number
  compare: string
  files: AdminCodeQuizFile[]
}

type CodeQuizLang = {
  lang: string
  name: string
}

export type CodeQuiz = {
  id: ID
  question_id: ID
  sequence: number
  description: string
  available_langs: CodeQuizLang[]
  answer?: {
    code: string
    lang: string
  }
}

export type Question = components['schemas']['Question'] & {
  code_quizzes: CodeQuiz[]
}

export type Admin = components['schemas']['Admin']
export type ExaminationScope = 'private' | 'global'

export type AdminExaminationCategory = {
  id: number
  name: string
  score: number
}
export type AdminExamination = components['schemas']['AdminExamination'] & {
  scope: ExaminationScope
  categories: AdminExaminationCategory[]
  organization_ids: number[]
  code?: string
  average_score: number
  best_score: number
  worst_score: number
  attendance_rate: number
  level: number
  group: number
}

export type AdminExaminationUser = components['schemas']['AdminExaminationUser']
export type Metadata = {
  key: string
  value: string
}
export type AdminQuestion = components['schemas']['AdminQuestion'] & {
  metadata: Metadata[]
  tags: string[]
  answer_count: number
  correct_answer_count: number
  correct_answer_rate: number
  level: number
  group: number
}

export interface MaterialTableState {
  query: SlimQuery
}

export interface SlimQuery {
  page: number,
  pageSize: number,
  search: string
}

export enum SessionKey {
  QuestionPageSize = "QuestionPageSize",
  QuestionKeyword = "QuestionKeyword",
  QuestionPage = "QuestionPage",
  ExamPageSize = "ExamPageSize",
  ExamKeyword = "ExamKeyword",
  ExamPage = "ExamPage",
  OrganizationPage = "OrganizationPage",
  OrganizationKeyword = "OrganizationKeyword",
  OrganizationPageSize = "OrganizationPageSize",
  UserPage = "UserPage",
  UserKeyword = "UserKeyword",
  UserPageSize = "UserPageSize"
}

export type AdminQuestionDetail = AdminQuestion & {
  examinations: { id: number; name: string }[]
  metadata: Metadata[]
  tags: string[]
  answer_count: number
  correct_answer_count: number
  correct_answer_rate: number
  level: number
  code_quizzes: AdminCodeQuiz[]
}
export type AdminQuiz = components['schemas']['Quiz']
export type AdminUser = components['schemas']['AdminUser'] & {
  is_invited?: boolean
}
export type Choice = components['schemas']['Choice']
export type License = components['schemas']['License'] & {
  organization_id: components['schemas']['Organization']['id']
  organization_name: components['schemas']['Organization']['name']
  examination_id: components['schemas']['Examination']['id']
  examination_name: components['schemas']['Examination']['name']
}

export type AdminQuestionTag = {
  name: string
}

export type Organization = components['schemas']['Organization'] & {
  comparable: boolean
}
export type OrganizationCategory = components['schemas']['OrganizationCategory']

export type OrganizationExamination = components['schemas']['OrganizationExamination']
export type OrganizationExaminationDetail = components['schemas']['OrganizationExaminationDetail']
export type OrganizationExaminationUser = components['schemas']['OrganizationExaminationUser']

export type OrganizationExaminationStat = {
  average_score: number
  categories: {
    name: string
    average_score: number
  }[]
}

export type OrganizationExaminationHistory = {
  id: number
  name: string
  description: string
  start_date_time: string
  end_date_time: string
  license_users_count: number
  taken_users_count: number
  average_score: number
  best_score: number
  worst_score: number
}

// Draft Types
export type AdminUserDetail = AdminUser & { examinations: Examination[] }

export type QuestionCategory = {
  id: number
  name: string
  group: number
}

export type Organizer = {
  id: number
  name: components['schemas']['_']['name']
  email: components['schemas']['_']['email']
}

export type Operator = {
  id: number
  name: components['schemas']['_']['name']
  email: components['schemas']['_']['email']
  password?: string
}

export type Manager = {
  id: number
  name: components['schemas']['_']['name']
  email: components['schemas']['_']['email']
  password?: string
  group: number
}
