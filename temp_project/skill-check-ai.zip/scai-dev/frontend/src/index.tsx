import React from 'react'
import ReactDOM from 'react-dom'
import * as serviceWorker from './serviceWorker'
import { UserApp } from './routes/UserApp'
import { GlobalStyle } from './components/page/utils/GlobalStyle'
import { SnackbarProvider } from 'notistack'
import { AdminApp } from './routes/AdminApp'
import { OrganizerApp } from './routes/OrganizerApp'
import { OperatorApp } from './routes/OperatorApp'
import { ManagerApp } from './routes/ManagerApp'

ReactDOM.render(
  <React.StrictMode>
    <GlobalStyle />
    <SnackbarProvider maxSnack={3} autoHideDuration={5000}>
      <UserApp />
      <AdminApp />
      <OrganizerApp />
      <OperatorApp />
      <ManagerApp />
    </SnackbarProvider>
  </React.StrictMode>,
  document.getElementById('root')
)

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister()
