import axios from 'axios'
import useAxios from 'axios-hooks'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { createContext, ReactNode, useState } from 'react'
import { Organizer } from '../types/domain'
import { apiPath } from '../utils/api'

type ContextValue = {
  authenticated: boolean
  setAuthenticated: (authenticated: boolean) => void
  organizer?: Organizer
  logout: (onLogout?: () => void) => void
}

export const OrganizerContext = createContext<ContextValue>({
  authenticated: false,
  setAuthenticated: () => {
    return
  },
  organizer: undefined,
  logout: () => {
    return
  },
})

type Props = {
  children: ReactNode
}

const AUTHENTICATED_KEY = 'organizerAuth'
const AUTHENTICATED_VALUE = '1'

export const OrganizerProvider = ({ children }: Props) => {
  const { enqueueSnackbar } = useSnackbar()
  const [authenticated, setAuthenticated] = useState<boolean>(false)

  React.useEffect(() => {
    if (localStorage.getItem(AUTHENTICATED_KEY) === AUTHENTICATED_VALUE) {
      setAuthenticated(true)
    }
  }, [])

  const [{ data: organizer, response, error }, getOrganizer] = useAxios<
    Organizer
  >(apiPath.organizer, {
    manual: true,
    useCache: false,
  })

  React.useEffect(() => {
    authenticated && getOrganizer()
  }, [authenticated, getOrganizer])

  React.useEffect(() => {
    if (error?.response?.status === 403 || error?.response?.status === 401) {
      setAuthenticated(false)
    }
  }, [response, error])

  return (
    <OrganizerContext.Provider
      value={{
        authenticated,
        setAuthenticated: (auth: boolean) => {
          localStorage.setItem(AUTHENTICATED_KEY, AUTHENTICATED_VALUE)
          setAuthenticated(auth)
        },
        organizer,
        logout: (onLogout) => {
          axios
            .delete<null>(apiPath.organizerAuth, {})
            .then((res) => {
              localStorage.setItem(AUTHENTICATED_KEY, '')
              setAuthenticated(false)
              enqueueSnackbar('ログアウトに成功しました', {
                variant: 'success',
              })
            })
            .catch((e) => {
              enqueueSnackbar('ログアウトに失敗しました', {
                variant: 'error',
              })
            })
            .finally(() => {
              onLogout && onLogout()
            })
        },
      }}
    >
      {children}
    </OrganizerContext.Provider>
  )
}
