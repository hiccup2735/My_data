/// <reference types="react-scripts" />
declare module 'markdown-it-katex'
declare module '@liradb2000/markdown-it-katex'
