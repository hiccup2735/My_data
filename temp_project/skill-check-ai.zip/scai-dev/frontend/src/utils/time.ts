import moment from 'moment'

const TIME_FORMAT = 'HH:mm:ss'
// const DATE_FORMAT = 'YYYY/MM/DD'
const DATETIME_FORMAT = 'YYYY/MM/DD HH:mm'

export const formatSeconds = (sec: number): string => {
  if (sec < 0) {
    return '-'
  }
  return moment({
    seconds: sec % 60,
    minutes: (sec % 3600) / 60,
    hours: (sec % 216000) / 3600,
  }).format(TIME_FORMAT)
}

export const getDiffSeconds = (serverNow: string): number =>
  (new Date().getTime() - moment(serverNow).toDate().getTime()) / 1000

export const getRestSeconds = (limit: string): number => {
  return (moment(limit).toDate().getTime() - new Date().getTime()) / 1000
}

export const formatDate = (date: string): string =>
  moment(date).format(DATETIME_FORMAT)
