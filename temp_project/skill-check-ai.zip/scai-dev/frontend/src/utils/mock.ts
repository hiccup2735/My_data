import * as faker from 'faker'
import moment from 'moment'
import {
  AdminExamination,
  AdminQuestion,
  CodeQuiz,
  Examination,
  ExaminationSummary,
  Question,
} from '../types/domain'

const now = moment().add(3, 'second')
const start = moment()
// const startLimit = moment().add(10, 'minutes')
// const end = moment().add(1, 'week')
const answerLimit = moment().add(30, 'minutes')

faker.seed(1)
// const lorem = faker.lorem.sentences(3)

export const examSummaries: ExaminationSummary[] = [
  {
    id: 1,
    name: '試験タイトル',
    description: '試験について',
    status: 'ready',
    questions_count: 10,
    limit_min: 60,
    start_limit_at: start.toISOString(),
    answer_limit_at: answerLimit.toISOString(),
  },
  {
    id: 2,
    name: faker.lorem.words(30),
    description: 'description',
    status: 'answering',
    questions_count: 10,
    limit_min: 60,
    start_limit_at: start.toISOString(),
    answer_limit_at: answerLimit.toISOString(),
  },
  {
    id: 3,
    name: 'exam#3',
    description: 'description',
    status: 'finished',
    questions_count: 10,
    limit_min: 60,
    start_limit_at: start.toISOString(),
    answer_limit_at: answerLimit.toISOString(),
  },
  {
    id: 4,
    name: 'exam#4',
    description: 'description',
    status: 'expired',
    questions_count: 10,
    limit_min: 60,
    start_limit_at: start.toISOString(),
    answer_limit_at: answerLimit.toISOString(),
  },
  {
    id: 5,
    name: 'exam#5',
    description: 'description',
    status: 'before',
    questions_count: 10,
    limit_min: 60,
    start_limit_at: start.toISOString(),
    answer_limit_at: answerLimit.toISOString(),
  },
  {
    id: 6,
    name: 'exam#6',
    description: 'description',
    status: 'scoring',
    questions_count: 10,
    limit_min: 60,
    start_limit_at: start.toISOString(),
    answer_limit_at: answerLimit.toISOString(),
  },
]

export const question: Question = {
  id: 1,
  name: 'Q#1',
  description: 'description of q#1',
  is_answered: false,
  category_name: 'category#1',
  quizzes: [],
  image_uri: undefined,
  code_quizzes: [],
}

/* eslint-disable no-useless-escape */
const mathDescription = `ディープラーニングに関連した手法であるオートエンコーダは、エンコーダとデコーダによって構成される。入力、隠れ層のアクティベーション、出力をそれぞれ $\\bm{x}$ , $\\mathbm{h}$, $\\mathbm{x'}$とし、エンコーダにおける活性化関数を$\\sigma$, 重み行列を$\\mathbf{W}$, バイアスを$\\mathbf{b}$とする。
また、デコーダにおける活性化関数を$\\sigma'$, 重み行列を$\\mathbf{W'}$, バイアスを$\\mathbf{b'}$とする。このとき、オートエンコーダの学習時に最小化すべき数式を以下から選びなさい。`
const mathChoice = `$\\parallel \\mathbf{x} - \\sigma' (\\mathbf{W'}(\\mathbf{\\sigma (\\mathbf{W}\\mathbf{x}+\\mathbf{b})})+\\mathbf{b'}) \\parallel ^2$`

const genQuestion = (id: number): Question => ({
  ...question,
  id,
  name: `Q #${id}`,
  description: mathDescription,
  code_quizzes: [],
  quizzes: [
    {
      id: 1,
      question_id: id,
      description: 'desc',
      sequence: 0,
      choices: [
        {
          quiz_id: 1,
          sequence: 1,
          point: 10,
          id: id * 10 + 1,
          name: `choice ${id}-1`,
          is_selected: true,
        },
        {
          quiz_id: 1,
          sequence: 1,
          point: 10,
          id: id * 10 + 2,
          name: mathChoice,
          is_selected: false,
        },
        {
          quiz_id: 1,
          sequence: 1,
          point: 10,
          id: id * 10 + 3,
          name: `choice ${id}-3`,
          is_selected: false,
        },
        {
          quiz_id: 1,
          sequence: 1,
          point: 10,
          id: id * 10 + 4,
          name: `choice ${id}-4`,
          is_selected: false,
        },
      ],
    },
  ],
})

export const questions: Question[] = [
  {
    ...genQuestion(1),
    is_answered: true,
    image_uri: 'https://via.placeholder.com/1280x720?text=Sample+Image',
  },
  { ...genQuestion(2) },
  { ...genQuestion(3) },
  { ...genQuestion(4) },
  { ...genQuestion(5) },
  { ...genQuestion(6) },
  { ...genQuestion(7) },
]

export const mathQuestion: Question = {
  ...questions[0],
  description: mathDescription,
}

export const exam: Examination = {
  ...examSummaries[0],
  questions_count: questions.length,
  score: 0,
  scores: [],
  limit_min: 30,
  now: now.toDate().toString(),
  questions,
  group: 0,
  previous_data: null,
  code_quiz_results: [],
}

export const codeQuizzes: CodeQuiz[] = [
  {
    id: 1,
    question_id: 10,
    sequence: 1,
    description: 'コード設問1説明文',
    available_langs: [
      {
        lang: 'cpp',
        name: 'C++',
      },
      {
        lang: 'java',
        name: 'Java',
      },
      {
        lang: 'python',
        name: 'Python',
      },
      {
        lang: 'r',
        name: 'R',
      },
      {
        lang: 'go',
        name: 'Go',
      },
    ],
  },
  {
    id: 2,
    question_id: 10,
    sequence: 2,
    description: 'コード設問2説明文',
    available_langs: [
      {
        lang: 'cpp',
        name: 'C++',
      },
      {
        lang: 'java',
        name: 'Java',
      },
      {
        lang: 'python',
        name: 'Python',
      },
      {
        lang: 'r',
        name: 'R',
      },
      {
        lang: 'go',
        name: 'Go',
      },
    ],
  },
]

export const finishedExam: Examination = {
  ...exam,
  id: 2,
  status: 'finished',
  score: 100,
  scores: [
    {
      category_name: 'カテゴリ1',
      score: 20,
    },
    {
      category_name: 'カテゴリ2',
      score: 30,
    },
    {
      category_name: 'カテゴリ3',
      score: 50,
    },
  ],
}

export const genAdminQuestion: (id: number) => AdminQuestion = (id: number) => {
  const q: AdminQuestion = {
    id,
    level: 1,
    group: 0,
    name: `Q #${id}`,
    category_id: 1,
    description: mathDescription,
    image_uri: 'https://via.placeholder.com/1440x720',
    metadata: [{ key: 'key', value: 'value' }],
    tags: ['a', 'b', 'c'],
    answer_count: 1,
    correct_answer_count: 1,
    correct_answer_rate: 100,
    quizzes: [
      {
        id: id * 10 + 1,
        question_id: id,
        description: 'desc',
        sequence: 0,
        choices: [
          {
            id: 1,
            is_selected: false,
            name: 'choice',
            quiz_id: id * 10 + 1,
            sequence: 0,
            point: 10,
          },
        ],
      },
    ],
  }

  return q
}

const adminQ: AdminQuestion = genAdminQuestion(1)

export const adminExam: AdminExamination = {
  ...exam,
  scope: 'global',
  questions: [adminQ],
  licenses_count: 0,
  organization_ids: [],
  users_count: 0,
  categories: [{ id: 1, name: 'category1', score: 100 }],
  code: '',
  average_score: 0,
  best_score: 0,
  worst_score: 0,
  attendance_rate: 0,
  level: 0,
  group: 0,
}

export const getAdminExams = (
  page: number,
  pageSize: number,
): AdminExamination[] =>
  Array(pageSize)
    .fill(null)
    .map((_, i) => ({
      ...adminExam,
      id: page * pageSize + i + 1,
    }))

export const getAdminQuestions = (
  page: number,
  pageSize: number,
): AdminQuestion[] =>
  Array(pageSize)
    .fill(null)
    .map((_, i) => ({
      ...genAdminQuestion(page * pageSize + i + 1),
    }))
