import cryptoRandomString from 'crypto-random-string'

export const genRandomString = (length = 16) =>
  cryptoRandomString({ length, type: 'ascii-printable' })
