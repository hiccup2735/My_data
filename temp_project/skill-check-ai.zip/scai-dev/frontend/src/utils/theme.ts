import { createMuiTheme } from '@material-ui/core/styles'
import { CSSProperties } from '@material-ui/core/styles/withStyles'

export const colors = {
  white: '#fff',
  primary: '#d29c08',
  text: '#333333',
  subText: '#777',
  background: '#ffffff',
  backgroundSub: '#f6f8fc',
  disabled: '#999',
  hint: '#666',
  copyright: '#acacac',
  separator: '#e9edf1',
  itemHeader: '#f4eacc',
  resultBackground: '#f9f6ed',
  emphasis: '#ea3838',
  alert: '#ee3366',
  checked: '#00cc66',
  table: {
    header: {
      color: '#333',
      background: '#eee',
    },
    column: {
      color: '#333',
      background: '#fff',
    },
  },

  org: {
    primary: '#0099cc',
  },
}

export const adminTheme = createMuiTheme({})

export const organizerTheme = createMuiTheme({
  palette: {
    primary: {
      main: colors.org.primary,
    },
  },
})

export const muiTheme = createMuiTheme({
  palette: {
    primary: {
      main: colors.primary,
    },
    text: {
      primary: colors.text,
      secondary: colors.text,
      disabled: colors.disabled,
      hint: colors.hint,
    },
    background: {
      default: colors.background,
      paper: colors.background,
    },
  },
  overrides: {
    MuiOutlinedInput: {
      input: {
        backgroundColor: colors.backgroundSub,
      },
      root: {
        backgroundColor: colors.backgroundSub,
      },
    },
    MuiButton: {
      root: {
        borderRadius: '48px',
      },
      containedPrimary: {
        color: 'white',
      },
    },
  },
})

export const tableHeaderStyle: CSSProperties = {
  backgroundColor: colors.table.header.background,
  color: colors.table.header.color,
}
