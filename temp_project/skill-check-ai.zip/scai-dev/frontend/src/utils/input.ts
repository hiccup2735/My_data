export const inputProps = {
  InputLabelProps: {
    //    shrink: true,
  },
  fullWidth: true,
}
