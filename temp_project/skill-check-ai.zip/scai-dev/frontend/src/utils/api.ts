import axios from 'axios'
import {
  Admin,
  AdminCodeQuiz,
  AdminExamination,
  AdminExaminationUser,
  AdminQuestion,
  AdminQuestionDetail,
  AdminQuestionTag,
  AdminQuiz,
  AdminUser,
  AdminUserDetail,
  Choice,
  CodeQuizFileType,
  Examination,
  ExaminationScope,
  License,
  Metadata,
  Organization,
  OrganizationCategory,
  OrganizationExamination,
  OrganizationExaminationDetail,
  OrganizationExaminationHistory,
  OrganizationExaminationStat,
  OrganizationExaminationUser,
  Organizer,
  QuestionCategory,
  User,
  Operator,
  Manager,
} from '../types/domain'

const API_BASE = '/api/v1.0'
const ADMIN_BASE = '/api/v1.0/admin'
const ORG_BASE = '/api/v1.0/organizer'
const OPE_BASE = '/api/v1.0/operator'
const MGR_BASE = '/api/v1.0/manager'

export const apiPath = {
  auth: `${API_BASE}/auth`,
  user: `${API_BASE}/user`,
  resetPassword: `${API_BASE}/user/reset`,
  verifyUser: `${API_BASE}/user/verify`,
  examinations: `${API_BASE}/examinations`,
  genExam: (id: string | number) => `${API_BASE}/examinations/${id}`,
  genExamQuestion: (examId: ID, questionId: ID) =>
    `${API_BASE}/examinations/${examId}/questions/${questionId}`,
  genExamQuestionCodeQuiz: (examId: ID, questionId: ID) =>
    `${API_BASE}/examinations/${examId}/questions/${questionId}/code_quiz`,
  admin: `${ADMIN_BASE}`,
  adminAuth: `${ADMIN_BASE}/auth`,
  adminUser: `${ADMIN_BASE}/user`,
  adminUsers: `${ADMIN_BASE}/users`,
  genAdminUser: (userId: ID) => `${ADMIN_BASE}/users/${userId}`,

  genAdminUserLicenses: (userId: ID) =>
    `${ADMIN_BASE}/users/${userId}/licenses`,
  genAdminUserLicense: (userId: ID, licenseId: ID) =>
    `${ADMIN_BASE}/users/${userId}/licenses/${licenseId}`,

  genAdminOrganizationsUsers: (organizationId: ID) =>
    `${ADMIN_BASE}/organizations/${organizationId}/users`,
  genAdminOrganizationsUser: (organizationId: ID, userId: ID) =>
    `${ADMIN_BASE}/organizations/${organizationId}/users/${userId}`,

  genAdminOrganizationsLicenses: (organizationId: ID) =>
    `${ADMIN_BASE}/organizations/${organizationId}/licenses`,
  genAdminOrganizationsLicense: (organizationId: ID, licenseId: ID) =>
    `${ADMIN_BASE}/organizations/${organizationId}/licenses/${licenseId}`,

  genAdminOrganizationsOrganizers: (organizationId: ID) =>
    `${ADMIN_BASE}/organizations/${organizationId}/organizers`,
  genAdminOrganizationsOrganizer: (organizationId: ID, organizerId: ID) =>
    `${ADMIN_BASE}/organizations/${organizationId}/organizers/${organizerId}`,

  admins: `${ADMIN_BASE}/admins`,
  genAdmin: (adminId: ID) => `${ADMIN_BASE}/admins/${adminId}`,
  adminExaminations: `${ADMIN_BASE}/examinations`,
  genAdminExam: (id: string | number) => `${ADMIN_BASE}/examinations/${id}`,
  genDuplicateExam: (id: string | number) =>
    `${ADMIN_BASE}/examinations/${id}/copy`,
  genAdminQuestion: (id: string | number) => `${ADMIN_BASE}/questions/${id}`,
  genDuplicateAdminQuestion: (id: string | number) =>
    `${ADMIN_BASE}/questions/${id}/copy`,
  genAdminExamUsers: (id: string | number) =>
    `${ADMIN_BASE}/examinations/${id}/users`,
  genAdminExamOrganization: (
    examId: string | number,
    organizationId: string | number,
  ) => `${ADMIN_BASE}/examinations/${examId}/organizations/${organizationId}`,
  adminQuestionsImagesUpload: `${ADMIN_BASE}/image/questions/upload`,
  genAdminQuestionQuizzes: (questionId: ID) =>
    `${ADMIN_BASE}/questions/${questionId}/quizzes`,
  genAdminQuestionCodeQuizzes: (questionId: ID) =>
    `${ADMIN_BASE}/questions/${questionId}/code_quizzes`,
  genAdminQuestionQuiz: (questionId: ID, quizId: ID) =>
    `${ADMIN_BASE}/questions/${questionId}/quizzes/${quizId}`,
  genAdminQuestionCodeQuiz: (questionId: ID, codeQuizId: ID) =>
    `${ADMIN_BASE}/questions/${questionId}/code_quizzes/${codeQuizId}`,
  genAdminQuestionCodeQuizSubmit: (questionId: ID, codeQuizId: ID) =>
    `${ADMIN_BASE}/questions/${questionId}/code_quizzes/${codeQuizId}/submit`,
  genAdminCodeQuizFileUpload: (codeQuizId: ID, fileType: CodeQuizFileType) =>
    `${ADMIN_BASE}/code_quizzes/${codeQuizId}/files/${fileType}`,
  genAdminCodeQuizFile: (codeQuizId: ID, fileID: ID) =>
    `${ADMIN_BASE}/code_quizzes/${codeQuizId}/files/${fileID}`,
  genAdminExamQuestion: (
    examId: string | number,
    questionId: string | number,
  ) => `${ADMIN_BASE}/examinations/${examId}/questions/${questionId}`,
  genAdminExamQuestionReorder: (
    examId: string | number,
    questionId: string | number,
  ) => `${ADMIN_BASE}/examinations/${examId}/questions/${questionId}/reorder`,

  adminQuestions: `${ADMIN_BASE}/questions`,
  genAdminQuizChoices: (quizId: ID) =>
    `${ADMIN_BASE}/quizzes/${quizId}/choices`,
  genAdminQuizChoice: (quizId: ID, choiceId: ID) =>
    `${ADMIN_BASE}/quizzes/${quizId}/choices/${choiceId}`,

  adminQuestionCategories: `${ADMIN_BASE}/question_categories`,
  genAdminQuestionCategory: (categoryId: ID) =>
    `${ADMIN_BASE}/question_categories/${categoryId}`,

  adminQuestionTags: `${ADMIN_BASE}/question_tags`,

  adminOrganizations: `${ADMIN_BASE}/organizations`,
  genAdminOrganization: (orgId: ID) => `${ADMIN_BASE}/organizations/${orgId}`,

  adminOrganizationCategories: `${ADMIN_BASE}/organization_categories`,
  genAdminOrganizationCategory: (categoryId: ID) =>
    `${ADMIN_BASE}/organization_categories/${categoryId}`,

  adminOperators: `${ADMIN_BASE}/operators`,
  getOperator: (opeatorId: ID) => `${ADMIN_BASE}/operators/${opeatorId}`,

  adminManagers: `${ADMIN_BASE}/managers`,
  getManager: (managerId: ID) => `${ADMIN_BASE}/managers/${managerId}`,

  organizer: `${ORG_BASE}`,
  organizerAuth: `${ORG_BASE}/auth`,
  organizerUsers: `${ORG_BASE}/users`,
  genOrganizerUser: (userId: ID) => `${ORG_BASE}/users/${userId}`,
  genOrganizerUserLicense: (userId: ID, licenseId: ID) =>
    `${ORG_BASE}/users/${userId}/licenses/${licenseId}`,
  organizerExaminations: `${ORG_BASE}/examinations`,
  genOrganizerExamination: (examId: ID) => `${ORG_BASE}/examinations/${examId}`,
  genOrganizerExaminationUsers: (examId: ID) =>
    `${ORG_BASE}/examinations/${examId}/users`,
  genOrganizerExaminationStat: (examId: ID) =>
    `${ORG_BASE}/examinations/${examId}/stat`,
  genOrganizerExaminationHistories: (examId: ID) =>
    `${ORG_BASE}/examinations/${examId}/histories`,

  organizerLicenses: `${ORG_BASE}/licenses`,

  operator: `${OPE_BASE}`,
  operatorAuth: `${OPE_BASE}/auth`,

  manager: `${MGR_BASE}`,
  managerAuth: `${MGR_BASE}/auth`,
}

export const requests = {
  startExam: (id: string | number) =>
    axios.post<Examination>(apiPath.genExam(id)),
  answerExam: (examId: ID, questionId: ID, quizId: ID, choiceId: ID) =>
    axios.patch<Examination>(apiPath.genExamQuestion(examId, questionId), {
      quiz_id: quizId,
      choice_id: choiceId,
    }),
  answerCodeQuiz: (
    examId: ID,
    questionId: ID,
    codeQuizId: ID,
    lang: string,
    code: string,
  ) =>
    axios.patch<Examination>(
      apiPath.genExamQuestionCodeQuiz(examId, questionId),
      {
        code_quiz_id: codeQuizId,
        lang,
        code,
      },
    ),
  finishExam: (id: string | number) =>
    axios.put<Examination>(apiPath.genExam(id)),
  requestPasswordChange: (email: string) =>
    axios.post<null>(apiPath.resetPassword, { email }),
  changePassword: (
    resetToken: string,
    password: string,
    passwordConfirmation: string,
  ) =>
    axios.put<User>(apiPath.resetPassword, {
      reset_token: resetToken,
      password,
      password_confirmation: passwordConfirmation,
    }),
  requestVerify: () => axios.post<null>(apiPath.verifyUser),
  verifyUser: (verifyToken: string) =>
    axios.put<User>(apiPath.verifyUser, {
      verify_token: verifyToken,
    }),
}

export type RecordSetProps = {
  total: number
  page: number
  page_size: number
}

type ID = string | number
type ListParams = { q?: string; page?: number; page_size?: number, group?: number }

export const adminRequests = {
  getExam: (examId: number | string) =>
    axios.get<AdminExamination>(apiPath.genAdminExam(examId)),
  deleteExam: (examId: number | string) =>
    axios.delete<AdminExamination>(apiPath.genAdminExam(examId)),
  duplicateExam: (examId: number | string) =>
    axios.post<AdminExamination>(apiPath.genDuplicateExam(examId)),
  getExams: (params: ListParams) =>
    axios.get<RecordSetProps & { examinations: AdminExamination[] }>(
      apiPath.adminExaminations,
      { params },
    ),
  getExamUsers: (examId: number | string, params: ListParams) =>
    axios.get<RecordSetProps & { users: AdminExaminationUser[] }>(
      apiPath.genAdminExamUsers(examId),
      { params },
    ),
  attachExamOrg: (examId: ID, orgId: ID) =>
    axios.patch<AdminExamination>(
      apiPath.genAdminExamOrganization(examId, orgId),
    ),
  detachExamOrg: (examId: ID, orgId: ID) =>
    axios.delete<AdminExamination>(
      apiPath.genAdminExamOrganization(examId, orgId),
    ),
  getQuestions: (params: ListParams & { tags?: string[] }) => {
    const { tags, ...restParams } = params
    return axios.get<RecordSetProps & { questions: AdminQuestion[] }>(
      apiPath.adminQuestions,
      { params: { ...restParams, tags: tags ? tags.join(',') : undefined } },
    )
  },
  getQuestion: (questionId: ID) =>
    axios.get<AdminQuestionDetail>(apiPath.genAdminQuestion(questionId)),
  deleteQuestion: (questionId: ID) =>
    axios.delete<AdminQuestion>(apiPath.genAdminQuestion(questionId)),
  duplicateQuestion: (questionId: ID) =>
    axios.post<AdminQuestion>(apiPath.genDuplicateAdminQuestion(questionId)),
  updateQuestion: (
    questionId: ID,
    params: {
      name: string
      description: string
      image_uri?: string
      category_id?: ID
      metadata?: Metadata[]
      tags?: string[]
      level?: number
      group?: number
    },
  ) => axios.patch<AdminQuestion>(apiPath.genAdminQuestion(questionId), params),
  createQuestion: (params: {
    name?: string
    description?: string
    image_uri?: string
    category_id?: ID
    metadata?: Metadata[]
    tags?: string[]
    level?: number
    group?: number
  }) => axios.post<AdminQuestion>(apiPath.adminQuestions, params),
  uploadQuestionImage: (file: File) => {
    const form = new FormData()
    form.append('image', file)
    return axios.post<{ image_url: string }>(
      apiPath.adminQuestionsImagesUpload,
      form,
      {
        headers: {
          'content-type': 'multipart/form-data',
        },
      },
    )
  },
  uploadCodeQuizFile: (
    codeQuizId: ID,
    fileType: CodeQuizFileType,
    file: File,
  ) => {
    const form = new FormData()
    form.append('file', file)
    return axios.put<{
      id: ID
      code_quiz_id: ID
      type: CodeQuizFileType
      url: string
    }>(apiPath.genAdminCodeQuizFileUpload(codeQuizId, fileType), form, {
      headers: {
        'content-type': 'multipart/form-data',
      },
    })
  },
  submitCodeQuiz: (questionId: ID, codeQuizId: ID) =>
    axios.put(apiPath.genAdminQuestionCodeQuizSubmit(questionId, codeQuizId)),
  deleteCodeQuizFile: (codeQuizId: ID, fileId: ID) =>
    axios.delete<AdminQuiz>(apiPath.genAdminCodeQuizFile(codeQuizId, fileId)),
  createQuiz: (
    questionId: ID,
    params: { description?: string; sequence?: number },
  ) =>
    axios.post<AdminQuiz>(apiPath.genAdminQuestionQuizzes(questionId), params),
  createCodeQuiz: (
    questionId: ID,
    params: {
      description?: string
      sequence?: number
      type?: string
      memory_limit?: number
      time_limit?: number
      criteria?: number
      compare: string
    } = {
      description: 'description',
      sequence: 1,
      type: 'standard_io',
      memory_limit: 128,
      time_limit: 120,
      criteria: 50,
      compare: 'standard',
    },
  ) =>
    axios.post<AdminQuiz>(
      apiPath.genAdminQuestionCodeQuizzes(questionId),
      params,
    ),
  updateCodeQuiz: (
    questionId: ID,
    codeQuizId: ID,
    params: Pick<
      AdminCodeQuiz,
      | 'compare'
      | 'criteria'
      | 'time_limit'
      | 'memory_limit'
      | 'description'
      | 'type'
      | 'sequence'
    >,
  ) => {
    return axios.patch<AdminCodeQuiz>(
      apiPath.genAdminQuestionCodeQuiz(questionId, codeQuizId),
      params,
    )
  },
  updateQuiz: (questionId: ID, quizId: ID, params: { description?: string }) =>
    axios.patch<AdminQuiz>(
      apiPath.genAdminQuestionQuiz(questionId, quizId),
      params,
    ),
  deleteQuiz: (questionId: ID, quizId: ID) =>
    axios.delete<AdminQuiz>(apiPath.genAdminQuestionQuiz(questionId, quizId)),
  updateExam: (
    id: number | string,
    params: {
      name?: string
      description?: string
      limit_min?: number
      scope?: ExaminationScope
      code?: string,
      group?: number,
    },
  ) => axios.patch<AdminExamination>(apiPath.genAdminExam(id), params),
  createExam: (params: {
    name?: string
    description?: string
    limit_min?: number
    scope?: ExaminationScope
    code?: string
    group?: number
  }) => axios.post<AdminExamination>(apiPath.adminExaminations, params),
  attachQuestion: (
    examId: number,
    questionId: number,
    sequence: number,
    categoryId: number,
  ) =>
    axios.patch<AdminExamination>(
      apiPath.genAdminExamQuestion(examId, questionId),
      { sequence, category_id: categoryId },
    ),
  detachQuestion: (examId: ID, questionId: ID) =>
    axios.delete<AdminExamination>(
      apiPath.genAdminExamQuestion(examId, questionId),
    ),
  reorderQuestion: (examId: ID, questionId: ID, index: number) =>
    axios.post<AdminExamination>(
      apiPath.genAdminExamQuestionReorder(examId, questionId),
      {
        to: index,
      },
    ),
  getChoices: (quizId: ID) =>
    axios.get<Choice[]>(apiPath.genAdminQuizChoices(quizId)),
  createChoice: (
    quizId: ID,
    params: { name: string; point: number; sequence?: number },
  ) => axios.post<Choice>(apiPath.genAdminQuizChoices(quizId), params),
  updateChoice: (
    quizId: ID,
    choiceId: ID,
    params: { name: string; point: number },
  ) =>
    axios.patch<Choice>(apiPath.genAdminQuizChoice(quizId, choiceId), params),
  deleteChoice: (quizId: ID, choiceId: ID) =>
    axios.delete<Choice>(apiPath.genAdminQuizChoice(quizId, choiceId)),

  // /admin/admins
  getAdmins: (params: ListParams) =>
    axios.get<RecordSetProps & { admins: Admin[] }>(apiPath.admins, { params }),
  createAdmin: (params: Omit<Admin, 'id'>) =>
    axios.post<Admin>(apiPath.admins, params),
  updateAdmin: (adminId: ID, params: Omit<Admin, 'id'>) =>
    axios.patch<Admin>(apiPath.genAdmin(adminId), params),
  deleteAdmin: (adminId: ID) => axios.delete<Admin>(apiPath.genAdmin(adminId)),

  // /admin/question_categories
  getQuestionCategories: (params: ListParams) =>
    axios.get<QuestionCategory[]>(apiPath.adminQuestionCategories, { params }),
  createQuestionCategory: (params: Omit<QuestionCategory, 'id'>) =>
    axios.post<QuestionCategory>(apiPath.adminQuestionCategories, params),
  updateQuestionCategory: (
    categoryId: ID,
    params: Omit<QuestionCategory, 'id'>,
  ) =>
    axios.patch<QuestionCategory>(
      apiPath.genAdminQuestionCategory(categoryId),
      params,
    ),
  deleteQuestionCategory: (categoryId: ID) =>
    axios.delete<QuestionCategory>(
      apiPath.genAdminQuestionCategory(categoryId),
    ),

  // /admin/question_tags
  getQuestionTags: (params: ListParams) =>
    axios.get<AdminQuestionTag[]>(apiPath.adminQuestionTags, { params }),

  // /admin/organizations
  getOrganizations: (params: ListParams) =>
    axios.get<RecordSetProps & { organizations: Organization[] }>(
      apiPath.adminOrganizations,
      { params },
    ),
  getOrganization: (orgId: ID) =>
    axios.get<Organization>(apiPath.genAdminOrganization(orgId)),
  createOrganization: (params: Omit<Organization, 'id'>) =>
    axios.post<Organization>(apiPath.adminOrganizations, params),
  updateOrganization: (orgId: ID, params: Partial<Omit<Organization, 'id'>>) =>
    axios.patch<Organization>(apiPath.genAdminOrganization(orgId), params),
  deleteOrganization: (orgId: ID) =>
    axios.delete<Organization>(apiPath.genAdminOrganization(orgId)),

  // /admin/organization_categories
  getOrganizationCategories: (params: ListParams) =>
    axios.get<
      OrganizationCategory[]
      //      RecordSetProps & { organization_categories: OrganizationCategory[] }
    >(apiPath.adminOrganizationCategories, { params }),
  createOrganizationCategory: (params: Omit<OrganizationCategory, 'id'>) =>
    axios.post<OrganizationCategory>(
      apiPath.adminOrganizationCategories,
      params,
    ),
  updateOrganizationCategory: (
    categoryId: ID,
    params: Partial<Omit<OrganizationCategory, 'id'>>,
  ) =>
    axios.patch<OrganizationCategory>(
      apiPath.genAdminOrganizationCategory(categoryId),
      params,
    ),

  // /admin/users
  getUsers: (params: ListParams) =>
    axios.get<RecordSetProps & { users: AdminUser[] }>(apiPath.adminUsers, {
      params,
    }),
  getUser: (userId: ID) =>
    axios.get<AdminUserDetail>(apiPath.genAdminUser(userId)),
  createUser: (params: Partial<AdminUser> & { password: string }) =>
    axios.post<AdminUser>(apiPath.adminUsers, params),
  updateUser: (
    userId: ID,
    params: Partial<
      Omit<AdminUser, 'id'> & { password?: string; organization_id?: number }
    >,
  ) => axios.patch<AdminUser>(apiPath.genAdminUser(userId), params),
  deleteUser: (userId: ID) =>
    axios.delete<AdminUser>(apiPath.genAdminUser(userId)),

  // /admin/organizations/:id/users
  getOrganizationUsers: (organizationId: ID, params: ListParams) =>
    axios.get<RecordSetProps & { users: AdminUser[] }>(
      apiPath.genAdminOrganizationsUsers(organizationId),
      {
        params,
      },
    ),
  createOrganizationUser: (
    organizationId: ID,
    params: Partial<AdminUser> & { password?: string },
  ) =>
    axios.post<AdminUser>(
      apiPath.genAdminOrganizationsUsers(organizationId),
      params,
    ),
  attachOrganizationUser: (organizationId: ID, userId: ID) =>
    axios.patch<AdminUser>(
      apiPath.genAdminOrganizationsUser(organizationId, userId),
      {},
    ),
  detachOrganizationUser: (organizationId: ID, userId: ID) =>
    axios.delete<AdminUser>(
      apiPath.genAdminOrganizationsUser(organizationId, userId),
    ),

  // /admin/organizations/:id/users
  getOrganizationLicenses: (organizationId: ID, params: ListParams) =>
    axios.get<RecordSetProps & { licenses: License[] }>(
      apiPath.genAdminOrganizationsLicenses(organizationId),
      {
        params,
      },
    ),
  createOrganizationLicense: (organizationId: ID, params: Partial<License>) =>
    axios.post<License>(
      apiPath.genAdminOrganizationsLicenses(organizationId),
      params,
    ),
  updateOrganizationLicense: (
    organizationId: ID,
    licenseId: ID,
    params: Partial<License>,
  ) =>
    axios.patch<License>(
      apiPath.genAdminOrganizationsLicense(organizationId, licenseId),
      params,
    ),
  deleteOrganizationLicense: (organizationId: ID, licenseId: ID) =>
    axios.delete<License>(
      apiPath.genAdminOrganizationsLicense(organizationId, licenseId),
    ),

  getOrganizationOrganizers: (organizationId: ID, params: ListParams) =>
    axios.get<RecordSetProps & { organizers: Organizer[] }>(
      apiPath.genAdminOrganizationsOrganizers(organizationId),
      {
        params,
      },
    ),
  createOrganizationOrganizer: (
    organizationId: ID,
    params: Partial<Organizer> & { password?: string },
  ) =>
    axios.post<Organizer>(
      apiPath.genAdminOrganizationsOrganizers(organizationId),
      params,
    ),
  updateOrganizationOrganizer: (
    organizationId: ID,
    organizerId: ID,
    params: Partial<Organizer>,
  ) =>
    axios.patch<Organizer>(
      apiPath.genAdminOrganizationsOrganizer(organizationId, organizerId),
      params,
    ),
  deleteOrganizationOrganizer: (organizationId: ID, organizerId: ID) =>
    axios.delete<Organizer>(
      apiPath.genAdminOrganizationsOrganizer(organizationId, organizerId),
    ),

  getUserLicenses: (userId: ID) =>
    axios.get<License[]>(apiPath.genAdminUserLicenses(userId)),
  addUserLicense: (userId: ID, licenseId: ID) =>
    axios.patch<License>(apiPath.genAdminUserLicense(userId, licenseId)),
  removeUserLicense: (userId: ID, licenseId: ID) =>
    axios.delete<License>(apiPath.genAdminUserLicense(userId, licenseId)),

  getOperators: (params: ListParams) =>
    axios.get<RecordSetProps & { operators: Operator[] }>(apiPath.adminOperators, {
      params,
    }),
  updateOperator: (operatorId: ID, params: Partial<Omit<Operator, 'id'>>) =>
    axios.patch<Operator>(apiPath.getOperator(operatorId), params),
  createOperator: (params: Partial<Omit<Operator, 'id'>>) =>
    axios.post<Operator>(apiPath.adminOperators, params),
  deleteOperator: (operatorId: ID) =>
    axios.delete<Operator>(apiPath.getOperator(operatorId)),    

  getManagers: (params: ListParams) =>
    axios.get<RecordSetProps & { managers: Manager[] }>(apiPath.adminManagers, {
      params,
    }),
  updateManager: (managerId: ID, params: Partial<Omit<Manager, 'id'>>) =>
    axios.patch<Manager>(apiPath.getManager(managerId), params),
  createManager: (params: Partial<Omit<Manager, 'id'>>) =>
    axios.post<Manager>(apiPath.adminManagers, params),
  deleteMangaer: (managerId: ID) =>
    axios.delete<Manager>(apiPath.getManager(managerId)),      
}

export const organizerRequests = {
  loginOrganizer: (email: string, password: string) =>
    axios.post<Organizer>(apiPath.organizerAuth, { email, password }),

  // users
  getUsers: (params: ListParams) =>
    axios.get<RecordSetProps & { users: AdminUser[] }>(apiPath.organizerUsers, {
      params,
    }),
  getUser: (userId: ID) =>
    axios.get<AdminUserDetail>(apiPath.genOrganizerUser(userId)),

  // exams
  getExams: (params: ListParams) =>
    axios.get<RecordSetProps & { examinations: OrganizationExamination[] }>(
      apiPath.organizerExaminations,
      { params },
    ),
  getExam: (examId: ID) =>
    axios.get<OrganizationExaminationDetail>(
      apiPath.genOrganizerExamination(examId),
    ),
  getExamUsers: (examId: ID, params: ListParams, sortByScore?: boolean) => {
    return axios.get<RecordSetProps & { users: OrganizationExaminationUser[] }>(
      apiPath.genOrganizerExaminationUsers(examId),
      { params: { ...params, direction: sortByScore ? 'desc' : undefined } },
    )
  },
  getExamStat: (examId: ID) => {
    return axios.get<OrganizationExaminationStat>(
      apiPath.genOrganizerExaminationStat(examId),
    )
  },
  getExamHistories: (examId: ID) => {
    return axios.get<{ examinations: OrganizationExaminationHistory[] }>(
      apiPath.genOrganizerExaminationHistories(examId),
    )
  },

  getLicenses: (params: ListParams) =>
    axios.get<RecordSetProps & { licenses: License[] }>(
      apiPath.organizerLicenses,
      { params },
    ),
  addUserLicense: (userId: ID, licenseId: ID) =>
    axios.patch<License>(apiPath.genOrganizerUserLicense(userId, licenseId)),
}

export const operatorRequests = {
  loginOperator: (email: string, password: string) =>
    axios.post<Operator>(apiPath.operatorAuth, { email, password }),
}

export const managerRequests = {
  loginManager: (email: string, password: string) =>
    axios.post<Manager>(apiPath.managerAuth, { email, password }),
}
