export const paths = {
  root: '/',
  signup: '/signup',
  forgetPassword: '/forget',
  login: '/login',
  logout: '/logout',
  setting: '/setting',
  examination: '/examinations/:id',
  genExamination: (id: string) => `/examinations/${id}`,
  genTest: (id: string) => `/tests/${id}`,
  // verification系
  verifyEmail: '/verify',
  resetPassword: '/reset',
}

type ID = number | string

export const ADMIN_ROOT = '/adm'
export const adminRegexp = new RegExp(`^${ADMIN_ROOT}`)
export const adminPaths = {
  root: ADMIN_ROOT,
  users: `${ADMIN_ROOT}/users`,
  user: `${ADMIN_ROOT}/users/:userId`,
  genUser: (userId: ID) => `${ADMIN_ROOT}/users/${userId}`,
  // 問一覧(問作成/詳細への遷移、問の削除)
  questions: `${ADMIN_ROOT}/questions`,
  // 問作成
  createQuestion: `${ADMIN_ROOT}/question/create`,
  // 問詳細(問の修正/削除、設問の追加/修正/削除)
  question: `${ADMIN_ROOT}/questions/:id`,
  genQuestion: (id: number | string) => `${ADMIN_ROOT}/questions/${id}`,
  // 試験一覧(試験作成/詳細への遷移、試験の削除)
  examinations: `${ADMIN_ROOT}/examinations`,
  // 試験の作成
  createExamination: `${ADMIN_ROOT}/examinations/create`,
  // 試験詳細(試験の編集/削除、問の付け外し)
  examination: `${ADMIN_ROOT}/examinations/:id`,
  genExamination: (id: number | string) => `${ADMIN_ROOT}/examinations/${id}`,
  // 問カテゴリの管理
  questionCategories: `${ADMIN_ROOT}/question_categories`,
  // 組織管理
  organizations: `${ADMIN_ROOT}/organizations`,
  // 組織カテゴリ
  organizationCategories: `${ADMIN_ROOT}/organization_categories`,
  // 組織内ユーザー
  organizationUsers: `${ADMIN_ROOT}/organizations/:organizationId/users`,
  // 組織内ユーザー詳細
  organizationUser: `${ADMIN_ROOT}/organizations/:organizationId/users/:userId`,
  // オペレーター管理
  operators: `${ADMIN_ROOT}/operators`,
  // サービス管理者管理  
  managers: `${ADMIN_ROOT}/managers`,
  genOrganizationUsers: (organizationId: string | number) =>
    `${ADMIN_ROOT}/organizations/${organizationId}/users`,
  genOrganizationUser: (
    organizationId: string | number,
    userId: string | number,
  ) => `${ADMIN_ROOT}/organizations/${organizationId}/users/${userId}`,
  // 組織ライセンス
  organizationLicenses: `${ADMIN_ROOT}/organizations/:organizationId/licenses`,
  genOrganizationLicenses: (organizationId: string | number) =>
    `${ADMIN_ROOT}/organizations/${organizationId}/licenses`,
  // 企業管理者
  organizationOrganizers: `${ADMIN_ROOT}/organizations/:organizationId/organizers`,
  genOrganizationOrganizers: (organizationId: string | number) =>
    `${ADMIN_ROOT}/organizations/${organizationId}/organizers`,
}

export const ORG_ROOT = '/org'
export const organizerRegexp = new RegExp(`^${ORG_ROOT}`)
export const organizerPaths = {
  root: ORG_ROOT,
  user: `${ORG_ROOT}/users/:userId`,
  users: `${ORG_ROOT}/users`,
  genUser: (userId: ID) => `${ORG_ROOT}/users/${userId}`,
  examinations: ORG_ROOT,
  examination: `${ORG_ROOT}/examinations/:id`,
  genExamination: (id: number | string) => `${ORG_ROOT}/examinations/${id}`,
}

export const OPE_ROOT = '/ope'
export const operatorRegexp = new RegExp(`^${OPE_ROOT}`)
export const operatorPaths = {
  root: OPE_ROOT,
  users: `${OPE_ROOT}/users`,
  user: `${OPE_ROOT}/users/:userId`,
  genUser: (userId: ID) => `${OPE_ROOT}/users/${userId}`,
  genQuestion: (id: number | string) => `${OPE_ROOT}/questions/${id}`,
  // 試験一覧(試験作成/詳細への遷移、試験の削除)
  examinations: `${OPE_ROOT}/examinations`,
  // 試験詳細(試験の編集/削除、問の付け外し)
  examination: `${OPE_ROOT}/examinations/:id`,
  genExamination: (id: number | string) => `${OPE_ROOT}/examinations/${id}`,
  // 問カテゴリの管理
  questionCategories: `${OPE_ROOT}/question_categories`,
  // 組織管理
  organizations: `${OPE_ROOT}/organizations`,
  // 組織カテゴリ
  organizationCategories: `${OPE_ROOT}/organization_categories`,
  // 組織内ユーザー
  organizationUsers: `${OPE_ROOT}/organizations/:organizationId/users`,
  // 組織内ユーザー詳細
  organizationUser: `${OPE_ROOT}/organizations/:organizationId/users/:userId`,
  genOrganizationUsers: (organizationId: string | number) =>
    `${OPE_ROOT}/organizations/${organizationId}/users`,
  genOrganizationUser: (
    organizationId: string | number,
    userId: string | number,
  ) => `${OPE_ROOT}/organizations/${organizationId}/users/${userId}`,
  // 組織ライセンス
  organizationLicenses: `${OPE_ROOT}/organizations/:organizationId/licenses`,
  genOrganizationLicenses: (organizationId: string | number) =>
    `${OPE_ROOT}/organizations/${organizationId}/licenses`,
  // 企業管理者
  organizationOrganizers: `${OPE_ROOT}/organizations/:organizationId/organizers`,
  genOrganizationOrganizers: (organizationId: string | number) =>
    `${OPE_ROOT}/organizations/${organizationId}/organizers`,
}

export const MGR_ROOT = '/mgr'
export const managerRegexp = new RegExp(`^${MGR_ROOT}`)
export const managerPaths = {
  root: MGR_ROOT,
  users: `${MGR_ROOT}/users`,
  user: `${MGR_ROOT}/users/:userId`,
  genUser: (userId: ID) => `${MGR_ROOT}/users/${userId}`,
  // 問一覧(問作成/詳細への遷移、問の削除)
  questions: `${MGR_ROOT}/questions`,
  // 問作成
  createQuestion: `${MGR_ROOT}/question/create`,
  // 問詳細(問の修正/削除、設問の追加/修正/削除)
  question: `${MGR_ROOT}/questions/:id`,
  genQuestion: (id: number | string) => `${MGR_ROOT}/questions/${id}`,
  // 試験一覧(試験作成/詳細への遷移、試験の削除)
  examinations: `${MGR_ROOT}/examinations`,
  // 試験の作成
  createExamination: `${MGR_ROOT}/examinations/create`,
  // 試験詳細(試験の編集/削除、問の付け外し)
  examination: `${MGR_ROOT}/examinations/:id`,
  genExamination: (id: number | string) => `${MGR_ROOT}/examinations/${id}`,
  // 問カテゴリの管理
  questionCategories: `${MGR_ROOT}/question_categories`,
  // 組織管理
  organizations: `${MGR_ROOT}/organizations`,
  // 組織カテゴリ
  organizationCategories: `${MGR_ROOT}/organization_categories`,
  // 組織内ユーザー
  organizationUsers: `${MGR_ROOT}/organizations/:organizationId/users`,
  // 組織内ユーザー詳細
  organizationUser: `${MGR_ROOT}/organizations/:organizationId/users/:userId`,
  genOrganizationUsers: (organizationId: string | number) =>
    `${MGR_ROOT}/organizations/${organizationId}/users`,
  genOrganizationUser: (
    organizationId: string | number,
    userId: string | number,
  ) => `${MGR_ROOT}/organizations/${organizationId}/users/${userId}`,
  // 組織ライセンス
  organizationLicenses: `${MGR_ROOT}/organizations/:organizationId/licenses`,
  genOrganizationLicenses: (organizationId: string | number) =>
    `${MGR_ROOT}/organizations/${organizationId}/licenses`,
  // 企業管理者
  organizationOrganizers: `${MGR_ROOT}/organizations/:organizationId/organizers`,
  genOrganizationOrganizers: (organizationId: string | number) =>
    `${MGR_ROOT}/organizations/${organizationId}/organizers`,
}