import * as faker from 'faker'
import React from 'react'
import { examSummaries } from '../../../utils/mock'
import { ExamList } from './ExamList'

faker.seed(1)
const lorem = faker.lorem.sentences(10)

export default {
  component: ExamList,
  title: 'page/ExamList',
}

const exams = examSummaries.map((e, i) => ({
  ...e,
  description: '(試験の説明) ' + lorem,
  available_at: new Date(2021, 3, 1 + i).toISOString(),
}))

export const Default = () => <ExamList exams={exams} />
export const NoTests = () => <ExamList exams={[]} />
