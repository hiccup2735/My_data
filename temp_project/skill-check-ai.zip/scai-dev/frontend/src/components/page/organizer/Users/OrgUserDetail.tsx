import { useSnackbar } from 'notistack'
import * as React from 'react'
import { RouteComponentProps, useHistory } from 'react-router-dom'
import { AdminUserDetail as User, License } from '../../../../types/domain'
import { organizerRequests } from '../../../../utils/api'
import { organizerPaths } from '../../../../utils/paths'
import { UserDetail } from '../../../module/admin/UserDetail'

type Props = RouteComponentProps<{ userId: string; organizationId?: string }>

export const OrgUserDetail = ({ match }: Props) => {
  const { userId, organizationId } = match.params
  const [user, setUser] = React.useState<User | undefined>(undefined)
  const [licenses, setLicenses] = React.useState<License[]>([])
  const history = useHistory()

  React.useEffect(() => {
    organizerRequests.getUser(userId).then((res) => {
      setUser(res.data)
    })
    /*
    if (organizationId) {
      adminRequests.getOrganization(organizationId).then((res) => {
        setOrganization(res.data)
      })
    }
    */
  }, [setUser])

  React.useEffect(() => {
    organizerRequests.getLicenses({ page: 0, page_size: 10000 }).then((res) => {
      setLicenses(res.data.licenses)
    })
  }, [setLicenses])

  const { enqueueSnackbar } = useSnackbar()

  if (!user) {
    return null
  }

  return (
    <UserDetail
      organizations={[]}
      adminType="organizer"
      onAddLicense={(licenseId) => {
        organizerRequests
          .addUserLicense(user.id, licenseId)
          .then(() => {
            // reload user
            organizerRequests.getUser(userId).then((res) => {
              setUser(res.data)
            })
            // reload licenses
            organizerRequests
              .getLicenses({
                page: 0,
                page_size: 10000,
              })
              .then((res) => {
                setLicenses(res.data.licenses)
              })
            enqueueSnackbar('ライセンスの付与を行いました', {
              variant: 'success',
            })
          })
          .catch(() => {
            enqueueSnackbar('ライセンスの付与に失敗しました', {
              variant: 'error',
            })
          })
      }}
      user={user}
      organizationId={organizationId}
      licenses={licenses}
      goToList={() => {
        history.push(organizerPaths.users)
      }}
    />
  )
}
