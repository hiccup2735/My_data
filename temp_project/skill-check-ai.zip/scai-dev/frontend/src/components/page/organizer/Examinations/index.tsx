import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { organizerRequests } from '../../../../utils/api'
import { organizerPaths } from '../../../../utils/paths'
import { OrganizationExaminationList } from '../../../module/organizer/ExamList'

export const OrganizerExaminations = () => {
  const history = useHistory()

  return (
    <OrganizationExaminationList
      data={(query) => {
        return new Promise((resolve) => {
          organizerRequests
            .getExams({
              page: query.page,
              page_size: query.pageSize,
            })
            .then((res) => {
              if (res.data) {
                resolve({
                  data: res.data.examinations,
                  page: res.data.page,
                  totalCount: res.data.total,
                })
              }
            })
        })
      }}
      onClick={(examId) => {
        history.push(organizerPaths.genExamination(examId))
      }}
    />
  )
}
