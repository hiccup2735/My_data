// import { useSnackbar } from 'notistack'
import { Box, Button } from '@material-ui/core'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { AdminUser, SessionKey } from '../../../../types/domain'
import { organizerRequests } from '../../../../utils/api'
import { downloadTextFile } from '../../../../utils/download'
import { UserList } from '../../../module/admin/UserList'

// const RESOURCE_NAME = 'ユーザー'

const usersToCSV = (users: AdminUser[]) => {
  const lines = ['ID,name,email']
  lines.push(...users.map((u) => [u.id, u.name, u.email].join(',')))
  return lines.join('\n')
}

export const OrgUsers = () => {
  const { enqueueSnackbar } = useSnackbar()
  const [totalUsers, setTotalUsers] = React.useState<number>(0)
  const [initialed, setInitialed] = React.useState<boolean>(false)
  const pageSize = Number(sessionStorage.getItem(SessionKey.UserPageSize)) || 20
  const keyword = sessionStorage.getItem(SessionKey.UserKeyword) || ''

  return (
    <>
      <UserList
        adminType="organizer"
        keyword={keyword}
        pageSize={pageSize}
        data={(query) => {
          const page = !initialed ? Number(sessionStorage.getItem(SessionKey.UserPage)) || 0 : query.page
          return new Promise((resolve) => {
            organizerRequests
              .getUsers({
                q: query.search,
                page: page,
                page_size: query.pageSize,
              })
              .then((res) => {
                setTotalUsers(res.data.total)
                resolve({
                  page: res.data.page,
                  totalCount: res.data.total,
                  data: res.data.users,
                })
                sessionStorage.setItem(SessionKey.UserKeyword, query.search)
                sessionStorage.setItem(SessionKey.UserPage, res.data.page.toString())
                sessionStorage.setItem(SessionKey.UserPageSize, query.pageSize.toString())
                setInitialed(true)
              })
          })
        }}
      />
      <Box style={{ padding: '16px 0px', textAlign: 'right' }}>
        <Button
          disabled={totalUsers === 0}
          variant="contained"
          onClick={() => {
            organizerRequests
              .getUsers({ page_size: totalUsers })
              .then((res) => {
                downloadTextFile(
                  usersToCSV(res.data.users),
                  `users_${new Date().getTime()}.csv`,
                )
              })
              .catch(() => {
                enqueueSnackbar('ダウンロードに失敗しました', {
                  variant: 'error',
                })
              })
          }}
        >
          ユーザー一覧のCSVをダウンロード
        </Button>
      </Box>
    </>
  )
}
