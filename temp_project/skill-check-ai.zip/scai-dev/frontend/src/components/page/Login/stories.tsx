import React from 'react'
import { Login } from '.'
import { action } from '@storybook/addon-actions'
import { BrowserRouter } from 'react-router-dom'

export default {
  component: Login,
  title: 'page/Login',
}

export const Default = () => (
  <BrowserRouter>
    <Login onLogin={action('login')} />
  </BrowserRouter>
)
