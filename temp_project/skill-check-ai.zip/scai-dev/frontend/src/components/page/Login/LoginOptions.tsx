import * as React from 'react'
import { Box, Typography } from '@material-ui/core'
import { useHistory } from 'react-router-dom'
import { paths } from '../../../utils/paths'
import { colors } from '../../../utils/theme'
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos'

type Props = {
  signup?: boolean
  login?: boolean
  resetPassword?: boolean
}

export const LoginOptions = ({
  signup = true,
  login = true,
  resetPassword = true,
}: Props) => {
  const history = useHistory()
  return (
    <>
      {/* {signup && (
        <Box
          style={{ paddingBottom: 8, cursor: 'pointer' }}
          onClick={() => {
            history.push(paths.signup)
          }}
        >
          <Typography style={{ fontSize: 14, color: colors.hint }}>
            <ArrowForwardIosIcon
              style={{
                display: 'inline-block',
                paddingRight: 4,
                color: colors.primary,
                fontSize: 14,
                transform: 'translateY(1px)',
              }}
            />
            新規登録の方はこちら
          </Typography>
        </Box>
      )} */}
      {login && (
        <Box
          style={{ paddingBottom: 8, cursor: 'pointer' }}
          onClick={() => {
            history.push(paths.login)
          }}
        >
          <Typography style={{ fontSize: 14, color: colors.hint }}>
            <ArrowForwardIosIcon
              style={{
                display: 'inline-block',
                paddingRight: 4,
                color: colors.primary,
                fontSize: 14,
                transform: 'translateY(1px)',
              }}
            />
            アカウントをお持ちの方はこちら
          </Typography>
        </Box>
      )}
      {resetPassword && (
        <Box
          style={{ paddingBottom: 8, cursor: 'pointer' }}
          onClick={() => {
            history.push(paths.forgetPassword)
          }}
        >
          <Typography style={{ fontSize: 14, color: colors.hint }}>
            <ArrowForwardIosIcon
              style={{
                display: 'inline-block',
                paddingRight: 4,
                color: colors.primary,
                fontSize: 14,
                transform: 'translateY(1px)',
              }}
            />
            パスワードをお忘れの方はこちら
          </Typography>
        </Box>
      )}
    </>
  )
}
