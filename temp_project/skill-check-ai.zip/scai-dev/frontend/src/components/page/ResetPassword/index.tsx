import {
  Box,
  Button,
  Container,
  Grid,
  Paper,
  TextField,
} from '@material-ui/core'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { Controller, useForm } from 'react-hook-form'
import { useHistory, useLocation } from 'react-router-dom'
import * as yup from 'yup'
import { UserContext } from '../../../contexts/UserContext'
import { validation } from '../../../types/validation'
import { requests } from '../../../utils/api'
import { inputProps } from '../../../utils/input'
import { paths } from '../../../utils/paths'
import { Copyright } from '../../ui/Copyright'
import { PageTitle } from '../../ui/PageTitle'

type FormValues = {
  password: string
  passwordConfirmation: string
}

const validationSchema = yup.object().shape({
  password: validation.password,
  passwordConfirmation: validation.passwordConfirmation,
})

type Props = {
  onResetPassword: (values: FormValues) => void
}

export const ResetPassword = ({ onResetPassword }: Props) => {
  const { handleSubmit, errors, control } = useForm<FormValues>({
    defaultValues: {
      password: '',
      passwordConfirmation: '',
    },
    validationSchema,
    mode: 'onChange',
  })
  return (
    <Container>
      <Grid container justify="center" style={{ paddingTop: 128 }}>
        <Grid item xs={6}>
          <Box style={{ paddingBottom: 128 }}>
            <Paper elevation={8} style={{ borderRadius: 10 }}>
              <form
                onSubmit={handleSubmit((values: FormValues) => {
                  onResetPassword(values)
                })}
              >
                <Box
                  style={{
                    paddingTop: 30,
                    paddingBottom: '48px',
                    paddingLeft: 64,
                    paddingRight: 64,
                  }}
                >
                  <PageTitle title="パスワードのリセット" />
                  <Box style={{}}>
                    <Controller
                      variant="outlined"
                      name="password"
                      control={control}
                      as={
                        <TextField
                          variant="outlined"
                          error={Boolean(errors.password)}
                          label="パスワード"
                          type="password"
                          helperText={errors.password?.message || ' '}
                          {...inputProps}
                        />
                      }
                    />
                  </Box>
                  <Box style={{}}>
                    <Controller
                      name="passwordConfirmation"
                      control={control}
                      as={
                        <TextField
                          variant="outlined"
                          error={Boolean(errors.passwordConfirmation)}
                          label="パスワードの確認"
                          type="password"
                          helperText={
                            errors.passwordConfirmation?.message || ' '
                          }
                          {...inputProps}
                        />
                      }
                    />
                  </Box>
                  <Box paddingBottom="48px">
                    <Button
                      style={{
                        width: '100%',
                        height: 56,
                        fontSize: 16,
                        fontWeight: 600,
                      }}
                      type="submit"
                      variant="contained"
                      color="primary"
                    >
                      パスワードを設定する
                    </Button>
                  </Box>
                </Box>
              </form>
            </Paper>
          </Box>
          <Copyright />
        </Grid>
      </Grid>
    </Container>
  )
}

export const ResetPasswordContainer = () => {
  const { enqueueSnackbar } = useSnackbar()
  const location = useLocation()
  const history = useHistory()
  const params = new URLSearchParams(location.search)
  const token = params.get('reset_token')
  const { setAuthenticated } = React.useContext(UserContext)

  if (!token) {
    return null
  }
  return (
    <ResetPassword
      onResetPassword={(values: FormValues) => {
        requests
          .changePassword(token, values.password, values.passwordConfirmation)
          .then(() => {
            enqueueSnackbar('パスワードを変更しました', {
              variant: 'success',
            })
            setAuthenticated(false)
            history.push(paths.login)
          })
          .catch((e) => {
            enqueueSnackbar('パスワードの変更に失敗しました', {
              variant: 'error',
            })
          })
      }}
    />
  )
}
