import React from 'react'
import { VerifyEmail } from '.'
import { BrowserRouter } from 'react-router-dom'

export default {
  component: VerifyEmail,
  title: 'page/VerifyEmail',
}

export const Succeeded = () => (
  <BrowserRouter>
    <VerifyEmail status="succeeded" />
  </BrowserRouter>
)

export const Verifying = () => (
  <BrowserRouter>
    <VerifyEmail status="verifying" />
  </BrowserRouter>
)

export const Failed = () => (
  <BrowserRouter>
    <VerifyEmail status="failed" />
  </BrowserRouter>
)
