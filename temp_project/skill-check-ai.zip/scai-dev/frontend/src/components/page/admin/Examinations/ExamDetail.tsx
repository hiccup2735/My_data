import useAxios from 'axios-hooks'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { RouteComponentProps, useHistory } from 'react-router-dom'
import {
  AdminExamination,
  AdminQuestionTag,
  Organization,
  QuestionCategory,
} from '../../../../types/domain'
import { adminRequests, apiPath } from '../../../../utils/api'
import { downloadTextFile } from '../../../../utils/download'
import { OPE_ROOT, adminPaths, managerPaths, operatorPaths } from '../../../../utils/paths'
import { ExamDetail } from '../../../module/admin/ExamDetail'
import { ExamForm } from '../../../module/admin/ExamDetail/ExamForm'
import { QuestionOption } from '../../../module/admin/QuestionSelector'
import { Loading } from '../../../ui/Loading'
import { usersToCSV } from './usersToCSV'
import { ManagerContext } from '../../../../contexts/ManagerContext'

type Mode = 'show' | 'edit'

type Props = RouteComponentProps<{ id: string }>

export const AdminExamDetail = ({
  match: {
    params: { id },
  },
}: Props) => {
  const [questionOptions, setQuestionOptions] = React.useState<
    QuestionOption[]
  >([])

  const [adminExam, setAdminExam] = React.useState<
    AdminExamination | undefined
  >(undefined)
  const [{ data, loading }, refetch] = useAxios<AdminExamination>(
    apiPath.genAdminExam(id),
    { useCache: false },
  )
  const [questionCategories, setQusetionCategories] = React.useState<
    QuestionCategory[]
  >([])
  const [
    selectedQuestionCategory,
    setSelectedQuestionCategory,
  ] = React.useState<QuestionCategory>()
  const [organizations, setOrganizations] = React.useState<Organization[]>([])

  const [questionTags, setQuestionTags] = React.useState<AdminQuestionTag[]>([])
  const [selectedTags, setSelectedTags] = React.useState<string[]>([])
  const { authenticated, group } = React.useContext(ManagerContext)
  const isManager = authenticated ? true : false
  const isOperator = window.location.pathname.includes(OPE_ROOT) ? true : false

  React.useEffect(() => {
    setAdminExam(data)
    adminRequests.getQuestionCategories({
      group: group,
    }).then((res) => {
      setQusetionCategories(res.data)
      if (res.data.length > 0) {
        setSelectedQuestionCategory(res.data[0])
      }
    })
    adminRequests.getQuestionTags({}).then((res) => {
      setQuestionTags(res.data)
    })
    adminRequests.getOrganizations({ page_size: 10000 }).then((res) => {
      setOrganizations(res.data.organizations)
    })
  }, [data])

  React.useEffect(() => {
    adminRequests
      .getQuestions({
        page_size: 50,
        page: 0,
        group: group,
        tags: selectedTags.length > 0 ? selectedTags : undefined,
      })
      .then((res) => {
        setQuestionOptions(
          res.data.questions.map((q) => ({ id: q.id, name: q.name })),
        )
      })
  }, [selectedTags])

  const [mode, setMode] = React.useState<Mode>('show')
  const [totalUsers, setTotalUsers] = React.useState<number>(0)
  const [updating, setUpdating] = React.useState<boolean>(false)
  const { enqueueSnackbar } = useSnackbar()
  const history = useHistory()

  React.useEffect(() => {
    window.scrollTo({ top: 0 })
  }, [mode])

  if (loading) {
    return <Loading />
  } else if (!adminExam) {
    return <div>not found</div>
  }

  if (mode === 'edit') {
    return (
      <ExamForm
        exam={adminExam}
        onSubmit={(values) => {
          console.log('onSubmit', values)

          setUpdating(true)
          adminRequests
            .updateExam(id, {
              name: values.name,
              description: values.description,
              limit_min: values.limitMin,
              code: values.code,
              group: values.group,
            })
            .then((res) => {
              enqueueSnackbar('更新しました', {
                variant: 'success',
              })
              setMode('show')
              setAdminExam(res.data)
            })
            .finally(() => {
              setUpdating(false)
            })
        }}
        onCancel={() => {
          setMode('show')
        }}
        updating={updating}
      />
    )
  }

  return (
    <ExamDetail
      isOperator={isOperator}
      tags={questionTags}
      onChangeTags={(tags) => setSelectedTags(tags)}
      organizations={organizations}
      onReorderQuestion={(questionId, to) => {
        console.log('reorder', questionId, to)
        adminRequests
          .reorderQuestion(adminExam.id, questionId, to + 1)
          .then((res) => {
            setAdminExam(res.data)
            enqueueSnackbar('問の並べ替えを行いました', {
              variant: 'success',
            })
          })
      }}
      attachOrganization={(organizationId, detach) => {
        if (detach) {
          adminRequests.detachExamOrg(adminExam.id, organizationId).then(() => {
            refetch()
            enqueueSnackbar('組織への紐付けを解除しました', {
              variant: 'success',
            })
          })
        } else {
          adminRequests
            .attachExamOrg(adminExam.id, organizationId)
            .then((res) => {
              setAdminExam(res.data)
              enqueueSnackbar('試験を組織に紐付けしました', {
                variant: 'success',
              })
            })
        }
      }}
      questionCategories={questionCategories}
      selectedQuestionCategory={selectedQuestionCategory}
      onQuestionCategoryChanged={(id) => {
        setSelectedQuestionCategory(questionCategories.find((c) => c.id === id))
      }}
      downloadUsers={() => {
        adminRequests
          .getExamUsers(id, { page_size: totalUsers })
          .then((res) => {
            downloadTextFile(
              usersToCSV(res.data.users),
              `examination_${
                adminExam.id
              }_users_${new Date().getTime().toString()}.txt`,
            )
          })
      }}
      users={(query) => {
        return new Promise((resolve) => {
          adminRequests
            .getExamUsers(id, { page_size: query.pageSize, page: query.page })
            .then((res) => {
              setTotalUsers(res.data.total)
              resolve({
                data: res.data.users,
                page: res.data.page,
                totalCount: res.data.total,
              })
            })
        })
      }}
      questionOptions={questionOptions}
      onAddQuestion={(questionId) => {
        if (!selectedQuestionCategory) {
          enqueueSnackbar('カテゴリを選択してください', { variant: 'warning' })
          return
        }

        adminRequests
          .attachQuestion(
            adminExam.id,
            questionId,
            adminExam.questions.length + 1,
            selectedQuestionCategory.id,
          )
          .then((res) => {
            console.log('attached', res)
            enqueueSnackbar(`問${questionId}を追加しました`, {
              variant: 'success',
            })
            adminRequests.getExam(adminExam.id).then((res2) => {
              setAdminExam(res2.data)
            })
            // setAdminExam(res.data)
          })
          .catch((e) => {
            console.log(e)
            enqueueSnackbar('問の追加に失敗しました', { variant: 'error' })
          })
      }}
      onRemoveQuestion={(questionId) => {
        adminRequests
          .detachQuestion(adminExam.id, questionId)
          .then((res) => {
            console.log('detached', res)
            enqueueSnackbar(`問${questionId}を外しました`, {
              variant: 'success',
            })
            adminRequests.getExam(adminExam.id).then((res2) => {
              setAdminExam(res2.data)
            })
            // setAdminExam(res.data)
          })
          .catch((e) => {
            console.log(e)
            enqueueSnackbar('問の取り外しに失敗しました', { variant: 'error' })
          })
      }}
      onSearchQuestion={(query) => {
        adminRequests.getQuestions({ 
          q: query,
          group: group,
        }).then((res) => {
          setQuestionOptions(
            res.data.questions.map((q) => ({ id: q.id, name: q.name })),
          )
        })
      }}
      goToList={() => { 
        const path = isManager ? managerPaths.examinations 
          : isOperator ? operatorPaths.examinations : adminPaths.examinations
        history.push(path)
      }}
      exam={adminExam}
      onEdit={() => {
        console.log('onEdit')
        setMode('edit')
      }}
    />
  )
}
