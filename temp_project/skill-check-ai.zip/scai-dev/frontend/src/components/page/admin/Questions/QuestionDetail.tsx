import { useSnackbar } from 'notistack'
import * as React from 'react'
import { RouteComponentProps, useHistory } from 'react-router-dom'
import { AdminQuestionDetail as AdminQuestion } from '../../../../types/domain'
import { adminRequests } from '../../../../utils/api'
import { adminPaths, managerPaths } from '../../../../utils/paths'
import { QuestionDetail } from '../../../module/admin/QuestionDetail'
import { QuestionForm } from '../../../module/admin/QuestionDetail/QuestionForm'
import { Loading } from '../../../ui/Loading'
import { AdminContext } from '../../../../contexts/AdminContext'
import { ManagerContext } from '../../../../contexts/ManagerContext'

type Mode = 'show' | 'edit'

type Props = RouteComponentProps<{ id: string }>

export const AdminQuestionDetail = ({
  match: {
    params: { id },
  },
}: Props) => {
  const [loading, setLoading] = React.useState<boolean>(false)
  const [question, setQuestion] = React.useState<AdminQuestion | undefined>(
    undefined,
  )

  const [mode, setMode] = React.useState<Mode>('show')
  const [updating, setUpdating] = React.useState<boolean>(false)
  const { enqueueSnackbar } = useSnackbar()
  const [editingQuizId, setEditingQuizId] = React.useState<number | undefined>(
    undefined,
  )

  const history = useHistory()
  const { authenticated } = React.useContext(AdminContext)
  const isAdmin = authenticated ? true : false
  const { group } = React.useContext(ManagerContext)

  React.useEffect(() => {
    window.scrollTo({ top: 0 })
  }, [mode])

  React.useEffect(() => {
    setLoading(true)
    adminRequests
      .getQuestion(id)
      .then((res) => {
        setQuestion(res.data)
      })
      .finally(() => {
        setLoading(false)
      })
  }, [setQuestion, id])

  if (loading) {
    return <Loading />
  } else if (!question) {
    return <div>not found</div>
  }

  const reloadQuestion = () => {
    adminRequests.getQuestion(id).then((res) => {
      setQuestion(res.data)
    })
  }

  if (mode === 'edit') {
    return (
      <QuestionForm
        question={question}
        onSubmit={(values) => {
          setUpdating(true)
          adminRequests
            .updateQuestion(id, {
              name: values.name,
              description: values.description,
              image_uri: values.image_url,
              level: values.level,
              group: isAdmin ? values.group : group,
            })
            .then(() => {
              adminRequests.getQuestion(id).then((res2) => {
                setQuestion(res2.data)
              })
              setMode('show')
              enqueueSnackbar('更新しました', {
                variant: 'success',
              })
            })
            .catch((e) => {
              enqueueSnackbar('更新に失敗しました', { variant: 'error' })
            })
            .finally(() => {
              setUpdating(false)
            })
        }}
        onCancel={() => setMode('show')}
        updating={updating}
        onFileDropped={(file: File) => {
          return new Promise((resolve) => {
            adminRequests
              .uploadQuestionImage(file)
              .then((res) => {
                enqueueSnackbar('画像をアップロードしました', {
                  variant: 'success',
                })
                resolve(res.data.image_url)
              })
              .catch(() => {
                enqueueSnackbar('アップロードに失敗しました', {
                  variant: 'error',
                })
              })
          })
        }}
      />
    )
  }

  return (
    <QuestionDetail
      onUploadCodeQuizFile={(codeQuizId, fileType, file) => {
        return new Promise((resolve) => {
          adminRequests
            .uploadCodeQuizFile(codeQuizId, fileType, file)
            .then((res) => {
              console.log(res)
              enqueueSnackbar('ファイルをアップロードしました')
              resolve(true)
              adminRequests
                .submitCodeQuiz(question.id, codeQuizId)
                .then((res) => {
                  enqueueSnackbar('コード問題をsubmitしました')
                })
                .catch((e) => {
                  enqueueSnackbar(
                    `コード問題のsubmitに失敗しました ${JSON.stringify(e)}`,
                  )
                })
            })
            .catch((e) => {
              console.log(e.response)
              enqueueSnackbar(
                <div>
                  <div>
                    ファイルのアップロードに失敗しました
                    {e.response?.status && <>({e.response.status})</>}
                  </div>
                  {e?.response && <div>{JSON.stringify(e.response?.data)}</div>}
                  <div>{JSON.stringify(e)}</div>
                </div>,
              )
              resolve(false)
            })
        })
      }}
      onUpdateCodeQuiz={(codeQuizId, params) => {
        return new Promise((resolve, reject) => {
          adminRequests
            .updateCodeQuiz(question.id, codeQuizId, params)
            .then(() => {
              reloadQuestion()
              resolve(true)
              enqueueSnackbar('更新しました')
              adminRequests
                .submitCodeQuiz(question.id, codeQuizId)
                .then((res) => {
                  enqueueSnackbar('コード問題をsubmitしました')
                })
                .catch((e) => {
                  enqueueSnackbar(
                    `コード問題のsubmitに失敗しました ${JSON.stringify(e)}`,
                  )
                })
            })
            .catch((e) => {
              enqueueSnackbar(
                <div>
                  <div>
                    更新に失敗しました
                    {e.response?.status && <>({e.response.status})</>}
                  </div>
                  {e?.response && <div>{JSON.stringify(e.response?.data)}</div>}
                  <div>{JSON.stringify(e)}</div>
                </div>,
              )
            })
        })
      }}
      onDeleteCodeQuizFile={(codeQuizId, fileId) => {
        return new Promise((resolve, reject) => {
          adminRequests
            .deleteCodeQuizFile(codeQuizId, fileId)
            .then(() => {
              reloadQuestion()
              resolve(true)
              enqueueSnackbar('ファイルを削除しました')
            })
            .catch((e) => {
              enqueueSnackbar('ファイルの削除に失敗しました')
            })
        })
      }}
      onCreateCodeQuiz={() => {
        return new Promise((resolve, reject) => {
          adminRequests
            .createCodeQuiz(id)
            .then(() => {
              reloadQuestion()
              resolve(true)
              enqueueSnackbar('設問を作成しました')
            })
            .catch((e) => {
              enqueueSnackbar('設問の作成に失敗しました')
            })
        })
      }}
      onAddTag={(tag) => {
        return new Promise((resolve, reject) => {
          adminRequests
            .updateQuestion(id, {
              name: question.name,
              description: question.description,
              image_uri: question.image_uri,
              tags: [...question.tags, tag],
            })
            .then(() => {
              adminRequests.getQuestion(id).then((res2) => {
                setQuestion(res2.data)
              })
              resolve(true)
            })
            .catch((e) => {
              reject(e)
            })
        })
      }}
      onDeleteTag={(tag) => {
        return new Promise((resolve, reject) => {
          adminRequests
            .updateQuestion(id, {
              name: question.name,
              description: question.description,
              image_uri: question.image_uri,
              tags: question.tags.filter((t) => t !== tag),
            })
            .then(() => {
              adminRequests.getQuestion(id).then((res2) => {
                setQuestion(res2.data)
              })
              resolve(true)
            })
            .catch((e) => {
              reject(e)
            })
        })
      }}
      onAddMetadata={(metadata) => {
        return new Promise((resolve, reject) => {
          adminRequests
            .updateQuestion(id, {
              name: question.name,
              description: question.description,
              image_uri: question.image_uri,
              metadata: [...question.metadata, metadata],
            })
            .then(() => {
              adminRequests.getQuestion(id).then((res2) => {
                setQuestion(res2.data)
              })
              resolve(true)
            })
            .catch((e) => {
              reject(e)
            })
        })
      }}
      onDeleteMetadata={(metadata) => {
        return new Promise((resolve, reject) => {
          adminRequests
            .updateQuestion(id, {
              name: question.name,
              description: question.description,
              image_uri: question.image_uri,
              metadata: question.metadata.filter((m) => m.key !== metadata.key),
            })
            .then(() => {
              adminRequests.getQuestion(id).then((res2) => {
                setQuestion(res2.data)
              })
              resolve(true)
            })
            .catch((e) => {
              reject(e)
            })
        })
      }}
      onCreateQuiz={() => {
        adminRequests
          .createQuiz(id, { description: '未設定' })
          .then(() => {
            enqueueSnackbar('設問を追加しました', {
              variant: 'success',
            })
          })
          .catch((e) => {
            console.log(e)
            enqueueSnackbar('設問の追加に失敗しました', { variant: 'error' })
          })
          .finally(() => {
            reloadQuestion()
          })
      }}
      onDeleteQuiz={(quizId) => {
        adminRequests
          .deleteQuiz(id, quizId)
          .then(() => {
            enqueueSnackbar('設問を削除しました', {
              variant: 'success',
            })
          })
          .catch((e) => {
            console.log(e)
            enqueueSnackbar('設問の削除に失敗しました', { variant: 'error' })
          })
          .finally(() => {
            reloadQuestion()
          })
      }}
      backToList={() => {
        history.push(isAdmin ? adminPaths.questions : managerPaths.questions)
      }}
      onEditQuiz={(quizId) => {
        console.log('onEditQuiz', quizId)
        setEditingQuizId(quizId)
      }}
      onEditedQuiz={(quiz) => {
        console.log('onEditedQuiz', quiz)
        adminRequests
          .updateQuiz(id, quiz.id, {
            description: quiz.description,
          })
          .then((res) => {
            console.log('quiz updated', res.data)
            enqueueSnackbar('設問を更新しました', {
              variant: 'success',
            })
            setEditingQuizId(undefined)
            reloadQuestion()
          })
          .catch((e) => {
            console.log(e)
            enqueueSnackbar('設問の更新に失敗しました', { variant: 'error' })
          })
      }}
      editingQuizId={editingQuizId}
      onCreateChoice={(choice) => {
        console.log('onCreateChoice', choice)

        adminRequests
          .createChoice(choice.quiz_id, {
            name: choice.name,
            point: choice.point,
          })
          .then(() => {
            enqueueSnackbar('選択肢を追加しました', {
              variant: 'success',
            })
          })
          .catch((e) => {
            console.log(e)
            enqueueSnackbar('選択肢の追加に失敗しました', { variant: 'error' })
          })
          .finally(() => {
            reloadQuestion()
          })
      }}
      onDeleteChoice={(quizId, choiceId) => {
        adminRequests
          .deleteChoice(quizId, choiceId)
          .then(() => {
            enqueueSnackbar('選択肢を削除しました', {
              variant: 'success',
            })
          })
          .catch((e) => {
            console.log(e)
            enqueueSnackbar('選択肢の削除に失敗しました', { variant: 'error' })
          })
          .finally(() => {
            reloadQuestion()
          })
      }}
      onEditChoice={(choice) => {
        adminRequests
          .updateChoice(choice.quiz_id, choice.id, {
            name: choice.name,
            point: choice.point,
          })
          .then(() => {
            enqueueSnackbar('選択肢を更新しました', {
              variant: 'success',
            })
          })
          .catch((e) => {
            console.log(e)
            enqueueSnackbar('選択肢の更新に失敗しました', { variant: 'error' })
          })
          .finally(() => {
            reloadQuestion()
          })
      }}
      question={question}
      onEdit={() => {
        console.log('onEdit')
        setMode('edit')
      }}
    />
  )
}
