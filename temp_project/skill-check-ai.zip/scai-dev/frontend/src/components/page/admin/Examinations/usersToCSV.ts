import { AdminExaminationUser } from '../../../../types/domain'

export const usersToCSV = (users: AdminExaminationUser[]) => {
  const lines = ['id,name,organization_name,status,score,categories']
  lines.push(
    ...users.map((u) => {
      const fields = [u.id, u.name, u.organization_name, u.status, u.score]
      fields.push(...u.scores.flatMap((ss) => [ss.category_name, ss.score]))
      return fields.join(',')
    }),
  )

  return lines.join('\n')
}
