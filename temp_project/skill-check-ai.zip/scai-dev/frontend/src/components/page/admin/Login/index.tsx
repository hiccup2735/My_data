import { useSnackbar } from 'notistack'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { AdminContext } from '../../../../contexts/AdminContext'
import { apiPath } from '../../../../utils/api'
import { Login, FormValues } from '../../Login'
import axios from 'axios'
import { adminPaths } from '../../../../utils/paths'
import { User } from '../../../../types/domain'

export const AdminLogin = () => {
  const { enqueueSnackbar } = useSnackbar()
  const { setAuthenticated } = React.useContext(AdminContext)
  const history = useHistory()

  return (
    <Login
      admin
      onLogin={(values: FormValues) => {
        axios
          .post<User>(apiPath.adminAuth, {
            email: values.email,
            password: values.password,
          })
          .then((res) => {
            console.log(res)
            setAuthenticated(true)
            enqueueSnackbar('ログインに成功しました', {
              variant: 'success',
            })
            history.push(adminPaths.root)
          })
          .catch((e) => {
            console.log(e)
            enqueueSnackbar('ログインに失敗しました', {
              variant: 'error',
            })
          })
      }}
    />
  )
}
