import { useSnackbar } from 'notistack'
import * as React from 'react'
import { adminRequests } from '../../../../utils/api'
import { OrganizationUserList } from '../../../module/admin/OrganizationUserList'
import { RouteComponentProps, useHistory } from 'react-router-dom'
import { adminPaths, operatorPaths, ADMIN_ROOT, MGR_ROOT, OPE_ROOT, managerPaths } from '../../../../utils/paths'
import { Organization } from '../../../../types/domain'
import { genRandomString } from '../../../../utils/random'
import { ImportUsers } from './ImportUsers'

const RESOURCE_NAME = 'ユーザー'

type Props = RouteComponentProps<{ organizationId: string }>

type Mode = 'list' | 'import'

export const AdminOrganizationUsers = ({ match }: Props) => {
  const [mode, setMode] = React.useState<Mode>('list')
  const { organizationId } = match.params
  const [org, setOrg] = React.useState<Organization | undefined>(undefined)
  React.useEffect(() => {
    adminRequests.getOrganization(organizationId).then((res) => {
      setOrg(res.data)
    })
  }, [setOrg])
  const history = useHistory()

  const { enqueueSnackbar } = useSnackbar()

  if (!org) {
    return null
  }

  if (mode === 'import') {
    return (
      <ImportUsers
        organizationId={organizationId}
        organization={org}
        goToList={() => {
          setMode('list')
        }}
      />
    )
  }

  const isAdmin = window.location.pathname.includes(ADMIN_ROOT) ? true : false
  const isManager = window.location.pathname.includes(MGR_ROOT) ? true : false
  const isOperator = window.location.pathname.includes(OPE_ROOT) ? true : false
  return (
    <OrganizationUserList
      organizationId={organizationId}
      goToList={() => {
        if (isAdmin) history.push(adminPaths.organizations)
        if (isManager) history.push(managerPaths.organizations)
        if (isOperator) history.push(operatorPaths.organizations)
      }}
      goToImport={() => {
        setMode('import')
      }}
      organization={org}
      data={(query) => {
        return new Promise((resolve) => {
          adminRequests
            .getOrganizationUsers(organizationId, {
              page: query.page,
              page_size: query.pageSize,
              q: query.search,
            })
            .then((res) => {
              resolve({
                page: res.data.page,
                totalCount: res.data.total,
                data: res.data.users,
              })
            })
        })
      }}
      onAdd={(newRecord) => {
        return new Promise((resolve) =>
          adminRequests
            .createOrganizationUser(organizationId, {
              name: newRecord.name,
              email: newRecord.email,
              password: newRecord.init_password || genRandomString(),
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を作成しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の作成に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
      onEdit={(record) => {
        return new Promise((resolve) => {
          const params: {
            name?: string
            email?: string
            password?: string
          } = {
            name: record.name,
            email: record.email,
          }
          if (record.init_password) {
            params.password = record.init_password
          }
          adminRequests
            .updateUser(record.id, params)
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を更新しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の更新に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        })
      }}
      onDelete={(resourceId) => {
        return new Promise((resolve) =>
          adminRequests
            .detachOrganizationUser(organizationId, resourceId)
            .then(() => {
              enqueueSnackbar(
                `${RESOURCE_NAME}の組織への紐付けを解除しました`,
                {
                  variant: 'success',
                }
              )
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の紐付け解除に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
    />
  )
}
