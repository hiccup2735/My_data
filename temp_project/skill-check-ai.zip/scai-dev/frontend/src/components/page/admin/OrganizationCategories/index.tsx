import { useSnackbar } from 'notistack'
import * as React from 'react'
import { adminRequests } from '../../../../utils/api'
import { OrganizationCategoryList } from '../../../module/admin/OrganizationCategoryList'

const RESOURCE_NAME = '組織カテゴリ'

export const AdminOrganizationCategories = () => {
  const { enqueueSnackbar } = useSnackbar()
  return (
    <OrganizationCategoryList
      data={(query) => {
        return new Promise((resolve) => {
          adminRequests
            .getOrganizationCategories({
              page: query.page,
              page_size: query.pageSize,
            })
            .then((res) => {
              resolve({
                page: query.page,
                totalCount: res.data.length,
                data: res.data,
              })
            })
        })
      }}
      onAdd={(newRecord) => {
        return new Promise((resolve) =>
          adminRequests
            .createOrganizationCategory({
              name: newRecord.name,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を作成しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の作成に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
      onEdit={(record) => {
        return new Promise((resolve) =>
          adminRequests
            .updateOrganizationCategory(record.id, {
              name: record.name,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を更新しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の更新に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
    />
  )
}
