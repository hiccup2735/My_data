import { useSnackbar } from 'notistack'
import * as React from 'react'
import { adminRequests } from '../../../../utils/api'
import { QuestionCategoryList } from '../../../module/admin/QuestionCategoryList'
import { ManagerContext } from '../../../../contexts/ManagerContext'
import { AdminContext } from '../../../../contexts/AdminContext'

const RESOURCE_NAME = '問カテゴリ'

export const AdminQuestionCategories = () => {
  const { enqueueSnackbar } = useSnackbar()
  const { group } = React.useContext(ManagerContext)
  const { authenticated } = React.useContext(AdminContext)
  const isAdmin = authenticated ? true : false
  return (
    <QuestionCategoryList
      data={(query) => {
        return new Promise((resolve) => {
          adminRequests
            .getQuestionCategories({
              page: query.page,
              page_size: query.pageSize,
              group: group,
            })
            .then((res) => {
              resolve({
                page: query.page,
                totalCount: res.data.length,
                data: res.data,
              })
            })
        })
      }}
      onAdd={(newRecord) => {
        return new Promise((resolve) =>
          adminRequests
            .createQuestionCategory({
              name: newRecord.name,
              group: isAdmin ? newRecord.group : group,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を作成しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の作成に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
      onEdit={(admin) => {
        return new Promise((resolve) =>
          adminRequests
            .updateQuestionCategory(admin.id, {
              name: admin.name,
              group: isAdmin ? admin.group : group,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を更新しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の更新に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
      onDelete={(resourceId) => {
        return new Promise((resolve) =>
          adminRequests
            .deleteQuestionCategory(resourceId)
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を削除しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の削除に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
    />
  )
}
