import { useSnackbar } from 'notistack'
import * as React from 'react'
import { RouteComponentProps, useHistory } from 'react-router-dom'
import {
  AdminUserDetail as User,
  License,
  Organization,
} from '../../../../types/domain'
import { adminRequests } from '../../../../utils/api'
import { adminPaths, operatorPaths, OPE_ROOT, ADMIN_ROOT, MGR_ROOT, managerPaths } from '../../../../utils/paths'
import { UserDetail } from '../../../module/admin/UserDetail'

type Props = RouteComponentProps<{ userId: string; organizationId?: string }>

export const AdminUserDetail = ({ match }: Props) => {
  const { userId, organizationId } = match.params
  const [user, setUser] = React.useState<User | undefined>(undefined)
  const [organization, setOrganization] = React.useState<
    Organization | undefined
  >(undefined)
  const [organizations, setOrganizations] = React.useState<Organization[]>([])
  const [reloadCount, setReloadCount] = React.useState<number>(0)

  const [licenses, setLicenses] = React.useState<License[]>([])
  const history = useHistory()

  console.log('licences', licenses, organization)

  React.useEffect(() => {
    adminRequests.getUser(userId).then((res) => {
      setUser(res.data)
    })
    if (organizationId) {
      adminRequests.getOrganization(organizationId).then((res) => {
        setOrganization(res.data)
      })
    }
  }, [setUser, setOrganization, reloadCount])

  React.useEffect(() => {
    if (organization) {
      adminRequests
        .getOrganizationLicenses(organization.id, { page: 0, page_size: 10000 })
        .then((res) => {
          setLicenses(res.data.licenses)
        })
    }
  }, [organization, setLicenses, user])

  React.useEffect(() => {
    const userOrg = organizations.find(
      (o) => o.name === user?.organization_name,
    )
    if (userOrg) {
      adminRequests
        .getOrganizationLicenses(userOrg.id, { page: 0, page_size: 10000 })
        .then((res) => {
          setLicenses(res.data.licenses)
        })
    }
  }, [organizations, setLicenses, user])

  React.useEffect(() => {
    adminRequests.getOrganizations({}).then((res) => {
      setOrganizations(res.data.organizations)
    })
  }, [setOrganizations])

  const { enqueueSnackbar } = useSnackbar()

  if (!user) {
    return null
  }
  const isAdmin = window.location.pathname.includes(ADMIN_ROOT) ? true : false
  const isManager = window.location.pathname.includes(MGR_ROOT) ? true : false
  const isOperator = window.location.pathname.includes(OPE_ROOT) ? true : false
  const adminType = isAdmin ? 'admin' : (isManager ? 'manager' : 'operator')
  return (
    <UserDetail
      adminType={adminType}
      organizationChangeable
      organizations={organizations}
      changeOrganization={(orgId) => {
        adminRequests
          .updateUser(userId, {
            name: user.name,
            email: user.email,
            organization_id: orgId,
          })
          .then(() => {
            enqueueSnackbar('所属組織を変更しました', {
              variant: 'success',
            })
            setReloadCount(reloadCount + 1)
          })
          .catch(() => {
            enqueueSnackbar('所属組織の変更に失敗しました', {
              variant: 'error',
            })
          })
      }}
      onAddLicense={(licenseId) => {
        adminRequests
          .addUserLicense(user.id, licenseId)
          .then(() => {
            // reload user
            adminRequests.getUser(userId).then((res) => {
              setUser(res.data)
            })
            // reload licenses
            if (organization) {
              adminRequests
                .getOrganizationLicenses(organization.id, {
                  page: 0,
                  page_size: 10000,
                })
                .then((res) => {
                  setLicenses(res.data.licenses)
                })
            }

            enqueueSnackbar('ライセンスの付与を行いました', {
              variant: 'success',
            })
          })
          .catch(() => {
            enqueueSnackbar('ライセンスの付与に失敗しました', {
              variant: 'error',
            })
          })
      }}
      user={user}
      organizationId={organizationId}
      licenses={licenses}
      goToList={(orgId) => {
        orgId
          ?
            isManager ?
              history.push(managerPaths.genOrganizationUsers(orgId)) :
            isOperator ?
              history.push(operatorPaths.genOrganizationUsers(orgId)) :
              history.push(adminPaths.genOrganizationUsers(orgId))
          :
            isManager ?
              history.push(managerPaths.users) :
            isOperator ?
              history.push(operatorPaths.users) :
              history.push(adminPaths.users)
      }}
    />
  )
}
