import { useSnackbar } from 'notistack'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { adminRequests } from '../../../../utils/api'
import { ADMIN_ROOT, OPE_ROOT, adminPaths, managerPaths, operatorPaths } from '../../../../utils/paths'
import { ExamList } from '../../../module/admin/ExamList'
import { SessionKey } from '../../../../types/domain'
import { ManagerContext } from '../../../../contexts/ManagerContext'

export const AdminExaminations = () => {
  const history = useHistory()

  const { enqueueSnackbar } = useSnackbar()
  const [reloadCount, setReloadCount] = React.useState<number>(0)
  const [initialed, setInitialed] = React.useState<boolean>(false)
  const isOperator = window.location.pathname.includes(OPE_ROOT) ? true : false
  const { group } = React.useContext(ManagerContext)
  const isAdmin = window.location.pathname.includes(ADMIN_ROOT) ? true : false

  return (
    <ExamList
      reloadCount={reloadCount}
      viewOnly={isOperator}
      onClickAddButton={() => {
        history.push(isAdmin ? adminPaths.createExamination : managerPaths.createExamination)
      }}
      onDelete={(examId: number) => {
        return new Promise<boolean>((resolve) => {
          adminRequests
            .deleteExam(examId)
            .then(() => {
              resolve(true)
              enqueueSnackbar('試験を削除しました', { variant: 'success' })
            })
            .catch(() => {
              resolve(false)
              enqueueSnackbar('試験の削除に失敗しました', { variant: 'error' })
            })
        })
      }}
      onDuplicate={(examId: number) => {
        return new Promise<boolean>((resolve) => {
          adminRequests
            .duplicateExam(examId)
            .then(() => {
              resolve(true)
              enqueueSnackbar('試験を複製しました', { variant: 'success' })
              setReloadCount(reloadCount + 1)
            })
            .catch(() => {
              resolve(false)
              enqueueSnackbar('試験の複製に失敗しました', {
                variant: 'error',
              })
            })
        })
      }}
      data={(query) => {
        return new Promise((resolve) => {
          const page = !initialed ? Number(sessionStorage.getItem(SessionKey.ExamPage)) || 0 : query.page
          adminRequests
            .getExams({
              page: page,
              q: query.search,
              page_size: query.pageSize,
              group: group
            })
            .then((res) => {
              if (res.data) {
                resolve({
                  data: res.data.examinations,
                  page: res.data.page,
                  totalCount: res.data.total,
                })
                sessionStorage.setItem(SessionKey.ExamKeyword, query.search)
                sessionStorage.setItem(SessionKey.ExamPage, res.data.page.toString())
                sessionStorage.setItem(SessionKey.ExamPageSize, query.pageSize.toString())
                setInitialed(true)
              }
            })
        })
      }}
      onClickExam={(examId) => {
        const path = 
          isOperator ? operatorPaths.genExamination(examId) 
            : isAdmin ? adminPaths.genExamination(examId)
                : managerPaths.genExamination(examId)
        history.push(path)
      }}
    />
  )
}
