import { useSnackbar } from 'notistack'
import * as React from 'react'
import { RouteComponentProps, useHistory } from 'react-router-dom'
import { Organization } from '../../../../types/domain'
import { adminRequests } from '../../../../utils/api'
import { adminPaths, operatorPaths, ADMIN_ROOT, MGR_ROOT, OPE_ROOT, managerPaths } from '../../../../utils/paths'
import { OrganizationOrganizerList } from '../../../module/admin/OrganizationOrganizerList'

const RESOURCE_NAME = '企業管理者'

type Props = RouteComponentProps<{ organizationId: string }>

export const AdminOrganizationOrganizers = ({ match }: Props) => {
  const { organizationId } = match.params
  const [org, setOrg] = React.useState<Organization | undefined>(undefined)
  React.useEffect(() => {
    adminRequests.getOrganization(organizationId).then((res) => {
      setOrg(res.data)
    })
  }, [setOrg])
  const history = useHistory()

  const { enqueueSnackbar } = useSnackbar()
  const isAdmin = window.location.pathname.includes(ADMIN_ROOT) ? true : false
  const isManager = window.location.pathname.includes(MGR_ROOT) ? true : false
  const isOperator = window.location.pathname.includes(OPE_ROOT) ? true : false

  return (
    <OrganizationOrganizerList
      goToList={() => {
        if (isAdmin) history.push(adminPaths.organizations)
        if (isManager) history.push(managerPaths.organizations)
        if (isOperator) history.push(operatorPaths.organizations)
      }}
      organization={org}
      data={(query) => {
        return new Promise((resolve) => {
          adminRequests
            .getOrganizationOrganizers(organizationId, {
              page: query.page,
              page_size: query.pageSize,
            })
            .then((res) => {
              resolve({
                page: res.data.page,
                totalCount: res.data.total,
                data: res.data.organizers,
              })
            })
        })
      }}
      onAdd={(newRecord) => {
        return new Promise((resolve) =>
          adminRequests
            .createOrganizationOrganizer(organizationId, {
              name: newRecord.name,
              email: newRecord.email,
              password: newRecord.password,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を作成しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の作成に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            }),
        )
      }}
      onEdit={(record) => {
        return new Promise((resolve) =>
          adminRequests
            .updateOrganizationOrganizer(organizationId, record.id, {
              name: record.name,
              email: record.email,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を更新しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の更新に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            }),
        )
      }}
      onDelete={(resourceId) => {
        return new Promise((resolve) =>
          adminRequests
            .deleteOrganizationOrganizer(organizationId, resourceId)
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を削除しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の削除に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            }),
        )
      }}
    />
  )
}
