import { Box, Breadcrumbs, Button, Link, TextField } from '@material-ui/core'
import MaterialTable from 'material-table'
import * as React from 'react'
import { Organization } from '../../../../types/domain'
import { adminRequests } from '../../../../utils/api'
import { AdminSection } from '../../../ui/admin/Section'

type Props = {
  organization?: Organization
  organizationId: string
  goToList?: () => void
}

type Status = 'ready' | 'created' | 'added' | 'failed'

type UserData = {
  name: string
  email: string
  password: string
  status: Status
}

const statusInfo: { [key in Status]: React.ReactNode } = {
  ready: 'インポートの準備ができました',
  created: 'ユーザーが作成されました',
  added: <div style={{ color: 'green' }}>組織にユーザーが追加されました</div>,
  failed: <div style={{ color: 'red' }}>failed</div>,
}

const makeUsers = (users: UserData[], i: number, status: Status) => {
  return [...users.slice(0, i), { ...users[i], status }, ...users.slice(i + 1)]
}

export const ImportUsers = ({
  organizationId,
  organization,
  goToList,
}: Props) => {
  const [users, setUsers] = React.useState<UserData[]>([])
  const [importing, setImporting] = React.useState<boolean>(false)

  React.useEffect(() => {
    if (importing) {
      const i = users.findIndex((u) => u.status === 'ready')
      if (i >= 0) {
        const user = users[i]
        adminRequests
          .createOrganizationUser(organizationId, {
            email: user.email,
            password: user.password,
            name: user.name,
          })
          .then(() => {
            window.setTimeout(() => {
              setUsers(makeUsers(users, i, 'added'))
            }, 200)
          })
          .catch(() => {
            setUsers(makeUsers(users, i, 'failed'))
          })
      } else {
        setImporting(false)
      }
    }
  }, [importing, users])

  return (
    <div>
      <Box style={{ paddingBottom: 24 }}>
        <Breadcrumbs>
          <Link
            style={{ cursor: 'pointer' }}
            onClick={() => goToList && goToList()}
          >
            ユーザー一覧に戻る
          </Link>
        </Breadcrumbs>
      </Box>
      <Box>
        <AdminSection>
          <h3>{organization?.name}にユーザーを一括インポート</h3>
        </AdminSection>
        <AdminSection>
          <TextField
            placeholder="[氏名],[メールアドレス],[パスワード], のCSVデータをコピー&amp;ペーストしてください"
            rows={10}
            fullWidth
            multiline
            variant="outlined"
            onChange={(e) => {
              const content = e.currentTarget.value
              const rows: UserData[] = []
              content.split('\n').forEach((row) => {
                const [name, email, password] = row.split(',')
                if (name && email && password) {
                  rows.push({
                    name,
                    email,
                    password,
                    status: 'ready',
                  })
                }
                setUsers(rows)
              })
            }}
          />
        </AdminSection>
        <AdminSection>
          <MaterialTable<UserData>
            options={{
              paging: false,
              search: false,
            }}
            title={
              <>
                <div style={{ display: 'inline-block', marginRight: 24 }}>
                  インポート対象
                </div>
                <div style={{ display: 'inline-block' }}>
                  <Button
                    variant="contained"
                    onClick={() => {
                      setImporting(true)
                    }}
                    color="primary"
                    disabled={
                      importing ||
                      users.filter((u) => u.status === 'ready').length === 0
                    }
                  >
                    インポートを開始する
                  </Button>
                </div>
              </>
            }
            data={users}
            columns={[
              { field: 'name', title: '氏名' },
              { field: 'email', title: 'メールアドレス' },
              { field: 'password', title: 'パスワード' },
              {
                field: 'status',
                title: 'ステータス',
                render: (row) => statusInfo[row.status],
              },
            ]}
          />
        </AdminSection>
      </Box>
    </div>
  )
}
