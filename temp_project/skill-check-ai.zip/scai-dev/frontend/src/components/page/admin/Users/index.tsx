import { useSnackbar } from 'notistack'
import * as React from 'react'
import { adminRequests } from '../../../../utils/api'
import { UserList } from '../../../module/admin/UserList'
import { SessionKey } from '../../../../types/domain'

const RESOURCE_NAME = 'ユーザー'

export const AdminUsers = () => {
  const { enqueueSnackbar } = useSnackbar()
  const [initialed, setInitialed] = React.useState<boolean>(false)
  const pageSize = Number(sessionStorage.getItem(SessionKey.UserPageSize)) || 20
  const keyword = sessionStorage.getItem(SessionKey.UserKeyword) || ''

  return (
    <UserList
      keyword={keyword}
      pageSize={pageSize}
      data={(query) => {
        const page = !initialed ? Number(sessionStorage.getItem(SessionKey.UserPage)) || 0 : query.page
        return new Promise((resolve) => {
          adminRequests
            .getUsers({
              q: query.search,
              page: page,
              page_size: query.pageSize,
            })
            .then((res) => {
              resolve({
                page: res.data.page,
                totalCount: res.data.total,
                data: res.data.users,
              })
              sessionStorage.setItem(SessionKey.UserKeyword, query.search)
              sessionStorage.setItem(SessionKey.UserPage, res.data.page.toString())
              sessionStorage.setItem(SessionKey.UserPageSize, query.pageSize.toString())
              setInitialed(true)
            })
        })
      }}
      onEdit={(record) => {
        return new Promise((resolve) => {
          const params: {
            name?: string
            email?: string
            password?: string
          } = {
            name: record.name,
            email: record.email,
          }
          if (record.init_password) {
            params.password = record.init_password
          }
          adminRequests
            .updateUser(record.id, params)
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を更新しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の更新に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        })
      }}
      onDelete={(resourceId) => {
        return new Promise((resolve) =>
          adminRequests
            .deleteUser(resourceId)
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を削除しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の削除に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
    />
  )
}
