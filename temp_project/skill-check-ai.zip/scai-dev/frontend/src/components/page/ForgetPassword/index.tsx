import {
  Box,
  Button,
  Container,
  Grid,
  Paper,
  TextField,
} from '@material-ui/core'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { Controller, useForm } from 'react-hook-form'
import { useHistory } from 'react-router-dom'
import * as yup from 'yup'
import { UserContext } from '../../../contexts/UserContext'
import { validation } from '../../../types/validation'
import { requests } from '../../../utils/api'
import { inputProps } from '../../../utils/input'
import { paths } from '../../../utils/paths'
import { Copyright } from '../../ui/Copyright'
import { PageTitle } from '../../ui/PageTitle'

type FormValues = {
  email: string
}

const validationSchema = yup.object().shape({
  email: validation.email,
})

type Props = {
  onRequest: (values: FormValues) => void
}

export const ForgetPassword = ({ onRequest }: Props) => {
  const { handleSubmit, errors, control } = useForm<FormValues>({
    defaultValues: {
      email: '',
    },
    validationSchema,
    mode: 'onChange',
  })
  return (
    <Container>
      <Grid container justify="center" style={{ paddingTop: 128 }}>
        <Grid item xs={6}>
          <Box style={{ paddingBottom: 128 }}>
            <Paper elevation={8} style={{ borderRadius: 10 }}>
              <form
                onSubmit={handleSubmit((values: FormValues) => {
                  onRequest(values)
                })}
              >
                <Box
                  style={{
                    paddingTop: 30,
                    paddingBottom: '48px',
                    paddingLeft: 64,
                    paddingRight: 64,
                  }}
                >
                  <PageTitle title="パスワードのリセット" />
                  <Box style={{}}>
                    <Controller
                      variant="outlined"
                      name="email"
                      control={control}
                      as={
                        <TextField
                          variant="outlined"
                          error={Boolean(errors.email)}
                          label="アカウント登録に使用したメールアドレス"
                          helperText={errors.email?.message || ' '}
                          {...inputProps}
                        />
                      }
                    />
                  </Box>
                  <Box>
                    <Button
                      style={{
                        width: '100%',
                        height: 56,
                        fontSize: 16,
                        fontWeight: 600,
                      }}
                      type="submit"
                      variant="contained"
                      color="primary"
                    >
                      パスワードリセットのメールを送信する
                    </Button>
                  </Box>
                </Box>
              </form>
            </Paper>
          </Box>
          <Copyright />
        </Grid>
      </Grid>
    </Container>
  )
}

export const ForgetPasswordContainer = () => {
  const { enqueueSnackbar } = useSnackbar()
  const history = useHistory()
  const { setAuthenticated } = React.useContext(UserContext)

  return (
    <ForgetPassword
      onRequest={(values: FormValues) => {
        requests
          .requestPasswordChange(values.email)
          .then(() => {
            enqueueSnackbar('パスワードリセットのメールを送信しました', {
              variant: 'success',
            })
            setAuthenticated(false)
            history.push(paths.login)
          })
          .catch((e) => {
            enqueueSnackbar('エラーが発生しました', {
              variant: 'error',
            })
          })
      }}
    />
  )
}
