import {
  Box,
  Button,
  Container,
  Grid,
  Paper,
  TextField,
} from '@material-ui/core'
import axios from 'axios'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { Controller, useForm } from 'react-hook-form'
import { useHistory } from 'react-router-dom'
import * as yup from 'yup'
import { UserContext } from '../../../contexts/UserContext'
import { User } from '../../../types/domain'
import { validation } from '../../../types/validation'
import { apiPath } from '../../../utils/api'
import { inputProps } from '../../../utils/input'
import { paths } from '../../../utils/paths'
import { Copyright } from '../../ui/Copyright'
import { PageTitle } from '../../ui/PageTitle'
import { LoginOptions } from '../Login/LoginOptions'

type FormValues = {
  name: string
  email: string
  password: string
  passwordConfirmation: string
}

const validationSchema = yup.object().shape({
  name: validation.name,
  email: validation.email,
  password: validation.password,
  passwordConfirmation: validation.passwordConfirmation,
})

type Props = {
  onSignup: (values: FormValues) => void
}

export const Signup = ({ onSignup }: Props) => {
  const { handleSubmit, errors, control } = useForm<FormValues>({
    defaultValues: {
      name: '',
      email: '',
      password: '',
      passwordConfirmation: '',
    },
    validationSchema,
    mode: 'onChange',
  })
  return (
    <Container>
      <Grid container justify="center" style={{ paddingTop: 128 }}>
        <Grid item xs={6}>
          <Box style={{ paddingBottom: 128 }}>
            <form
              onSubmit={handleSubmit((values: FormValues) => {
                onSignup(values)
              })}
            >
              <Paper elevation={8} style={{ borderRadius: 10 }}>
                <Box
                  style={{
                    paddingTop: 30,
                    paddingBottom: '48px',
                    paddingLeft: 64,
                    paddingRight: 64,
                  }}
                >
                  <PageTitle title="アカウントの作成" />
                  <Box>
                    <Controller
                      name="name"
                      control={control}
                      as={
                        <TextField
                          variant="outlined"
                          error={Boolean(errors.name)}
                          label="ユーザー名"
                          helperText={errors.name?.message || ' '}
                          {...inputProps}
                        />
                      }
                    />
                  </Box>
                  <Box>
                    <Controller
                      name="email"
                      control={control}
                      as={
                        <TextField
                          variant="outlined"
                          error={Boolean(errors.email)}
                          label="メールアドレス"
                          helperText={errors.email?.message || ' '}
                          {...inputProps}
                        />
                      }
                    />
                  </Box>
                  <Box>
                    <Controller
                      variant="outlined"
                      name="password"
                      control={control}
                      as={
                        <TextField
                          variant="outlined"
                          error={Boolean(errors.password)}
                          label="パスワード"
                          type="password"
                          helperText={errors.password?.message || ' '}
                          {...inputProps}
                        />
                      }
                    />
                  </Box>
                  <Box>
                    <Controller
                      name="passwordConfirmation"
                      control={control}
                      as={
                        <TextField
                          variant="outlined"
                          error={Boolean(errors.passwordConfirmation)}
                          label="パスワードの確認"
                          type="password"
                          helperText={
                            errors.passwordConfirmation?.message || ' '
                          }
                          {...inputProps}
                        />
                      }
                    />
                  </Box>
                  <Box paddingBottom="48px">
                    <Button
                      style={{
                        width: '100%',
                        height: 56,
                        fontSize: 16,
                        fontWeight: 600,
                      }}
                      type="submit"
                      variant="contained"
                      color="primary"
                    >
                      アカウントを作成する
                    </Button>
                  </Box>
                  <LoginOptions signup={false} />
                </Box>
              </Paper>
            </form>
          </Box>
          <Copyright />
        </Grid>
      </Grid>
    </Container>
  )
}

export const SignupContainer = () => {
  const { enqueueSnackbar } = useSnackbar()
  const { setAuthenticated } = React.useContext(UserContext)
  const history = useHistory()
  return (
    <Signup
      onSignup={(values: FormValues) => {
        axios
          .post<User>(apiPath.user, {
            name: values.name,
            email: values.email,
            password: values.password,
            password_confirmation: values.passwordConfirmation,
          })
          .then(() => {
            enqueueSnackbar('サインアップに成功しました', {
              variant: 'success',
            })
            setAuthenticated(true)
            history.push(paths.root)
          })
          .catch(() => {
            enqueueSnackbar('サインアップに失敗しました', {
              variant: 'error',
            })
          })
      }}
    />
  )
}
