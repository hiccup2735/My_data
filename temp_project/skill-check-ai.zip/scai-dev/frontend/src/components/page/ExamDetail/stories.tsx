import { action } from '@storybook/addon-actions'
import faker from 'faker'
import React from 'react'
import { ExamDetail } from '.'
import {
  codeQuizzes,
  exam,
  finishedExam,
  mathQuestion,
} from '../../../utils/mock'
import { AnswerExam } from './AnswerExam'
import { CategoryChart } from './CategoryChart'
import { ExamFinished } from './ExamFinished'
import { ExamInfo } from './ExamInfo'
import { QuestionItem } from './QuestionItem'

faker.seed(1)

export default {
  component: ExamDetail,
  title: 'page/ExamDetail',
}

export const Info = () => <ExamInfo exam={exam} onStart={action('onStart')} />
export const InfoBefore = () => (
  <ExamInfo exam={{ ...exam, status: 'before' }} onStart={action('onStart')} />
)
export const Infofinished = () => (
  <ExamInfo
    exam={{
      ...finishedExam,
      score: 75,
      scores: [
        { category_name: 'ML', score: 50 },
        { category_name: 'DL', score: 50 },
        { category_name: 'MATH', score: 100 },
        { category_name: '前処理', score: 100 },
        { category_name: 'SuperLongCategory', score: 100 },
        { category_name: 'AIの歴史と動向', score: 50 },
      ],
    }}
    onStart={action('onStart')}
  />
)

export const InfofinishedWithHistories = () => (
  <ExamInfo
    exam={{
      ...finishedExam,
      score: 75,
      scores: [
        { category_name: 'ML', score: 50 },
        { category_name: 'DL', score: 50 },
        { category_name: 'MATH', score: 100 },
        { category_name: '前処理', score: 100 },
        { category_name: 'SuperLongCategory', score: 100 },
        { category_name: 'AIの歴史と動向', score: 50 },
      ],
      started_at: '2021/03/30 10:00:00',
      previous_data: {
        ...finishedExam,
        started_at: '2021/03/18 10:00:00',
        score: 60,
        scores: [
          { category_name: 'ML', score: 20 },
          { category_name: 'DL', score: 40 },
          { category_name: 'MATH', score: 100 },
          { category_name: '前処理', score: 80 },
          { category_name: 'SuperLongCategory', score: 70 },
          { category_name: 'AIの歴史と動向', score: 50 },
        ],
      },
    }}
    onStart={action('onStart')}
  />
)

export const Answer = () => (
  <AnswerExam
    exam={exam}
    onComplete={action('onComplete')}
    onAnswer={action('onAnswer')}
    onAnswerCodeQuiz={() => new Promise((r) => r(true))}
  />
)
export const Question = () => (
  <QuestionItem
    questionNumber={1}
    question={exam.questions[0]}
    onChoice={action('onChoice')}
    onNext={action('onNext')}
    onPrev={action('onPrev')}
    onAnswerCodeQuiz={() => new Promise((r) => r(true))}
  />
)

export const QuestioIncludesMath = () => (
  <QuestionItem
    questionNumber={1}
    question={mathQuestion}
    onChoice={action('onChoice')}
    onNext={action('onNext')}
    onPrev={action('onPrev')}
    onAnswerCodeQuiz={() => new Promise((r) => r(true))}
  />
)

const question = exam.questions[0]

export const QuestionWithCodeQuizzes = () => (
  <QuestionItem
    questionNumber={1}
    question={{
      ...question,
      quizzes: [],
      code_quizzes: codeQuizzes,
    }}
    onChoice={action('onChoice')}
    onNext={action('onNext')}
    onPrev={action('onPrev')}
    onAnswerCodeQuiz={() => new Promise((r) => r(true))}
  />
)

export const QuestionWithLengthyChoices = () => (
  <QuestionItem
    questionNumber={1}
    question={{
      ...question,
      quizzes: [
        {
          ...question.quizzes[0],
          choices: [
            { ...question.quizzes[0].choices[0], name: faker.lorem.words(20) },
            question.quizzes[0].choices[1],
            question.quizzes[0].choices[2],
            { ...question.quizzes[0].choices[3], name: faker.lorem.words(40) },
          ],
        },
      ],
    }}
    onChoice={action('onChoice')}
    onNext={action('onNext')}
    onAnswerCodeQuiz={() => new Promise((r) => r(true))}
    onPrev={action('onPrev')}
  />
)

export const QuestionWithoutImage = () => (
  <QuestionItem
    questionNumber={1}
    question={exam.questions[1]}
    onChoice={action('onChoice')}
    onNext={action('onNext')}
    onPrev={action('onPrev')}
    onAnswerCodeQuiz={() => new Promise((r) => r(true))}
  />
)

export const QuestionWithMaxChoices = () => (
  <QuestionItem
    questionNumber={1}
    question={{
      ...exam.questions[0],
      name:
        'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa ',
    }}
    onChoice={action('onChoice')}
    onNext={action('onNext')}
    onAnswerCodeQuiz={() => new Promise((r) => r(true))}
    onPrev={action('onPrev')}
  />
)

export const Finished = () => <ExamFinished exam={finishedExam} />

export const Chart = () => (
  <CategoryChart
    scores={[
      { category_name: 'ML', score: 50 },
      { category_name: 'DL', score: 50 },
      { category_name: 'MATH', score: 100 },
      { category_name: '前処理', score: 100 },
      { category_name: 'Python', score: 100 },
      { category_name: '統計', score: 50 },
    ]}
  />
)

export const ChartWithAFewScores = () => (
  <>
    <CategoryChart scores={[{ category_name: 'ML', score: 50 }]} />
    <CategoryChart
      scores={[
        { category_name: 'ML', score: 50 },
        { category_name: 'DL', score: 50 },
      ]}
    />
    <CategoryChart
      scores={[
        { category_name: 'ML', score: 50 },
        { category_name: 'DL', score: 50 },
        { category_name: 'MATH', score: 100 },
      ]}
    />
    <CategoryChart
      scores={[
        { category_name: 'ML', score: 50 },
        { category_name: 'DL', score: 50 },
        { category_name: 'MATH', score: 100 },
        { category_name: '前処理', score: 100 },
      ]}
    />
    <CategoryChart
      scores={[
        { category_name: 'ML', score: 50 },
        { category_name: 'DL', score: 50 },
        { category_name: 'MATH', score: 100 },
        { category_name: '前処理', score: 100 },
        { category_name: 'SupserLongCategoryNameDeluxe', score: 100 },
      ]}
    />
  </>
)
