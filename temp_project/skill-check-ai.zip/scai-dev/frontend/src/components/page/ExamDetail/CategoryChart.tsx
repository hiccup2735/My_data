import * as React from 'react'
import {
  Legend,
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
} from 'recharts'
import { Score } from '../../../types/domain'
import { colors } from '../../../utils/theme'

type TickProps = {
  index: number
  payload: {
    coordinate: number
    index: number
    offset: number
    value: string
  }
  radius: number
  stroke: string
  textAnchor: string
  x: number
  y: number
}

const Tick = ({
  x,
  y,
  radius,
  //  textAnchor,
  payload: { value, coordinate },
}: TickProps) => {
  const rad = coordinate * (Math.PI / 180)
  const sin = Math.sin(rad)
  const cos = Math.cos(rad)

  if (/^dummy_\d/.test(value)) {
    return null
  }

  return (
    <g className="recharts-layer recharts-polar-angle-axis-tick">
      <text
        radius={radius}
        stroke="none"
        x={x}
        y={y - sin * 15 + 5}
        fill={colors.hint}
        style={{ fontSize: 14 }}
        className="recharts-text recharts-polar-angle-axis-tick-value"
        textAnchor="middle"
      >
        <tspan x={x + cos * 40} dy="0em">
          {value}
        </tspan>
      </text>
    </g>
  )
}
type Props = {
  scores: Array<Score>
  pastScores?: Array<Score>
}

const modifyScores = (scores: Array<Score>): Array<Score> => {
  if (scores.length > 3) {
    return scores
  }
  const newScores = [...scores]
  Array(3 - scores.length)
    .fill(null)
    .forEach((v, i) => {
      newScores.push({ category_name: `dummy_${i}`, score: 0 })
    })

  return newScores
}

export const CategoryChart = ({ scores, pastScores }: Props) => {
  const pastData = pastScores ? modifyScores(pastScores) : []
  const data = modifyScores(scores).map((s) => {
    const past =
      pastData.find((p) => p.category_name === s.category_name)?.score || 0
    return {
      score: s.score,
      past,
      subject: s.category_name,
      fullMark: 100,
    }
  })

  return (
    <RadarChart
      cx={200}
      cy={150}
      outerRadius={80}
      width={400}
      height={300}
      data={data}
    >
      <PolarGrid />
      <PolarAngleAxis
        dataKey="subject"
        tick={(props) => {
          return <Tick {...props} />
        }}
      ></PolarAngleAxis>
      <PolarRadiusAxis angle={90}></PolarRadiusAxis>
      {pastScores && (
        <Radar
          name="前回"
          dataKey="past"
          stroke={colors.disabled}
          fill={colors.disabled}
          fillOpacity={0.1}
        />
      )}
      <Radar
        name="今回"
        dataKey="score"
        stroke={colors.primary}
        fill={colors.primary}
        fillOpacity={0.1}
      />
      {pastScores && <Legend />}
    </RadarChart>
  )
}
