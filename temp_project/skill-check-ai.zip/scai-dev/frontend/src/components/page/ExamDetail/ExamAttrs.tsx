import { Box, Typography } from '@material-ui/core'
import * as React from 'react'
import { ExaminationSummary } from '../../../types/domain'
import { colors } from '../../../utils/theme'
import { formatDate } from '../../../utils/time'

type Props = {
  exam: ExaminationSummary
  showCount?: boolean
}

export const ExamAttrs = ({ exam, showCount = true }: Props) => (
  <Typography
    style={{
      fontSize: 14,
      fontWeight: 500,
      color: colors.subText,
    }}
  >
    {/* eslint-disable-next-line no-irregular-whitespace */}
    {showCount && <>問題数：{exam.questions_count}問　</>}
    {/* eslint-disable-next-line no-irregular-whitespace */}
    <>テスト時間：{exam.limit_min}分　</>
    <>
      受験期間：{exam.available_at && formatDate(exam.available_at)}〜
      {exam.start_limit_at && formatDate(exam.start_limit_at)}
    </>
  </Typography>
)

export const ExamAttrsMin = ({ exam, showCount = true }: Props) => (
  <Box
    style={{
      paddingTop: 10,
      fontSize: 14,
      fontWeight: 500,
      color: colors.subText,
    }}
  >
    {/* eslint-disable-next-line no-irregular-whitespace */}
    {showCount && <Box>問題数：{exam.questions_count}問　</Box>}
    {/* eslint-disable-next-line no-irregular-whitespace */}
    <Box>テスト時間：{exam.limit_min}分　</Box>
    <Box>受験日時：{exam.started_at && formatDate(exam.started_at)}</Box>
  </Box>
)
