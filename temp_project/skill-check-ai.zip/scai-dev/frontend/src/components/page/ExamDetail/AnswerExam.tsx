import {
  AppBar,
  Box,
  Button,
  Container,
  Dialog,
  DialogTitle,
  DialogActions,
  DialogContent,
  DialogContentText,
  LinearProgress,
  Typography,
  CircularProgress,
} from '@material-ui/core'
import TimerIcon from '@material-ui/icons/Timer'
import * as React from 'react'
import { Examination } from '../../../types/domain'
import { colors } from '../../../utils/theme'
import {
  formatSeconds,
  //  getDiffSeconds,
  getRestSeconds,
} from '../../../utils/time'
import { PageContainer } from '../../ui/PageContainer'
import { QuestionItem } from './QuestionItem'

type Props = {
  exam: Examination
  onAnswer: (questionId: number, quizId: number, choiceId: number) => void
  onComplete: () => void
  onAnswerCodeQuiz: (
    questionId: number,
    codeQuizId: number,
    lang: string,
    code: string,
  ) => Promise<boolean>
  disableCompleteButton: boolean
}

const getRest = (exam: Examination): number => {
  let rest = 0
  if (exam.answer_limit_at) {
    rest = getRestSeconds(exam.answer_limit_at)
  }

  return rest < 0 ? 0 : rest
}

type RestTimeProps = {
  rest: number
}

export const RestTime = ({ rest }: RestTimeProps) => (
  <Box>
    <TimerIcon
      style={{
        transform: 'translateY(4px)',
        fontSize: 20,
        color: colors.primary,
      }}
    />
    テスト残り時間 <span style={{ fontSize: 18 }}>{formatSeconds(rest)}</span>
  </Box>
)

export const AnswerExam = ({
  exam,
  onAnswer,
  onComplete,
  onAnswerCodeQuiz,
  disableCompleteButton,
}: Props) => {
  const [currentQuestion, setCurrentQuestion] = React.useState<number>(0)
  const numQuestions = exam.questions.length
  const numAnswered = exam.questions.filter((q) => q.is_answered).length
  let effectCountdown = true

  const question = exam.questions[currentQuestion]
  const [rest, setRest] = React.useState<number>(getRest(exam))
  const [interval, setInterval] = React.useState<number>(0)
  const [dialogOpened, setDialogOpened] = React.useState<boolean>(false)
  const [timeupDialogOpened, setTimeoutDialogOpened] = React.useState<boolean>(false)
  const handleDialogClose = () => {
    setDialogOpened(false)
  }
  const handleDialogGo = () => {
    if (interval) {
      effectCountdown = false
      window.clearInterval(interval)
      setInterval(0)
    }
    onComplete()
    effectCountdown = true
  }

  // const [diff, setDiff] = React.useState<number>(0)

  React.useEffect(() => {
    window.scrollTo({ top: 0, left: 0 })
  }, [currentQuestion])

  React.useEffect(() => {
    if (exam && effectCountdown) {
      setRest(getRest(exam))
      if (interval) {
        window.clearInterval(interval)
      }
      setInterval(
        window.setInterval(() => {
          setRest(getRest(exam))
        }, 1000),
      )
    }
    return () => {
      if (interval) window.clearInterval(interval)
    }
  }, [exam])

  // const fixedRest = rest + diff


  React.useEffect(() => {
    if (rest <= 0) {
      if (interval) {
        window.clearInterval(interval)
      }
      setDialogOpened(false)
      setTimeoutDialogOpened(true)
      onComplete()
      //setTimeoutDialogOpened(false)
    }
  }, [rest])

  // 送信エラー等 リセット
  React.useEffect(() => {
    if (dialogOpened && !disableCompleteButton) {
      setDialogOpened(false)
      if (!interval) {
        setInterval(window.setInterval(() => {
          setRest(getRest(exam))
        }, 1000))
      }
    }
  }, [disableCompleteButton])

  return (
    <Container>
      <AppBar
        color="default"
        style={{ height: 64, paddingRight: 24, paddingLeft: 24 }}
      >
        <Box display="flex" alignItems="center" style={{ height: 64 }}>
          <Box width="100%" mr={1}>
            <LinearProgress
              variant="determinate"
              value={(numAnswered / numQuestions) * 100}
            />
          </Box>
          <Box minWidth={100} style={{ textAlign: 'center' }}>
            <Typography variant="body2" color="textSecondary">
              {numAnswered}/{numQuestions} 回答済
            </Typography>
          </Box>
          <Box minWidth={240} style={{ textAlign: 'center' }}>
            <Typography variant="body2" color="textSecondary">
              <RestTime rest={rest} />
            </Typography>
          </Box>
          <Box minWidth={160}>
            <Button
              fullWidth
              color="primary"
              variant="contained"
              onClick={() => {
                setDialogOpened(true)
              }}
              disabled={disableCompleteButton}
            >
              テストを終了する
            </Button>
          </Box>
        </Box>
        <Dialog open={dialogOpened} disableEscapeKeyDown={true}>
          <DialogTitle>{'回答の提出'}</DialogTitle>
          <DialogContent>
            {disableCompleteButton ? (
              <Box
                style={{ display: 'flex', flexDirection: 'row', gap: '1rem' }}
              >
                <CircularProgress color="inherit" size="1.2rem" />
                <DialogContentText id="alert-dialog-description">
                  回答送信中です。そのままお待ちください。
                </DialogContentText>
              </Box>
            ) : (
              <DialogContentText id="alert-dialog-description">
                回答を提出します。よろしいですか？
              </DialogContentText>
            )}
          </DialogContent>
          {!disableCompleteButton && (
            <DialogActions>
              <Button onClick={handleDialogClose}>いいえ</Button>
              <Button onClick={handleDialogGo} autoFocus>
                はい
              </Button>
            </DialogActions>
          )}
        </Dialog>
        <Dialog open={timeupDialogOpened} disableEscapeKeyDown={true}>
          <DialogTitle>{'回答の提出'}</DialogTitle>
          <DialogContent>
              <Box
                style={{ display: 'flex', flexDirection: 'row', gap: '1rem' }}
              >
                <CircularProgress color="inherit" size="1.2rem" />
                <DialogContentText id="alert-dialog-description">
                  試験終了時間になりました。<br />回答送信中です。そのままお待ちください。
                </DialogContentText>
              </Box>
          </DialogContent>
        </Dialog>
      </AppBar>
      {question && (
        <PageContainer>
          <Box style={{ paddingTop: 0 }}>
            <QuestionItem
              onAnswerCodeQuiz={onAnswerCodeQuiz}
              questionNumber={currentQuestion + 1}
              onChoice={(quizId, choiceId) => {
                onAnswer(question.id, quizId, choiceId)
              }}
              onPrev={
                currentQuestion > 0
                  ? () => {
                      setCurrentQuestion(currentQuestion - 1)
                    }
                  : undefined
              }
              onNext={
                currentQuestion < exam.questions.length - 1
                  ? () => {
                      setCurrentQuestion(currentQuestion + 1)
                    }
                  : undefined
              }
              question={question}
              key={`q_${question.id}`}
            />
          </Box>
        </PageContainer>
      )}
    </Container>
  )
}
