import useAxios from 'axios-hooks'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { RouteComponentProps, useHistory } from 'react-router-dom'
import { Examination } from '../../../types/domain'
import { apiPath, requests } from '../../../utils/api'
import { Loading } from '../../ui/Loading'
import { AnswerExam } from './AnswerExam'
import { ExamFinished } from './ExamFinished'
import { ExamInfo } from './ExamInfo'

type Props = RouteComponentProps<{ id: string }>

type Status = 'info' | 'answering' | 'sending' | 'finished'

export const ExamDetail = ({
  match: {
    params: { id },
  },
}: Props) => {
  const [status, setStatus] = React.useState<Status>('info')
  const [{ data: examData, loading }] = useAxios<Examination>(
    apiPath.genExam(id),
    { useCache: false },
  )
  const { enqueueSnackbar } = useSnackbar()

  const [exam, setExam] = React.useState<Examination | undefined>(undefined)

  const history = useHistory()

  const disableCompleteButton = status === 'sending'

  React.useEffect(() => {
    setExam(examData)
  }, [examData])

  if (loading) {
    return <Loading />
  } else if (!exam) {
    return null
  }

  if (status === 'answering' || status === 'sending') {
    return (
      <AnswerExam
        exam={exam}
        onAnswer={(questionId, quizId, choiceId) => {
          requests
            .answerExam(exam.id, questionId, quizId, choiceId)
            .then((res) => {
              setExam(res.data)
              // enqueueSnackbar('回答を送信しました', { variant: 'info' })
            })
            .catch(() => {
              enqueueSnackbar('回答の送信に失敗しました', {
                variant: 'error',
              })
            })
        }}
        onComplete={() => {
          // sending status
          if (status === 'sending') {
            return
          }
          setStatus('sending')
          requests
            .finishExam(exam.id)
            .then((res) => {
              setExam(res.data)
              setStatus('finished')
              enqueueSnackbar('試験を終了しました', {
                variant: 'success',
              })
            })
            .catch(() => {
              enqueueSnackbar('試験を終了できませんでした', {
                variant: 'error',
              })
              setStatus('answering')
            })
        }}
        onAnswerCodeQuiz={(
          questionId: number,
          codeQuizId: number,
          lang: string,
          code: string,
        ) => {
          return new Promise((resolve) => {
            requests
              .answerCodeQuiz(exam.id, questionId, codeQuizId, lang, code)
              .then((res) => {
                setExam(res.data)
                resolve(true)
              })
              .catch(() => {
                enqueueSnackbar('回答の送信に失敗しました', {
                  variant: 'error',
                })
                resolve(false)
              })
          })
        }}
        disableCompleteButton={disableCompleteButton}
      />
    )
  } else if (status === 'finished') {
    return <ExamFinished exam={exam} />
  }

  return (
    <ExamInfo
      exam={exam}
      onBack={() => {
        history.goBack()
      }}
      onStart={() => {
        requests
          .startExam(exam.id)
          .then((res) => {
            setExam(res.data)
            setStatus('answering')
          })
          .catch(() => {
            enqueueSnackbar('試験を開始できませんでした', { variant: 'error' })
          })
      }}
    />
  )
}
