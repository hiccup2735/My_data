import { Box, Button, Paper, Typography } from '@material-ui/core'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { Examination } from '../../../types/domain'
import { paths } from '../../../utils/paths'
import { PageContainer } from '../../ui/PageContainer'
import { ExamScores } from './ExamResult'

type Props = {
  exam: Examination
}

export const ExamFinished = ({ exam }: Props) => {
  const history = useHistory()
  return (
    <PageContainer>
      <Paper
        elevation={4}
        style={{
          marginBottom: 24,
          padding: 0,
          paddingTop: 50,
          paddingBottom: 40,
        }}
      >
        {exam.status !== 'scoring' && (
          <Box style={{ paddingLeft: 30, paddingRight: 30 }}>
            <ExamScores exam={exam} />
          </Box>
        )}
        <Box style={{ paddingTop: 40, textAlign: 'center' }}>
          <Button
            style={{
              fontSize: 16,
              height: 48,
              paddingRight: 40,
              paddingLeft: 40,
            }}
            variant="outlined"
            color="primary"
            onClick={() => {
              history.push(paths.root)
            }}
          >
            テスト一覧へ戻る
          </Button>
        </Box>
      </Paper>
    </PageContainer>
  )
}
