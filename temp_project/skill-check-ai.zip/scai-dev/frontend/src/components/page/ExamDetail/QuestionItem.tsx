import { Box, Button, Grid, Paper, Typography } from '@material-ui/core'
import * as React from 'react'
import Lightbox from 'react-image-lightbox'
import 'react-image-lightbox/style.css'
import { Question } from '../../../types/domain'
import { colors } from '../../../utils/theme'
import { ExamDescription } from '../../ui/ExamDescription'
import { CodeQuizItem } from './CodeQuizItem'

type QuestionItemProps = {
  question: Question
  questionNumber: number
  onChoice: (quizId: number, choiceId: number) => void
  onNext?: () => void
  onPrev?: () => void
  onAnswerCodeQuiz: (
    questionId: number,
    codeQuizId: number,
    lang: string,
    code: string,
  ) => Promise<boolean>
}

export const QuestionItem = ({
  onChoice,
  question,
  onPrev,
  onNext,
  questionNumber,
  onAnswerCodeQuiz,
}: QuestionItemProps) => {
  const [imageUrl, setImageUrl] = React.useState<string | undefined>(undefined)
  return (
    <Grid style={{ userSelect: 'none' }}>
      <Grid style={{ flexGrow: 1, paddingBottom: 24, width: '100%' }}>
        <Grid component={Paper}>
          <Grid
            style={{
              backgroundColor: colors.itemHeader,
              padding: '20px 40px 20px 40px',
            }}
          >
            <Grid container>
              <Grid item md={1}>
                <div
                  style={{
                    backgroundColor: colors.emphasis,
                    textAlign: 'center',
                    fontWeight: 600,
                    width: 64,
                    lineHeight: '30px',
                    borderRadius: 4,
                    fontSize: 14,
                    color: colors.white,
                  }}
                >
                  問{questionNumber}
                </div>
              </Grid>
              <Grid item md={11} style={{ paddingLeft: 16 }}>
                <Typography style={{ fontSize: 18, color: colors.hint }}>
                  {question.name}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          <Grid
            style={{
              padding: '30px 40px 30px 40px',
            }}
          >
            {question.image_uri ? (
              <Grid>
                <Grid style={{ paddingBottom: 24 }}>
                  <ExamDescription text={question.description} />
                </Grid>
                <Grid>
                  {imageUrl && (
                    <Lightbox
                      mainSrc={imageUrl}
                      onCloseRequest={() => {
                        setImageUrl(undefined)
                      }}
                    />
                  )}
                  <img
                    onClick={() => {
                      setImageUrl(question.image_uri)
                    }}
                    alt="image"
                    style={{ width: '100%', cursor: 'pointer' }}
                    src={question.image_uri}
                  />
                </Grid>
              </Grid>
            ) : (
              <Box>
                <ExamDescription text={question.description} />
              </Box>
            )}
          </Grid>
        </Grid>
      </Grid>

      {question.code_quizzes.map((codeQuiz, i) => {
        return (
          <Grid
            key={`code_quiz_${i}`}
            item
            component={Paper}
            style={{ padding: '24px 40px 24px 40px', marginBottom: 24 }}
          >
            <CodeQuizItem
              codeQuiz={codeQuiz}
              onAnswerCodeQuiz={onAnswerCodeQuiz}
            />
          </Grid>
        )
      })}

      {question.quizzes.map((quiz, i) => {
        return (
          <Grid
            key={`quiz_${i}`}
            item
            component={Paper}
            style={{ padding: '24px 40px 24px 40px', marginBottom: 24 }}
          >
            <Grid style={{ paddingBottom: 24 }}>
              <ExamDescription text={quiz.description} />
            </Grid>
            <Grid>
              <Grid
                direction="row"
                justify="space-evenly"
                alignItems="stretch"
                style={{}}
              >
                {quiz.choices.map((c) => {
                  return (
                    <Grid
                      style={{
                        cursor: 'pointer',
                        paddingBottom: 8,
                      }}
                      onClick={() => onChoice(quiz.id, c.id)}
                      key={`q_${question.id}_c_${c.id}`}
                    >
                      <Paper
                        style={{
                          padding: '20px',
                          backgroundColor: c.is_selected
                            ? colors.itemHeader
                            : 'white',
                        }}
                      >
                        <ExamDescription text={c.name} />
                      </Paper>
                    </Grid>
                  )
                })}
              </Grid>
            </Grid>
          </Grid>
        )
      })}
      <Grid container style={{ paddingBottom: 40 }}>
        <Grid item xs={6} style={{ textAlign: 'right', paddingRight: 10 }}>
          {
            <Button
              disabled={onPrev === undefined}
              color="primary"
              style={{
                height: 48,
                paddingRight: 40,
                paddingLeft: 40,
                fontSize: 18,
              }}
              variant="outlined"
              onClick={() => {
                onPrev && onPrev()
              }}
            >
              前の問へ
            </Button>
          }
        </Grid>
        <Grid item xs={6} style={{ textAlign: 'left', paddingLeft: 10 }}>
          {
            <Button
              disabled={onNext === undefined}
              color="primary"
              style={{
                height: 48,
                paddingRight: 40,
                paddingLeft: 40,
                fontSize: 18,
              }}
              variant="contained"
              onClick={() => {
                onNext && onNext()
              }}
            >
              次の問へ
            </Button>
          }
        </Grid>
      </Grid>
    </Grid>
  )
}
