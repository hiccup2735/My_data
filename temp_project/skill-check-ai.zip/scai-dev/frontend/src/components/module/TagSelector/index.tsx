import { TextField } from '@material-ui/core'
import { Autocomplete } from '@material-ui/lab'
import * as React from 'react'
import { AdminQuestionTag } from '../../../types/domain'

export type Option = { id: string; name: string }

type Props = {
  tags: AdminQuestionTag[]
  onChange?: (tags: string[]) => void
}

export const TagSelector = ({ tags, onChange }: Props) => {
  const options = tags.map((t) => ({ id: t.name, name: t.name }))
  return (
    <Autocomplete<Option, true>
      options={options}
      multiple
      getOptionLabel={(option) => option.name}
      onChange={(_, value) => {
        onChange && Array.isArray(value) && onChange(value.map((v) => v.name))
      }}
      renderInput={(params) => (
        <TextField {...params} label="タグを選択" variant="outlined" />
      )}
    />
  )
}
