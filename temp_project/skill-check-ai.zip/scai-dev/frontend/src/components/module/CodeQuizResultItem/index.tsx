import styled from '@emotion/styled'
import * as React from 'react'
import { CodeQuizResult, CodeQuizResultType } from '../../../types/domain'
import { colors } from '../../../utils/theme'
import { ExamDescription } from '../../ui/ExamDescription'

const Container = styled.div`
  color: ${colors.text};
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 20px;

  display: flex;
  flex-direction: column;
  row-gap: 20px;

  .items {
    display: flex;
    flex-direction: column;
    row-gap: 10px;

    .item {
      .item-label {
        color: ${colors.subText};
        font-weight: bold;
      }
    }
  }

  .fields {
    display: flex;
    flex-direction: column;
    row-gap: 10px;

    .field {
      display: flex;

      .label {
        width: 100px;
        color: ${colors.subText};
      }

      .value {
        flex-grow: 1;
      }
    }
  }
`

const resultLabels: Record<CodeQuizResultType, string> = {
  OK: '正答',
  NG: '誤答',
  ERR: 'エラー',
}

const resultLabelColors: Record<CodeQuizResultType, string> = {
  OK: colors.checked,
  NG: colors.alert,
  ERR: colors.disabled,
}

export const codeQuizStatsKeys = [
  'AC',
  'WA',
  'TLE',
  'MLE',
  'RE',
  'CE',
  'FE',
] as const
export type CodeQuizStatsKey = typeof codeQuizStatsKeys[number]
function isCodeQuizStatsKey(key: string): key is CodeQuizStatsKey {
  return codeQuizStatsKeys.includes(key as CodeQuizStatsKey)
}

const codeQuizStatsLabels: Record<CodeQuizStatsKey, string> = {
  AC: '正解',
  WA: '間違い',
  TLE: '時間制限エラー',
  MLE: 'メモリー制限エラー',
  RE: 'ランタイムエラー',
  CE: 'コンパイルエラー',
  FE: 'フォーマットエラー',
}

type Props = {
  result: CodeQuizResult
}

export const CodeQuizResultItem = ({ result }: Props) => {
  return (
    <Container>
      <div className="items">
        <div className="item">
          <div className="item-label">問</div>
          <ExamDescription text={result.question.name} />
        </div>
        <div className="item">
          <div className="item-label">設問</div>
          <ExamDescription text={result.code_quiz.description} />
        </div>
      </div>
      <div className="fields">
        <div className="field">
          <div className="label">結果</div>
          <div
            className="value"
            style={{ color: resultLabelColors[result.result] }}
          >
            {resultLabels[result.result]}
          </div>
        </div>
        <div className="field">
          <div className="label">スコア</div>
          <div className="value">{result.score}</div>
        </div>
        <div className="field">
          <div className="label">統計情報</div>
          <div className="value">
            {result.statistics.split(',').map((s, i) => {
              const [k, v] = s.split(':')

              return (
                <div key={`s_${i}`}>
                  {isCodeQuizStatsKey(k) ? codeQuizStatsLabels[k] : k}：{v}
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </Container>
  )
}
