import { MenuItem, Select } from '@material-ui/core'
import * as React from 'react'
import { QuestionCategory } from '../../../../types/domain'

type Props = {
  value?: number
  categories: QuestionCategory[]
  onChange?: (categoryId: number) => void
}

export const CategorySelector = ({ categories, onChange, value }: Props) => {
  return (
    <Select
      fullWidth
      variant="outlined"
      value={value}
      onChange={(e) => {
        console.log('onChange', e)
        onChange && onChange(parseInt(`${e.target.value}`, 10))
      }}
    >
      {categories.map((c) => (
        <MenuItem value={c.id} key={`o_${c.id}`}>
          {c.name}
        </MenuItem>
      ))}
    </Select>
  )
}
