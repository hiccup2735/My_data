import { Box, Breadcrumbs, Button, Link } from '@material-ui/core'
import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { License, Organization } from '../../../../types/domain'

type RecordType = License

type Props = {
  organization?: Organization
  data: (query: Query<RecordType>) => Promise<QueryResult<RecordType>>
  onAdd?: (admin: RecordType) => Promise<boolean>
  onEdit?: (admin: RecordType) => Promise<boolean>
  onDelete?: (adminId: number) => Promise<boolean>
  goToList?: () => void
  onClickMultiple?: () => void
}

export const OrganizationLicenseList = ({
  organization,
  data,
  onAdd,
  onEdit,
  onDelete,
  goToList,
  onClickMultiple,
}: Props) => (
  <div>
    <Box style={{ paddingBottom: 24 }}>
      <Breadcrumbs>
        <Link
          style={{ cursor: 'pointer' }}
          onClick={() => goToList && goToList()}
        >
          組織一覧に戻る
        </Link>
      </Breadcrumbs>
    </Box>

    <MaterialTable<RecordType>
      options={{
        pageSize: 20,
        pageSizeOptions: [20, 50, 100],
        search: false,
      }}
      title={
        <>
          <div style={{ display: 'inline-block', paddingRight: 16 }}>
            {organization?.name} ライセンス一覧
          </div>
          <div style={{ display: 'inline-block' }}>
            <Button
              variant="contained"
              onClick={() => onClickMultiple && onClickMultiple()}
            >
              一括付与
            </Button>
          </div>
        </>
      }
      data={data}
      editable={{
        onRowAdd: (row) => {
          return onAdd ? onAdd(row) : new Promise((resolve) => resolve(true))
        },
        onRowDelete: (row) => {
          return onDelete
            ? onDelete(row.id)
            : new Promise((resolve) => resolve(true))
        },
        onRowUpdate: (newRow) => {
          return onEdit
            ? onEdit(newRow)
            : new Promise((resolve) => resolve(true))
        },
      }}
      columns={[
        { field: 'id', title: 'ID', editable: 'never' },
        {
          field: 'count',
          title: 'ライセンス数',
          type: 'numeric',
          render: (row) => {
            return `${row.count}(残${row.quantity})`
          },
        },
        {
          field: 'quantity',
          title: 'ライセンス付与数',
          type: 'numeric',
          editable: 'never',
          render: (row) => `${row.count - row.quantity}`,
        },
        {
          field: 'examination_id',
          title: '試験(ID)',
          type: 'numeric',
          editable: 'onAdd',
          render: (row) => (
            <div>
              {row.examination_name}(id: {row.examination_id})
            </div>
          ),
        },
        { field: 'start_date_time', title: '開始', type: 'datetime' },
        { field: 'end_date_time', title: '終了', type: 'datetime' },
      ]}
    />
  </div>
)
