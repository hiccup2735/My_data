import React from 'react'
import { OrganizationUserList } from '.'

export default {
  component: OrganizationUserList,
  title: 'module/admin/OrganizationUserList',
}

export const Default = () => (
  <OrganizationUserList
    data={() => {
      return new Promise((resolve) => {
        resolve({
          page: 0,
          totalCount: 2,
          data: [
            {
              id: 100,
              name: 'name',
              email: 'user@example.com',
              organization_name: '企業A',
              examinations_count: 10,
            },
            {
              id: 101,
              name: 'name2',
              email: 'user2@example.com',
              organization_name: '企業B',
              examinations_count: 11,
            },
          ],
        })
      })
    }}
  />
)
