import { Box, IconButton } from '@material-ui/core'
import { Delete } from '@material-ui/icons'
import * as React from 'react'
import { AdminQuestion, QuestionCategory } from '../../../../types/domain'

type Props = {
  question: Pick<AdminQuestion, 'id' | 'name' | 'category_id'>
  onRemove?: (questionId: number) => void
  categories: QuestionCategory[]
}

export const QuestionItem = ({ onRemove, question, categories }: Props) => (
  <Box>
    {question.id} {question.name}(
    {categories.find((c) => c.id === question.category_id)?.name ||
      `カテゴリ不明: ${question.category_id}`}
    )
    <IconButton onClick={() => onRemove && onRemove(question.id)}>
      <Delete />
    </IconButton>
  </Box>
)
