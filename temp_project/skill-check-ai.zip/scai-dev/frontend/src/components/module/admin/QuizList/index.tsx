import * as React from 'react'
import MaterialTable from 'material-table'
import { tableHeaderStyle } from '../../../../utils/theme'
import { AdminQuiz } from '../../../../types/domain'

type Props = {
  quizzes: AdminQuiz[]
  onDeleteQuiz?: (id: number) => void
  onEdit?: (id: number) => void
}

export const QuizList = ({ quizzes, onDeleteQuiz, onEdit }: Props) => (
  <MaterialTable<AdminQuiz>
    data={quizzes}
    totalCount={quizzes.length}
    page={0}
    title="設問一覧"
    options={{
      search: false,
      paging: false,
      pageSize: quizzes.length,
      headerStyle: tableHeaderStyle,
    }}
    editable={{
      onRowDelete: (row) => {
        console.log('onRowDelete', row, onDeleteQuiz)
        return new Promise((resolve) => {
          onDeleteQuiz && onDeleteQuiz(row.id)
          resolve(row)
        })
      },
      onRowAdd: (row) => {
        return new Promise((resolve) => {
          resolve(row)
        })
      },
    }}
    actions={[
      {
        icon: 'edit',
        tooltip: '設問を編集',
        onClick: (e, row) => {
          console.log('onEdit', row)
          if (!Array.isArray(row)) {
            onEdit && onEdit(row.id)
          }
        },
      },
    ]}
    columns={[
      { field: 'description', title: '問題文' },
      {
        field: 'choices',
        title: '選択肢',
        // eslint-disable-next-line react/display-name
        render: (quiz) => (
          <div>{(quiz.choices || []).map((c) => c.name).join('/')}</div>
        ),
      },
    ]}
  />
)
