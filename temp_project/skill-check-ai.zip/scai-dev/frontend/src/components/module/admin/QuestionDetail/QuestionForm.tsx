import { Box, Button, Grid, Paper, TextField, Select, MenuItem } from '@material-ui/core'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { useDropzone } from 'react-dropzone'
import { Controller, ErrorMessage, useForm } from 'react-hook-form'
import * as yup from 'yup'
import { AdminQuestion } from '../../../../types/domain'
import { validation } from '../../../../types/validation'
import { ErrorMessageBox } from '../../../ui/ErrorMessageBox'
import { ExamDescription } from '../../../ui/ExamDescription'
import { ImageView } from '../../../ui/ImageView'
import { PageContainer } from '../../../ui/PageContainer'
import { AdminContext } from '../../../../contexts/AdminContext'

type Props = {
  question?: AdminQuestion
  onSubmit?: (values: FormValues & { image_url?: string }) => void
  onCancel?: () => void
  onFileDropped?: (file: File) => Promise<string>
  updating?: boolean
}

const validationSchema = yup.object().shape({
  name: validation.examinationName,
  description: validation.examinationDescription,
  level: validation.level,
  group: validation.group,
})

type FormValues = {
  name: string
  description: string
  level: number
  group: number
}

export const QuestionForm = ({
  question,
  onSubmit,
  updating,
  onCancel,
  onFileDropped,
}: Props) => {
  const { enqueueSnackbar } = useSnackbar()
  const [imageUrl, setImageUrl] = React.useState<string | undefined>(
    question?.image_uri,
  )
  const { control, errors, handleSubmit, watch, setValue } = useForm<
    FormValues
  >({
    defaultValues: {
      name: question?.name,
      description: question?.description,
      level: question?.level || 0,
      group: question?.group || 0,
    },
    validationSchema,
  })
  const onDrop = React.useCallback(
    (acceptedFiles) => {
      console.log('acceptedFiles', acceptedFiles)
      if (acceptedFiles.length === 0) {
        console.log('no accepted files')
        enqueueSnackbar('アップロードできるのはpng画像のみです', {
          variant: 'warning',
        })
        return
      }

      if (onFileDropped) {
        onFileDropped(acceptedFiles[0] as File).then((fileUrl: string) => {
          console.log('fileUrl', fileUrl)
          setImageUrl(fileUrl)
        })
      }
    },
    [setValue],
  )
  const { getInputProps, getRootProps, isDragActive } = useDropzone({
    onDrop,
    multiple: false,
    accept: '.png,.jpg,.jpeg,.gif',
  })

  const description = watch('description')
  const { authenticated } = React.useContext(AdminContext)
  const isAdmin = authenticated ? true : false

  return (
    <PageContainer>
      <Grid container style={{ padding: '24px' }} component={Paper}>
        <Grid style={{ paddingBottom: 24 }} md={12} item>
          <Box>{question ? `問の編集 id: ${question.id}` : '新規作成'}</Box>
        </Grid>
        <Grid md={12} item>
          <form
            onSubmit={handleSubmit((values) => {
              console.log('handleSubmit', values, imageUrl)
              onSubmit && onSubmit({ ...values, image_url: imageUrl })
            })}
          >
            <Grid item style={{ paddingBottom: '8px' }}>
              <Box>
                <h3>タイトル</h3>
              </Box>
              <Box>
                <Controller
                  control={control}
                  name="name"
                  as={
                    <TextField variant="outlined" style={{ width: '100%' }} />
                  }
                />
              </Box>
              <ErrorMessageBox>
                <ErrorMessage name="name" errors={errors} />
              </ErrorMessageBox>
            </Grid>
            { isAdmin &&
              <Grid item style={{ paddingBottom: '8px' }}>
                <Box>
                  <h3>グループ</h3>
                </Box>
                <Box>
                  <Controller
                    control={control}
                    name="group"
                    as={
                      <Select
                        label="グループ"
                        fullWidth
                        variant="outlined"
                      >
                        <MenuItem value={0}>グループを選択してください</MenuItem>
                        <MenuItem value={1}>(GX)検定</MenuItem>
                        <MenuItem value={2}>(GX/DX)研修</MenuItem>
                      </Select>
                    }
                  />
                </Box>
                <ErrorMessageBox>
                  <ErrorMessage name="group" errors={errors} />
                </ErrorMessageBox>
              </Grid>
            }
            <Grid item style={{ paddingBottom: '8px' }}>
              <Box>
                <h3>難易度</h3>
              </Box>
              <Box>
                <Controller
                  control={control}
                  name="level"
                  as={
                    <TextField
                      variant="outlined"
                      type="number"
                      style={{ width: '100%' }}
                    />
                  }
                />
              </Box>
              <ErrorMessageBox>
                <ErrorMessage name="name" errors={errors} />
              </ErrorMessageBox>
            </Grid>
            <Grid item style={{ paddingBottom: '8px' }}>
              <Box>
                <h3>本文</h3>
              </Box>
              <Box>
                <Controller
                  control={control}
                  name="description"
                  as={
                    <TextField
                      multiline
                      rows={6}
                      variant="outlined"
                      style={{ width: '100%', resize: 'vertical' }}
                    />
                  }
                />
              </Box>
              <Box
                style={{
                  marginTop: 24,
                }}
              >
                <Box>プレビュー</Box>
                <Box
                  style={{
                    border: '1px solid #ccc',
                    padding: 16,
                    fontSize: 'small',
                  }}
                >
                  <ExamDescription text={description} />
                </Box>
              </Box>
              <ErrorMessageBox>
                <ErrorMessage name="description" errors={errors} />
              </ErrorMessageBox>
            </Grid>

            <Grid item style={{ paddingBottom: '8px' }}>
              <Box>
                <h3>画像</h3>
              </Box>
              <Box>
                <div
                  {...getRootProps()}
                  style={{
                    border: '1px solid #ccc',
                    padding: 16,
                    marginBottom: 24,
                    fontSize: 'small',
                  }}
                >
                  <input {...getInputProps()} />
                  {isDragActive ? (
                    <p>ここにファイルをドロップしてください...</p>
                  ) : (
                    <p>
                      画像をアップロードするにはファイルをドラッグ&amp;ドロップするかここをクリックしてファイルを選択してください
                    </p>
                  )}
                </div>
              </Box>
              {imageUrl && (
                <Box>
                  <div>プレビュー</div>
                  <div>
                    <ImageView url={imageUrl} />
                  </div>
                  <div style={{ fontSize: 'small' }}>画像のURL: {imageUrl}</div>
                  <Box textAlign="right">
                    <Button
                      variant="contained"
                      color="secondary"
                      onClick={() => {
                        setImageUrl('')
                      }}
                    >
                      画像の削除
                    </Button>
                  </Box>
                </Box>
              )}
              <ErrorMessageBox>
                <ErrorMessage name="image_uri" errors={errors} />
              </ErrorMessageBox>
            </Grid>
            <Grid style={{ textAlign: 'right' }}>
              <Button
                variant="contained"
                color="default"
                onClick={() => onCancel && onCancel()}
                style={{ marginRight: 8 }}
              >
                キャンセル
              </Button>
              <Button
                disabled={updating}
                type="submit"
                variant="contained"
                color="primary"
              >
                保存する
              </Button>
            </Grid>
          </form>
        </Grid>
      </Grid>
    </PageContainer>
  )
}
