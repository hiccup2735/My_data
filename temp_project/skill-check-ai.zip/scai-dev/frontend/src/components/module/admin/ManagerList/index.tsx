import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { Manager, GroupNames } from '../../../../types/domain'
import { Select, MenuItem } from '@material-ui/core'

type Props = {
  data: (manager: Query<Manager>) => Promise<QueryResult<Manager>>
  onAdd?: (manager: Manager) => Promise<boolean>
  onEdit?: (manager: Manager) => Promise<boolean>
  onDelete?: (managerId: number) => Promise<boolean>
  pageSize: number
  keyword: string
}

export const ManagerList = ({ data, onAdd, onEdit, onDelete, pageSize, keyword }: Props) => (
  <div>
    <MaterialTable<Manager>
      title="サービス管理者一覧"
      options={{
        searchText: keyword,
        pageSize: pageSize,
        pageSizeOptions: [10, 20, 50],
      }}
      data={data}
      editable={{
        onRowAdd: (row) => {
          return onAdd ? onAdd(row) : new Promise((resolve) => resolve(true))
        },
        onRowDelete: (row) => {
          return onDelete
            ? onDelete(row.id)
            : new Promise((resolve) => resolve(true))
        },
        onRowUpdate: (newRow) => {
          return onEdit
            ? onEdit(newRow)
            : new Promise((resolve) => resolve(true))
        },
      }}
      columns={[
        { field: 'id', title: 'ID', editable: 'never' },
        { field: 'name', title: 'ユーザー名' },
        { field: 'email', title: 'メールアドレス' },
        {
          field: 'group',
          title: 'グループ',
          render: rowData => GroupNames[rowData.group],
          /* eslint-disable react/prop-types */
          editComponent: (props: any) => (
            <Select
              value={props.value || 0}
              onChange={(e) => props.onChange(e.target.value)}
              style={{ width: '120px' }}
            >
              <MenuItem value={0}>未設定</MenuItem>
              <MenuItem value={1}>(GX)検定</MenuItem>
              <MenuItem value={2}>(GX/DX)研修</MenuItem>
            </Select>
          )
        },
        { field: 'password', title: 'パスワード', render: () => '****' }
      ]}
    />
  </div>
)
