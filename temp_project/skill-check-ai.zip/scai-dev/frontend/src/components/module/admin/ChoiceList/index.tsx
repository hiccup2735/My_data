import { Box } from '@material-ui/core'
import MaterialTable from 'material-table'
import * as React from 'react'
import { Choice } from '../../../../types/domain'
import { tableHeaderStyle } from '../../../../utils/theme'
import { ExamDescription } from '../../../ui/ExamDescription'

type Props = {
  choices: Choice[]
  onDelete?: (id: number) => void
  onEdit?: (choice: Choice) => void
  onCreate?: (newData: Exclude<Choice, 'id'>) => void
}

export const ChoiceList = ({ choices, onDelete, onEdit, onCreate }: Props) => (
  <Box>
    <MaterialTable<Choice>
      data={choices}
      totalCount={choices.length}
      page={0}
      title="選択肢一覧"
      options={{
        paging: false,
        pageSize: choices.length,
        headerStyle: tableHeaderStyle,
        search: false,
      }}
      editable={{
        onRowAdd: (row) => {
          console.log('onRowAdd', row)
          return new Promise((resolve) => {
            onCreate && onCreate(row)
            resolve(row)
          })
        },
        onRowDelete: (row) => {
          console.log('onRowDelete', row)
          return new Promise((resolve) => {
            onDelete && onDelete(row.id)
            resolve(row)
          })
        },
        onRowUpdate: (newRow, oldRow) => {
          console.log('onRowUpdate', oldRow, newRow)
          return new Promise((resolve, reject) => {
            try {
              onEdit && oldRow && onEdit({ ...newRow, id: oldRow.id })
            } catch {
              reject()
            }
            resolve(newRow)
          })
        },
      }}
      columns={[
        {
          field: 'name',
          title: '選択肢',
          type: 'string',
          render: (row) => <ExamDescription text={row.name} />,
        },
        {
          field: 'point',
          title: '得点',
          type: 'numeric',
        },
      ]}
    />
  </Box>
)
