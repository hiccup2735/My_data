import styled from '@emotion/styled'
import { Box, Breadcrumbs, Button, Link, Paper } from '@material-ui/core'
import MaterialTable from 'material-table'
import * as React from 'react'
import { Controller, useForm } from 'react-hook-form'
import * as yup from 'yup'
import {
  AdminUserDetail,
  Examination,
  License,
  Organization,
} from '../../../../types/domain'
import { validation } from '../../../../types/validation'
import { adminPaths, managerPaths } from '../../../../utils/paths'
import { colors } from '../../../../utils/theme'
import { formatDate } from '../../../../utils/time'
import { AdminSection } from '../../../ui/admin/Section'
import { ExamTag } from '../../../ui/ExamTag'
import { Select } from '../../../ui/Select'
import { TextLink } from '../../../ui/TextLink'
import { OrganizationSelector } from '../OrganizationSelector'
import { ManagerContext } from '../../../../contexts/ManagerContext'

const validationSchema = yup.object().shape({
  licenseId: validation.id,
})

const OrgBox = styled.div`
  padding: 20px 0px;
  .display {
    display: flex;
    align-items: center;
    height: 30px;

    .button {
      margin-left: 16px;
    }
  }
  .change {
    margin-top: 16px;
    border: 1px solid ${colors.alert};
    width: 500px;
    border-radius: 4px;
    padding: 16px;

    display: flex;
    align-items: center;

    .label {
      padding-right: 16px;
    }

    .selector {
      flex-grow: 1;
      padding-right: 16px;
    }

    .cancel {
    }
  }
`

type AdminType = 'admin' | 'organizer' | 'operator' | 'manager'

type Props = {
  adminType?: AdminType
  organizationId?: string
  user: AdminUserDetail
  goToList?: (organizationId?: string) => void
  licenses: License[]
  onAddLicense?: (licenseId: number) => void
  organizations: Organization[]
  changeOrganization?: (organizationId: number) => void
  organizationChangeable?: boolean
}

type FormValue = {
  licenseId: number
}

export const UserDetail = ({
  adminType = 'admin',
  user,
  goToList,
  organizationId,
  licenses,
  onAddLicense,
  organizations,
  changeOrganization,
  organizationChangeable,
}: Props) => {
  const {
    handleSubmit,
    control,
    formState: { isValid },
  } = useForm<FormValue>({
    mode: 'onChange',
    defaultValues: {},
    validationSchema,
  })

  const [orgEditing, setOrgEditing] = React.useState<boolean>(false)
  const { group } = React.useContext(ManagerContext)
  return (
    <>
      <Box style={{ paddingBottom: 24 }}>
        <Breadcrumbs>
          <Link
            style={{ cursor: 'pointer' }}
            onClick={() => goToList && goToList(organizationId)}
          >
            ユーザー一覧に戻る
          </Link>
        </Breadcrumbs>
      </Box>
      <Box component={Paper} style={{ padding: 24 }}>
        <Box>
          <h3>ユーザー詳細 ID: {user.id}</h3>
        </Box>
        <AdminSection>
          <Box>
            <h4>基本情報</h4>
          </Box>
          <Box>氏名: {user.name}</Box>
          <Box>メールアドレス: {user.email}</Box>
          <OrgBox>
            <div className="display">
              組織名: {user.organization_name}
              {organizationChangeable && !orgEditing && (
                <Button
                  color="secondary"
                  variant="outlined"
                  size="small"
                  className="button"
                  onClick={() => setOrgEditing(true)}
                >
                  組織の変更
                </Button>
              )}
            </div>
            {organizationChangeable && orgEditing && (
              <div className="change">
                <div className="label">組織の変更</div>
                <div className="selector">
                  <OrganizationSelector
                    options={organizations}
                    onChange={(orgId) =>
                      changeOrganization && changeOrganization(orgId)
                    }
                  />
                </div>
                <div className="cancel">
                  <Button
                    color="default"
                    size="small"
                    variant="outlined"
                    onClick={() => setOrgEditing(false)}
                  >
                    キャンセル
                  </Button>
                </div>
              </div>
            )}
          </OrgBox>
          <Box>試験数: {user.examinations_count || 0}</Box>
        </AdminSection>
        <AdminSection>
          <Box>
            <h4>ライセンス付与</h4>
          </Box>
          <Box>
            <form
              onSubmit={handleSubmit((values) => {
                console.log('submit', values)
                onAddLicense && onAddLicense(values.licenseId)
              })}
            >
              <Box style={{ paddingBottom: 16 }}>
                <Controller
                  control={control}
                  name="licenseId"
                  as={
                    <Select
                      isDisabled={(o) => {
                        const license = licenses.find((l) => l.id === o.value)
                        return license ? license.quantity <= 0 : false
                      }}
                      placeholder="付与するライセンスを選択してください"
                      options={licenses.map((l) => ({
                        value: l.id,
                        label: `${l.examination_name}(残数: ${l.quantity})`,
                      }))}
                    />
                  }
                />
              </Box>
              <Box>
                <Button
                  disabled={!isValid}
                  color="primary"
                  type="submit"
                  variant="contained"
                >
                  ライセンス追加
                </Button>
              </Box>
            </form>
          </Box>
        </AdminSection>
        <AdminSection>
          <Box>
            <MaterialTable
              options={{
                search: false,
                paging: false,
              }}
              title="試験一覧"
              data={user.examinations}
              columns={[
                {
                  field: 'id',
                  title: 'ID',
                  sorting: false,
                  width: 50,
                },
                {
                  field: 'name',
                  title: '試験タイトル',
                  sorting: false,
                  render: (exam: Examination) => {
                    const genExaminationPath = adminType === 'admin' ? adminPaths.genExamination(exam.id) : managerPaths.genExamination(exam.id)
                    return (adminType === 'admin' || (adminType == 'manager' && exam.group === group)) ? (
                      <TextLink to={genExaminationPath}>
                        {exam.name}
                      </TextLink>
                    ) : (
                      exam.name
                    )
                  }
                },
                {
                  field: 'status',
                  sorting: false,
                  title: 'ステータス',
                  width: 120,
                  render: (row) => <ExamTag status={row.status} />,
                },
                {
                  field: 'date',
                  sorting: false,
                  title: '受験日時',
                  width: 120,
                  render: (row) => (
                    <div>
                      {row.started_at ? formatDate(row.started_at) : '-'}
                    </div>
                  ),
                },
                {
                  field: 'score',
                  title: '得点',
                  sorting: false,
                  width: 100,
                },
                {
                  field: 'scores',
                  title: 'カテゴリ別',
                  render: (row) => {
                    return (
                      <div>
                        {(row.scores || []).map((s, i) => (
                          <div key={`s_${i}`}>
                            {s.category_name}: {s.score}点
                          </div>
                        ))}
                      </div>
                    )
                  },
                },
              ]}
            />
          </Box>
        </AdminSection>
      </Box>
    </>
  )
}
