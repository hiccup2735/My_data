import { Box, Button, Grid, Paper, TextField, Select, MenuItem } from '@material-ui/core'
import * as React from 'react'
import { Controller, ErrorMessage, useForm } from 'react-hook-form'
import * as yup from 'yup'
import { AdminExamination, ExaminationScope } from '../../../../types/domain'
import { validation } from '../../../../types/validation'
import { ErrorMessageBox } from '../../../ui/ErrorMessageBox'
import { PageContainer } from '../../../ui/PageContainer'
import { AdminContext } from '../../../../contexts/AdminContext'

type Props = {
  exam?: AdminExamination
  updating?: boolean
  onSubmit?: (values: FormValues) => void
  onCancel?: () => void
}

const validationSchema = yup.object().shape({
  name: validation.examinationName,
  description: validation.examinationDescription,
  limitMin: validation.examinationLimitMin,
  group: validation.group,
})

type FormValues = {
  name: string
  description: string
  limitMin: number
  scope: ExaminationScope
  code: string
  group: number
}

export const ExamForm = ({ exam, onSubmit, updating, onCancel }: Props) => {
  const { handleSubmit, errors, control, register } = useForm<FormValues>({
    validationSchema,
    defaultValues: {
      name: exam?.name,
      description: exam?.description,
      limitMin: exam?.limit_min || 10,
      scope: 'global',
      code: exam?.code || '',
      group: exam?.group || 0,
    },
  })
  const { authenticated } = React.useContext(AdminContext)
  const isAdmin = authenticated ? true : false
  return (
    <PageContainer>
      <Grid style={{ padding: 24 }} container component={Paper}>
        <Grid style={{ paddingBottom: 24 }} md={12} item>
          <Box>{exam ? `id: ${exam.id}の編集` : '新規作成'}</Box>
        </Grid>
        <Grid md={12} item>
          <form
            onSubmit={handleSubmit((values) => {
              console.log(values)
              onSubmit && onSubmit(values)
            })}
          >
            <input type="hidden" name="scope" ref={register} />
            <Box paddingBottom="8px">
              <Box>
                <Controller
                  control={control}
                  name="name"
                  as={
                    <TextField
                      style={{ width: '100%' }}
                      variant="outlined"
                      label="タイトル"
                      error={Boolean(errors.name)}
                    />
                  }
                />
              </Box>
              <ErrorMessageBox>
                <ErrorMessage name="name" errors={errors} />
              </ErrorMessageBox>
            </Box>
            <Box paddingBottom="8px">
              <Box>
                <Controller
                  control={control}
                  name="code"
                  as={
                    <TextField
                      fullWidth
                      variant="outlined"
                      label="試験コード"
                      error={Boolean(errors.code)}
                    />
                  }
                />
              </Box>
              <ErrorMessageBox>
                <ErrorMessage name="code" errors={errors} />
              </ErrorMessageBox>
            </Box>
            { isAdmin && (
                <Box paddingBottom="8px">
                  <Box>
                    <Controller
                      control={control}
                      name="group"
                      as={
                        <Select
                          label="グループ"
                          fullWidth
                          variant="outlined"
                        >
                          <MenuItem value={0}>グループを選択してください</MenuItem>
                          <MenuItem value={1}>(GX)検定</MenuItem>
                          <MenuItem value={2}>(GX/DX)研修</MenuItem>
                        </Select>
                      }
                    />
                  </Box>
                  <ErrorMessageBox>
                    <ErrorMessage name="group" errors={errors} />
                  </ErrorMessageBox>
                </Box>
              )
            }
            <Box paddingBottom="8px">
              <Box>
                <Controller
                  control={control}
                  name="limitMin"
                  as={
                    <TextField
                      style={{ width: '100%' }}
                      variant="outlined"
                      label="制限時間"
                      type="number"
                      inputProps={{
                        step: 1,
                        max: 1000,
                        min: 0,
                      }}
                      error={Boolean(errors.limitMin)}
                    />
                  }
                />
              </Box>
              <ErrorMessageBox>
                <ErrorMessage name="limitMin" errors={errors} />
              </ErrorMessageBox>
            </Box>
            <Box paddingBottom="8px">
              <Box>
                <Controller
                  control={control}
                  name="description"
                  as={
                    <TextField
                      style={{ resize: 'vertical', width: '100%' }}
                      variant="outlined"
                      multiline
                      rows={4}
                      label="説明"
                      error={Boolean(errors.description)}
                    />
                  }
                />
              </Box>
              <ErrorMessageBox>
                <ErrorMessage name="description" errors={errors} />
              </ErrorMessageBox>
            </Box>
            <Box style={{ textAlign: 'right' }}>
              <Button
                size="large"
                variant="contained"
                color="default"
                onClick={() => onCancel && onCancel()}
                style={{ marginRight: 8 }}
              >
                キャンセル
              </Button>
              <Button
                disabled={updating}
                size="large"
                type="submit"
                variant="contained"
                color="primary"
              >
                保存する
              </Button>
            </Box>
          </form>
        </Grid>
      </Grid>
    </PageContainer>
  )
}
