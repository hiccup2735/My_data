import React from 'react'
import { QuizDetail } from '.'
import { question } from '../../../../utils/mock'
import { action } from '@storybook/addon-actions'

export default {
  component: QuizDetail,
  title: 'module/admin/QuizDetail',
}

export const Default = () => {
  return <QuizDetail quiz={question.quizzes[0]} onEdit={action('onEdit')} />
}
