import * as React from 'react'
import { Grid, Paper, Button } from '@material-ui/core'
import { ChoiceList } from '../ChoiceList'
import { AdminQuiz, Choice } from '../../../../types/domain'
import { ExamDescription } from '../../../ui/ExamDescription'
import { QuizForm } from './QuizForm'

type Mode = 'edit' | 'show'

type Props = {
  mode?: Mode
  quiz: AdminQuiz
  onEdit?: (id: number) => void
  onDelete?: (id: number) => void
  onCancelEdit?: () => void
  onEdited?: (quiz: AdminQuiz) => void
  onDeleteChoice?: (id: number) => void
  onEditChoice?: (choice: Choice) => void
  onCreateChoice?: (newData: Exclude<Choice, 'id'>) => void
}

export const QuizDetail = ({
  mode,
  quiz,
  onEdit,
  onDelete,
  onCancelEdit,
  onEdited,
  onDeleteChoice,
  onEditChoice,
  onCreateChoice,
}: Props) => {
  if (mode === 'edit') {
    return (
      <QuizForm
        quiz={quiz}
        onSubmit={(values) => {
          onEdited && onEdited({ ...quiz, description: values.description })
        }}
        onCancel={() => {
          onCancelEdit && onCancelEdit()
        }}
      />
    )
  }

  return (
    <Grid style={{ padding: '24px', marginBottom: 24 }} component={Paper}>
      <Grid style={{ paddingBottom: 24 }} container>
        <Grid md={8} item>
          設問ID: {quiz.id}
        </Grid>
        <Grid style={{ textAlign: 'right' }} md={4} item>
          <Button
            style={{ marginRight: 8 }}
            onClick={() => onDelete && onDelete(quiz.id)}
            color="secondary"
            variant="contained"
          >
            Delete
          </Button>
          <Button onClick={() => onEdit && onEdit(quiz.id)} variant="contained">
            Edit
          </Button>
        </Grid>
      </Grid>
      <Grid style={{ paddingBottom: 16 }}>
        <h3>Description</h3>
        <ExamDescription text={quiz.description} />
      </Grid>
      <Grid>
        <ChoiceList
          choices={quiz.choices}
          onCreate={(choice) => {
            console.log('onCreateChoice', choice)
            onCreateChoice && onCreateChoice({ ...choice, quiz_id: quiz.id })
          }}
          onEdit={(choice) => {
            console.log('onEditChoice', choice)
            onEditChoice && onEditChoice({ ...choice, quiz_id: quiz.id })
          }}
          onDelete={(choiceId) => {
            console.log('onDeleteCHoice', choiceId)
            onDeleteChoice && onDeleteChoice(choiceId)
          }}
        />
      </Grid>
    </Grid>
  )
}
