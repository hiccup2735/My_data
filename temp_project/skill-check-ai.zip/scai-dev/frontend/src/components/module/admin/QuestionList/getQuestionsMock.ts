import { QuestionDraft } from '../../../../types/draft'

export const getQuestions = (
  page: number,
  pageSize: number,
  search?: string
): QuestionDraft[] => {
  return Array(pageSize)
    .fill(null)
    .map((_, i) => ({
      id: page * pageSize + i + 1,
      name: 'Name',
      description: search
        ? `Question for search query "${search}"`
        : 'Description',
      image_uri: '',
      quizzes: Array(3)
        .fill(null)
        .map((_, j) => ({
          id: (page * pageSize + i + 1) * 100 + j,
          category_name: 'cat',
          description: `Quiz Description ${i}-${j}`,
          choices: Array(3)
            .fill(null)
            .map((_, k) => ({
              id: j * 10 + k,
              name: `choice_${k}`,
              is_selected: false,
            })),
          is_answered: false,
        })),
    }))
}
