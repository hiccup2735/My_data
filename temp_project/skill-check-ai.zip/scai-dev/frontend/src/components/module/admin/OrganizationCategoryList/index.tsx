import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { OrganizationCategory } from '../../../../types/domain'

type RecordType = OrganizationCategory

type Props = {
  data: (query: Query<RecordType>) => Promise<QueryResult<RecordType>>
  onAdd?: (admin: RecordType) => Promise<boolean>
  onEdit?: (admin: RecordType) => Promise<boolean>
  onDelete?: (adminId: number) => Promise<boolean>
}

export const OrganizationCategoryList = ({ data, onAdd, onEdit }: Props) => (
  <div>
    <MaterialTable<RecordType>
      title="組織カテゴリ一覧"
      data={data}
      editable={{
        onRowAdd: (row) => {
          return onAdd ? onAdd(row) : new Promise((resolve) => resolve(true))
        },
        /*
        onRowDelete: (row) => {
          return onDelete
            ? onDelete(row.id)
            : new Promise((resolve) => resolve(true))
        },
        */
        onRowUpdate: (newRow) => {
          return onEdit
            ? onEdit(newRow)
            : new Promise((resolve) => resolve(true))
        },
      }}
      columns={[
        { field: 'id', title: 'ID', editable: 'never' },
        { field: 'name', title: '組織カテゴリ名' },
      ]}
    />
  </div>
)
