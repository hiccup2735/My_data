import styled from '@emotion/styled'
import {
  Box,
  Breadcrumbs,
  Button,
  Divider,
  Grid,
  Link,
  Paper,
} from '@material-ui/core'
import MaterialTable from 'material-table'
import * as React from 'react'
import {
  AdminQuestionDetail,
  AdminQuiz,
  Choice,
  CodeQuizFileType,
  GroupNames,
  Metadata,
} from '../../../../types/domain'
import { AddButton } from '../../../ui/AddButton'
import { ExamDescription } from '../../../ui/ExamDescription'
import { PageContainer } from '../../../ui/PageContainer'
import { CodeQuizDetail } from '../CodeQuizDetail'
import { QuizDetail } from '../QuizDetail'
import { QuestionExaminations } from './QuestionExaminations'

const CodeSection = styled.div`
  .code-quizzes {
    display: flex;
    flex-direction: column;
    row-gap: 10px;
  }
`

type Props = {
  question: AdminQuestionDetail
  onEdit?: (id: number) => void
  onDeleteChoice?: (quizId: number, choiceId: number) => void
  editingQuizId?: number
  onEditQuiz?: (quizId?: number) => void
  onCreateQuiz?: () => void
  onDeleteQuiz?: (quizId: number) => void
  onEditedQuiz?: (quiz: AdminQuiz) => void
  onEditChoice?: (choice: Choice) => void
  onCreateChoice?: (newData: Exclude<Choice, 'id'>) => void
  backToList?: () => void
  onAddMetadata: (metadata: Metadata) => Promise<boolean>
  onDeleteMetadata: (metadata: Metadata) => Promise<boolean>
  onAddTag: (tag: string) => Promise<boolean>
  onDeleteTag: (tag: string) => Promise<boolean>
  onCreateCodeQuiz: () => Promise<boolean>
  onUploadCodeQuizFile: (
    codeQuizId: number | string,
    fileType: CodeQuizFileType,
    file: File,
  ) => Promise<boolean>
  onUpdateCodeQuiz: Parameters<typeof CodeQuizDetail>[0]['onUpdateCodeQuiz']
  onDeleteCodeQuizFile: Parameters<
    typeof CodeQuizDetail
  >[0]['onDeleteCodeQuizFile']
}

export const QuestionDetail = ({
  question,
  onEdit,
  onEditQuiz,
  editingQuizId,
  onDeleteChoice,
  onEditedQuiz,
  onEditChoice,
  onCreateChoice,
  backToList,
  onCreateQuiz,
  onDeleteQuiz,
  onAddMetadata,
  onDeleteMetadata,
  onAddTag,
  onDeleteTag,
  onCreateCodeQuiz,
  onUploadCodeQuizFile,
  onUpdateCodeQuiz,
  onDeleteCodeQuizFile,
}: Props) => {
  const [addingCodeQuiz, setAddingCodeQuiz] = React.useState<boolean>(false)

  return (
    <PageContainer>
      <AddButton
        onClick={() => {
          onCreateQuiz && onCreateQuiz()
        }}
      />
      {backToList && (
        <Box style={{ paddingBottom: 24 }}>
          <Breadcrumbs aria-label="breadcrumb">
            <Link style={{ cursor: 'pointer' }} onClick={() => backToList()}>
              問一覧に戻る
            </Link>
          </Breadcrumbs>
        </Box>
      )}
      <Grid style={{ padding: '24px', marginBottom: 24 }} component={Paper}>
        <Grid style={{ paddingBottom: 24 }} md={12} container>
          <Grid md={8} item>
            <h3>
              {question.name}(id: {question.id})
            </h3>
          </Grid>
          <Grid style={{ textAlign: 'right' }} md={4} item>
            <Button
              onClick={() => onEdit && onEdit(question.id)}
              variant="contained"
            >
              Edit
            </Button>
          </Grid>
        </Grid>
        <Grid
          style={{ border: '1px solid #ccc', borderRadius: 4, padding: 16 }}
        >
          <ExamDescription text={question.description} />
        </Grid>
        <Grid>
          <h4>グループ</h4>
          <div>{GroupNames[question.group]}</div>
        </Grid>
        <Grid>
          <h4>難易度</h4>
          <div>{question.level}</div>
        </Grid>
        <Grid>
          <QuestionExaminations question={question} />
        </Grid>
        <Divider />
        <Grid style={{ padding: '16px 0px' }}>
          <MaterialTable
            data={question.tags.map((tag) => ({ tag }))}
            options={{
              search: false,
              paging: false,
              header: false,
            }}
            editable={{
              onRowAdd: (r) => onAddTag(r.tag),
              onRowDelete: (r) => onDeleteTag(r.tag),
            }}
            title={<h4>タグ一覧</h4>}
            columns={[
              {
                title: 'タグ',
                field: 'tag',
              },
            ]}
          />
        </Grid>
        <Grid>
          <MaterialTable
            data={question.metadata}
            options={{
              search: false,
              paging: false,
            }}
            editable={{
              onRowAdd: (r) => onAddMetadata(r),
              onRowDelete: (r) => onDeleteMetadata(r),
            }}
            title={<h4>メタデータ</h4>}
            columns={[
              {
                title: 'キー',
                field: 'key',
              },
              {
                title: '値',
                field: 'value',
              },
            ]}
          />
        </Grid>
      </Grid>
      {question.quizzes.map((q) => {
        return (
          <QuizDetail
            onDelete={(quizId) => {
              onDeleteQuiz && onDeleteQuiz(quizId)
            }}
            mode={editingQuizId === q.id ? 'edit' : 'show'}
            onDeleteChoice={(choiceId) =>
              onDeleteChoice && onDeleteChoice(q.id, choiceId)
            }
            onEditChoice={onEditChoice}
            onCreateChoice={onCreateChoice}
            onEdit={onEditQuiz}
            onEdited={onEditedQuiz}
            onCancelEdit={() => {
              onEditQuiz && onEditQuiz(undefined)
            }}
            key={`quiz_${q.id}`}
            quiz={q}
          />
        )
      })}

      <CodeSection>
        <h3>コード設問</h3>

        <div className="code-quizzes">
          {question.code_quizzes.map((cq) => {
            return (
              <CodeQuizDetail
                key={cq.id}
                codeQuiz={cq}
                onUploadCodeQuizFile={onUploadCodeQuizFile}
                onUpdateCodeQuiz={onUpdateCodeQuiz}
                onDeleteCodeQuizFile={onDeleteCodeQuizFile}
              />
            )
          })}
          <div className="new">
            {addingCodeQuiz ? (
              <div className="adding">コード設問を作成中</div>
            ) : (
              <Button
                variant="contained"
                onClick={() => {
                  setAddingCodeQuiz(true)
                  onCreateCodeQuiz().finally(() => {
                    setAddingCodeQuiz(false)
                  })
                }}
              >
                新規追加
              </Button>
            )}
          </div>
        </div>
      </CodeSection>
    </PageContainer>
  )
}
