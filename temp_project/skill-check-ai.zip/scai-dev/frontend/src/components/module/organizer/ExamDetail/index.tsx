import {
  Box,
  Breadcrumbs,
  Checkbox,
  Grid,
  Link,
  Paper,
} from '@material-ui/core'
import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import {
  OrganizationExaminationDetail,
  OrganizationExaminationHistory,
  OrganizationExaminationStat,
  OrganizationExaminationUser,
} from '../../../../types/domain'
import { organizerPaths } from '../../../../utils/paths'
import { formatDate } from '../../../../utils/time'
import { ExamTag } from '../../../ui/ExamTag'
import { PageContainer } from '../../../ui/PageContainer'
import { TextLink } from '../../../ui/TextLink'

type RecordType = OrganizationExaminationUser

type Props = {
  users: (query: Query<RecordType>) => Promise<QueryResult<RecordType>>
  exam: OrganizationExaminationDetail
  goToList?: () => void
  sortByScore?: boolean
  onChangeSortByScore?: (sort: boolean) => void
  stat?: OrganizationExaminationStat
  histories: OrganizationExaminationHistory[]
}

export const ExamDetail = ({
  users,
  exam,
  goToList,
  sortByScore = false,
  onChangeSortByScore,
  stat,
  histories,
}: Props) => {
  return (
    <PageContainer>
      {goToList && (
        <Box style={{ paddingBottom: 24 }}>
          <Breadcrumbs>
            <Link style={{ cursor: 'pointer' }} onClick={() => goToList()}>
              試験一覧に戻る
            </Link>
          </Breadcrumbs>
        </Box>
      )}
      <Grid style={{ padding: 24 }} component={Paper}>
        <Grid>
          <Box>
            <h3>{exam.name}</h3>
          </Box>
          <Box>
            <h4>説明文</h4>
            <Box>{exam.description}</Box>
          </Box>
          <Box>
            <h4>試験期間</h4>
            <Box>
              {formatDate(exam.start_date_time)} 〜
              {exam.end_date_time && formatDate(exam.end_date_time)}
            </Box>
          </Box>
          {stat && <Stat stat={stat} />}
        </Grid>
      </Grid>
      <Grid style={{ paddingTop: 24 }}>
        {histories && <Histories histories={histories} />}
      </Grid>
      <Grid style={{ paddingTop: 24 }}>
        <MaterialTable<RecordType>
          key={`t_${sortByScore ? 's' : 'd'}`}
          options={{
            pageSize: 50,
            pageSizeOptions: [20, 50, 100],
            search: false,
          }}
          title={
            <Box
              style={{ display: 'flex', width: '100%', alignItems: 'center' }}
            >
              <div style={{ paddingRight: 16, flexGrow: 1 }}>
                <h4>受験者一覧</h4>
              </div>
              <div style={{ paddingLeft: 20 }}>
                <Checkbox
                  checked={sortByScore}
                  onChange={(e) =>
                    onChangeSortByScore && onChangeSortByScore(e.target.checked)
                  }
                />
                スコア順にソート
              </div>
            </Box>
          }
          data={users}
          columns={[
            {
              field: 'id',
              title: 'ID',
              editable: 'never',
              width: '50px',
              sorting: false,
            },
            {
              field: 'name',
              title: '氏名',
              sorting: false,
              editable: 'never',
              render: (row) => (
                <TextLink to={organizerPaths.genUser(row.id)}>
                  {row.name}
                </TextLink>
              ),
            },
            {
              width: '120px',
              field: 'status',
              title: 'ステータス',
              sorting: false,
              render: (row) => <ExamTag status={row.status} />,
            },
            {
              field: 'score',
              title: '得点',
              editable: 'never',
              sorting: false,
              width: '100px',
            },
            {
              field: 'categories',
              title: 'カテゴリ別',
              sorting: false,
              width: '300px',
              render: (row) => {
                return (
                  <>
                    {row.scores.map((s, i) => {
                      return (
                        <Box key={`c_${i}`}>
                          <strong>{s.category_name}</strong>：{s.score}％
                        </Box>
                      )
                    })}
                  </>
                )
              },
            },
          ]}
        />
      </Grid>
    </PageContainer>
  )
}

type StatProps = {
  stat: OrganizationExaminationStat
}

const Stat = ({ stat }: StatProps) => (
  <Box>
    <h4>他組織の平均点</h4>
    <Box>平均点: {stat.average_score}</Box>
  </Box>
)

type HistoriesProps = {
  histories: OrganizationExaminationHistory[]
}

const Histories = ({ histories }: HistoriesProps) => {
  return (
    <Box>
      <MaterialTable<OrganizationExaminationHistory>
        options={{ search: false, paging: false }}
        data={histories}
        columns={[
          {
            field: 'name',
            title: 'タイトル',
            sorting: false,
          },
          {
            field: 'taken_users_count',
            title: (
              <Box>
                受験者数/
                <br />
                ライセンス数
              </Box>
            ),
            width: '120px',
            sorting: false,
            render: (row) => (
              <Box>
                {row.taken_users_count}/{row.license_users_count}
              </Box>
            ),
          },
          {
            field: 'average_score',
            title: '平均点',
            width: '120px',
            sorting: true,
          },
          {
            field: 'best_score',
            title: '最高点',
            width: '120px',
            sorting: true,
          },
          {
            field: 'worst_score',
            title: '最低点',
            width: '120px',
            sorting: true,
          },
          {
            field: 'term',
            title: '試験期間',
            width: '120px',
            sorting: false,
            render: (row) => (
              <div>
                <div>{formatDate(row.start_date_time)}〜</div>
                <div>{formatDate(row.end_date_time)}</div>
              </div>
            ),
          },
        ]}
        title={<h4>同じカテゴリーの試験結果</h4>}
      />
    </Box>
  )
}
