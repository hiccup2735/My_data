import * as React from 'react'
import { Link, LinkProps } from 'react-router-dom'
import * as H from 'history'
import { useTheme } from '@material-ui/core'

type Props = React.PropsWithoutRef<LinkProps<H.LocationState>> &
  React.RefAttributes<HTMLAnchorElement>

export const TextLink = (props: Props) => {
  const theme = useTheme()
  return (
    <Link
      style={{ color: theme.palette.primary.main, textDecoration: 'none' }}
      {...props}
    />
  )
}
