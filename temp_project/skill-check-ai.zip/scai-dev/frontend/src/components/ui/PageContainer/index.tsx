import { Box, Container, useMediaQuery } from '@material-ui/core'
import * as React from 'react'
import { Copyright } from '../Copyright'

type Props = {
  children: React.ReactNode
}

export const PageContainer = ({ children }: Props) => {
  const print = useMediaQuery('print')

  if (print) {
    return (
      <Box style={{ padding: '24px' }}>
        {children}
        <Copyright />
      </Box>
    )
  }

  return (
    <Container>
      <Box style={{ padding: '32px 96px 24px 96px' }}>
        {children}
        <Copyright />
      </Box>
    </Container>
  )
}
