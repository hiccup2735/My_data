import {
  AppBar,
  IconButton,
  Menu,
  MenuItem,
  Toolbar,
  Typography,
} from '@material-ui/core'
import MenuIcon from '@material-ui/icons/Menu'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { OperatorContext } from '../../../../contexts/OperatorContext'
import { operatorPaths } from '../../../../utils/paths'

export const OperatorHeader = () => {
  const [anchorEl, setAnchorEl] = React.useState(null)
  const history = useHistory()
  const { logout } = React.useContext(OperatorContext)

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const goTo = (location: string) => {
    history.push(location)
    handleClose()
  }

  return (
    <AppBar color="default">
      <Toolbar>
        <IconButton
          edge="start"
          color="inherit"
          aria-label="menu"
          aria-controls="admin-header-menu"
          aria-haspopup="true"
          onClick={handleClick}
        >
          <MenuIcon />
        </IconButton>
        <Menu
          id="admin-header-menu"
          anchorEl={anchorEl}
          keepMounted
          open={Boolean(anchorEl)}
          onClose={handleClose}
        >
          <MenuItem onClick={() => goTo(operatorPaths.users)}>
            ユーザーの一覧
          </MenuItem>
          <MenuItem onClick={() => goTo(operatorPaths.examinations)}>
            試験の管理
          </MenuItem>
          <MenuItem onClick={() => goTo(operatorPaths.organizations)}>
            組織の管理
          </MenuItem>
          <MenuItem onClick={() => goTo(operatorPaths.organizationCategories)}>
            組織カテゴリの管理
          </MenuItem>
          <MenuItem
            onClick={() => {
              logout && logout()
            }}
          >
            ログアウト
          </MenuItem>
        </Menu>
        <Typography variant="h6">オペレーター</Typography>
      </Toolbar>
    </AppBar>
  )
}
