import { Box } from '@material-ui/core'
import styled from '@emotion/styled'

export const AdminSection = styled(Box)`
  margin-bottom: 24px;
`
