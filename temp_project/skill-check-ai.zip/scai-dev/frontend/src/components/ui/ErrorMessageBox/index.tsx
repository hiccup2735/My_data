import styled from '@emotion/styled'
import { colors } from '../../../utils/theme'

export const ErrorMessageBox = styled.div`
  color: ${colors.alert};
  padding-top: 4px;
  padding-bottom: 4px;
  min-height: 32px;
  line-height: 24px;
  box-sizing: border-box;
`
