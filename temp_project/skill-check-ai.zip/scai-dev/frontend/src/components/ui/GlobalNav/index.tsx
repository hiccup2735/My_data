import {
  AppBar,
  Box,
  IconButton,
  Menu,
  MenuItem,
  Toolbar,
} from '@material-ui/core'
import AccountCircle from '@material-ui/icons/AccountCircle'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { UserContext } from '../../../contexts/UserContext'
import { paths } from '../../../utils/paths'
import { colors } from '../../../utils/theme'
import logo from './logo.svg'

export const GlobalNav = () => {
  const { logout, authenticated } = React.useContext(UserContext)

  const [anchorEl, setAnchorEl] = React.useState<HTMLElement | null>(null)
  const open = Boolean(anchorEl)

  const history = useHistory()

  const handleClose = () => {
    setAnchorEl(null)
  }

  return (
    <AppBar
      color="default"
      style={{ backgroundColor: colors.background }}
      className="no_print"
    >
      <Toolbar>
        <div style={{ flexGrow: 1 }}>
          <Box
            style={{ cursor: 'pointer' }}
            onClick={() => {
              history.push(paths.root)
            }}
          >
            <img alt="logo" src={logo} height="32px" width="auto" />
          </Box>
        </div>
        <div style={{ visibility: authenticated ? 'visible' : 'hidden' }}>
          <IconButton
            aria-label="account of current user"
            aria-controls="menu-appbar"
            aria-haspopup="true"
            onClick={(event) => {
              setAnchorEl(event.currentTarget)
            }}
            color="inherit"
          >
            <AccountCircle />
          </IconButton>
          <Menu
            id="menu-appbar"
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            keepMounted
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={open}
            onClose={handleClose}
          >
            <MenuItem
              onClick={() => {
                history.push(paths.setting)
                handleClose()
              }}
            >
              ユーザー設定
            </MenuItem>
            <MenuItem
              onClick={() => {
                logout &&
                  logout(() => {
                    history.replace(paths.root)
                  })
                handleClose()
              }}
            >
              ログアウト
            </MenuItem>
          </Menu>
        </div>
      </Toolbar>
    </AppBar>
  )
}
