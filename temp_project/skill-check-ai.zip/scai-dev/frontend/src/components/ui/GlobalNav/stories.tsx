import React from 'react'
import { GlobalNav } from '.'

export default {
  component: GlobalNav,
  title: 'ui/GlobalNav',
}

export const Default = () => <GlobalNav />
