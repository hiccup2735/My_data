import { Button, Modal, Paper, Box } from '@material-ui/core'
import * as React from 'react'
import styled from '@emotion/styled'

const StyledPaper = styled(Paper)`
  :focus {
    outline: none;
  }
`

type Props = {
  open: boolean
  label: React.ReactNode
  onConfirm?: () => void
  confirmText?: string
  onCancel?: () => void
  cancelText?: string
  closable?: boolean
}

export const Confirm = ({
  open,
  closable = true,
  label,
  onConfirm,
  confirmText = 'OK',
  onCancel,
  cancelText = 'キャンセル',
}: Props) => (
  <div>
    <Modal
      open={open}
      disableBackdropClick={!closable}
      disableEscapeKeyDown={!closable}
      onEscapeKeyDown={() => onCancel && onCancel()}
      onBackdropClick={() => onCancel && onCancel()}
    >
      <StyledPaper
        style={{
          top: '50%',
          left: '50%',
          width: '400px',
          position: 'absolute',
          transform: 'translate(-50%, -50%)',
          padding: 24,
        }}
      >
        <Box style={{ paddingBottom: 24 }}>{label}</Box>
        <Box style={{ textAlign: 'right' }}>
          {onCancel && (
            <Button
              style={{ marginRight: onConfirm ? 8 : 0 }}
              variant="contained"
              onClick={() => onCancel()}
            >
              {cancelText}
            </Button>
          )}
          {onConfirm && (
            <Button
              variant="contained"
              onClick={() => onConfirm()}
              color="primary"
            >
              {confirmText}
            </Button>
          )}
        </Box>
      </StyledPaper>
    </Modal>
  </div>
)
