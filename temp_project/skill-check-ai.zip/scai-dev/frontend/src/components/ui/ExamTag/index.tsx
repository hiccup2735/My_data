import { CSSProperties } from '@material-ui/core/styles/withStyles'
import * as React from 'react'
import { ExaminationStatus } from '../../../types/domain'
import { colors } from '../../../utils/theme'

type Props = {
  status: ExaminationStatus
}

export const ExamTag = ({ status }: Props) => {
  const tagStyle: CSSProperties = {
    width: '100%',
    backgroundColor: '#ea3838',
    borderRadius: 4,
    fontSize: '14px',
    textAlign: 'center',
    color: 'white',
  }
  let label = '未受験'
  if (status === 'answering') {
    label = '受験中'
  } else if (status === 'expired') {
    label = '期限切れ'
    tagStyle.backgroundColor = colors.hint
  } else if (status === 'finished') {
    label = '受験済み'
    tagStyle.backgroundColor = '#50667a'
  } else if (status === 'before') {
    label = '開始前'
    tagStyle.backgroundColor = colors.hint
  } else if (status === 'scoring') {
    label = '採点中'
    tagStyle.backgroundColor = colors.hint
  }

  return <div style={tagStyle}>{label}</div>
}
