import {
  AppBar,
  IconButton,
  Menu,
  MenuItem,
  Toolbar,
  Typography,
} from '@material-ui/core'
import MenuIcon from '@material-ui/icons/Menu'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { ManagerContext } from '../../../../contexts/ManagerContext'
import { managerPaths } from '../../../../utils/paths'

export const ManagerHeader = () => {
  const [anchorEl, setAnchorEl] = React.useState(null)
  const history = useHistory()
  const { logout } = React.useContext(ManagerContext)

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const goTo = (location: string) => {
    history.push(location)
    handleClose()
  }

  return (
    <AppBar color="default">
      <Toolbar>
        <IconButton
          edge="start"
          color="inherit"
          aria-label="menu"
          aria-controls="admin-header-menu"
          aria-haspopup="true"
          onClick={handleClick}
        >
          <MenuIcon />
        </IconButton>
        <Menu
          id="admin-header-menu"
          anchorEl={anchorEl}
          keepMounted
          open={Boolean(anchorEl)}
          onClose={handleClose}
        >
          <MenuItem onClick={() => goTo(managerPaths.users)}>
            ユーザーの管理
          </MenuItem>
          <MenuItem onClick={() => goTo(managerPaths.examinations)}>
            試験の管理
          </MenuItem>
          <MenuItem onClick={() => goTo(managerPaths.questions)}>
            問の管理
          </MenuItem>
          <MenuItem onClick={() => goTo(managerPaths.questionCategories)}>
            問カテゴリの管理
          </MenuItem>
          <MenuItem onClick={() => goTo(managerPaths.organizations)}>
            組織の管理
          </MenuItem>
          <MenuItem onClick={() => goTo(managerPaths.organizationCategories)}>
            組織カテゴリの管理
          </MenuItem>
          <MenuItem
            onClick={() => {
              logout && logout()
            }}
          >
            ログアウト
          </MenuItem>
        </Menu>
        <Typography variant="h6">サービス管理者</Typography>
      </Toolbar>
    </AppBar>
  )
}
