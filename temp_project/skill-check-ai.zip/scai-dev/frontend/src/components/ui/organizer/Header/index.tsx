import {
  AppBar,
  IconButton,
  Menu,
  MenuItem,
  Toolbar,
  Typography,
} from '@material-ui/core'
import MenuIcon from '@material-ui/icons/Menu'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { OrganizerContext } from '../../../../contexts/OrganizerContext'
import { organizerPaths } from '../../../../utils/paths'

export const OrganizerHeader = () => {
  const [anchorEl, setAnchorEl] = React.useState(null)
  const history = useHistory()
  const { logout } = React.useContext(OrganizerContext)

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const goTo = (location: string) => {
    history.push(location)
    handleClose()
  }

  return (
    <AppBar color="default">
      <Toolbar>
        <IconButton
          edge="start"
          color="inherit"
          aria-label="menu"
          aria-controls="admin-header-menu"
          aria-haspopup="true"
          onClick={handleClick}
        >
          <MenuIcon />
        </IconButton>
        <Menu
          id="admin-header-menu"
          anchorEl={anchorEl}
          keepMounted
          open={Boolean(anchorEl)}
          onClose={handleClose}
        >
          <MenuItem onClick={() => goTo(organizerPaths.root)}>
            試験一覧
          </MenuItem>
          <MenuItem onClick={() => goTo(organizerPaths.users)}>
            ユーザー一覧
          </MenuItem>
          <MenuItem
            onClick={() => {
              logout && logout()
            }}
          >
            ログアウト
          </MenuItem>
        </Menu>
        <Typography variant="h6">SCAI 企業管理者ツール</Typography>
      </Toolbar>
    </AppBar>
  )
}
