import styled from '@emotion/styled'
import { colors } from '../../../utils/theme'

export const ClickableText = styled.span`
  cursor: pointer;
  color: ${colors.text};

  &:hover {
    color: ${colors.primary};
    text-decoration: underline;
  }
`
