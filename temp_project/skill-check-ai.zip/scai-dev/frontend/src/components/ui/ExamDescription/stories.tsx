import React from 'react'
import { ExamDescription } from '.'

export default {
  component: ExamDescription,
  title: 'ui/ExamDescription',
}

/* eslint-disable no-useless-escape */
const sampleText = `ディープラーニングに関連した手法であるオートエンコーダは、エンコーダとデコーダによって構成される。入力、隠れ層のアクティベーション、出力をそれぞれ$\\mathbm{x}$, $\\mathbm{h}$, $\\mathbm{x'}$とし、エンコーダにおける活性化関数を$\\sigma$, 重み行列を$\\mathbf{W}$, バイアスを$\\mathbf{b}$とする。
また、デコーダにおける活性化関数を$\\sigma'$, 重み行列を$\\mathbf{W'}$, バイアスを$\\mathbf{b'}$とする。このとき、オートエンコーダの学習時に最小化すべき数式を以下から選びなさい。`

const formula = `$\\parallel \\mathbf{x} - \\sigma' (\\mathbf{W'}(\\mathbf{\\sigma (\\mathbf{W}\\mathbf{x}+\\mathbf{b})})+\\mathbf{b'}) \\parallel ^2$`

export const Default = () => (
  <>
    <ExamDescription text={sampleText} />
    <ExamDescription text={formula} />
  </>
)
