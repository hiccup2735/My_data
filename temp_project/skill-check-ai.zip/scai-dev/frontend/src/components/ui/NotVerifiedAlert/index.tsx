import { Box, Button } from '@material-ui/core'
import { Alert } from '@material-ui/lab'
import * as React from 'react'
import { User } from '../../../types/domain'

type Props = {
  user?: User
  onRequestVerify?: () => void
}

export const NotVerifiedAlert = ({ user, onRequestVerify }: Props) => {
  return (
    <>
      {user && !user.is_verified && (
        <Box>
          <Alert
            severity="error"
            action={
              <Button
                style={{ minWidth: 200 }}
                variant="outlined"
                color="secondary"
                onClick={() => onRequestVerify && onRequestVerify()}
              >
                確認メールを送信する
              </Button>
            }
          >
            メールアドレスの確認が完了していません。受験にはメールアドレスの確認が必要となります。
          </Alert>
        </Box>
      )}
    </>
  )
}
