import * as React from 'react'

type Props = {
  url: string
}

export const ImageView = ({ url }: Props) => {
  return (
    <>
      <div
        style={{
          width: 'auto',
          height: '300px',
          backgroundSize: 'contain',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          backgroundImage: `url(${url})`,
        }}
      />
    </>
  )
}
