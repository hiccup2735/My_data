import { MenuItem, Select as MuiSelect } from '@material-ui/core'
import * as React from 'react'
import { CSSProperties, ReactNode } from 'react'

type OptionValue<TValue> = {
  label: ReactNode
  value: TValue
}

type Props<TValue> = {
  options: OptionValue<TValue>[]
  value?: TValue
  onChange?: (value: TValue) => void
  disabled?: boolean
  placeholder?: string
  isDisabled?: (option: OptionValue<TValue>) => boolean
  fullWidth?: boolean
  style?: CSSProperties
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function isNumber(item: any): item is number {
  return typeof item === 'number'
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function isString(item: any): item is string {
  return typeof item === 'string'
}

export function Select({
  options,
  value,
  onChange,
  disabled,
  placeholder,
  isDisabled,
  fullWidth = true,
  style,
}: Props<number | string>) {
  return (
    <MuiSelect
      style={style}
      value={value}
      placeholder={placeholder}
      variant="outlined"
      fullWidth={fullWidth}
      disabled={disabled}
      onChange={(e) => {
        const value = e.target.value
        if (isNumber(value) || isString(value)) {
          onChange && onChange(value)
        }
      }}
    >
      {options.map((o, i) => (
        <MenuItem
          disabled={isDisabled ? isDisabled(o) : false}
          key={`o_${i}`}
          value={o.value}
          selected={value === o.value}
        >
          {o.label}
        </MenuItem>
      ))}
    </MuiSelect>
  )
}
