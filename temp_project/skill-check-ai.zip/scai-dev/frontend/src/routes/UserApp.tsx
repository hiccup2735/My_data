import styled from '@emotion/styled'
import { ThemeProvider } from '@material-ui/core'
import * as React from 'react'
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import { Dashboard } from '../components/page/Dashboard'
import { ExamDetail } from '../components/page/ExamDetail'
import { ForgetPasswordContainer } from '../components/page/ForgetPassword'
import { LoginContainer } from '../components/page/Login'
import { LogoutContainer } from '../components/page/Logout'
import { ResetPasswordContainer } from '../components/page/ResetPassword'
import { SettingContainer } from '../components/page/Setting'
import { SignupContainer } from '../components/page/Signup'
import { VerifyEmailContainer } from '../components/page/VerifyEmail'
import { GlobalNav } from '../components/ui/GlobalNav'
import { UserContext, UserProvider } from '../contexts/UserContext'
import { adminRegexp, organizerRegexp, operatorRegexp, paths, managerRegexp } from '../utils/paths'
import { muiTheme } from '../utils/theme'

const StyledDiv = styled.div`
  padding-top: 64px;

  @media print {
    padding-top: 0px;
  }
`

export const Routes = () => {
  const { authenticated } = React.useContext(UserContext)

  if (!authenticated) {
    return (
      <BrowserRouter>
        <GlobalNav />
        <StyledDiv>
          <Switch>
            <Route
              component={VerifyEmailContainer}
              path={paths.verifyEmail}
              exact
            />
            <Route
              component={ResetPasswordContainer}
              path={paths.resetPassword}
              exact
            />
            <Route
              component={ForgetPasswordContainer}
              path={paths.forgetPassword}
              exact
            />
            <Route component={SignupContainer} path={paths.signup} exact />
            <Route component={LoginContainer} />
          </Switch>
        </StyledDiv>
      </BrowserRouter>
    )
  }

  return (
    <BrowserRouter>
      <GlobalNav />
      <StyledDiv>
        <Switch>
          <Route
            component={VerifyEmailContainer}
            path={paths.verifyEmail}
            exact
          />
          <Route
            component={ResetPasswordContainer}
            path={paths.resetPassword}
            exact
          />
          <Route component={LogoutContainer} path={paths.logout} exact />
          <Route component={SettingContainer} path={paths.setting} exact />
          <Route
            render={(props) => <ExamDetail {...props} />}
            path={paths.examination}
          />
          <Route component={Dashboard} />
        </Switch>
      </StyledDiv>
    </BrowserRouter>
  )
}

export const UserApp = () => {
  if (
    adminRegexp.test(window.location.pathname) ||
    organizerRegexp.test(window.location.pathname) || 
    operatorRegexp.test(window.location.pathname) ||
    managerRegexp.test(window.location.pathname)
  ) {
    return null
  }

  return (
    <UserProvider>
      <ThemeProvider theme={muiTheme}>
        <BrowserRouter>
          <Routes />
        </BrowserRouter>
      </ThemeProvider>
    </UserProvider>
  )
}
