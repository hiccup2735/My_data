import { ThemeProvider } from '@material-ui/core'
import * as React from 'react'
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import { OrganizerExaminations } from '../components/page/organizer/Examinations'
import { OrgExamDetail } from '../components/page/organizer/Examinations/ExamDetail'
import { OrganizerLogin } from '../components/page/organizer/Login'
import { OrgUsers } from '../components/page/organizer/Users'
import { OrgUserDetail } from '../components/page/organizer/Users/OrgUserDetail'
import { AdminPageContainer } from '../components/ui/admin/PageContainer'
import { OrganizerHeader } from '../components/ui/organizer/Header'
import {
  OrganizerContext,
  OrganizerProvider,
} from '../contexts/OrganizerContext'
import { organizerPaths, organizerRegexp } from '../utils/paths'
import { organizerTheme } from '../utils/theme'

export const OrganizerRoutes = () => {
  const { authenticated } = React.useContext(OrganizerContext)

  React.useEffect(() => {
    document.title = 'SCAI 企業管理者ツール'
  }, [])

  if (!authenticated) {
    return (
      <Switch>
        <Route component={OrganizerLogin} />
      </Switch>
    )
  }

  return (
    <>
      <OrganizerHeader />
      <AdminPageContainer maxWidth="xl">
        <Switch>
          <Route path={organizerPaths.examination} component={OrgExamDetail} />
          <Route path={organizerPaths.user} component={OrgUserDetail} />
          <Route path={organizerPaths.users} component={OrgUsers} />
          <Route path={organizerPaths.root} component={OrganizerExaminations} />
        </Switch>
      </AdminPageContainer>
    </>
  )
}

export const OrganizerApp = () => {
  if (!organizerRegexp.test(window.location.pathname)) {
    return null
  }
  return (
    <OrganizerProvider>
      <ThemeProvider theme={organizerTheme}>
        <BrowserRouter>
          <OrganizerRoutes />
        </BrowserRouter>
      </ThemeProvider>
    </OrganizerProvider>
  )
}
