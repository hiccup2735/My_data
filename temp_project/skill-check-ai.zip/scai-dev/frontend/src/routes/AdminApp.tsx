import { ThemeProvider } from '@material-ui/core'
import * as React from 'react'
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import { AdminExaminations } from '../components/page/admin/Examinations'
import { AdminCreateExamination } from '../components/page/admin/Examinations/CreateExamination'
import { AdminExamDetail } from '../components/page/admin/Examinations/ExamDetail'
import { AdminLogin } from '../components/page/admin/Login'
import { AdminOrganizationCategories } from '../components/page/admin/OrganizationCategories'
import { AdminOrganizationLicenses } from '../components/page/admin/OrganizationLicenses'
import { AdminOrganizationOrganizers } from '../components/page/admin/OrganizationOrganizers'
import { AdminOrganizations } from '../components/page/admin/Organizations'
import { AdminOrganizationUsers } from '../components/page/admin/OrganizationUsers'
import { AdminQuestionCategories } from '../components/page/admin/QuestionCategories'
import { AdminQuestions } from '../components/page/admin/Questions'
import { AdminQuestionDetail } from '../components/page/admin/Questions/QuestionDetail'
import { AdminUsers } from '../components/page/admin/Users'
import { AdminUserDetail } from '../components/page/admin/Users/UserDetail'
import { AdminHeader } from '../components/ui/admin/Header'
import { AdminPageContainer } from '../components/ui/admin/PageContainer'
import { AdminContext, AdminProvider } from '../contexts/AdminContext'
import { adminPaths, adminRegexp } from '../utils/paths'
import { adminTheme } from '../utils/theme'
import { AdminOperators } from '../components/page/admin/Operators'
import { AdminManagers } from '../components/page/admin/Managers'

export const AdminRoutes = () => {
  const { authenticated } = React.useContext(AdminContext)

  React.useEffect(() => {
    document.title = 'SCAI サービス管理者ツール'
  }, [])

  if (!authenticated) {
    return (
      <Switch>
        <Route component={AdminLogin} />
      </Switch>
    )
  }

  return (
    <>
      <AdminHeader />
      <AdminPageContainer maxWidth="xl">
        <Switch>
          <Route path={adminPaths.user} component={AdminUserDetail} />
          <Route path={adminPaths.users} component={AdminUsers} />
          <Route
            path={adminPaths.organizationOrganizers}
            component={AdminOrganizationOrganizers}
          />

          <Route
            path={adminPaths.organizationUser}
            component={AdminUserDetail}
          />
          <Route
            path={adminPaths.organizationUsers}
            component={AdminOrganizationUsers}
          />
          <Route
            path={adminPaths.organizationLicenses}
            component={AdminOrganizationLicenses}
          />
          <Route
            path={adminPaths.organizationCategories}
            component={AdminOrganizationCategories}
          />
          <Route
            path={adminPaths.organizations}
            component={AdminOrganizations}
          />
          <Route
            path={adminPaths.questionCategories}
            component={AdminQuestionCategories}
          />
          <Route
            path={adminPaths.createExamination}
            component={AdminCreateExamination}
          />
          <Route path={adminPaths.examination} component={AdminExamDetail} />
          <Route path={adminPaths.examinations} component={AdminExaminations} />
          <Route path={adminPaths.question} component={AdminQuestionDetail} />
          <Route path={adminPaths.questions} component={AdminQuestions} />
          <Route path={adminPaths.operators} component={AdminOperators} />
          <Route path={adminPaths.managers} component={AdminManagers} />
          <Route path={adminPaths.root} component={AdminExaminations} />
        </Switch>
      </AdminPageContainer>
    </>
  )
}

export const AdminApp = () => {
  if (!adminRegexp.test(window.location.pathname)) {
    return null
  }

  return (
    <AdminProvider>
      <ThemeProvider theme={adminTheme}>
        <BrowserRouter>
          <AdminRoutes />
        </BrowserRouter>
      </ThemeProvider>
    </AdminProvider>
  )
}
