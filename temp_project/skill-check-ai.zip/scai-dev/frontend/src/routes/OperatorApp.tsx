import { ThemeProvider } from '@material-ui/core'
import * as React from 'react'
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import { AdminExaminations } from '../components/page/admin/Examinations'
import { AdminOrganizationCategories } from '../components/page/admin/OrganizationCategories'
import { AdminOrganizationLicenses } from '../components/page/admin/OrganizationLicenses'
import { AdminOrganizationOrganizers } from '../components/page/admin/OrganizationOrganizers'
import { AdminOrganizations } from '../components/page/admin/Organizations'
import { AdminOrganizationUsers } from '../components/page/admin/OrganizationUsers'
import { AdminUsers } from '../components/page/admin/Users'
import { AdminUserDetail } from '../components/page/admin/Users/UserDetail'
import { OperatorLogin } from '../components/page/operator/Login'
import { AdminPageContainer } from '../components/ui/admin/PageContainer'
import { OperatorContext, OperatorProvider } from '../contexts/OperatorContext'
import { operatorPaths, operatorRegexp } from '../utils/paths'
import { adminTheme } from '../utils/theme'
import { OperatorHeader } from '../components/ui/operator/Header'
import { AdminExamDetail } from '../components/page/admin/Examinations/ExamDetail'

export const OperatorRoutes = () => {
  const { authenticated } = React.useContext(OperatorContext)

  React.useEffect(() => {
    document.title = 'SCAI オペレーター管理ツール'
  }, [])

  if (!authenticated) {
    return (
      <Switch>
        <Route component={OperatorLogin} />
      </Switch>
    )
  }

  return (
    <>
      <OperatorHeader />
      <AdminPageContainer maxWidth="xl">
        <Switch>
          <Route path={operatorPaths.user} component={AdminUserDetail} />
          <Route path={operatorPaths.users} component={AdminUsers} />
          <Route
            path={operatorPaths.organizationOrganizers}
            component={AdminOrganizationOrganizers}
          />
          <Route
            path={operatorPaths.organizationUser}
            component={AdminUserDetail}
          />
          <Route
            path={operatorPaths.organizationUsers}
            component={AdminOrganizationUsers}
          />
          <Route
            path={operatorPaths.organizationLicenses}
            component={AdminOrganizationLicenses}
          />
          <Route
            path={operatorPaths.organizationCategories}
            component={AdminOrganizationCategories}
          />
          <Route
            path={operatorPaths.organizations}
            component={AdminOrganizations}
          />
          <Route path={operatorPaths.examination} component={AdminExamDetail} />
          <Route path={operatorPaths.root} component={AdminExaminations} />
        </Switch>
      </AdminPageContainer>
    </>
  )
}

export const OperatorApp = () => {
  if (!operatorRegexp.test(window.location.pathname)) {
    return null
  }

  return (
    <OperatorProvider>
      <ThemeProvider theme={adminTheme}>
        <BrowserRouter>
          <OperatorRoutes />
        </BrowserRouter>
      </ThemeProvider>
    </OperatorProvider>
  )
}
