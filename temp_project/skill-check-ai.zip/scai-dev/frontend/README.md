## SCAI frontend

### 各種パス

#### パスワードのリセット

/reset?reset_token=[reset_token]

#### メールアドレスの検証

/verify?verify_token=[verify_token]

### deploy

frontend ディレクトリで以下のコマンドを実行し、frontend/build ディレクトリ以下の成果物を公開してください

```
$ yarn
$ yarn build
```

### ローカルでの動作確認

#### frontend

```
$ yarn
$ PORT=3001 yarn start
```

#### backend

api/nginx/nginx.conf を以下のように書き換えて docker-compose up

```
    location / {
      proxy_pass http://host.docker.internal:3001;
    }
```

#### admin

https://local.skill-check-ai.com/adm

pass: Passw0rd!
email: admin@example.com

#### organizer

https://local.skill-check-ai.com/org

pass: Passw0rd!
email: organizer_1@example.com

### docker basic 認証

user: scai-user
password: 9!hv[TI6
