# Terraform
インフラ構成のコードを管理するディレクトリ

## システム構成図
![システム構成図](architecture.png)

## 依存
| ソフトフェア | バージョン | 公式サイト |
| --- | --- | --- |
| Terraform | 0.12.29 | https://www.terraform.io/ |
| Terraform AWS Provider | ~> 2.70.0 | https://registry.terraform.io/providers/hashicorp/aws/2.70.0 |

## 手順
### 事前作業
terraformを利用する前に必要となる作業

1. terraform実行用ユーザーを作成
    - 管理者権限を持ったユーザーの作成
1. terraform backend用のS3バケットを作成
    - バージョニングを有効にする
    - バケット名は `scai-${var.ENV}-tfstate`
1. route53のホストゾーンを作成
   
### 初期化
terraform init時のコマンド
- backendのS3バケットの指定が必要
```sh
terraform init -backend-config="bucket=scai-${var.ENV}-tfstate"
```
