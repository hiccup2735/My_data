package image

import (
	"fmt"
	"github.com/disintegration/imaging"
	"image"
	_ "image/gif"
	_ "image/jpeg"
	"image/png"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"os"
)

// Resize 画像リサイズ
func Resize(inputPath string, outputPath string, size int) (err error) {
	inputFile, err := os.Open(inputPath)
	if err != nil {
		return err
	}
	defer func() {
		closeErr := inputFile.Close()
		if closeErr != nil {
			err = fmt.Errorf("failed to close: %v (error: %v)", closeErr, err)
		}
	}()
	inputImage, imageType, err := image.Decode(inputFile)
	if err != nil {
		return err
	}
	if imageType != "png" {
		return fmt.Errorf("invalid iamge type")
	}
	outputImage := inputImage
	if size != 0 {
		width := 0
		height := 0
		bounds := inputImage.Bounds()
		if bounds.Dx() > bounds.Dy() {
			width = size
		} else {
			height = size
		}
		outputImage = imaging.Resize(inputImage, width, height, imaging.Lanczos)
	}
	outputFile, err := os.Create(outputPath)
	if err != nil {
		return err
	}
	defer func() {
		closeErr := outputFile.Close()
		if closeErr != nil {
			err = fmt.Errorf("failed to close: %v (error: %v)", closeErr, err)
		}
	}()
	if err := png.Encode(outputFile, outputImage); err != nil {
		return err
	}
	return nil
}

// Download ファイルをダウンロードして保存
func Download(uri string, filepath string) (err error) {
	response, err := http.Get(uri)
	if err != nil {
		return err
	}
	defer func() {
		closeErr := response.Body.Close()
		if closeErr != nil {
			err = fmt.Errorf("failed to close: %v (error: %v)", closeErr, err)
		}
	}()
	if response.StatusCode != 200 {
		body, err := ioutil.ReadAll(response.Body)
		if err != nil {
			return err
		}
		return fmt.Errorf(string(body))
	}
	file, err := os.Create(filepath)
	if err != nil {
		return err
	}
	if _, err := io.Copy(file, response.Body); err != nil {
		return err
	}
	return nil
}

func Detect(f multipart.File) (string, error) {
	_, format, err := image.DecodeConfig(f)
	if err != nil {
		return "", err
	}
	return format, nil
}
