package admin

import "app/model"

type questionExaminationResponse struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

type questionMetadataResponse struct {
	Key   string `json:"key"`
	Value string `json:"value"`
}

type QuestionResponse struct {
	ID          int                        `json:"id"`
	Name        string                     `json:"name"`
	Description string                     `json:"description"`
	ImageURI    string                     `json:"image_uri"`
	Level       int                        `json:"level"`
	Tags        []string                   `json:"tags"`
	Metadata    []questionMetadataResponse `json:"metadata"`
	Group       int                        `json:"group"`
}

type QuestionIndexResponse struct {
	QuestionResponse
	AnswerCount        int     `json:"answer_count"`
	CorrectAnswerCount int     `json:"correct_answer_count"`
	CorrectAnswerRate  float64 `json:"correct_answer_rate"`
}

type QuestionDetailResponse struct {
	QuestionResponse
	Quizzes      []*model.Quiz                 `json:"quizzes"`
	CodeQuizzes  []*model.CodeQuiz             `json:"code_quizzes"`
	Examinations []questionExaminationResponse `json:"examinations"`
}

func toQuestionResponse(question *model.Question) QuestionResponse {
	tags := make([]string, len(question.Tags))
	for i, t := range question.Tags {
		tags[i] = t.Name
	}

	metadata := make([]questionMetadataResponse, len(question.Metadata))
	for i, m := range question.Metadata {
		metadata[i] = questionMetadataResponse{
			Key:   m.Key,
			Value: m.Value,
		}
	}

	return QuestionResponse{
		ID:          question.ID,
		Name:        question.Name,
		Description: question.Description,
		ImageURI:    question.ImageURI,
		Level:       question.Level,
		Tags:        tags,
		Metadata:    metadata,
		Group:       question.Group,
	}
}

type QuestionPresenter struct{}

func (*QuestionPresenter) ToIndexResponses(questions []*model.QuestionSummary) []QuestionIndexResponse {
	ress := make([]QuestionIndexResponse, len(questions))
	for i, q := range questions {
		println(q.GetCorrectAnswerRate())
		ress[i] = QuestionIndexResponse{
			QuestionResponse:   toQuestionResponse(q.Question),
			AnswerCount:        q.AnswerCount,
			CorrectAnswerCount: q.CorrectAnswerCount,
			CorrectAnswerRate:  q.GetCorrectAnswerRate(),
		}
	}

	return ress
}

func (*QuestionPresenter) ToDetailResponse(question *model.Question) QuestionDetailResponse {
	exams := make([]questionExaminationResponse, len(question.Examinations))
	for i, e := range question.Examinations {
		exams[i] = questionExaminationResponse{
			ID:   e.ID,
			Name: e.Name,
		}
	}

	return QuestionDetailResponse{
		QuestionResponse: toQuestionResponse(question),
		Quizzes:          question.Quizzes,
		CodeQuizzes:      question.CodeQuizzes,
		Examinations:     exams,
	}
}

type questionSummaryResponse struct {
	ID          int                        `json:"id"`
	Name        string                     `json:"name"`
	Description string                     `json:"description"`
	ImageURI    string                     `json:"image_uri"`
	Level       int                        `json:"level"`
	Tags        []string                   `json:"tags"`
	Metadata    []questionMetadataResponse `json:"metadata"`
}

type examinationQuestionIndex struct {
	questionSummaryResponse
	CategoryID int `json:"category_id"`
}

func toExaminationQuestionIndexResponse(examQuess []*model.ExaminationQuestion) (rs []examinationQuestionIndex) {
	for _, examQues := range examQuess {
		rs = append(rs, examinationQuestionIndex{
			questionSummaryResponse: questionSummaryResponse{
				ID:          examQues.Question.ID,
				Name:        examQues.Question.Name,
				Description: examQues.Question.Description,
				ImageURI:    examQues.Question.ImageURI,
			},
			CategoryID: examQues.CategoryID,
		})
	}
	return rs
}
