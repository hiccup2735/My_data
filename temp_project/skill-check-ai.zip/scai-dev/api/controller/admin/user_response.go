package admin

import (
	"app/model"
	"time"
)

type UserResponse struct {
	ID               int    `json:"id"`
	Name             string `json:"name"`
	Email            string `json:"email"`
	OrganizationName string `json:"organization_name"`
	ExaminationCount int    `json:"examination_count"`
	IsInvited        bool   `json:"is_invited"`
}

type UserIndexResponse struct {
	UserResponse
}

func toUserResponses(users []*model.User) []UserResponse {
	responses := make([]UserResponse, len(users))
	for i, user := range users {
		responses[i] = toUserResponse(user)
	}
	return responses
}

func toUserResponse(user *model.User) UserResponse {
	orgName := ""
	if user.Organization != nil {
		orgName = user.Organization.Name
	}
	return UserResponse{
		ID:               user.ID,
		Name:             user.Name,
		Email:            user.Email,
		OrganizationName: orgName,
		ExaminationCount: len(user.Examinations),
		IsInvited:        user.LastLoginAt != nil,
	}
}

type UserPresenter struct{}

func (*UserPresenter) ToIndexResponse(users []*model.User) []UserIndexResponse {
	ress := make([]UserIndexResponse, len(users))
	for i, u := range users {
		ress[i] = UserIndexResponse{
			UserResponse: toUserResponse(u),
		}
	}

	return ress
}

type UserDetailResponse struct {
	UserResponse
	Examinations []UserExaminationResponse `json:"examinations"`
}

type UserExaminationResponse struct {
	ID         int                    `json:"id"`
	Name       string                 `json:"name"`
	Status     string                 `json:"status"`
	Score      int                    `json:"score"`
	Group      int                    `json:"group"`	
	Scores     []*model.ScoreResponse `json:"scores"`
	StartedAt  *time.Time             `json:"started_at"`
	FinishedAt *time.Time             `json:"finished_at"`
}

func toUserDetailResponse(user *model.User) UserDetailResponse {
	responses := make([]UserExaminationResponse, len(user.UserExaminations))
	for i, exam := range user.UserExaminations {
		// TODO: error handling
		_ = exam.GetExaminationAnswers()
		status, _ := exam.Status()
		score := 0
		var scoreResponses []*model.ScoreResponse
		if exam.IsFinished() {
			totalScore, _ := model.FindUserExaminationScoreByUserExaminationID(exam.ID)
			score = 0
			if totalScore != nil {
				score = totalScore.Score
			}

			catScores, _ := model.GetUserExaminationCategoryScoreByUserExaminationID(exam.ID)
			scoreResponses = make([]*model.ScoreResponse, len(catScores))
			for i, s := range catScores {
				scoreResponses[i] = &model.ScoreResponse{
					CategoryName: s.Category.Name,
					Score:        s.Score,
				}
			}
		}
		responses[i] = UserExaminationResponse{
			ID:         exam.Examination.ID,
			Name:       exam.Examination.Name,
			Status:     status.ToString(),
			Score:      score,
			Group:      exam.Examination.Group,
			Scores:     scoreResponses,
			StartedAt:  exam.StartedAt,
			FinishedAt: exam.FinishedAt,
		}
	}

	return UserDetailResponse{
		UserResponse: toUserResponse(user),
		Examinations: responses,
	}
}
