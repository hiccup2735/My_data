package admin

import (
	"app/controller"
	"app/model"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/rs/zerolog/log"
	"golang.org/x/crypto/bcrypt"
	"net/http"
	"strconv"
)

type organizationController struct{}

func NewOrganizationController() *organizationController {
	return &organizationController{}
}

func (*organizationController) Index(ctx *gin.Context) {
	searchWord := ctx.Query("q")
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "100"))

	organizations, err := model.FilterByOrganization(searchWord, page, pageSize)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	total, err := model.CountOrganization(searchWord)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"page":          page,
		"page_size":     pageSize,
		"total":         total,
		"organizations": organizations,
	})
}

func (*organizationController) Create(ctx *gin.Context) {
	organization := &model.Organization{}
	if err := ctx.ShouldBindJSON(&organization); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	if err := model.CreateOrganization(organization); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, organization)
}

func (*organizationController) Show(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	organization, err := model.FindOrganizationByID(id, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	// TODO: users: null, organizers: nullを空配列にする
	ctx.JSON(http.StatusOK, organization)
}

func (*organizationController) Update(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	organization, err := model.FindOrganizationByID(id, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	data := &model.Organization{}
	if err := ctx.ShouldBindJSON(&data); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	if err := organization.Update(data); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	// TODO: users: null, organizers: nullを空配列にする
	ctx.JSON(http.StatusOK, organization)
}

func (*organizationController) Delete(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	organization, err := model.FindOrganizationByID(id, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	if err := organization.Delete(); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{})
}

func (*organizationController) IndexUser(ctx *gin.Context) {
	orgRepo := &model.OrganizationRepository{}
	userRepo := &model.UserRepository{}

	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "25"))
	searchTerm := ctx.Query("q")

	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}
	organizationID := model.OrganizationID(id)
	organization, err := orgRepo.FindByID(organizationID)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	if organization == nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
		return
	}

	condition := model.UserFilterCondition2{
		OrganizationID: organizationID,
		SearchTerm:     searchTerm,
	}
	users, err := userRepo.Limit(pageSize).Offset(pageSize * page).
		Preload(model.UserPreload2{
			Examinations: true,
		}).
		FilterByCondition(condition)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	count, err := userRepo.CountByCondition(condition)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"page":      page,
		"page_size": pageSize,
		"total":     count,
		"users":     toUserResponses(users),
	})
}

func (*organizationController) CreateUser(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	type params struct {
		Name     string `json:"name"     binding:"required,min=1,max=255"`
		Email    string `json:"email"    binding:"required,min=1,max=255,email"`
		Password string `json:"password" binding:"required,min=8,max=255,printascii,excludes= "`
	}
	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	organization, err := model.OrganizationFindByID(id, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	// TODO: passwordバリデート
	// UserCreateAllでバリデートをしているが、フロントにバリデートエラーと返すようにする

	user := &model.User{
		Name:         p.Name,
		Email:        p.Email,
		Password:     p.Password,
		Organization: organization,
	}
	var users []*model.User
	users = append(users, user)
	if err := model.UserCreateAll(users); err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	if err := user.SendCreatedMail(p.Password); err != nil {
		log.Printf("Error: send created mail error: user_id: %d", user.ID)
		log.Printf("Error: send mail error: reason: %s", err.Error())
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"users": toUserDetailResponse(user),
	})
}

func (*organizationController) UpdateUser(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	userID, err := strconv.Atoi(ctx.Param("user_id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	organization, err := model.OrganizationFindByID(id, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	// TODO: preloadが適切か確認する
	user, err := model.UserFindByID(userID, model.UserPreload{
		Organization:     true,
		Examinations:     true,
		UserExaminations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	// TODO: Preloadで取ってきた値が設定されていないuser_examinationが空で設定されてvalidation errorになる
	user.UserExaminations = []*model.UserExamination{}
	if err := organization.AppendUser(user); err != nil {
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}
	ctx.JSON(http.StatusOK, gin.H{
		"users": toUserResponses(organization.Users),
	})
}

func (*organizationController) DeleteUser(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	userID, err := strconv.Atoi(ctx.Param("user_id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	organization, err := model.OrganizationFindByID(id, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	// TODO: preloadが適切か確認する
	user, err := model.UserFindByID(userID, model.UserPreload{
		Organization:     true,
		Examinations:     true,
		UserExaminations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	if err := organization.DeleteUser(user); err != nil {
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}
	ctx.JSON(http.StatusOK, gin.H{
		"users": toUserResponses(organization.Users),
	})
}

func (*organizationController) IndexLicense(ctx *gin.Context) {
	organizationId, err := strconv.Atoi(ctx.Param("id"))
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "20"))
		
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	licenses, err := model.FindLicenses(organizationId, page, pageSize)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	total, err := model.CountLicense(organizationId)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"page":      page,
		"page_size": pageSize,
		"total":     total,		
		"licenses": toOrganizationLicenseResponses(licenses),
	})
}

func (*organizationController) CreateLicense(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	license := &model.License{}
	if err := ctx.ShouldBindJSON(&license); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	organization, err := model.OrganizationFindByID(id, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	exam, err := model.FindExaminationByID(license.ExaminationID, model.ExaminationPreload{
		ExaminationOrganizations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found examination")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	// 所属無し組織の場合は、global試験のみライセンスの発行が可能
	if organization.IsIndependent() && !exam.IsGlobalScope() {
		_ = controller.SetErrorContext(ctx, fmt.Errorf("invalid request"), http.StatusNotFound, "Not found")
		return
	}

	if !exam.IsGlobalScope() {
		ok := false
		for _, eo := range exam.ExaminationOrganizations {
			if eo.OrganizationID == organization.ID {
				ok = true
				break
			}
		}
		if !ok {
			_ = controller.SetErrorContext(ctx, fmt.Errorf("invalid request"), http.StatusNotFound, "Not found")
			return
		}
	}

	if err := organization.AppendLicense(license); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		// TODO: 作成したデータのみの返却にする
		"licenses": toOrganizationLicenseResponses(organization.Licenses),
	})
}

func (*organizationController) UpdateLicense(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	licenseID, err := strconv.Atoi(ctx.Param("license_id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("license_id")))
		return
	}

	data := &model.License{}
	if err := ctx.ShouldBindJSON(&data); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	organization, err := model.OrganizationFindByID(id, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	license, err := organization.FindLicenseByID(licenseID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found license")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	// 一度発行したライセンスの試験IDが変更されると、発行済ライセンスと試験の整合性が取れなくなるため、試験IDの変更を無効にしている
	data.ExaminationID = license.ExaminationID
	_, err = model.FindExaminationByID(data.ExaminationID, model.ExaminationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found examination")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	if err := license.Update(data); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		// TODO: 更新したデータのみの返却にする
		"licenses": toOrganizationLicenseResponses(organization.Licenses),
	})
}

func (*organizationController) DeleteLicense(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	licenseID, err := strconv.Atoi(ctx.Param("license_id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter license_id : %v", ctx.Param("license_id")))
		return
	}

	organization, err := model.OrganizationFindByID(id, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	license, err := organization.FindLicenseByID(licenseID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found license")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	if err := license.Delete(); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		// TODO: ステータスのみの返却で問題ないか確認する
		"licenses": toOrganizationLicenseResponses(organization.Licenses),
	})
}

func (*organizationController) IndexOrganizer(ctx *gin.Context) {
	// TODO: 検索対応
	// searchWord := ctx.Query("q")
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "25"))

	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	organization, err := model.FindOrganizationByID(id, model.OrganizationPreload{
		Organizers: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	responses := make([]organizerResponse, 0)
	for _, organizer := range organization.Organizers {
		responses = append(responses, toOrganizerResponse(*organizer))
	}

	// FIXME: 件数の取得
	total := len(responses)

	ctx.JSON(http.StatusOK, gin.H{
		"page":       page,
		"page_size":  pageSize,
		"total":      total,
		"organizers": responses,
	})
}

func (*organizationController) CreateOrganizer(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	type params struct {
		Name     string `json:"name"            binding:"required,min=1,max=255"`
		Email    string `json:"email"           binding:"required,min=1,max=255,email"`
		Password string `json:"password"        binding:"required,min=8,max=255,printascii,excludes= "`
	}
	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	organization, err := model.FindOrganizationByID(id, model.OrganizationPreload{
		Organizers: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(p.Password), 10)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	organizer := &model.Organizer{
		Name:           p.Name,
		Email:          p.Email,
		Password:       string(hash),
		OrganizationID: organization.ID,
	}
	if err := model.CreateOrganizer(organizer); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, toOrganizerResponse(*organizer))
}

func (*organizationController) UpdateOrganizer(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	organizerID, err := strconv.Atoi(ctx.Param("organizer_id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter organizer_id : %v", ctx.Param("organizer_id")))
		return
	}

	type params struct {
		Name  string `json:"name"            binding:"required,min=1,max=255"`
		Email string `json:"email"           binding:"required,min=1,max=255,email"`
	}
	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	organization, err := model.FindOrganizationByID(id, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organization")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	organizer, err := model.FindOrganizerByID(organizerID, model.OrganizerPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found organizer")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	// システム管理者による更新時は、パスワードの更新をさせないのでDBから取得した値を再度設定する
	if err := organizer.Update(&model.Organizer{
		Name:           p.Name,
		Password:       organizer.Password,
		Email:          p.Email,
		OrganizationID: organization.ID,
	}); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, toOrganizerResponse(*organizer))
}
