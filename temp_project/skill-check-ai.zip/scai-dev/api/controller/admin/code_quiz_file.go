package admin

import (
	"app/controller"
	"app/model"
	"app/service"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/rs/zerolog/log"
	"net/http"
	"strconv"
)

type codeQuizFileController struct {
	codeQuizRepository     *model.CodeQuizRepository
	codeQuizFileRepository *model.CodeQuizFileRepository
	scaiS3Service          *service.S3Service
}

func NewCodeQuizFileController(
	codeQuizRepository *model.CodeQuizRepository,
	codeQuizFileRepository *model.CodeQuizFileRepository,
	scaiS3Service *service.S3Service,
) *codeQuizFileController {
	return &codeQuizFileController{
		codeQuizRepository,
		codeQuizFileRepository,
		scaiS3Service,
	}
}

func (c *codeQuizFileController) Upload(ctx *gin.Context) {
	rQuizID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	quizID := model.CodeQuizID(rQuizID)

	fileType := model.CodeQuizFileType(ctx.Param("type"))
	if !fileType.IsValid() {
		controller.SetBadRequestError(ctx, "Invalid type")
		return
	}

	quiz, err := c.codeQuizRepository.FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}

	file, header, err := ctx.Request.FormFile("file")
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	quizFile, err := c.codeQuizFileRepository.FindByQuizIDWithFileType(quiz.ID, fileType)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	res, err := c.scaiS3Service.Upload(
		fmt.Sprintf("uploaded/code_quiz/%d/%s/%s", quiz.ID, fileType, header.Filename),
		file,
	)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	if quizFile == nil {
		quizFile = &model.CodeQuizFile{
			CodeQuizID: quizID,
			Type:       fileType,
			URL:        res.Location,
		}
		err = c.codeQuizFileRepository.Insert(quizFile)
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}

	} else {
		oldURL := quizFile.URL
		quizFile.URL = res.Location
		err = c.codeQuizFileRepository.Update(*quizFile)
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}

		if oldURL != res.Location {
			err = c.scaiS3Service.Delete(oldURL)
			if err != nil {
				log.Printf("Failed to delete %s file", oldURL)
			}
		}
	}

	ctx.JSON(http.StatusOK, quizFile)
}

func (c *codeQuizFileController) Delete(ctx *gin.Context) {
	rQuizID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	quizID := model.CodeQuizID(rQuizID)

	rQuizFileID, err := strconv.Atoi(ctx.Param("file_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid file_id")
		return
	}
	quizFileID := model.CodeQuizFileID(rQuizFileID)

	quiz, err := c.codeQuizRepository.FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}

	quizFile, err := c.codeQuizFileRepository.FindByID(quizFileID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quizFile == nil {
		controller.SetNotFoundError(ctx, "Not found quiz file")
		return
	}

	err = c.codeQuizFileRepository.DeleteByID(quizFile.ID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	err = c.scaiS3Service.Delete(quizFile.URL)
	if err != nil {
		log.Printf("Failed to delete %s file", quizFile.URL)
	}

	ctx.JSON(http.StatusOK, gin.H{})
}
