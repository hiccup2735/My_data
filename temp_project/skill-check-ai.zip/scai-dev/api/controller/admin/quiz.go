package admin

import (
	"app/controller"
	"app/model"
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
)

type quizController struct {
	questionRepository *model.QuestionRepository
	quizRepository     *model.QuizRepository
}

func NewQuizController(
	questionRepository *model.QuestionRepository,
	quizRepository *model.QuizRepository,
) *quizController {
	return &quizController{
		questionRepository,
		quizRepository,
	}
}

func (c *quizController) Index(ctx *gin.Context) {
	rQuestionID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	questionID := model.QuestionID(rQuestionID)

	question, err := c.questionRepository.FindByID(questionID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if question == nil {
		controller.SetNotFoundError(ctx, "Not found question")
		return
	}

	quizzes, err := c.quizRepository.FilterByQuestionID(
		questionID,
		model.QuizPreload{Choices: true},
	)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"quizzes": quizzes,
	})
}

func (c *quizController) Create(ctx *gin.Context) {
	rQuestionID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	questionID := model.QuestionID(rQuestionID)

	question, err := c.questionRepository.FindByID(questionID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if question == nil {
		controller.SetNotFoundError(ctx, "Not found question")
		return
	}

	var quiz *model.Quiz
	err = ctx.ShouldBindJSON(&quiz)
	if err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	quiz.QuestionID = question.ID
	err = c.quizRepository.Insert(quiz)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, quiz)
}

func (c *quizController) Update(ctx *gin.Context) {
	rQuestionID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	questionID := model.QuestionID(rQuestionID)

	rQuizID, err := strconv.Atoi(ctx.Param("quiz_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid quiz_id")
		return
	}
	quizID := model.QuizID(rQuizID)

	question, err := c.questionRepository.FindByID(questionID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if question == nil {
		controller.SetNotFoundError(ctx, "Not found question")
		return
	}

	quiz, err := c.quizRepository.FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}
	if quiz.QuestionID != question.ID {
		controller.SetBadRequestError(ctx, "Not related question and quiz")
		return
	}

	err = ctx.ShouldBindJSON(&quiz)
	if err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	err = c.quizRepository.Update(*quiz)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, quiz)
}

func (c *quizController) Delete(ctx *gin.Context) {
	rQuestionID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	questionID := model.QuestionID(rQuestionID)

	rQuizID, err := strconv.Atoi(ctx.Param("quiz_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid quiz_id")
		return
	}
	quizID := model.QuizID(rQuizID)

	question, err := c.questionRepository.FindByID(questionID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if question == nil {
		controller.SetNotFoundError(ctx, "Not found question")
		return
	}

	quiz, err := c.quizRepository.FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}
	if quiz.QuestionID != question.ID {
		controller.SetBadRequestError(ctx, "Not related question and quiz")
		return
	}

	err = c.quizRepository.DeleteByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, gin.H{})
}
