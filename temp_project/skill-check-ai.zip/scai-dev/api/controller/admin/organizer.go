package admin

import (
	"app/model"
	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
	"net/http"
)

// CreateOrganizer action: POST /admin/organizers
func CreateOrganizer(c *gin.Context) {
	type params struct {
		Name           string `json:"name"            binding:"required,min=1,max=255"`
		Email          string `json:"email"           binding:"required,min=1,max=255,email"`
		Password       string `json:"password"        binding:"required,min=8,max=255,printascii,excludes= "`
		OrganizationID int    `json:"organization_id" binding:"required,min=1,max=4294967295"`
	}
	var p params
	if err := c.ShouldBindJSON(&p); err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	org, err := model.OrganizationFindByID(p.OrganizationID, model.OrganizationPreload{})
	if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	organizer := &model.Organizer{
		Name:           p.Name,
		Email:          p.Email,
		Password:       p.Password,
		OrganizationID: org.ID,
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(organizer.Password), 10)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	organizer.Password = string(hash)

	if err := model.CreateOrganizer(organizer); err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	c.JSON(http.StatusOK, organizer)
}
