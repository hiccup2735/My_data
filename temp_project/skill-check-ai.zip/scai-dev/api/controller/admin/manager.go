package admin

import (
	"fmt"
	"errors"
	"app/controller"
	"app/model"
	"net/http"
	"strconv"
	"github.com/jinzhu/gorm"
	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

type managerController struct{}

func NewManagerController() *managerController {
	return &managerController{}
}

func (*managerController) Index(ctx *gin.Context) {
	searchWord := ctx.Query("q")
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "25"))

	managers, err := model.FindManagers(searchWord, page, pageSize)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	total, err := model.CountManager(searchWord)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"page":        page,
		"page_size":   pageSize,
		"total":       total,
		"managers":   toManagerResponses(managers),
	})
}

func (*managerController) Create(ctx *gin.Context) {
	type params struct {
		Name      string `json:"name"       binding:"required,min=1,max=255"`
		Email     string `json:"email"      binding:"required,min=1,max=255,email"`
		Password  string `json:"password"   binding:"required,min=8,max=255,printascii,excludes= "`
		Group     int    `json:"group"      binding:"required,min=0,max=255"`
	}
	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	if !model.ValidatePassword(p.Password) {
		_ = controller.SetErrorContext(ctx, fmt.Errorf("Invalid password"), http.StatusBadRequest, "Bad request")
		return
	}

	manager := &model.Manager{
		Name:     p.Name,
		Email:    p.Email,
		Password: p.Password,
		Group:    p.Group,
	}
	var managers []*model.Manager
	managers = append(managers, manager)
	if err := model.CreateManager(managers); err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	response := toManagerResponses(managers)
	ctx.JSON(http.StatusOK, response)
}

func (*managerController) Update(ctx *gin.Context) {
	type params struct {
		Name           string `json:"name"            binding:"required,min=1,max=255"`
		Email          string `json:"email"           binding:"required,min=1,max=255,email"`
		Password       string `json:"password"        binding:"min=0,max=255,printascii,excludes= "`
		Group          int    `json:"group"           binding:"required,min=0,max=255"`
	}
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	manager, err := model.FindManagerByID(id)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	data := &model.Manager{}
	data.Name = p.Name
	data.Email = p.Email
	data.Group = p.Group
	if p.Password != "" {
		if !model.ValidatePassword(p.Password) {
			_ = controller.SetErrorContext(ctx, fmt.Errorf("Invalid password"), http.StatusBadRequest, "Bad request")
			return
		}
		hash, err := bcrypt.GenerateFromPassword([]byte(p.Password), 10)
		if err != nil {
			ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
			return
		}
		data.Password = string(hash)
	}

	if err := manager.UpdateManager(data); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, toManagerResponse(manager))
}

func (*managerController) Delete(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	manager, err := model.FindManagerByID(id)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	if err := manager.DeleteManager(); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{})
}

type ManagerResponse struct {
	ID               int     `json:"id"`
	Name             string  `json:"name"`
	Email            string  `json:"email"`
	Group            int     `json:"group"`
}

func toManagerResponses(managers []*model.Manager) []ManagerResponse {
	responses := make([]ManagerResponse, len(managers))
	for i, manager := range managers {
		responses[i] = toManagerResponse(manager)
	}
	return responses
}

func toManagerResponse(manager *model.Manager) ManagerResponse {
	return ManagerResponse{
		ID:               manager.ID,
		Name:             manager.Name,
		Email:            manager.Email,
		Group:            manager.Group,
	}
}