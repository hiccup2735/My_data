package admin

import (
	"app/controller"
	"app/model"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"net/http"
	"strconv"
	"strings"
)

type questionController struct{}

func NewQuestionController() *questionController {
	return &questionController{}
}

func (*questionController) Index(ctx *gin.Context) {
	searchWord := ctx.Query("q")
	tags := strings.FieldsFunc(ctx.Query("tags"), func(c rune) bool {
		return c == ','
	})
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "25"))
	group, _ := strconv.Atoi(ctx.DefaultQuery("group", "0"))

	questions, err := model.FilterByQuestion(searchWord, tags, page, pageSize, group)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	total, err := model.CountQuestion(searchWord, tags, group)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ids := make([]int, len(questions))
	for i, q := range questions {
		ids[i] = q.ID
	}
	counts, err := model.GetQuestionAnswerCount(ids)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	for _, q := range questions {
		for _, cnt := range counts {
			if q.ID == cnt.ID {
				cnt.Question = q
				break
			}
		}
	}

	presenter := QuestionPresenter{}
	ress := presenter.ToIndexResponses(counts)

	ctx.JSON(http.StatusOK, gin.H{
		"page":      page,
		"page_size": pageSize,
		"total":     total,
		"questions": ress,
	})
}

type questionParam struct {
	Name        string                  `json:"name"        binding:"required,min=1,max=255"`
	Description string                  `json:"description" binding:"min=0,max=10000"`
	ImageURI    string                  `json:"image_uri"   binding:"omitempty,min=1,max=255,url"`
	Level       int                     `json:"level"       binding:"min=0,max=4294967295"`
	Tags        []string                `json:"tags"        binding:"omitempty,unique"`
	Metadata    []questionMetadataParam `json:"metadata"    binding:"omitempty"`
	Group       int                     `json:"group"       binding:"min=0,max=255"`
}

type questionMetadataParam struct {
	Key   string `json:"key"   binding:"required"`
	Value string `json:"value" binding:"required"`
}

func (*questionController) Create(ctx *gin.Context) {
	var param questionParam
	if err := ctx.ShouldBindJSON(&param); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	tags := make([]*model.QuestionTag, len(param.Tags))
	for i, t := range param.Tags {
		tags[i] = &model.QuestionTag{
			Name: t,
		}
	}

	metadata := make([]*model.QuestionMetadata, len(param.Metadata))
	for i, d := range param.Metadata {
		metadata[i] = &model.QuestionMetadata{
			Key:   d.Key,
			Value: d.Value,
		}
	}

	ques := &model.Question{
		Name:        param.Name,
		Description: param.Description,
		ImageURI:    param.ImageURI,
		Level:       param.Level,
		Tags:        tags,
		Metadata:    metadata,
		Group:       param.Group,
	}

	if err := model.CreateQuestion(ques); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := QuestionPresenter{}
	res := presenter.ToDetailResponse(ques)

	ctx.JSON(http.StatusOK, res)
}

func (*questionController) Show(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	ques, err := model.FindQuestionByID(id, model.QuestionPreload{
		Quizzes:          true,
		QuizzesChoices:   true,
		CodeQuizzes:      true,
		CodeQuizzesFiles: true,
		Examinations:     true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := QuestionPresenter{}
	res := presenter.ToDetailResponse(ques)

	ctx.JSON(http.StatusOK, res)
}

func (*questionController) Update(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	var param questionParam
	if err := ctx.ShouldBindJSON(&param); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	ques, err := model.FindQuestionByID(id, model.QuestionPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	tags := ques.Tags
	if param.Tags != nil {
		tags = make([]*model.QuestionTag, len(param.Tags))
		for i, t := range param.Tags {
			tags[i] = &model.QuestionTag{
				Name: t,
			}
		}

		for _, t := range ques.Tags {
			if err := t.Delete(); err != nil {
				_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
				return
			}
		}
	}

	metadata := ques.Metadata
	if param.Metadata != nil {
		metadata = make([]*model.QuestionMetadata, len(param.Metadata))
		for i, d := range param.Metadata {
			metadata[i] = &model.QuestionMetadata{
				Key:   d.Key,
				Value: d.Value,
			}
		}
		for _, d := range ques.Metadata {
			if err := d.Delete(); err != nil {
				_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
				return
			}
		}
	}

	data := &model.Question{
		Name:        param.Name,
		Description: param.Description,
		ImageURI:    param.ImageURI,
		Level:       param.Level,
		Tags:        tags,
		Metadata:    metadata,
		Group:       param.Group,
	}
	if err := ques.Update(data); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ques, err = model.FindQuestionByID(id, model.QuestionPreload{
		Quizzes:        true,
		QuizzesChoices: true,
	})

	presenter := QuestionPresenter{}
	res := presenter.ToDetailResponse(ques)

	ctx.JSON(http.StatusOK, res)
}

func (*questionController) Delete(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	question, err := model.FindQuestionByID(id, model.QuestionPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found question")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	// TODO: 配下のquizも消すか確認する
	if err := question.Delete(); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{})
}

func (*questionController) Copy(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	ques, err := model.FindQuestionByID(id, model.QuestionPreload{
		Quizzes:        true,
		QuizzesChoices: true,
	})

	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	newQues, err := ques.Copy()
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	if err := model.CreateQuestion(newQues); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	newQues, err = model.FindQuestionByID(newQues.ID, model.QuestionPreload{
		Quizzes:        true,
		QuizzesChoices: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := QuestionPresenter{}
	res := presenter.ToDetailResponse(newQues)

	ctx.JSON(http.StatusOK, res)
}
