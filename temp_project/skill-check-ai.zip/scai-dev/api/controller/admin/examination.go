package admin

import (
	"app/controller"
	"app/model"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"net/http"
	"strconv"
	"time"
)

type examinationController struct{}

func NewExaminationController() *examinationController {
	return &examinationController{}
}

func (*examinationController) Index(ctx *gin.Context) {
	searchWord := ctx.Query("q")
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "25"))
	group, _ := strconv.Atoi(ctx.DefaultQuery("group", "0"))

	exams, err := model.FilterByExamination(searchWord, page, pageSize, group)

	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	total, err := model.CountExamination(searchWord)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := ExaminationPresenter{}
	ress := presenter.ToIndexResponse(exams)

	ctx.JSON(http.StatusOK, gin.H{
		"page":         page,
		"page_size":    pageSize,
		"total":        total,
		"examinations": ress,
		"group":        group,
	})
}

func (*examinationController) Create(ctx *gin.Context) {
	var exam *model.Examination
	if err := ctx.ShouldBindJSON(&exam); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	if err := model.CreateExamination(exam, false); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := ExaminationPresenter{}
	res := presenter.ToDetailResponse(exam)

	ctx.JSON(http.StatusOK, res)
}

func (*examinationController) Show(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	exam, err := model.FindExaminationByID(id, model.ExaminationPreload{
		Questions:                true,
		QuestionsQuizzes:         true,
		QuestionsQuizzesChoices:  true,
		ExaminationOrganizations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := ExaminationPresenter{}
	res := presenter.ToDetailResponse(exam)

	ctx.JSON(http.StatusOK, res)
}

func (*examinationController) Update(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	exam, err := model.FindExaminationByID(id, model.ExaminationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	var data *model.Examination
	if err := ctx.ShouldBindJSON(&data); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	if err := exam.Update(data); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	updatedExam, err := model.FindExaminationByID(id, model.ExaminationPreload{
		Questions:                true,
		QuestionsQuizzes:         true,
		QuestionsQuizzesChoices:  true,
		ExaminationOrganizations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := ExaminationPresenter{}
	res := presenter.ToDetailResponse(updatedExam)

	ctx.JSON(http.StatusOK, res)
}

func (*examinationController) Delete(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	examination, err := model.FindExaminationByID(id, model.ExaminationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found examination")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	if err := examination.Delete(); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{})
}

func (*examinationController) Copy(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	exam, err := model.FindExaminationByID(id, model.ExaminationPreload{
		Questions:               true,
		QuestionsQuizzes:        true,
		QuestionsQuizzesChoices: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	copiedExam, err := exam.Copy()
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	if err := model.CreateExamination(copiedExam.Examination, false); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	for _, examQues := range exam.ExaminationQuestions {
		for _, copyedQues := range copiedExam.CopiedQuestions {
			if examQues.QuestionID == copyedQues.OriginID {
				err := copiedExam.Examination.AppendExaminationQuestion(&model.ExaminationQuestion{
					QuestionID: copyedQues.OriginID,
					Sequence:   examQues.Sequence,
					CategoryID: examQues.CategoryID,
				})
				if err != nil {
					_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
					return
				}
				break
			}
		}
	}

	newExam, err := model.FindExaminationByID(copiedExam.Examination.ID, model.ExaminationPreload{
		Questions:               true,
		QuestionsQuizzes:        true,
		QuestionsQuizzesChoices: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := ExaminationPresenter{}
	res := presenter.ToDetailResponse(newExam)

	ctx.JSON(http.StatusOK, res)
}

func (*examinationController) IndexQuestion(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	examination, err := model.FindExaminationByID(id, model.ExaminationPreload{
		Questions: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found examination")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"questions": toExaminationQuestionIndexResponse(examination.ExaminationQuestions),
	})
}

func (*examinationController) RelateQuestion(ctx *gin.Context) {
	examID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	quesID, err := strconv.Atoi(ctx.Param("question_id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter question_id : %v", ctx.Param("question_id")))
		return
	}

	type params struct {
		Sequence   int `json:"sequence"    binding:"min=0,max=4294967295"`
		CategoryID int `json:"category_id" binding:"required,min=1,max=4294967295"`
	}
	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	exam, err := model.FindExaminationByID(examID, model.ExaminationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ques, err := model.FindQuestionByID(quesID, model.QuestionPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	if _, err = model.FindCategoryByID(p.CategoryID); err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	// TODO: 既に追加済みの場合、insertでduplicate entryになってしまうので、一度削除しているがappend時にreplaceにできないか
	if err := exam.DeleteQuestion(ques); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	if p.Sequence == 0 {
		seq := model.GetExaminationQuestionMaxSequence(exam.ID)
		p.Sequence = seq + 1
	}

	examQues := &model.ExaminationQuestion{Sequence: p.Sequence, CategoryID: p.CategoryID, Question: ques}
	if err := exam.AppendExaminationQuestion(examQues); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	exam, err = model.FindExaminationByID(examID, model.ExaminationPreload{
		Questions:               true,
		QuestionsQuizzes:        true,
		QuestionsQuizzesChoices: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := ExaminationPresenter{}
	res := presenter.ToDetailResponse(exam)

	ctx.JSON(http.StatusOK, res)
}

func (*examinationController) RemoveQuestion(ctx *gin.Context) {
	examID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	quesID, err := strconv.Atoi(ctx.Param("question_id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter question_id : %v", ctx.Param("question_id")))
		return
	}

	exam, err := model.FindExaminationByID(examID, model.ExaminationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ques, err := model.FindQuestionByID(quesID, model.QuestionPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	if err := exam.DeleteQuestion(ques); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	exam, err = model.FindExaminationByID(examID, model.ExaminationPreload{
		Questions:               true,
		QuestionsQuizzes:        true,
		QuestionsQuizzesChoices: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := ExaminationPresenter{}
	res := presenter.ToDetailResponse(exam)

	ctx.JSON(http.StatusOK, res)
}

func (*examinationController) ReorderQuestions(ctx *gin.Context) {
	examID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	quesID, err := strconv.Atoi(ctx.Param("question_id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter question_id : %v", ctx.Param("question_id")))
		return
	}

	type params struct {
		To int `json:"to"   binding:"required,min=1,max=4294967295"`
	}
	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	exam, err := model.FindExaminationByID(examID, model.ExaminationPreload{
		Questions: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ok := false
	for _, q := range exam.ExaminationQuestions {
		if q.QuestionID == quesID {
			ok = true
			break
		}
	}
	if !ok {
		_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
		return
	}

	{
		n := len(exam.ExaminationQuestions)
		if p.To > n {
			p.To = n
		}
	}

	var target *model.ExaminationQuestion
	ordered := make([]*model.ExaminationQuestion, 0)
	for _, q := range exam.ExaminationQuestions {
		if q.QuestionID == quesID {
			target = q
		} else {
			ordered = append(ordered, q)
		}
	}
	ordered = append(ordered[:p.To], ordered[p.To-1:]...)
	ordered[p.To-1] = target

	for i, o := range ordered {
		o.Sequence = i + 1
		ordered[i] = o
		if err := o.Update(); err != nil {
			_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
			return
		}
	}

	exam.ExaminationQuestions = ordered

	presenter := ExaminationPresenter{}
	res := presenter.ToDetailResponse(exam)

	ctx.JSON(http.StatusOK, res)
}

func (*examinationController) IndexUser(ctx *gin.Context) {
	examRepo := model.ExaminationRepository{}
	userExamRepo := model.UserExaminationRepository{}

	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "25"))
	rawID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}
	examID := model.ExaminationID(rawID)
	exam, err := examRepo.ConditionID(examID).First()
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	if exam == nil {
		_ = controller.SetErrorContext(ctx, errors.New("examination not found"), http.StatusNotFound, "Not found")
		return
	}

	type score struct {
		CategoryName string `json:"category_name"`
		Score        int    `json:"score"`
	}
	type response struct {
		ID               int        `json:"id"`
		Name             string     `json:"name"`
		OrganizationName string     `json:"organization_name"`
		Status           string     `json:"status"`
		StartedAt        *time.Time `json:"started_at"`
		Score            int        `json:"score"`
		Scores           []score    `json:"scores"`
	}

	responses := make([]response, 0)
	userExams, err := userExamRepo.Limit(pageSize).Offset(pageSize * page).
		PreloadUser().PreloadLicense().ConditionExaminationID(examID).Find()
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	totalUserExamCount, err := userExamRepo.ConditionExaminationID(examID).Count()
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	for _, userExam := range userExams {
		if userExam.User == nil {
			continue
		}

		userExamStatus, err := userExam.Status()
		if err != nil {
			_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, "Invalid user examination status")
			return
		}

		totalScore := 0
		scores := make([]score, 0)
		if userExam.IsFinished() {
			s, err := model.FindUserExaminationScoreByUserExaminationID(userExam.ID)
			if err != nil {
				_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, "Invalid user examination total score")
				return
			}
			totalScore = 0
			if s != nil {
				totalScore = s.Score
			}

			catScores, err := model.GetUserExaminationCategoryScoreByUserExaminationID(userExam.ID)
			if err != nil {
				_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, "Invalid user examination category scores")
				return
			}

			scores = make([]score, len(catScores))
			for i, s := range catScores {
				scores[i] = score{
					Score:        s.Score,
					CategoryName: s.Category.Name,
				}
			}
		}

		responses = append(responses, response{
			ID:               userExam.User.ID,
			Name:             userExam.User.Name,
			OrganizationName: userExam.User.Organization.Name,
			Status:           userExamStatus.ToString(),
			StartedAt:        userExam.StartedAt,
			Score:            totalScore,
			Scores:           scores,
		})
	}

	ctx.JSON(http.StatusOK, gin.H{
		"page":      page,
		"page_size": pageSize,
		"total":     totalUserExamCount,
		"users":     responses,
	})
}

func (*examinationController) RelateOrganization(ctx *gin.Context) {
	examID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	orgID, err := strconv.Atoi(ctx.Param("organization_id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter organization_id : %v", ctx.Param("organization_id")))
		return
	}

	exam, err := model.FindExaminationByID(examID, model.ExaminationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	org, err := model.FindOrganizationByID(orgID, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	if org.IsIndependent() {
		_ = controller.SetErrorContext(ctx, fmt.Errorf("Invalid organization"), http.StatusBadRequest, "Bad request")
		return
	}

	// TODO: 既に追加済みの場合、insertでduplicate entryになってしまうので、一度削除しているがappend時にreplaceにできないか
	if err := exam.DeleteOrganization(org); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	examOrg := &model.ExaminationOrganization{
		ExaminationID:  exam.ID,
		OrganizationID: org.ID,
	}
	if err := exam.AppendOrganization(examOrg); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	// 試験のスコープをprivateに変更
	data := &model.Examination{
		Scope: "private",
	}
	if err := exam.Update(data); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	updatedExam, err := model.FindExaminationByID(examID, model.ExaminationPreload{
		Questions:                true,
		QuestionsQuizzes:         true,
		QuestionsQuizzesChoices:  true,
		ExaminationOrganizations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := ExaminationPresenter{}
	res := presenter.ToDetailResponse(updatedExam)

	ctx.JSON(http.StatusOK, res)
}

func (*examinationController) RemoveOrganization(ctx *gin.Context) {
	examID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	orgID, err := strconv.Atoi(ctx.Param("organization_id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter organization_id : %v", ctx.Param("organization_id")))
		return
	}

	exam, err := model.FindExaminationByID(examID, model.ExaminationPreload{
		ExaminationOrganizations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	org, err := model.FindOrganizationByID(orgID, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	if org.IsIndependent() {
		_ = controller.SetErrorContext(ctx, fmt.Errorf("Invalid organization"), http.StatusBadRequest, "Bad request")
		return
	}

	if err := exam.DeleteOrganization(org); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	if len(exam.ExaminationOrganizations)-1 == 0 {
		// 試験のスコープをglobalに変更
		data := &model.Examination{
			Scope: "global",
		}
		if err := exam.Update(data); err != nil {
			_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
			return
		}
	}

	updatedExam, err := model.FindExaminationByID(examID, model.ExaminationPreload{
		Questions:                true,
		QuestionsQuizzes:         true,
		QuestionsQuizzesChoices:  true,
		ExaminationOrganizations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := ExaminationPresenter{}
	res := presenter.ToDetailResponse(updatedExam)

	ctx.JSON(http.StatusOK, res)
}
