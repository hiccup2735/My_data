package admin

import (
	"app/controller"
	"app/model"
	"app/service"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/pkg/errors"
	"log"
	"net/http"
	"os"
	"path"
	"strconv"
)

type codeQuizController struct {
	questionRepository     *model.QuestionRepository
	codeQuizRepository     *model.CodeQuizRepository
	codeQuizFileRepository *model.CodeQuizFileRepository
	scaiS3Service          *service.S3Service
	codeRunnerS3Service    *service.S3Service
}

func NewCodeQuizController(
	questionRepository *model.QuestionRepository,
	codeQuizRepository *model.CodeQuizRepository,
	codeQuizFileRepository *model.CodeQuizFileRepository,
	scaiS3Service *service.S3Service,
	codeRunnerS3Service *service.S3Service,
) *codeQuizController {
	return &codeQuizController{
		questionRepository,
		codeQuizRepository,
		codeQuizFileRepository,
		scaiS3Service,
		codeRunnerS3Service,
	}
}

func (c *codeQuizController) Create(ctx *gin.Context) {
	rQuestionID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	questionID := model.QuestionID(rQuestionID)

	question, err := c.questionRepository.FindByID(questionID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if question == nil {
		controller.SetNotFoundError(ctx, "Not found question")
		return
	}

	var quiz *model.CodeQuiz
	err = ctx.ShouldBindJSON(&quiz)
	if err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	quiz.QuestionID = questionID
	err = c.codeQuizRepository.Insert(quiz)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	// レスポンスjsonのfilesがnullになるのを防ぐため
	quiz.CodeQuizFiles = make([]*model.CodeQuizFile, 0)

	ctx.JSON(http.StatusOK, quiz)
}

func (c *codeQuizController) Update(ctx *gin.Context) {
	rQuestionID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	questionID := model.QuestionID(rQuestionID)

	rQuizID, err := strconv.Atoi(ctx.Param("quiz_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid quiz_id")
		return
	}
	quizID := model.CodeQuizID(rQuizID)

	question, err := c.questionRepository.FindByID(questionID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if question == nil {
		controller.SetNotFoundError(ctx, "Not found question")
		return
	}

	quiz, err := c.codeQuizRepository.WithPreload().
		FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}
	if quiz.QuestionID != questionID {
		controller.SetBadRequestError(ctx, "Not related question and quiz")
		return
	}

	err = ctx.ShouldBindJSON(&quiz)
	if err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	quiz.IsSubmitted = false
	err = c.codeQuizRepository.Update(quiz)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, quiz)
}

func (c *codeQuizController) Delete(ctx *gin.Context) {
	rQuestionID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	questionID := model.QuestionID(rQuestionID)

	rQuizID, err := strconv.Atoi(ctx.Param("quiz_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid quiz_id")
		return
	}
	quizID := model.CodeQuizID(rQuizID)

	question, err := c.questionRepository.FindByID(questionID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if question == nil {
		controller.SetNotFoundError(ctx, "Not found question")
		return
	}

	quiz, err := c.codeQuizRepository.FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}
	if quiz.QuestionID != questionID {
		controller.SetBadRequestError(ctx, "Not related question and quiz")
		return
	}

	err = c.codeQuizRepository.DeleteByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	// CodeQuizが消えたら、ファイルの削除失敗はエラーにはしない
	err = c.codeQuizFileRepository.DeleteByQuizID(quizID)
	if err != nil {
		log.Printf("Failed to delete CodeQuiz id: %d files", quizID.ToInt())
	}

	ctx.JSON(http.StatusOK, gin.H{})
}

func (c *codeQuizController) Submit(ctx *gin.Context) {
	rQuestionID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	questionID := model.QuestionID(rQuestionID)

	rQuizID, err := strconv.Atoi(ctx.Param("quiz_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid quiz_id")
		return
	}
	quizID := model.CodeQuizID(rQuizID)

	question, err := c.questionRepository.FindByID(questionID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if question == nil {
		controller.SetNotFoundError(ctx, "Not found question")
		return
	}

	quiz, err := c.codeQuizRepository.FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}
	if quiz.QuestionID != questionID {
		controller.SetBadRequestError(ctx, "Not related question and quiz")
		return
	}

	files, err := c.codeQuizFileRepository.FilterByQuizID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	tempDir, err := os.MkdirTemp("/tmp", "code_quiz_submit")
	defer os.RemoveAll(tempDir)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	downloadFileMap := make(map[model.CodeQuizFileType]*os.File)
	for _, file := range files {
		d, err := os.MkdirTemp(tempDir, file.Type.ToString())
		if err != nil {
			controller.SetInternalServerError(ctx, errors.WithStack(err))
			return
		}

		f, err := os.Create(fmt.Sprintf("%s/%s", d, path.Base(file.URL)))
		if err != nil {
			controller.SetInternalServerError(ctx, errors.WithStack(err))
			return
		}

		err = c.scaiS3Service.Download(file.URL, f)
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}

		downloadFileMap[file.Type] = f
	}

	codeRunnerService := service.NewCodeRunnerService(c.codeRunnerS3Service, tempDir, *quiz)
	err = codeRunnerService.UploadMetadata()
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	for _, fileType := range model.GetAllCodeQuizFileType() {
		var err error

		file, ok := downloadFileMap[fileType]
		if ok {
			switch fileType {
			case model.CodeQuizFileTypeInput:
				err = codeRunnerService.UploadInput(file)
			case model.CodeQuizFileTypeOutput:
				err = codeRunnerService.UploadOutput(file)
			case model.CodeQuizFileTypeNgList:
				err = codeRunnerService.UploadNgList(file)
			case model.CodeQuizFileTypeOkList:
				err = codeRunnerService.UploadOkList(file)
			case model.CodeQuizFileTypeSetup:
				err = codeRunnerService.UploadSetup(file)
			}
		} else {
			// Note: 存在しないobjectを指定してS3から削除しようとしても、errはnilとなるので、
			//       S3からダウンロードされなかったタイプに関しては、毎回削除を試みて差分を無くしている
			switch fileType {
			case model.CodeQuizFileTypeInput:
				err = codeRunnerService.DeleteInput()
			case model.CodeQuizFileTypeOutput:
				err = codeRunnerService.DeleteOutput()
			case model.CodeQuizFileTypeNgList:
				err = codeRunnerService.DeleteNgList()
			case model.CodeQuizFileTypeOkList:
				err = codeRunnerService.DeleteOkList()
			case model.CodeQuizFileTypeSetup:
				err = codeRunnerService.DeleteSetup()
			}
		}

		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}
	}

	quiz.IsSubmitted = true
	err = c.codeQuizRepository.Update(quiz)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, gin.H{})
}
