package admin

import (
	"app/controller"
	"app/model"
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
)

type organizationCategoryController struct {
	organizationCategoryRepository *model.OrganizationCategoryRepository
}

func NewOrganizationCategoryController(
	organizationCategoryRepository *model.OrganizationCategoryRepository,
) *organizationCategoryController {
	return &organizationCategoryController{
		organizationCategoryRepository: organizationCategoryRepository,
	}
}

func (c *organizationCategoryController) Index(ctx *gin.Context) {
	categories, err := c.organizationCategoryRepository.FindAll()
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, categories)
}

func (c *organizationCategoryController) Create(ctx *gin.Context) {
	category := &model.OrganizationCategory{}
	err := ctx.ShouldBindJSON(category)
	if err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	err = c.organizationCategoryRepository.Insert(*category)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, category)
}

func (c *organizationCategoryController) Update(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	categoryID := model.OrganizationCategoryID(id)

	var data *model.OrganizationCategory
	if err := ctx.ShouldBindJSON(&data); err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	category, err := c.organizationCategoryRepository.FindByID(categoryID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if category == nil {
		controller.SetNotFoundError(ctx, "Not found organization category")
		return
	}

	category.Name = data.Name
	err = c.organizationCategoryRepository.Update(*category)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, category)
}
