package admin

import (
	"fmt"
	"errors"
	"app/controller"
	"app/model"
	"net/http"
	"strconv"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"golang.org/x/crypto/bcrypt"
)

type operatorController struct{}

func NewOperatorController() *operatorController {
	return &operatorController{}
}

func (*operatorController) Index(ctx *gin.Context) {
	searchWord := ctx.Query("q")
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "25"))

	operators, err := model.FindOperators(searchWord, page, pageSize)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	total, err := model.CountOperator(searchWord)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"page":        page,
		"page_size":   pageSize,
		"total":       total,
		"operators":   toOperatorResponses(operators),
	})
}

func (*operatorController) Create(ctx *gin.Context) {
	type params struct {
		Name     string `json:"name"     binding:"required,min=1,max=255"`
		Email    string `json:"email"    binding:"required,min=1,max=255,email"`
		Password string `json:"password" binding:"required,min=8,max=255,printascii,excludes= "`
	}
	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	if !model.ValidatePassword(p.Password) {
		_ = controller.SetErrorContext(ctx, fmt.Errorf("Invalid password"), http.StatusBadRequest, "Bad request")
		return
	}

	operator := &model.Operator{
		Name:     p.Name,
		Email:    p.Email,
		Password: p.Password,
	}
	var operators []*model.Operator
	operators = append(operators, operator)
	if err := model.CreateOperator(operators); err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	response := toOperatorResponse(operator)
	ctx.JSON(http.StatusOK, response)
}

func (*operatorController) Update(ctx *gin.Context) {
	type params struct {
		Name           string `json:"name"            binding:"required,min=1,max=255"`
		Email          string `json:"email"           binding:"required,min=1,max=255,email"`
		Password       string `json:"password"        binding:"min=0,max=255,printascii,excludes= "`
	}
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	operator, err := model.FindOperatorByID(id)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	data := &model.Operator{}
	data.Name = p.Name
	data.Email = p.Email

	if p.Password != "" {
		if !model.ValidatePassword(p.Password) {
			_ = controller.SetErrorContext(ctx, fmt.Errorf("Invalid password"), http.StatusBadRequest, "Bad request")
			return
		}
		hash, err := bcrypt.GenerateFromPassword([]byte(p.Password), 10)
		if err != nil {
			ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
			return
		}
		data.Password = string(hash)
	}

	if err := operator.UpdateOperator(data); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, toOperatorResponse(operator))
}

func (*operatorController) Delete(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	operator, err := model.FindOperatorByID(id)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	if err := operator.DeleteOperator(); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, gin.H{})
}

type OperatorResponse struct {
	ID               int     `json:"id"`
	Name             string  `json:"name"`
	Email            string  `json:"email"`
}

func toOperatorResponses(operators []*model.Operator) []OperatorResponse {
	responses := make([]OperatorResponse, len(operators))
	for i, operator := range operators {
		responses[i] = OperatorResponse{
			ID:               operator.ID,
			Name:             operator.Name,
			Email:            operator.Email,
		}
	}
	return responses
}

func toOperatorResponse(operator *model.Operator) OperatorResponse {
	return OperatorResponse{
		ID:               operator.ID,
		Name:             operator.Name,
		Email:            operator.Email,
	}
}