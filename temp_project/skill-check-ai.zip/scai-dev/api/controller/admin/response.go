package admin

import (
	"app/model"
	"time"
)

type OrganizationLicenseResponse struct {
	*model.License
	Quantity         int    `json:"quantity"`
	OrganizationName string `json:"organization_name"`
	ExaminationName  string `json:"examination_name"`
}

func toOrganizationLicenseResponses(licenses []*model.License) []OrganizationLicenseResponse {
	responses := make([]OrganizationLicenseResponse, len(licenses))
	for i, license := range licenses {
		responses[i] = toOrganizationLicenseResponse(license)
	}
	return responses
}

func toOrganizationLicenseResponse(license *model.License) OrganizationLicenseResponse {
	return OrganizationLicenseResponse{
		License:          license,
		Quantity:         license.CountQuantity(),
		OrganizationName: license.Organization.Name,
		ExaminationName:  license.Examination.Name,
	}
}

type UserLicenseResponse struct {
	ID              int        `json:"id"`
	StartDateTime   *time.Time `json:"start_date_time"`
	EndDateTime     *time.Time `json:"end_date_time"`
	ExaminationID   int        `json:"examination_id"`
	ExaminationName string     `json:"examination_name"`
}

func toUserLicenseResponses(exams []*model.UserExamination) []UserLicenseResponse {
	responses := make([]UserLicenseResponse, len(exams))
	for i, exam := range exams {
		responses[i] = toUserLicenseResponse(exam.License)
	}
	return responses
}

func toUserLicenseResponse(license *model.License) UserLicenseResponse {
	return UserLicenseResponse{
		ID:              license.ID,
		StartDateTime:   license.StartDateTime,
		EndDateTime:     license.EndDateTime,
		ExaminationID:   license.Examination.ID,
		ExaminationName: license.Examination.Name,
	}
}

type organizerResponse struct {
	ID             int    `json:"id"`
	Name           string `json:"name"`
	Email          string `json:"email"`
	OrganizationID int    `json:"organization_id"`
}

func toOrganizerResponse(organizer model.Organizer) organizerResponse {
	return organizerResponse{
		ID:             organizer.ID,
		Name:           organizer.Name,
		Email:          organizer.Email,
		OrganizationID: organizer.OrganizationID,
	}
}
