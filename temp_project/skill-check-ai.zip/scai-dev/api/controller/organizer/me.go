package organizer

import (
	"app/controller"
	"app/session"
	"github.com/gin-gonic/gin"
	"net/http"
)

// ShowMe ログイン中のorganizerを取得
func ShowMe(c *gin.Context) {
	organizer, err := session.GetContextOrganizer(c)
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusInternalServerError, err.Error())
		return
	}

	c.JSON(http.StatusOK, organizer)
}
