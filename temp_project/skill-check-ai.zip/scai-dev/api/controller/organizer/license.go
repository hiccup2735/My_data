package organizer

import (
	"app/controller"
	"app/model"
	"app/session"
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
	"time"
)

// IndexLicenses action: GET /organizer/licenses
func IndexLicenses(c *gin.Context) {
	// TODO: 検索を有効にする
	// searchWord := c.Query("q")
	page, _ := strconv.Atoi(c.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("page_size", "25"))

	organizer, err := session.GetContextOrganizer(c)
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusUnauthorized, err.Error())
		return
	}

	// FIXME: 絞り込みに対応する
	organization, err := model.FindOrganizationByID(organizer.OrganizationID,
		model.OrganizationPreload{
			LicensesOrganization: true,
			LicensesExamination:  true,
		})
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusInternalServerError, err.Error())
		return
	}

	type response struct {
		ID               int        `json:"id"`
		Count            int        `json:"count"`
		StartDateTime    *time.Time `json:"start_date_time"`
		EndDateTime      *time.Time `json:"end_date_time"`
		OrganizationID   int        `json:"organization_id"`
		ExaminationID    int        `json:"examination_id"`
		Quantity         int        `json:"quantity"`
		OrganizationName string     `json:"organization_name"`
		ExaminationName  string     `json:"examination_name"`
	}

	var responses []response
	for _, license := range organization.Licenses {
		responses = append(responses, response{
			ID:               license.ID,
			Count:            license.Count,
			StartDateTime:    license.StartDateTime,
			EndDateTime:      license.EndDateTime,
			OrganizationID:   license.OrganizationID,
			ExaminationID:    license.ExaminationID,
			Quantity:         license.CountQuantity(),
			OrganizationName: license.Organization.Name,
			ExaminationName:  license.Examination.Name,
		})
	}

	// FIXME: 件数を取得

	c.JSON(http.StatusOK, gin.H{
		"page":      page,
		"page_size": pageSize,
		"total":     len(responses),
		"licenses":  responses,
	})
}
