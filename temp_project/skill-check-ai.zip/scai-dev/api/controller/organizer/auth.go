package organizer

import (
	"app/controller"
	"app/model"
	"app/session"
	"github.com/gin-gonic/gin"
	"net/http"
)

type AuthController struct{}

func NewAuthController() *AuthController {
	return &AuthController{}
}

func (*AuthController) SignIn(ctx *gin.Context) {
	type params struct {
		Email    string `json:"email"    binding:"required,email"`
		Password string `json:"password" binding:"required"`
	}

	var p params
	if err := ctx.ShouldBind(&p); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	organizer, err := model.OrganizerSignIn(p.Email, p.Password)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest, err.Error())
		return
	}
	if err := session.SetOrganizerID(ctx, organizer.ID); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.JSON(http.StatusOK, organizer)
}

func (*AuthController) SignOut(ctx *gin.Context) {
	if err := session.Clear(ctx); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.Status(http.StatusOK)
}
