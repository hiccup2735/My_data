package manager

import (
	"app/model"
	"app/session"
	"github.com/gin-gonic/gin"
	"net/http"
)

type AuthController struct{}

func NewAuthController() *AuthController {
	return &AuthController{}
}

// SignIn POST /manager/auth
func SignIn(c *gin.Context) {
	type params struct {
		Email    string `json:"email"    binding:"required,email"`
		Password string `json:"password" binding:"required"`
	}
	var p params
	if err := c.ShouldBind(&p); err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	manager, err := model.ManagerSignIn(p.Email, p.Password)
	if err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	if err := session.SetManagerID(c, manager.ID); err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, manager.ToResponse())
}

// SignOut DELETE /manager/auth
func SignOut(c *gin.Context) {
	if err := session.Clear(c); err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	c.Status(http.StatusOK)
}
