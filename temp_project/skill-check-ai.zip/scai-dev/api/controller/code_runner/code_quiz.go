package code_runner

import (
	"app/controller"
	"app/model"
	"github.com/gin-gonic/gin"
	"github.com/rs/zerolog/log"
	"net/http"
)

type codeQuizResultController struct {
	codeQuizAnswerRepository                *model.CodeQuizAnswerRepository
	userExaminationCodeQuizResultRepository *model.UserExaminationCodeQuizResultRepository
	userExaminationRepository               *model.UserExaminationRepository
}

func NewCodeQuizResultController(
	codeQuizAnswerRepository *model.CodeQuizAnswerRepository,
	userExaminationCodeQuizResultRepository *model.UserExaminationCodeQuizResultRepository,
	userExaminationRepository *model.UserExaminationRepository,
) *codeQuizResultController {
	return &codeQuizResultController{
		codeQuizAnswerRepository,
		userExaminationCodeQuizResultRepository,
		userExaminationRepository,
	}
}

// CreateOrUpdate 結果の作成 or 更新
// code runnerの結果パラメータフォーマット
// {
//   "id":"900d810f-6731-48ea-b276-f1ab483484c2", // 提出時のsubmission_id
//   "app":"scai",
//   "problem":"1", // code_quizのid
//   "result":"OK",
//   "score":"9/10",
//   "statistics":"AC:9,WA:0,TLE:1,MLE:0,RE:0,CE:0,FE:0"
// }
func (c *codeQuizResultController) CreateOrUpdate(ctx *gin.Context) {
	type params struct {
		SubmissionID string `json:"id"      binding:"required"`
		Problem      string `json:"problem" binding:"required"`
		Result       string `json:"result"  binding:"required"`
		Score        string `json:"score"`
		Statistics   string `json:"statistics"`
	}

	var p params
	err := ctx.ShouldBindJSON(&p)
	if err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	log.Printf("code runner param %v", p)

	answer, err := c.codeQuizAnswerRepository.
		WithPreload().
		FindBySubmissionID(p.SubmissionID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if answer == nil {
		controller.SetNotFoundError(ctx, "Not found code quiz answer")
		return
	}
	if answer.UserExamination == nil {
		controller.SetNotFoundError(ctx, "Not found user examination")
		return
	}

	result := &model.UserExaminationCodeQuizResult{
		UserExaminationID: model.UserExaminationID(answer.UserExaminationID),
		ExaminationID:     answer.UserExamination.ExaminationID,
		CodeQuizID:        answer.CodeQuizID,
		SubmissionID:      *answer.SubmissionID,
		Result:            p.Result,
		Score:             &p.Score,
		Statistics:        &p.Statistics,
	}

	// TODO: 結果の存在チェックをする
	// TODO: upsertにできないか
	err = c.userExaminationCodeQuizResultRepository.Insert(result)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	// TODO: Insertのhookにできないか
	// code runnerから送信された結果と同一の試験の回答数と結果数が一致する場合は、
	// 全ての結果が揃ったので、試験を終了させる
	answers, err := c.codeQuizAnswerRepository.
		FilterByUserExaminationID(
			model.UserExaminationID(answer.UserExaminationID),
		)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	results, err := c.userExaminationCodeQuizResultRepository.
		FilterByUserExaminationID(
			model.UserExaminationID(answer.UserExaminationID),
		)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	if len(answers) == len(results) {
		err = answer.UserExamination.Finish()
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}
		err = c.userExaminationRepository.Update(answer.UserExamination)
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}
	}

	ctx.JSON(http.StatusOK, result)
}
