package controller

import (
	"app/middleware"
	"errors"
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
)

// SetErrorContext APIエラーコンテキストを設定
func SetErrorContext(c *gin.Context, err error, httpCode int, msg string) error {
	return c.Error(err).SetType(gin.ErrorTypePublic).
		SetMeta(middleware.APIError{
			HTTPCode: httpCode,
			Message:  msg,
		})
}

func SetInternalServerError(c *gin.Context, err error) {
	// TODO: ログ出力はmiddlewareに移す
	log.Printf("%+v", err)

	c.Error(err).SetType(gin.ErrorTypePublic).
		SetMeta(middleware.APIError{
			HTTPCode: http.StatusInternalServerError,
			Message:  "Internal server error",
		})
}

func SetNotFoundError(c *gin.Context, msg string) {
	c.Error(errors.New(msg)).SetType(gin.ErrorTypePublic).
		SetMeta(middleware.APIError{
			HTTPCode: http.StatusNotFound,
			Message:  msg,
		})
}

func SetBadRequestError(c *gin.Context, msg string) {
	c.Error(errors.New(msg)).SetType(gin.ErrorTypePublic).
		SetMeta(middleware.APIError{
			HTTPCode: http.StatusBadRequest,
			Message:  msg,
		})
}
