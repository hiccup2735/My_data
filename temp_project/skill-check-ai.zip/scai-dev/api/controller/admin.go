package controller

import (
	"app/env"
	"app/model"
	"app/session"
	"app/util/image"
	"app/util/s3"
	"errors"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
	"mime/multipart"
	"net/http"
)

func AdminGetAdmin(c *gin.Context) {
	admin, err := session.GetContextAdmin(c)
	if err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, admin.ToResponse())
}

func AdminPostAdmin(c *gin.Context) {
	var admin *model.Admin
	if err := c.ShouldBindJSON(&admin); err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(admin.Password), 10)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	admin.Password = string(hash)
	if err := model.AdminCreate(admin); err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, admin.ToResponse())
}

func AdminPostImageQuestionsUpload(c *gin.Context) {
	file, header, err := c.Request.FormFile("image")
	if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	format, err := image.Detect(file)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}
	key, err := uploadImage(header, format)
	if err != nil {
		c.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}
	defer file.Close()
	c.JSON(200, gin.H{
		// TODO 環境変数で設定する
		"image_url": "https://scai-" + env.Config.Env + "-app.s3-ap-northeast-1.amazonaws.com/" + key,
	})
}

func uploadImage(fileHeader *multipart.FileHeader, format string) (string, error) {
	contentType, err := convertMimeType(format)
	if err != nil {
		return "", err
	}

	uuid, err := uuid.NewRandom()
	if err != nil {
		return "", err
	}

	key := "uploaded/question/" + uuid.String() + "/" + fileHeader.Filename
	if err := s3.UploadRawFile(fileHeader, key, contentType); err != nil {
		return "", err
	}
	// TODO: url
	return key, nil
}

func convertMimeType(format string) (string, error) {
	switch format {
	case "png":
		return "image/png", nil
	case "gif":
		return "image/gif", nil
	case "jpg", "jpeg":
		return "image/jpeg", nil
	}
	return "", errors.New("invalid format")
}
