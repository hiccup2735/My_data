package user

import (
	"app/controller"
	"app/model"
	"app/session"
	"github.com/gin-gonic/gin"
	"net/http"
	"time"
)

type authController struct{}

func NewAuthController() *authController {
	return &authController{}
}

func (*authController) SignIn(ctx *gin.Context) {
	type params struct {
		Email    string `json:"email"    binding:"required,email"`
		Password string `json:"password" binding:"required"`
	}
	var p params
	if err := ctx.ShouldBind(&p); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	user, err := model.UserSignIn(p.Email, p.Password)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest, err.Error())
		return
	}

	now := time.Now()
	if err := user.UpdateLastLoginAt(now); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	if err := session.SetUserID(ctx, user.ID); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	response := user.ToResponse() // 今後関連テーブルを増やした場合はuser.GetResponse()を使うこと
	ctx.JSON(http.StatusOK, response)
}

func (*authController) SignOut(ctx *gin.Context) {
	if err := session.Clear(ctx); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	ctx.Status(http.StatusOK)
}
