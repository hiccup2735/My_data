package user

import (
	"app/model"
	"time"
)

type userExaminationSummaryResponse struct {
	ID            int        `json:"id"`
	Name          string     `json:"name"`
	Description   string     `json:"description"`
	LimitMin      int        `json:"limit_min"`
	AvailableAt   *time.Time `json:"available_at"`
	StartLimitAt  *time.Time `json:"start_limit_at"`
	StartedAt     *time.Time `json:"started_at"`
	AnswerLimitAt *time.Time `json:"answer_limit_at"`
	SubmittedAt   *time.Time `json:"submitted_at"`
	FinishedAt    *time.Time `json:"finished_at"`
	Status        string     `json:"status"`
}

func toUserExaminationSummaryResponse(exam *model.UserExamination) (res *userExaminationSummaryResponse, err error) {
	status, err := exam.Status()
	if err != nil {
		// TODO: エラーlog
		return nil, err
	}

	return &userExaminationSummaryResponse{
		ID:            exam.ID,
		Name:          exam.Examination.Name,
		Description:   exam.Examination.Description,
		LimitMin:      exam.Examination.LimitMin,
		AvailableAt:   exam.License.StartDateTime,
		StartLimitAt:  exam.License.EndDateTime,
		StartedAt:     exam.StartedAt,
		AnswerLimitAt: exam.AnswerLimitAt,
		SubmittedAt:   exam.SubmittedAt,
		FinishedAt:    exam.FinishedAt,
		Status:        status.ToString(),
	}, nil
}
