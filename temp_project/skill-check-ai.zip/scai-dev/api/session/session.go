package session

import (
	"fmt"
	"github.com/gin-gonic/gin"
)

const (
	sessionExpires = "sessionExpires"
	userID         = "userID"
	adminID        = "adminID"
	organizerID    = "organizerID"
	operatorID     = "operatorID"
	managerID      = "managerID"
)

// SetSessionExpires SessionExpiresを保存
func SetSessionExpires(c *gin.Context, value int) error {
	return set(c, sessionExpires, value)
}

// GetSessionExpires SessionExpiresを取得
func GetSessionExpires(c *gin.Context) (int, error) {
	v := get(c, sessionExpires)
	value, ok := v.(int)
	if !ok {
		return 0, fmt.Errorf("%s is not found in session", sessionExpires)
	}
	return value, nil
}

// SetUserID UserIDを保存
func SetUserID(c *gin.Context, value int) error {
	return set(c, userID, value)
}

// GetUserID UserIDを取得
func GetUserID(c *gin.Context) (int, error) {
	v := get(c, userID)
	value, ok := v.(int)
	if !ok {
		return 0, fmt.Errorf("%s is not found in session", userID)
	}
	return value, nil
}

// GetAdminID AdminIDを取得
func GetAdminID(c *gin.Context) (int, error) {
	v := get(c, adminID)
	value, ok := v.(int)
	if !ok {
		return 0, fmt.Errorf("%s is not found in session", adminID)
	}
	return value, nil
}

// SetAdminID AdminIDを保存
func SetAdminID(c *gin.Context, value int) error {
	return set(c, adminID, value)
}

// GetOrganizerID OrganizerIDを取得
func GetOrganizerID(c *gin.Context) (int, error) {
	v := get(c, organizerID)
	value, ok := v.(int)
	if !ok {
		return 0, fmt.Errorf("%s is not found in session", organizerID)
	}
	return value, nil
}

// SetOrganizerID OrganizerIDを保存
func SetOrganizerID(c *gin.Context, value int) error {
	return set(c, organizerID, value)
}

func GetOperatorID(c *gin.Context) (int, error) {
	v := get(c, operatorID)
	value, ok := v.(int)
	if !ok {
		return 0, fmt.Errorf("%s is not found in session", operatorID)
	}
	return value, nil
}

func SetOperatorID(c *gin.Context, value int) error {
	return set(c, operatorID, value)
}

func GetManagerID(c *gin.Context) (int, error) {
	v := get(c, managerID)
	value, ok := v.(int)
	if !ok {
		return 0, fmt.Errorf("%s is not found in session", managerID)
	}
	return value, nil
}

func SetManagerID(c *gin.Context, value int) error {
	return set(c, managerID, value)
}
