package mail

import (
	"app/env"
	"fmt"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/ses"
	"log"
	"net/smtp"
	"strings"
)

var (
	server     = env.Config.MailServer
	from       = env.Config.MailFrom
	awsSession = session.Must(session.NewSessionWithOptions(session.Options{
		SharedConfigState: session.SharedConfigEnable,
	}))
)

// Send メール送信
func Send(to string, title string, body string) error {
	formattedBody := format(body)
	if server == "" {
		return sendBySES(to, title, formattedBody)
	}
	return sendByLocal(to, title, formattedBody)
}

func format(body string) string {
	replacer := strings.NewReplacer("\t", " ", "\r\n", "\n", "\r", "\n")
	lines := strings.Split(replacer.Replace(body), "\n")
	var newLines = make([]string, len(lines))
	for i, line := range lines {
		newLines[i] = strings.Trim(line, " ")
	}
	return strings.Trim(strings.Join(newLines, "\n"), "\n")
}

func sendBySES(to string, title string, body string) error {
	svc := ses.New(awsSession)

	log.Printf("Debug: sendBySES from %s", from)
	log.Printf("Debug: sendBySES to %s", to)
	log.Printf("Debug: sendBySES title %s", title)
	log.Printf("Debug: sendBySES body %s", body)

	input := &ses.SendEmailInput{
		Destination: &ses.Destination{
			ToAddresses: []*string{
				aws.String(to),
			},
		},
		Message: &ses.Message{
			Body: &ses.Body{
				Text: &ses.Content{
					Charset: aws.String("UTF-8"),
					Data:    aws.String(body),
				},
			},
			Subject: &ses.Content{
				Charset: aws.String("UTF-8"),
				Data:    aws.String(title),
			},
		},
		Source: aws.String(from),
	}
	_, err := svc.SendEmail(input)
	return err
}

func sendByLocal(to string, title string, body string) error {
	message := []byte(strings.ReplaceAll(fmt.Sprintf("From: %s\nTo: %s\nSubject: %s\n\n%s", from, to, title, body), "\n", "\r\n"))
	return smtp.SendMail(server, smtp.CRAMMD5Auth("", ""), from, []string{to}, message)
}
