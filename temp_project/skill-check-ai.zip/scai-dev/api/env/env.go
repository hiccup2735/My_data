package env

import (
	"github.com/kelseyhightower/envconfig"
)

// Config env.Config.FooBarで環境変数を取得
var Config config

type config struct {
	Env           string `envconfig:"ENV"             required:"true"`
	Port          string `envconfig:"PORT"            required:"true"`
	Domain        string `envconfig:"DOMAIN"          required:"true"`
	Secret        string `envconfig:"SECRET"          required:"true"`
	MailFrom      string `envconfig:"MAIL_FROM"       required:"true"`
	MailServer    string `envconfig:"MAIL_SERVER"     required:"false"`
	DBHost        string `envconfig:"DB_HOST"         required:"true"`
	DBPort        string `envconfig:"DB_PORT"         required:"true"`
	DBUser        string `envconfig:"DB_USER"         required:"true"`
	DBPassword    string `envconfig:"DB_PASSWORD"     required:"true"`
	DBName        string `envconfig:"DB_NAME"         required:"true"`
	DBCharset     string `envconfig:"DB_CHARSET"      required:"true"`
	DBCollation   string `envconfig:"DB_COLLATION"    required:"true"`
	DBTimezone    string `envconfig:"DB_TIMEZONE"     required:"true"`
	AWSS3Endpoint string `envconfig:"AWS_S3_ENDPOINT" required:"false"`
	AWSS3Bucket   string `envconfig:"AWS_S3_BUCKET"   required:"true"`
	// FIXME: esc設定後required trueにする
	CodeRunnerAWSAccessKeyID     string `envconfig:"CODE_RUNNER_AWS_ACCESS_KEY_ID" required:"false"`
	CodeRunnerAWSSecretAccessKey string `envconfig:"CODE_RUNNER_AWS_SECRET_ACCESS_KEY" required:"false"`
	CodeRunnerAWSS3Bucket        string `envconfig:"CODE_RUNNER_AWS_S3_BUCKET" required:"false"`
}

func init() {
	if err := envconfig.Process("", &Config); err != nil {
		panic(err)
	}
}
