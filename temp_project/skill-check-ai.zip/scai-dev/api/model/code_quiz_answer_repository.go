package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
)

type CodeQuizAnswerRepository struct {
	db *gorm.DB
}

func NewCodeQuizAnswerRepository() *CodeQuizAnswerRepository {
	return &CodeQuizAnswerRepository{db: db}
}

func (r *CodeQuizAnswerRepository) FindByID(id CodeQuizAnswerID) (*CodeQuizAnswer, error) {
	entity := &CodeQuizAnswer{}
	err := r.db.First(entity, id.ToInt()).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *CodeQuizAnswerRepository) Insert(entity *CodeQuizAnswer) error {
	err := r.db.Create(&entity).Error
	return errors.WithStack(err)
}

func (r *CodeQuizAnswerRepository) Update(entity *CodeQuizAnswer) error {
	err := r.db.Set("gorm:save_associations", false).
		Model(&CodeQuizAnswer{}).
		Where("id = ?", entity.ID).
		Updates(map[string]interface{}{
			"UserExaminationID": entity.UserExaminationID,
			"QuestionID":        entity.QuestionID,
			"CodeQuizID":        entity.CodeQuizID,
			"Lang":              entity.Lang,
			"Code":              entity.Code,
			"SubmissionID":      entity.SubmissionID,
		}).Error
	return errors.WithStack(err)
}

func (r *CodeQuizAnswerRepository) DeleteByID(id CodeQuizAnswerID) error {
	err := r.db.Delete(&CodeQuizAnswer{}, id.ToInt()).Error
	return errors.WithStack(err)
}

func (r *CodeQuizAnswerRepository) WithPreload() *CodeQuizAnswerRepository {
	r.db = r.db.Preload("UserExamination")
	return r
}

func (r *CodeQuizAnswerRepository) FindByUniqueID(userExaminationID int, questionID QuestionID, codeQuizID CodeQuizID) (*CodeQuizAnswer, error) {
	entity := &CodeQuizAnswer{}
	err := r.db.Where("user_examination_id = ?", userExaminationID).
		Where("question_id = ?", questionID.ToInt()).
		Where("code_quiz_id = ?", codeQuizID.ToInt()).
		First(entity).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *CodeQuizAnswerRepository) FindBySubmissionID(submissionID string) (*CodeQuizAnswer, error) {
	entity := &CodeQuizAnswer{}
	err := r.db.Where("submission_id = ?", submissionID).
		First(entity).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *CodeQuizAnswerRepository) FilterByUserExaminationID(userExaminationID UserExaminationID) ([]CodeQuizAnswer, error) {
	var entities []CodeQuizAnswer
	err := r.db.Where("user_examination_id = ?", userExaminationID.ToInt()).
		Find(&entities).Error
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return entities, nil
}
