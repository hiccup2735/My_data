package model

// Quiz 選択形式の設問
type Quiz struct {
	NewModel
	QuestionID  int       `json:"question_id" gorm:"index;not null"`
	Sequence    int       `json:"sequence"    gorm:"not null"                     validate:"min=0,max=4294967295"`
	Description string    `json:"description" gorm:"type:varchar(10000);not null" validate:"min=1,max=10000"`
	Choices     []*Choice `json:"choices"     gorm:""                             validate:"min=2,max=10"`
}

type QuizID int

// Copy copy new struct from receiver
func (quiz *Quiz) Copy() (newQuiz *Quiz, err error) {
	if err = copyModel(quiz, &newQuiz); err != nil {
		return nil, err
	}

	// TODO: question.goのCopyと同一の対応を検討
	newQuiz.ID = 0

	if quiz.Choices != nil {
		newChoices := make([]*Choice, 0)
		for _, choice := range quiz.Choices {
			newChoice, err := choice.Copy()
			if err != nil {
				return nil, err
			}
			newChoices = append(newChoices, newChoice)
		}
		newQuiz.Choices = newChoices
	}

	return newQuiz, nil
}

// GetMaxPoint get max point
func (quiz *Quiz) GetMaxPoint() (p int) {
	for _, c := range quiz.Choices {
		if c.Point > p {
			p = c.Point
		}
	}

	return p
}
