package model

import (
	"time"
)

// License licenses
type License struct {
	NewModel
	Count            int                `json:"count"                gorm:"not null"        validate:"required,min=1,max=4294967395"`
	StartDateTime    *time.Time         `json:"start_date_time"      gorm:"not null"        validate:"required"`
	EndDateTime      *time.Time         `json:"end_date_time"        gorm:""                validate:"omitempty,gtefield=StartDateTime"`
	OrganizationID   int                `json:"organization_id"      gorm:"not null"        validate:"required,min=1,max=4294967395"`
	Organization     Organization       `json:"-"                    gorm:""                validate:""`
	ExaminationID    int                `json:"examination_id"       gorm:"not null"        validate:"required,min=1,max=4294967395"`
	Examination      Examination        `json:"-"                    gorm:""                validate:""`
	UserExaminations []*UserExamination `json:"-"                    gorm:""                validate:""`
}

func LicenseFindByID(id int) (*License, error) {
	license := &License{}
	if err := db.Preload("Organization").
		First(license, id).Error; err != nil {
		return nil, err
	}
	return license, nil
}

// LicenseFilterConditions filter licenses condition
type LicenseFilterConditions struct {
	OrganizationID int
	ExaminationID  int
}

// LicenseFilterBy filter licenses by condition
func LicenseFilterBy(cond LicenseFilterConditions) (data []*License, err error) {
	// note: 0 valueは条件に含まれてない
	// https://gorm.io/ja_JP/docs/query.html#Struct-amp-Map-Conditions
	if err = db.Where(&License{
		OrganizationID: cond.OrganizationID,
		ExaminationID:  cond.ExaminationID,
	}).
		// TODO: preloadを絞りたい
		Preload("UserExaminations").
		Preload("UserExaminations.License").
		Preload("UserExaminations.User").
		Find(&data).Error; err != nil {
		return nil, err
	}

	return data, nil
}

func (m *License) Update(data *License) error {
	return db.First(m).Updates(data).Error
}

func (m *License) Delete() error {
	return db.Delete(&m).Error
}

func (m *License) CountUsed() int {
	return db.Model(&m).Association("UserExaminations").Count()
}

func (m *License) CountQuantity() int {
	return m.Count - m.CountUsed()
}

func (m *License) IsAvailable() bool {
	return !m.isExpired() && m.hasStock()
}

func (m *License) hasStock() bool {
	return (m.Count - m.CountUsed()) > 0
}

func (m *License) isExpired() bool {
	now := time.Now()
	return now.Before(*m.StartDateTime) || now.After(*m.EndDateTime)
}

func FindLicenses(organizationId int, page int, pageSize int) (licenses []*License, err error) {
	tx := db.Where("organization_id = ?",  organizationId)
	tx = appendPagerQuery(tx, page, pageSize).Preload("Organization").Preload("Examination")

	if err := tx.Find(&licenses).Error; err != nil {
		return nil, err
	}

	return licenses, nil
}

func CountLicense(organizationId int) (count int, err error) {
	var licenses []*License

	tx := db.Where("organization_id = ?",  organizationId)

	if err := tx.Find(&licenses).Count(&count).Error; err != nil {
		return 0, err
	}

	return count, nil
}