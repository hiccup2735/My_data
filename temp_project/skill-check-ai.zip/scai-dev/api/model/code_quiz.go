package model

type CodeQuizID int

func (i CodeQuizID) ToInt() int {
	return int(i)
}

type CodeQuizType string

const (
	CodeQuizTypeStandardIO CodeQuizType = "standard_io"
	CodeQuizTypeFileIO     CodeQuizType = "file_io"
)

func (t CodeQuizType) ToString() string {
	return string(t)
}

func (t CodeQuizType) IsValid() bool {
	switch t {
	case CodeQuizTypeStandardIO, CodeQuizTypeFileIO:
		return true
	}
	return false
}

// CodeQuiz コード提出形式の設問
type CodeQuiz struct {
	ID           CodeQuizID   `json:"id,omitempty" gorm:"primary_key"                       validate:""`
	QuestionID   QuestionID   `json:"question_id"  gorm:""                                  validate:""`
	Sequence     int          `json:"sequence"     gorm:"not null"                          validate:"min=0,max=4294967295"`
	IsSubmitted  bool         `json:"is_submitted" gorm:"not null;default:false"            validate:"boolean"`
	Type         CodeQuizType `json:"type"         gorm:"not null"                          validate:"min=0,max=10000"`
	Description  string       `json:"description"  gorm:"type:varchar(10000);not null"      validate:"min=1,max=10000"`
	MemoryLimit  int          `json:"memory_limit" gorm:"not null"                          validate:"min=1,max=4294967295"`
	TimeLimit    int          `json:"time_limit"   gorm:"not null"                          validate:"min=1,max=4294967295"`
	Criteria     int          `json:"criteria"     gorm:"not null"                          validate:"min=0,max=100"`
	Compare      string       `json:"compare"      gorm:""                                  validate:"min=1,max=10000"`
	IsNotDeleted *bool        `json:"-"            gorm:"default:true;index:is_not_deleted" validate:""`
	Timestamps
	CodeQuizFiles []*CodeQuizFile `json:"files"            gorm:"" validate:""`
	Answer        *CodeQuizAnswer `json:"answer,omitempty" gorm:"" validate:""`
	Question      *Question       `json:"-"                gorm:"" validate:""`
}
