package model

import (
	"github.com/jinzhu/gorm"
	"math"
)

type Question struct {
	NewModel
	Name                 string                 `json:"name"         gorm:"not null"                        validate:"required,min=1,max=255"`
	Description          string                 `json:"description"  gorm:"type:varchar(10000);not null"    validate:"min=0,max=10000"`
	ImageURI             string                 `json:"image_uri"    gorm:""                                validate:"omitempty,min=1,max=255,url"`
	Level                int                    `json:"level"        gorm:""                                validate:"min=0,max=4294967295"`
	Quizzes              []*Quiz                `json:"quizzes"      gorm:""                                validate:"min=0,max=10"`
	CodeQuizzes          []*CodeQuiz            `json:"code_quizzes" gorm:""                                validate:""`
	Examinations         []*Examination         `json:"-"            gorm:"many2many:examination_questions" validate:""`
	ExaminationQuestions []*ExaminationQuestion `json:"-"            gorm:""                                validate:""`
	Answers              []*Answer              `json:"-"            gorm:""                                validate:""`
	Tags                 []*QuestionTag         `json:"tags"         gorm:""                                validate:""`
	Metadata             []*QuestionMetadata    `json:"metadata"     gorm:""                                validate:""`
	Group                int                    `json:"group"        gorm:"not null;default:0"              validate:"min=0,max=255"`
}

type CopiedQuestion struct {
	OriginID int
	*Question
}

type QuestionID int

func (i QuestionID) ToInt() int {
	return int(i)
}

// QuestionPreload preload relation
type QuestionPreload struct {
	Quizzes          bool
	QuizzesChoices   bool
	CodeQuizzes      bool
	CodeQuizzesFiles bool
	Examinations     bool
}

func appendQuestionSearchQuery(db *gorm.DB, searchWord string) *gorm.DB {
	return db.Where("(name LIKE ? or description LIKE ?)", "%"+searchWord+"%", "%"+searchWord+"%")
}

func appendQuestionGroupQuery(db *gorm.DB, group int) *gorm.DB {
	return db.Where("`group` = ?", group)
}

func appendQuestionTagsQuery(db *gorm.DB, tags []string) *gorm.DB {
	return db.Where("id IN (SELECT DISTINCT question_id FROM question_tags WHERE name IN (?))", tags)
}

// FindQuestionByID find question by id
func FindQuestionByID(id int, preload QuestionPreload) (*Question, error) {
	question := &Question{}
	tx := db

	tx = tx.Preload("Tags").Preload("Metadata")

	if preload.Quizzes {
		tx = tx.Preload("Quizzes", func(db *gorm.DB) *gorm.DB {
			return db.Order("sequence")
		})
	}

	if preload.QuizzesChoices {
		tx = tx.Preload("Quizzes.Choices", func(db *gorm.DB) *gorm.DB {
			return db.Order("sequence")
		})
	}

	if preload.CodeQuizzes {
		tx = tx.Preload("CodeQuizzes", func(db *gorm.DB) *gorm.DB {
			return db.Order("sequence")
		})
	}

	if preload.CodeQuizzesFiles {
		tx = tx.Preload("CodeQuizzes.CodeQuizFiles")
	}

	if preload.Examinations {
		tx = tx.Preload("Examinations")
	}

	if err := tx.First(question, id).Error; err != nil {
		return nil, err
	}

	return question, nil
}

// CountQuestion count question
func CountQuestion(searchWord string, tags []string, group int) (count int, err error) {
	var questions []*Question

	tx := db
	if searchWord != "" {
		tx = appendQuestionSearchQuery(tx, searchWord)
	}

	if group != 0 {
		tx = appendQuestionGroupQuery(tx, group)
	}

	if len(tags) > 0 {
		tx = appendQuestionTagsQuery(tx, tags)
	}

	if err := tx.Find(&questions).Count(&count).Error; err != nil {
		return 0, err
	}

	return count, nil
}

// FilterByQuestion filter question
// TODO: ソートできるようにする
func FilterByQuestion(searchWord string, tags []string, page int, pageSize int, group int) (questions []*Question, err error) {
	tx := db
	tx = tx.Preload("Tags").Preload("Metadata")

	if searchWord != "" {
		tx = appendQuestionSearchQuery(tx, searchWord)
	}
	if group != 0 {
		tx = appendQuestionGroupQuery(tx, group)
	}

	if len(tags) > 0 {
		tx = appendQuestionTagsQuery(tx, tags)
	}

	tx = appendPagerQuery(tx, page, pageSize)
	if err := tx.Find(&questions).Error; err != nil {
		return nil, err
	}

	return questions, nil
}

// CreateQuestion create question
func CreateQuestion(question *Question) error {
	return db.Create(question).Error
}

// ConvNilToEmptySlice convert nil slice to empty slice
func (question *Question) ConvNilToEmptySlice() {
	if question.Quizzes == nil {
		question.Quizzes = make([]*Quiz, 0)
	}
}

// Update update
func (question *Question) Update(data *Question) error {
	return db.First(question).Updates(
		map[string]interface{}{
			"name":        data.Name,
			"description": data.Description,
			"image_uri":   data.ImageURI,
			"level":       data.Level,
			"tags":        data.Tags,
			"metadata":    data.Metadata,
			"group":       data.Group,
		},
	).Error
}

func (question *Question) Delete() error {
	return db.Delete(&question).Error
}

// Copy copy new struct from receiver
func (ques *Question) Copy() (newQues *Question, err error) {
	if err = copyModel(ques, &newQues); err != nil {
		return nil, err
	}

	// TODO: structのjson '-'にすれば、unmarshal時に値が設定されないので、
	//       IDの初期値を設定しなくてもいいので、structの定義でできないか検討したい
	//       https://github.com/jinzhu/copier を利用するとより簡潔にできる可能性も
	newQues.ID = 0

	if ques.Quizzes != nil {
		newQuizzes := make([]*Quiz, 0)
		for _, quiz := range ques.Quizzes {
			newQuiz, err := quiz.Copy()
			if err != nil {
				return nil, err
			}
			newQuizzes = append(newQuizzes, newQuiz)
		}
		newQues.Quizzes = newQuizzes
	}

	if ques.Tags != nil {
		newTags := make([]*QuestionTag, 0)
		for _, t := range ques.Tags {
			newTag, err := t.Copy()
			if err != nil {
				return nil, err
			}
			newTags = append(newTags, newTag)
		}
		newQues.Tags = newTags
	}

	metadata := make([]*QuestionMetadata, len(ques.Metadata))
	for i, d := range ques.Metadata {
		new, err := d.Copy()
		if err != nil {
			return nil, err
		}
		metadata[i] = new
	}
	newQues.Metadata = metadata

	return newQues, nil
}

// GetPoint get point
func (ques *Question) GetPoint() (p int) {
	for _, quiz := range ques.Quizzes {
		p += quiz.GetMaxPoint()
	}

	return p
}

type QuestionSummary struct {
	*Question
	AnswerCount        int
	CorrectAnswerCount int
}

func (q *QuestionSummary) GetCorrectAnswerRate() float64 {
	div := 1
	if q.AnswerCount > 0 {
		div = q.AnswerCount
	}

	return math.Round(float64(q.CorrectAnswerCount) / float64(div) * 100)
}

func GetQuestionAnswerCount(ids []int) (rows []*QuestionSummary, err error) {
	if err = db.Model(&Question{}).
		Select(`
			questions.id AS id,
			count(answers.id) AS answer_count,
			count(IF(choices.point > 0, answers.id, null)) AS correct_answer_count
		`).
		Joins("left join quizzes on questions.id = quizzes.question_id").
		Joins("left join choices on quizzes.id = choices.quiz_id").
		Joins("left join answers on choices.id = answers.choice_id").
		Where("questions.id IN (?)", ids).
		Group("questions.id").
		Scan(&rows).Error; err != nil {
		return nil, err
	}

	return rows, nil
}
