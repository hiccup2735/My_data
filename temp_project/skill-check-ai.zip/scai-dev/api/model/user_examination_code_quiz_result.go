package model

type UserExaminationCodeQuizResultID int

func (i UserExaminationCodeQuizResultID) ToInt() int {
	return int(i)
}

type UserExaminationCodeQuizResult struct {
	ID                UserExaminationCodeQuizResultID `json:"id"                  gorm:"primary_key"                             validate:""`
	UserExaminationID UserExaminationID               `json:"user_examination_id" gorm:"not null;unique_index:is_not_deleted"    validate:"required,min=1,max=4294967295"`
	ExaminationID     int                             `json:"examination_id"      gorm:"not null;index:idx_examination_id"       validate:"required,min=1,max=4294967295"`
	CodeQuizID        CodeQuizID                      `json:"code_quiz_id"        gorm:"not null;unique_index:is_not_deleted"    validate:"required,min=1,max=4294967295"`
	SubmissionID      string                          `json:"submission_id"       gorm:"not null;unique_index:idx_submission_id" validate:"required"`
	Result            string                          `json:"result"              gorm:""                                        validate:"required"`
	Score             *string                         `json:"score"               gorm:""                                        validate:""`
	Statistics        *string                         `json:"statistics"          gorm:""                                        validate:""`
	Timestamps
	CodeQuiz *CodeQuiz `json:"-" gorm:"" validate:""`
}
