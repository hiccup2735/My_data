package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
)

type OrganizationCategoryRepository struct {
	db *gorm.DB
}

func NewOrganizationCategoryRepository() *OrganizationCategoryRepository {
	return &OrganizationCategoryRepository{db: db}
}

func (r *OrganizationCategoryRepository) FindAll() ([]OrganizationCategory, error) {
	var entities []OrganizationCategory
	err := r.db.Find(&entities).Error
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return entities, nil
}

func (r *OrganizationCategoryRepository) FindByID(id OrganizationCategoryID) (*OrganizationCategory, error) {
	entity := &OrganizationCategory{}
	err := r.db.First(entity, int(id)).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *OrganizationCategoryRepository) Insert(entity OrganizationCategory) error {
	err := r.db.Create(&entity).Error
	return errors.WithStack(err)
}

func (r *OrganizationCategoryRepository) Update(entity OrganizationCategory) error {
	err := r.db.Model(&entity).
		Where("id = ?", entity.ID).
		Updates(map[string]interface{}{
			"Name": entity.Name,
		}).Error
	return errors.WithStack(err)
}
