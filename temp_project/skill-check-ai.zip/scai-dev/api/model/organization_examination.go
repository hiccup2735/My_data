package model

// ExaminationOrganization examination_organization
type ExaminationOrganization struct {
	Model
	ExaminationID  int           `json:"examination_id"  gorm:"not null;unique_index:is_not_deleted" validate:"required_without=Examination,min=1,max=4294967295"`
	OrganizationID int           `json:"organization_id" gorm:"not null;unique_index:is_not_deleted" validate:"required_without=Organization,min=1,max=4294967295"`
	Examination    *Examination  `json:"examination"     gorm:""                                     validate:"required_without=ExaminationID"`
	Organization   *Organization `json:"organization"    gorm:""                                     validate:"required_without=OrganizationID"`
}
