package model

import (
	"github.com/jinzhu/gorm"
)

// UserResponse UserResponse
type UserResponse struct {
	Name       string `json:"name"`
	Email      string `json:"email"`
	IsVerified bool   `json:"is_verified"`
}

// ToResponse User
func (user *User) ToResponse() *UserResponse {
	return &UserResponse{
		Name:       user.Name,
		Email:      user.Email,
		IsVerified: user.IsVerified(),
	}
}

// GetResponse User
func (user *User) GetResponse() (*UserResponse, error) {
	if err := db.First(user, user.ID).Error; err != nil {
		return nil, err
	}
	return user.ToResponse(), nil
}

func (userExamination *UserExamination) GetExaminationAnswers() error {
	if err := db.
		Preload("Examination.ExaminationQuestions.Category").
		Preload("Examination.Questions", func(db *gorm.DB) *gorm.DB { return db.Order("examination_questions.sequence") }).
		Preload("Examination.Questions.Quizzes", func(db *gorm.DB) *gorm.DB { return db.Order("sequence") }).
		Preload("Examination.Questions.Quizzes.Choices", func(db *gorm.DB) *gorm.DB { return db.Order("sequence") }).
		Preload("Examination.Questions.Quizzes.Choices.Answers", "user_examination_id = ?", userExamination.ID).
		Preload("Examination.Questions.Answers", "user_examination_id = ?", userExamination.ID).
		First(userExamination, userExamination.ID).Error; err != nil {
		return err
	}
	return nil
}

// GetResponse 詳細用
func (userExamination *UserExamination) GetResponse() (*UserExaminationResponse, error) {
	if err := userExamination.FindUserExaminationAnswers(); err != nil {
		return nil, err
	}
	return createUserExaminationResponse(userExamination)
}

// ScoreResponse ScoreResponse
type ScoreResponse struct {
	CategoryName string `json:"category_name"`
	Score        int    `json:"score"`
}

// ToResponse Score
func (score *Score) ToResponse() *ScoreResponse {
	return &ScoreResponse{
		CategoryName: score.CategoryName,
		Score:        score.Score,
	}
}

// GetScoreResponses UserExamination
func (userExamination *UserExamination) GetScoreResponses() ([]*ScoreResponse, error) {
	scores, err := userExamination.ScoresByCategory()
	if err != nil {
		return nil, err
	}
	scoreResponses := make([]*ScoreResponse, len(scores))
	for i, score := range scores {
		scoreResponses[i] = score.ToResponse()
	}
	return scoreResponses, nil
}

type CodeQuizForResult struct {
	ID          CodeQuizID `json:"id"`
	Description string     `json:"description"`
}

type QuestionForResult struct {
	ID          QuestionID `json:"id"`
	Name        string     `json:"name"`
	Description string     `json:"description"`
}

type CodeQuizResultResponse struct {
	ID         UserExaminationCodeQuizResultID `json:"id"`
	CodeQuiz   CodeQuizForResult               `json:"code_quiz"`
	Question   QuestionForResult               `json:"question"`
	Result     string                          `json:"result"`
	Score      *string                         `json:"score"`
	Statistics *string                         `json:"statistics"`
}

type AdminResponse struct {
	ID    int    `json:"id"`
	Email string `json:"email"`
}

func (admin *Admin) ToResponse() AdminResponse {
	return AdminResponse{
		ID:    admin.ID,
		Email: admin.Email,
	}
}

type OperatorResponse struct {
	ID    int    `json:"id"`
	Email string `json:"email"`
}

func (operator *Operator) ToResponse() OperatorResponse {
	return OperatorResponse{
		ID:    operator.ID,
		Email: operator.Email,
	}
}

type ManagerResponse struct {
	ID    int    `json:"id"`
	Email string `json:"email"`
	Group int    `json:"group"`
}

func (manager *Manager) ToResponse() ManagerResponse {
	return ManagerResponse{
		ID:    manager.ID,
		Email: manager.Email,
		Group: manager.Group,
	}
}