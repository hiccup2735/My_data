package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
)

type QuestionCategoryRepository struct {
	db *gorm.DB
}

func NewQuestionCategoryRepository() *QuestionCategoryRepository {
	return &QuestionCategoryRepository{db: db}
}

func (r *QuestionCategoryRepository) FindAll() ([]QuestionCategory, error) {
	var entities []QuestionCategory
	err := r.db.Find(&entities).Error
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return entities, nil
}

func (r *QuestionCategoryRepository) FindByID(id QuestionCategoryID) (*QuestionCategory, error) {
	entity := &QuestionCategory{}
	err := r.db.First(entity, int(id)).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *QuestionCategoryRepository) FindByGroup(group int) ([]QuestionCategory, error) {
	var entities []QuestionCategory
	var err error
	if group == 0 {
		err = r.db.Find(&entities).Error
	} else {
		err = r.db.Where("`group`=?", group).Find(&entities).Error
	}
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entities, nil
}

func (r *QuestionCategoryRepository) Insert(entity QuestionCategory) error {
	err := r.db.Create(&entity).Error
	return errors.WithStack(err)
}

func (r *QuestionCategoryRepository) Update(entity QuestionCategory) error {
	err := r.db.Model(&entity).
		Where("id = ?", entity.ID).
		Updates(map[string]interface{}{
			"Name": entity.Name,
			"Group": entity.Group,
		}).Error
	return errors.WithStack(err)
}
