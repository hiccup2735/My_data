package model

type OrganizationCategory struct {
	Model
	Name          string          `json:"name"      gorm:"not null;unique_index:is_not_deleted" validate:"required,min=1,max=255"`
	Organizations []*Organization `json:"-"         gorm:""                                     validate:""`
}

type OrganizationCategoryID int
