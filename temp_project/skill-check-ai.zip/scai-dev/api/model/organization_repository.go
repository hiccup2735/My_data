package model

import (
	"errors"
	"github.com/jinzhu/gorm"
)

type OrganizationRepository struct {
	db *gorm.DB
}

func (r *OrganizationRepository) first() (*Organization, error) {
	defer func() {
		r.db = nil
	}()
	if r.db == nil {
		r.db = db
	}

	entity := &Organization{}
	err := r.db.First(entity).Error
	if err != nil {
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, err
		}
		return nil, nil
	}
	return entity, err
}

func (r *OrganizationRepository) whereID(id OrganizationID) *OrganizationRepository {
	if r.db == nil {
		r.db = db
	}
	r.db = r.db.Where("id = ?", id)
	return r
}

func (r *OrganizationRepository) FindByID(id OrganizationID) (*Organization, error) {
	if r.db == nil {
		r.db = db
	}

	entity, err := r.whereID(id).first()
	if err != nil {
		return nil, err
	}
	if entity == nil {
		return nil, nil
	}
	return entity, nil
}
