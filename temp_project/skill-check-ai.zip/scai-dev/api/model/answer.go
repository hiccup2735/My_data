package model

// Answer 選択形式の設問(Quiz)の回答
type Answer struct {
	Model
	UserExaminationID int              `json:"user_examination_id" gorm:"not null;unique_index:is_not_deleted" validate:"required_without=UserExamination,omitempty,min=1,max=4294967295"`
	QuestionID        int              `json:"question_id"         gorm:"not null;unique_index:is_not_deleted" validate:"required_without=Question,omitempty,min=1,max=4294967295"`
	QuizID            int              `json:"quiz_id"             gorm:"not null;unique_index:is_not_deleted" validate:"required_without=Quiz,omitempty,min=1,max=4294967295"`
	ChoiceID          int              `json:"choice_id"           gorm:"index;not null"                             validate:"required_without=Choice,omitempty,min=1,max=4294967295"`
	UserExamination   *UserExamination `json:"user_examination"    gorm:""                                     validate:"required_without=UserExaminationID"`
	Question          *Question        `json:"question"            gorm:""                                     validate:"required_without=QuestionID"`
	Quiz              *Quiz            `json:"quiz"                gorm:""                                     validate:"required_without=QuizID"`
	Choice            *Choice          `json:"choice"              gorm:""                                     validate:"required_without=ChoiceID"`
}
