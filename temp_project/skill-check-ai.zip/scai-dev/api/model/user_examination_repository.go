package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
)

type UserExaminationRepository struct {
	db *gorm.DB
}

func NewUserExaminationRepository() *UserExaminationRepository {
	return &UserExaminationRepository{db: db}
}

func (r *UserExaminationRepository) Find() ([]*UserExamination, error) {
	defer func() {
		r.db = nil
	}()
	if r.db == nil {
		r.db = db
	}

	var entities []*UserExamination
	err := r.db.Find(&entities).Error
	if err != nil {
		return []*UserExamination{}, err
	}
	return entities, nil
}

func (r *UserExaminationRepository) Count() (int, error) {
	defer func() {
		r.db = nil
	}()
	if r.db == nil {
		r.db = db
	}

	count := 0
	err := r.db.Model(&UserExamination{}).Count(&count).Error
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (r *UserExaminationRepository) ConditionExaminationID(id ExaminationID) *UserExaminationRepository {
	if r.db == nil {
		r.db = db
	}
	r.db = r.db.Where("examination_id = ?", id)
	return r
}

func (r *UserExaminationRepository) PreloadUser() *UserExaminationRepository {
	if r.db == nil {
		r.db = db
	}
	r.db = r.db.Preload("User.Organization")
	return r
}

func (r *UserExaminationRepository) PreloadLicense() *UserExaminationRepository {
	if r.db == nil {
		r.db = db
	}
	r.db = r.db.Preload("License")
	return r
}

func (r *UserExaminationRepository) Limit(n int) *UserExaminationRepository {
	if r.db == nil {
		r.db = db
	}
	r.db = r.db.Limit(n)
	return r
}

func (r *UserExaminationRepository) Offset(n int) *UserExaminationRepository {
	if r.db == nil {
		r.db = db
	}
	r.db = r.db.Offset(n)
	return r
}

func (r *UserExaminationRepository) Update(entity *UserExamination) error {
	err := r.db.Set("gorm:save_associations", false).
		Model(&UserExamination{}).
		Where("id = ?", entity.ID).
		Updates(map[string]interface{}{
			"UserID":        entity.UserID,
			"ExaminationID": entity.ExaminationID,
			"LicenseID":     entity.LicenseID,
			"AvailableAt":   entity.AvailableAt,
			"StartLimitAt":  entity.StartLimitAt,
			"StartedAt":     entity.StartedAt,
			"AnswerLimitAt": entity.AnswerLimitAt,
			"FinishedAt":    entity.FinishedAt,
			"SubmittedAt":   entity.SubmittedAt,
		}).Error

	return errors.WithStack(err)
}

func (r *UserExaminationRepository) FindByCodeQuizUniqueID(id UserExaminationID, questionID QuestionID, codeQuizID CodeQuizID) (*UserExamination, error) {
	entity := &UserExamination{}
	err := r.db.Model(&UserExamination{}).
		Joins("INNER JOIN examinations ON user_examinations.examination_id = examinations.id").
		Joins("INNER JOIN examination_questions ON examinations.id = examination_questions.examination_id").
		Joins("INNER JOIN questions ON examination_questions.question_id = questions.id").
		Joins("INNER JOIN code_quizzes ON questions.id = code_quizzes.question_id").
		Where("user_examinations.id = ?", id.ToInt()).
		Where("questions.id = ?", questionID.ToInt()).
		Where("code_quizzes.id = ?", codeQuizID.ToInt()).
		First(entity).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}
