package model

import (
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	pkgerrors "github.com/pkg/errors"
	"time"
)

type UserExaminationStatus string

const (
	UserExaminationStatusBefore    UserExaminationStatus = "before"    // 受講可能前
	UserExaminationStatusReady     UserExaminationStatus = "ready"     // 受講可能
	UserExaminationStatusAnswering UserExaminationStatus = "answering" // 試験中
	UserExaminationStatusScoring   UserExaminationStatus = "scoring"   // 採点中
	UserExaminationStatusFinished  UserExaminationStatus = "finished"  // 試験終了
	UserExaminationStatusExpired   UserExaminationStatus = "expired"   // 期限切れ（試験開始せず）
)

func (s UserExaminationStatus) ToString() string {
	return string(s)
}

// UserExamination user_examinations
type UserExamination struct {
	Model
	UserID        int          `json:"user_Id"         gorm:"not null;unique_index:is_not_deleted" validate:"required_without=User,omitempty,min=1,max=4294967295"`
	ExaminationID int          `json:"examination_id"  gorm:"not null;unique_index:is_not_deleted" validate:"required_without=Examination,omitempty,min=1,max=4294967295"`
	LicenseID     int          `json:"license_id"      gorm:"not null;unique_index:is_not_deleted" validate:"required,min=1,max=4294967295"`
	AvailableAt   *time.Time   `json:"available_at"    gorm:""                                     validate:""`
	StartLimitAt  *time.Time   `json:"start_limit_at"  gorm:""                                     validate:"required"`
	StartedAt     *time.Time   `json:"started_at"      gorm:""                                     validate:"required_with=AnswerLimitAt FinishedAt"`
	AnswerLimitAt *time.Time   `json:"answer_limit_at" gorm:""                                     validate:"omitempty,gtefield=StartedAt"`
	FinishedAt    *time.Time   `json:"finished_at"     gorm:""                                     validate:"omitempty,gtefield=StartedAt"`
	SubmittedAt   *time.Time   `json:"submitted_at"    gorm:""                                     validate:"omitempty,gtefield=StartedAt"`
	User          *User        `json:"-"               gorm:""                                     validate:"required_without=UserID"`
	Examination   *Examination `json:"-"               gorm:""                                     validate:"required_without=ExaminationID"`
	Answers       []*Answer    `json:"-"               gorm:""                                     validate:""`
	License       *License     `json:"-"               gorm:""                                     validate:""`
}

type UserExaminationID uint

func (i UserExaminationID) ToInt() int {
	return int(i)
}

// FindUserExaminationByID IDで検索
func FindUserExaminationByID(id int) (*UserExamination, error) {
	userExamination := &UserExamination{}
	if err := db.Preload("License").
		Preload("User").
		Preload("Examination").
		First(userExamination, id).Error; err != nil {

		return nil, err
	}
	return userExamination, nil
}

// FindUserExaminationAnswers IDでユーザー試験と回答を取得
func (userExamination *UserExamination) FindUserExaminationAnswers() error {
	err := db.
		Preload("License").
		Preload("Examination.ExaminationQuestions.Category").
		Preload("Examination.Questions", func(db *gorm.DB) *gorm.DB { return db.Order("examination_questions.sequence") }).
		Preload("Examination.Questions.Quizzes", func(db *gorm.DB) *gorm.DB { return db.Order("sequence") }).
		Preload("Examination.Questions.Quizzes.Choices", func(db *gorm.DB) *gorm.DB { return db.Order("sequence") }).
		Preload("Examination.Questions.Quizzes.Choices.Answers", "user_examination_id = ?", userExamination.ID).
		Preload("Examination.Questions.Answers", "user_examination_id = ?", userExamination.ID).
		Preload("Examination.Questions.CodeQuizzes", func(db *gorm.DB) *gorm.DB { return db.Order("sequence") }).
		Preload("Examination.Questions.CodeQuizzes.Answer", "user_examination_id = ?", userExamination.ID).
		First(userExamination, userExamination.ID).Error
	if err != nil {
		return pkgerrors.WithStack(err)
	}

	return nil
}

// GetPreviousResult 前回の試験データを取得
// 試験終了時間が自身よりも前であり、その中で最新の物を取得
func (m *UserExamination) GetPreviousResult() (*UserExamination, error) {
	if !m.IsFinished() {
		return nil, nil
	}

	prev := &UserExamination{}
	if err := db.Where("user_id = ? AND examination_id = ? AND finished_at <= ?",
		m.UserID, m.ExaminationID, m.FinishedAt).
		Not("id = ? OR finished_at IS NULL", m.ID).
		Order("finished_at desc").
		First(&prev).Error; err != nil {
		return nil, err
	}

	return prev, nil
}

// 試験開始前
func (userExamination *UserExamination) isBefore() bool {
	return userExamination.License.StartDateTime.After(time.Now())
}

// 受講可能状態
func (userExamination *UserExamination) isReady() bool {
	return userExamination.StartedAt == nil && !userExamination.License.EndDateTime.Before(time.Now())
}

// IsAnswering　回答中
func (m *UserExamination) IsAnswering() bool {
	return m.StartedAt != nil && m.SubmittedAt == nil && m.FinishedAt == nil
}

// IsSubmitted 提出済み
func (userExamination *UserExamination) IsSubmitted() bool {
	return userExamination.SubmittedAt != nil
}

// IsScoring 採点中
func (m *UserExamination) IsScoring() bool {
	return m.SubmittedAt != nil && m.FinishedAt == nil
}

// IsFinished 回答終了
func (userExamination *UserExamination) IsFinished() bool {
	return userExamination.StartedAt != nil && userExamination.FinishedAt != nil
}

// 期限切れ
func (userExamination *UserExamination) isExpired() bool {
	return userExamination.StartedAt == nil && userExamination.License.EndDateTime.Before(time.Now())
}

func (userExamination *UserExamination) Status() (UserExaminationStatus, error) {
	if userExamination.isBefore() {
		return UserExaminationStatusBefore, nil
	}
	if userExamination.isReady() {
		return UserExaminationStatusReady, nil
	}
	if userExamination.IsAnswering() {
		return UserExaminationStatusAnswering, nil
	}
	if userExamination.IsScoring() {
		return UserExaminationStatusScoring, nil
	}
	if userExamination.IsFinished() {
		return UserExaminationStatusFinished, nil
	}
	if userExamination.isExpired() {
		return UserExaminationStatusExpired, nil
	}
	return "", fmt.Errorf("invalid status")
}

// Start 試験開始
func (userExamination *UserExamination) Start() error {
	if userExamination.isBefore() || !userExamination.isReady() {
		return nil
	}
	// User.FinishExpiredUserExaminations()をシンプルにするためにここでAnswerLimitAtを事前に入れておく（そうしないとJOINが必要でコードが長くなる）
	// userExaminationのupdateで巻き込まれないように別のpreloadではなく別インスタンスとして取ってくる
	examination := &Examination{}
	if err := db.Model(&userExamination).Related(&examination).Error; err != nil {
		return err
	}
	now := time.Now()
	answerLimitAt := now.Add(time.Minute * time.Duration(examination.LimitMin))

	return db.Exec("UPDATE user_examinations"+
		" SET user_examinations.answer_limit_at = ?, user_examinations.started_at = ?, user_examinations.updated_at = ?"+
		" WHERE user_examinations.deleted_at IS NULL AND user_examinations.id = ?",
		answerLimitAt, now, now, userExamination.ID,
	).Error
}

// Answer 回答
func (userExamination *UserExamination) Answer(questionID int, quizID int, choiceID int) error {
	if !userExamination.IsAnswering() {
		return nil
	}
	if err := db.Model(userExamination).
		Joins("JOIN examination_questions ON examination_questions.examination_id = user_examinations.examination_id").
		Joins("JOIN quizzes ON quizzes.question_id = examination_questions.question_id").
		Joins("JOIN choices ON choices.quiz_id = quizzes.id").
		Where("user_examinations.id = ?", userExamination.ID).
		Where("quizzes.id = ?", quizID).
		Where("choices.id = ?", choiceID).
		First(userExamination).Error; err != nil {
		return err
	}
	if err := db.Where(&Answer{UserExaminationID: userExamination.ID, QuestionID: questionID, QuizID: quizID}).Assign(&Answer{ChoiceID: choiceID}).FirstOrCreate(&Answer{}).Error; err != nil {
		return err
	}
	return nil
}

// Submit 試験提出
func (m *UserExamination) Submit() error {
	if !m.IsAnswering() {
		// TODO: error typeの導入を考えてみる
		return errors.New("user examination status is not answering")
	}

	now := time.Now()
	m.SubmittedAt = &now
	if m.AnswerLimitAt.Before(*m.SubmittedAt) {
		m.SubmittedAt = m.AnswerLimitAt
	}

	return nil
}

// Finish 試験完了
func (m *UserExamination) Finish() error {
	if m.IsAnswering() {
		err := m.Submit()
		if err != nil {
			return err
		}
	} else if !m.IsScoring() {
		// TODO: error typeの導入を考えてみる
		return errors.New("user examination status is not answering or scoring")
	}

	now := time.Now()
	m.FinishedAt = &now
	if m.AnswerLimitAt.Before(*m.FinishedAt) {
		m.FinishedAt = m.AnswerLimitAt
	}

	return nil
}

// FindQuestionByID 指定のQuestion（存在しなければエラー）
func (userExamination *UserExamination) FindQuestionByID(id int) (*Question, error) {
	question := &Question{}
	if err := db.Model(question).
		Joins("JOIN examination_questions ON examination_questions.question_id = questions.id").
		Where("examination_questions.examination_id = ?", userExamination.ExaminationID).
		Where("questions.id = ?", id).
		First(question).Error; err != nil {
		return nil, err
	}
	return question, nil
}

// Score Score
type Score struct {
	QuestionID   int
	CategoryID   int
	CategoryName string
	Point        int
	MaxPoint     int
	Score        int
}

const scoreQuery = `SELECT
	questions.id AS question_id,
	categories.id AS category_id,
	categories.name AS category_name,
	MAX((IFNULL(answers.id, 0) > 0) * choices.point) AS point,
	MAX(choices.point) AS max_point
	FROM user_examinations
	JOIN examination_questions ON examination_questions.examination_id = user_examinations.examination_id
	JOIN quizzes ON examination_questions.question_id = quizzes.question_id
	JOIN choices ON quizzes.id = choices.quiz_id
	JOIN questions ON questions.id = examination_questions.question_id
	JOIN categories ON categories.id = examination_questions.category_id
	LEFT JOIN answers ON
	answers.user_examination_id = user_examinations.id
	AND answers.quiz_id = choices.quiz_id AND answers.choice_id = choices.id
	WHERE user_examinations.id = ?
	AND user_examinations.deleted_at IS NULL
	AND examination_questions.deleted_at IS NULL
	AND quizzes.deleted_at IS NULL
	AND choices.deleted_at IS NULL
	AND questions.deleted_at IS NULL
	AND categories.deleted_at IS NULL
	AND answers.deleted_at IS NULL
	GROUP BY questions.id, quizzes.id, examination_questions.category_id
	ORDER BY questions.id`

func (userExamination *UserExamination) scoresByQuestion() ([]*Score, error) {
	query := scoreQuery
	scores := []*Score{}
	if err := db.Raw(query, userExamination.ID).Scan(&scores).Error; err != nil {
		return nil, err
	}
	scoreAll, err := userExamination.scoreAll()
	if err != nil {
		return nil, err
	}
	for _, score := range scores {
		base := 1
		if scoreAll.MaxPoint != 0 {
			base = scoreAll.MaxPoint
		}
		score.Score = score.Point * 100 / base
	}
	return scores, nil
}

func (userExamination *UserExamination) ScoresByCategory() ([]*Score, error) {
	query := `SELECT 0 AS question_id, category_id, category_name, SUM(point) AS point, SUM(max_point) AS max_point FROM (` + scoreQuery + `) AS points GROUP BY category_id`
	scores := []*Score{}
	if err := db.Raw(query, userExamination.ID).Scan(&scores).Error; err != nil {
		return nil, err
	}
	for _, score := range scores {
		base := 1
		if score.MaxPoint != 0 {
			base = score.MaxPoint
		}
		score.Score = score.Point * 100 / base
	}
	return scores, nil
}

func (userExamination *UserExamination) scoreAll() (*Score, error) {
	query := `SELECT 0 AS question_id, 0 AS category_id, "ALL" AS category_name, SUM(point) AS point, SUM(max_point) AS max_point FROM (` + scoreQuery + `) AS points`
	score := &Score{}
	if err := db.Raw(query, userExamination.ID).Scan(score).Error; err != nil {
		return nil, err
	}
	base := 1
	if score.MaxPoint != 0 {
		base = score.MaxPoint
	}
	score.Score = score.Point * 100 / base
	return score, nil
}

func (userExamination *UserExamination) CreateTotalScore() error {
	score, err := userExamination.scoreAll()
	if err != nil {
		return err
	}

	if err := CreateUserExaminationScore(&UserExaminationScore{
		UserExaminationID: userExamination.ID,
		ExaminationID:     userExamination.ExaminationID,
		Score:             score.Score,
		Point:             score.Point,
		MaxPoint:          score.MaxPoint,
	}); err != nil {
		return err
	}

	return nil
}

func (userExamination *UserExamination) CreateCategoryScores() error {
	scores, err := userExamination.ScoresByCategory()
	if err != nil {
		return err
	}

	for _, score := range scores {
		// TODO データ移行が完了した戻す
		err := db.Where(&UserExaminationCategoryScore{
			UserExaminationID: userExamination.ID,
			CategoryID:        score.CategoryID,
		}).First(&UserExaminationCategoryScore{}).Error
		if err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				if err := CreateUserExaminationCategoryScore(&UserExaminationCategoryScore{
					UserExaminationID: userExamination.ID,
					ExaminationID:     userExamination.ExaminationID,
					CategoryID:        score.CategoryID,
					Score:             score.Score,
					Point:             score.Point,
					MaxPoint:          score.MaxPoint,
				}); err != nil {
					return err
				}
			} else {
				return err
			}
		}
	}

	return nil
}

type UserExaminationWithScore struct {
	*UserExamination
	Score int
}

// TODO: pager対応
func GetUserExaminationsWithScoreByLicenseIDs(ids []int, sortDir string) (exams []*UserExaminationWithScore, err error) {
	baseQuery := "SELECT user_examinations.*, user_examination_scores.score FROM user_examinations" +
		" LEFT JOIN user_examination_scores" +
		" ON user_examinations.id = user_examination_scores.user_examination_id" +
		" WHERE user_examinations.license_id IN (?)"

	orderQuery := ""
	if sortDir == "asc" {
		orderQuery = " ORDER BY score IS NULL, score"
	} else if sortDir == "desc" {
		orderQuery = " ORDER BY score IS NULL, score DESC"
	}
	baseQuery = baseQuery + orderQuery

	if err = db.Raw(baseQuery, ids).
		Scan(&exams).Error; err != nil {
		return nil, err
	}

	return exams, nil
}

// Visible 退職等で受講時の組織と所属組織が異なる可能性があるので、
//         privateスコープのテストは、所属組織が試験に紐付いている場合のみ表示可能
func (userExamination *UserExamination) Visible(user *User) bool {
	if userExamination.Examination.IsGlobalScope() {
		return true
	}

	return userExamination.License.OrganizationID == user.OrganizationID
}
