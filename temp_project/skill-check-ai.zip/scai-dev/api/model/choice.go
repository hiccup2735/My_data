package model

// Choice 選択肢
type Choice struct {
	NewModel
	QuizID   int       `json:"quiz_id"           gorm:"index;not null"                       validate:"omitempty,min=1,max=4294967295"`
	Sequence int       `json:"sequence"          gorm:"not null"                             validate:"min=0,max=4294967295"`
	Name     string    `json:"name"              gorm:"not null;unique_index:is_not_deleted" validate:"min=1,max=255"`
	Point    int       `json:"point"             gorm:"not null"                             validate:"min=0,max=4294967295"`
	Answers  []*Answer `json:"answers,omitempty" gorm:""                                     validate:""`
}

type ChoiceID int

// Copy copy new struct from receiver
func (choice *Choice) Copy() (newChoice *Choice, err error) {
	if err = copyModel(choice, &newChoice); err != nil {
		return nil, err
	}

	// TODO: question.goのCopyと同一の対応を検討
	newChoice.ID = 0

	return newChoice, nil
}
