package model

import (
	"app/util"
)

// UserExaminationCategoryScore UserExaminationCategoryScore
type UserExaminationCategoryScore struct {
	Model
	UserExaminationID int               `json:"user_examination_id" gorm:"not null;unique_index:is_not_deleted" validate:"required,min=1,max=4294967295"`
	ExaminationID     int               `json:"examination_id"      gorm:"not null;index:idx_examination_id"    validate:"required,min=1,max=4294967295"`
	CategoryID        int               `json:"category_id"         gorm:"not null;unique_index:is_not_deleted" validate:"required,min=1,max=4294967295"`
	Score             int               `json:"score"               gorm:"not null"                             validate:"required,min=0,max=4294967295"`
	Point             int               `json:"point"               gorm:"not null"                             validate:"required,min=0,max=4294967295"`
	MaxPoint          int               `json:"max_point"           gorm:"not null"                             validate:"required,min=0,max=4294967295"`
	UserExamination   *UserExamination  `json:"-"                   gorm:""                                     validate:""`
	Examination       *Examination      `json:"-"                   gorm:""                                     validate:""`
	Category          *QuestionCategory `json:"-"                   gorm:""                                     validate:""`
}

// CreateUserExaminationCategoryScore create
func CreateUserExaminationCategoryScore(score *UserExaminationCategoryScore) error {
	return db.Create(score).Error
}

// GetUserExaminationCategoryScoreByUserExaminationID get by UserExaminationID
func GetUserExaminationCategoryScoreByUserExaminationID(id int) (scores []*UserExaminationCategoryScore, err error) {
	if err := db.Preload("Category").
		Where(&UserExaminationCategoryScore{UserExaminationID: id}).
		Find(&scores).Error; err != nil {
		return nil, err
	}

	return scores, nil
}

// ExaminationCategoryScoreStatData 試験スコアのカテゴリ毎の統計データ
type ExaminationCategoryScoreStatData struct {
	CategoryID   int
	CategoryName string
	ResultCount  int
	AverageScore float64
	MaxScore     int
	MinScore     int
}

// GetExaminationCategoryStatDataByExaminationID 特定試験IDのカテゴリ毎の統計データを取得
func GetExaminationCategoryStatDataByExaminationID(examID int, excludeOrgIds ...int) (catData []*ExaminationCategoryScoreStatData, err error) {
	tx := db.Table("user_examination_category_scores").
		Joins("INNER JOIN categories ON "+
			"user_examination_category_scores.category_id = categories.id").
		Joins("INNER JOIN user_examinations ON "+
			"user_examination_category_scores.user_examination_id = user_examinations.id").
		Joins("INNER JOIN users ON user_examinations.user_id = users.id").
		Joins("INNER JOIN organizations ON users.organization_id = organizations.id").
		Where("organizations.comparable = ? AND "+
			"user_examination_category_scores.examination_id = ?", true, examID).
		Group("categories.id").
		Select("categories.id AS category_id, categories.name AS category_name, " +
			"COUNT(user_examination_category_scores.id) AS result_count, AVG(score) AS average_score, " +
			"MAX(score) AS max_score, MIN(score) AS min_score")

	if len(excludeOrgIds) > 0 {
		tx = tx.Not("organizations.id IN (?)", excludeOrgIds)
	}

	if err := tx.Find(&catData).Error; err != nil {
		return nil, err
	}

	for _, c := range catData {
		c.AverageScore = util.RoundToSecondDecimal(c.AverageScore)
	}

	return catData, nil
}
