package model

import (
	"app/env"
	"fmt"
	"github.com/google/uuid"
	"math/rand"
	"time"

	"golang.org/x/crypto/bcrypt"

	"github.com/go-playground/validator/v10"
	"github.com/go-sql-driver/mysql"
	"github.com/jinzhu/gorm"
)

var (
	db       *gorm.DB
	validate *validator.Validate
)

func init() {
	rand.Seed(time.Now().UnixNano())
	validate = validator.New()
	db = connect()
	db.Callback().Delete().Replace("gorm:delete", deleteCallback)
	db.LogMode(true)
	Migrate()
}

func connect() *gorm.DB {
	// https://godoc.org/github.com/go-sql-driver/mysql#Config.InterpolateParams
	config := mysql.Config{
		User:                 env.Config.DBUser,
		Passwd:               env.Config.DBPassword,
		Net:                  "tcp",
		Addr:                 env.Config.DBHost + ":" + env.Config.DBPort,
		DBName:               env.Config.DBName,
		Params:               map[string]string{"charset": env.Config.DBCharset},
		Collation:            env.Config.DBCollation,
		Loc:                  time.FixedZone("Local", 9*60*60),
		ParseTime:            true,
		AllowNativePasswords: true,
	}
	database, err := gorm.Open("mysql", config.FormatDSN())
	if err != nil {
		panic(err)
	}
	return database
}

func DropTables() {
	if err := db.DropTableIfExists(&ExaminationQuestion{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&UserExamination{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&UserExaminationScore{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&UserExaminationCategoryScore{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&ExaminationOrganization{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&Admin{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&OrganizationCategory{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&Organization{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&Organizer{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&User{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&Examination{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&QuestionCategory{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&QuestionMetadata{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&QuestionTag{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&Question{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&Quiz{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&Choice{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&Answer{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&License{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&CodeQuiz{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&CodeQuizFile{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&CodeQuizAnswer{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&UserExaminationCodeQuizResult{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&Operator{}).Error; err != nil {
		panic(err)
	}
	if err := db.DropTableIfExists(&Manager{}).Error; err != nil {
		panic(err)
	}	
}

func Migrate() {
	// many2many
	if err := db.AutoMigrate(&ExaminationQuestion{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&UserExamination{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&UserExaminationScore{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&UserExaminationCategoryScore{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&ExaminationOrganization{}).Error; err != nil {
		panic(err)
	}
	// normal
	if err := db.AutoMigrate(&Admin{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&OrganizationCategory{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&Organization{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&Organizer{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&User{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&Examination{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&QuestionCategory{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&QuestionMetadata{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&QuestionTag{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&Question{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&Quiz{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&Choice{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&Answer{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&License{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&CodeQuiz{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&CodeQuizFile{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&CodeQuizAnswer{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&UserExaminationCodeQuizResult{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&Operator{}).Error; err != nil {
		panic(err)
	}
	if err := db.AutoMigrate(&Manager{}).Error; err != nil {
		panic(err)
	}
}

// BeforeSave ExaminationQuestion
func (m *ExaminationQuestion) BeforeSave() error { return validate.Struct(m) }

// BeforeSave Admin
func (m *Admin) BeforeSave() error { return validate.Struct(m) }

// BeforeSave OrganizationCategory
func (m *OrganizationCategory) BeforeSave() error { return validate.Struct(m) }

// BeforeSave Organization
func (m *Organization) BeforeSave() error { return validate.Struct(m) }

// BeforeSave Organizer
func (m *Organizer) BeforeSave() error { return validate.Struct(m) }

// BeforeSave Examination
func (m *Examination) BeforeSave() error { return validate.Struct(m) }

// BeforeSave QuestionCategory
func (m *QuestionCategory) BeforeSave() error { return validate.Struct(m) }

// BeforeSave Question
func (m *Question) BeforeSave() error { return validate.Struct(m) }

/**
TODO: Questionに画像を上げた時にDB更新後のS3にアップロードするhook
post, patch時に、dummyのURLがAPIレスポンスされるので無効化しているので、
利用するか別なメソッドを作成して削除する
*/
// func (m *Question) AfterSave() error  { return m.saveImage() }

// BeforeSave Choice
func (m *Choice) BeforeSave() error { return validate.Struct(m) }

// BeforeSave Answer
func (m *Answer) BeforeSave() error { return validate.Struct(m) }

// BeforeSave User
func (m *User) BeforeSave() error { return validate.Struct(m) }

// BeforeSave UserExamination
func (m *UserExamination) BeforeSave() error { return validate.Struct(m) }

// BeforeSave Operator
func (m *Operator) BeforeSave() error { return validate.Struct(m) }

// Seeds 開発用に初期データ投入
func Seeds() {
	categoryMath := &QuestionCategory{Name: "数学"}
	if err := db.Create(categoryMath).Error; err != nil {
		panic(err)
	}
	categoryPrep := &QuestionCategory{Name: "前処理"}
	if err := db.Create(categoryPrep).Error; err != nil {
		panic(err)
	}
	categoryAlgo := &QuestionCategory{Name: "アルゴリズム"}
	if err := db.Create(categoryAlgo).Error; err != nil {
		panic(err)
	}
	questionMath1 := &Question{
		Name:        "数学問題1",
		Description: "数学問題1説明文",
		ImageURI:    "https://upload.wikimedia.org/wikipedia/commons/7/70/Example.png",
		Level:       1,
		Quizzes: []*Quiz{
			{
				Sequence:    1,
				Description: "数学設問1",
				Choices: []*Choice{
					{Sequence: 2, Name: "数学問題1設問1選択肢2点", Point: 2},
					{Sequence: 1, Name: "数学問題1設問1選択肢1点", Point: 1},
					{Sequence: 0, Name: "数学問題1設問1選択肢0点", Point: 0},
				},
			},
			{
				Sequence:    2,
				Description: "数学設問2",
				Choices: []*Choice{
					{Sequence: 2, Name: "数学問題1設問2選択肢2点", Point: 2},
					{Sequence: 1, Name: "数学問題1設問2選択肢1点", Point: 1},
					{Sequence: 0, Name: "数学問題1設問2選択肢0点", Point: 0},
				},
			},
		},
		Tags: []*QuestionTag{
			{Name: "数学"},
			{Name: "問題1"},
		},
	}
	if err := db.Create(questionMath1).Error; err != nil {
		panic(err)
	}
	questionMath2 := &Question{
		Name:        "数学問題2",
		Description: "数学問題2説明文",
		Level:       2,
		Quizzes: []*Quiz{
			{
				Sequence:    1,
				Description: "数学問題2設問1",
				Choices: []*Choice{
					{Sequence: 2, Name: "数学問題2設問1選択肢2点", Point: 2},
					{Sequence: 1, Name: "数学問題2設問1選択肢1点", Point: 1},
					{Sequence: 0, Name: "数学問題2設問1選択肢0点", Point: 0},
				},
			},
			{
				Sequence:    2,
				Description: "数学問題2設問2",
				Choices: []*Choice{
					{Sequence: 2, Name: "数学問題2設問2選択肢2点", Point: 2},
					{Sequence: 1, Name: "数学問題2設問2選択肢1点", Point: 1},
					{Sequence: 0, Name: "数学問題2設問2選択肢0点", Point: 0},
				},
			},
		},
		Tags: []*QuestionTag{
			{Name: "数学"},
			{Name: "問題2"},
		},
	}
	if err := db.Create(questionMath2).Error; err != nil {
		panic(err)
	}
	questionMath3 := &Question{
		Name:        "数学問題3",
		Description: "数学問題3説明文",
		Level:       3,
		Quizzes: []*Quiz{
			{
				Sequence:    1,
				Description: "数学問題3設問1",
				Choices: []*Choice{
					{Sequence: 2, Name: "数学問題3設問1選択肢2点", Point: 2},
					{Sequence: 1, Name: "数学問題3設問1選択肢1点", Point: 1},
					{Sequence: 0, Name: "数学問題3設問1選択肢0点", Point: 0},
				},
			},
			{
				Sequence:    2,
				Description: "数学問題3設問2",
				Choices: []*Choice{
					{Sequence: 2, Name: "数学問題3設問2選択肢2点", Point: 2},
					{Sequence: 1, Name: "数学問題3設問2選択肢1点", Point: 1},
					{Sequence: 0, Name: "数学問題3設問2選択肢0点", Point: 0},
				},
			},
		},
		Tags: []*QuestionTag{
			{Name: "数学"},
			{Name: "問題3"},
		},
	}
	if err := db.Create(questionMath3).Error; err != nil {
		panic(err)
	}
	questionPrep1 := &Question{
		Name:        "前処理問題1",
		Description: "前処理問題1説明文",
		Level:       4,
		Quizzes: []*Quiz{
			{
				Sequence:    1,
				Description: "前処理問題1設問1",
				Choices: []*Choice{
					{Sequence: 2, Name: "前処理問題1設問1選択肢2点", Point: 2},
					{Sequence: 1, Name: "前処理問題1設問1選択肢1点", Point: 1},
					{Sequence: 0, Name: "前処理問題1設問1選択肢0点", Point: 0},
				},
			},
			{
				Sequence:    2,
				Description: "前処理問題1設問2",
				Choices: []*Choice{
					{Sequence: 2, Name: "前処理問題1設問2選択肢2点", Point: 2},
					{Sequence: 1, Name: "前処理問題1設問2選択肢1点", Point: 1},
					{Sequence: 0, Name: "前処理問題1設問2選択肢0点", Point: 0},
				},
			},
		},
		Tags: []*QuestionTag{
			{Name: "前処理"},
			{Name: "問題1"},
		},
	}
	if err := db.Create(questionPrep1).Error; err != nil {
		panic(err)
	}
	questionPrep2 := &Question{
		Name:        "前処理問題2",
		Description: "前処理問題2説明文",
		Level:       5,
		Quizzes: []*Quiz{
			{
				Sequence:    1,
				Description: "前処理問題2設問1",
				Choices: []*Choice{
					{Sequence: 2, Name: "前処理問題2設問1選択肢2点", Point: 2},
					{Sequence: 1, Name: "前処理問題2設問1選択肢1点", Point: 1},
					{Sequence: 0, Name: "前処理問題2設問1選択肢0点", Point: 0},
				},
			},
			{
				Sequence:    2,
				Description: "前処理問題2設問2",
				Choices: []*Choice{
					{Sequence: 2, Name: "前処理問題2設問2選択肢2点", Point: 2},
					{Sequence: 1, Name: "前処理問題2設問2選択肢1点", Point: 1},
					{Sequence: 0, Name: "前処理問題2設問2選択肢0点", Point: 0},
				},
			},
		},
		Tags: []*QuestionTag{
			{Name: "前処理"},
			{Name: "問題2"},
		},
	}
	if err := db.Create(questionPrep2).Error; err != nil {
		panic(err)
	}
	questionPrep3 := &Question{
		Name:        "前処理問題3",
		Description: "前処理問題3説明文",
		Level:       6,
		Quizzes: []*Quiz{
			{
				Sequence:    1,
				Description: "前処理問題3設問1",
				Choices: []*Choice{
					{Sequence: 2, Name: "前処理問題3設問1選択肢2点", Point: 2},
					{Sequence: 1, Name: "前処理問題3設問1選択肢1点", Point: 1},
					{Sequence: 0, Name: "前処理問題3設問1選択肢0点", Point: 0},
				},
			},
			{
				Sequence:    2,
				Description: "前処理問題3設問2",
				Choices: []*Choice{
					{Sequence: 2, Name: "前処理問題3設問2選択肢2点", Point: 2},
					{Sequence: 1, Name: "前処理問題3設問2選択肢1点", Point: 1},
					{Sequence: 0, Name: "前処理問題3設問2選択肢0点", Point: 0},
				},
			},
		},
		Tags: []*QuestionTag{
			{Name: "前処理"},
			{Name: "問題3"},
		},
	}
	if err := db.Create(questionPrep3).Error; err != nil {
		panic(err)
	}
	questionAlgo1 := &Question{
		Name:        "アルゴリズム問題1",
		Description: "アルゴリズム問題1説明文",
		Level:       7,
		Quizzes: []*Quiz{
			{
				Sequence:    1,
				Description: "アルゴリズム問題1設問1",
				Choices: []*Choice{
					{Sequence: 3, Name: "アルゴリズム問題1選択肢3点", Point: 3},
					{Sequence: 2, Name: "アルゴリズム問題1選択肢2点", Point: 2},
					{Sequence: 1, Name: "アルゴリズム問題1選択肢1点", Point: 1},
					{Sequence: 0, Name: "アルゴリズム問題1選択肢0点", Point: 0},
				},
			},
		},
		Tags: []*QuestionTag{
			{Name: "アルゴリズム"},
			{Name: "問題1"},
		},
	}
	if err := db.Create(questionAlgo1).Error; err != nil {
		panic(err)
	}
	questionAlgo2 := &Question{
		Name:        "アルゴリズム問題2",
		Description: "アルゴリズム問題2説明文",
		Level:       8,
		Quizzes: []*Quiz{
			{
				Sequence:    1,
				Description: "アルゴリズム問題2設問1",
				Choices: []*Choice{
					{Sequence: 3, Name: "アルゴリズム問題2選択肢3点", Point: 3},
					{Sequence: 2, Name: "アルゴリズム問題2選択肢2点", Point: 2},
					{Sequence: 1, Name: "アルゴリズム問題2選択肢1点", Point: 1},
					{Sequence: 0, Name: "アルゴリズム問題2選択肢0点", Point: 0},
				},
			},
		},
		Tags: []*QuestionTag{
			{Name: "アルゴリズム"},
			{Name: "問題2"},
		},
	}
	if err := db.Create(questionAlgo2).Error; err != nil {
		panic(err)
	}
	questionAlgo3 := &Question{
		Name:        "アルゴリズム問題3",
		Description: "アルゴリズム問題3説明文",
		Level:       9,
		Quizzes: []*Quiz{
			{
				Sequence:    1,
				Description: "アルゴリズム問題2設問1",
				Choices: []*Choice{
					{Sequence: 3, Name: "アルゴリズム問題3選択肢3点", Point: 3},
					{Sequence: 2, Name: "アルゴリズム問題3選択肢2点", Point: 2},
					{Sequence: 1, Name: "アルゴリズム問題3選択肢1点", Point: 1},
					{Sequence: 0, Name: "アルゴリズム問題3選択肢0点", Point: 0},
				},
			},
		},
		Tags: []*QuestionTag{
			{Name: "アルゴリズム"},
			{Name: "問題3"},
		},
	}
	if err := db.Create(questionAlgo3).Error; err != nil {
		panic(err)
	}
	questionCodeQuiz := &Question{
		Name:        "コード問タイトル",
		Description: "コード問設問分",
		Level:       1,
		CodeQuizzes: []*CodeQuiz{
			{
				Sequence:    1,
				IsSubmitted: true,
				Type:        CodeQuizTypeStandardIO,
				Description: "コード設問1説明文",
				MemoryLimit: 1024,
				TimeLimit:   60,
				Criteria:    100,
				CodeQuizFiles: []*CodeQuizFile{
					{
						Type: CodeQuizFileTypeInput,
						URL:  "https://scai-dev-mock-data.s3.ap-northeast-1.amazonaws.com/uploaded/code_quiz/1/input/input.zip",
					},
					{
						Type: CodeQuizFileTypeOutput,
						URL:  "https://scai-dev-mock-data.s3.ap-northeast-1.amazonaws.com/uploaded/code_quiz/1/output/output.zip",
					},
					{
						Type: CodeQuizFileTypeOkList,
						URL:  "https://scai-dev-mock-data.s3.ap-northeast-1.amazonaws.com/uploaded/code_quiz/1/ok_list/ok.list",
					},
					{
						Type: CodeQuizFileTypeNgList,
						URL:  "https://scai-dev-mock-data.s3.ap-northeast-1.amazonaws.com/uploaded/code_quiz/1/ng_list/ng.list",
					},
					{
						Type: CodeQuizFileTypeSetup,
						URL:  "https://scai-dev-mock-data.s3.ap-northeast-1.amazonaws.com/uploaded/code_quiz/1/setup/setup.sh",
					},
				},
			},
			{
				Sequence:    2,
				IsSubmitted: true,
				Type:        CodeQuizTypeStandardIO,
				Description: "コード設問2説明文!",
				MemoryLimit: 2048,
				TimeLimit:   30,
				Criteria:    50,
				Compare:     "float",
				CodeQuizFiles: []*CodeQuizFile{
					{
						Type: CodeQuizFileTypeInput,
						URL:  "https://scai-dev-mock-data.s3.ap-northeast-1.amazonaws.com/uploaded/code_quiz/2/input/input.zip",
					},
					{
						Type: CodeQuizFileTypeOutput,
						URL:  "https://scai-dev-mock-data.s3.ap-northeast-1.amazonaws.com/uploaded/code_quiz/2/output/output.zip",
					},
				},
			},
		},
	}
	if err := db.Create(questionCodeQuiz).Error; err != nil {
		panic(err)
	}
	questionEmptyQuizzes := &Question{
		Name:        "設問空問題1",
		Description: "設問空問題1説明文",
		Level:       1,
	}
	if err := db.Create(questionEmptyQuizzes).Error; err != nil {
		panic(err)
	}

	organizationCategory := &OrganizationCategory{Name: "IT"}
	if err := db.Create(organizationCategory).Error; err != nil {
		panic(err)
	}

	independentOrganization := &Organization{
		Model: Model{
			ID: IndependentOrganizationID,
		},
		Name:                   "無所属組織",
		Address:                " ",
		Email:                  "org@example.com",
		Tel:                    " ",
		ContactPerson:          " ",
		OrganizationCategoryID: organizationCategory.ID,
	}
	if err := db.Create(independentOrganization).Error; err != nil {
		panic(err)
	}

	organizationSample := &Organization{
		Name:                   "サンプル組織1",
		Address:                "東京都新宿区西新宿2-8-1",
		Email:                  "org@example.com",
		Tel:                    "0312345678",
		ContactPerson:          "担当者1",
		OrganizationCategoryID: organizationCategory.ID,
	}
	if err := db.Create(organizationSample).Error; err != nil {
		panic(err)
	}

	examinationMathPrep := &Examination{
		Name:        "試験数学＆前処理タイトル",
		Description: "試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明",
		LimitMin:    10,
		Code:        "math_prep",
		Group:       1,
		ExaminationQuestions: []*ExaminationQuestion{
			{Sequence: 1, CategoryID: categoryMath.ID, Question: questionMath1},
			{Sequence: 2, CategoryID: categoryPrep.ID, Question: questionPrep1},
			{Sequence: 3, CategoryID: categoryMath.ID, Question: questionMath2},
			{Sequence: 4, CategoryID: categoryPrep.ID, Question: questionPrep2},
		},
	}
	if err := db.Create(examinationMathPrep).Error; err != nil {
		panic(err)
	}

	examinationMathPrep2 := &Examination{
		Name:        "試験数学＆前処理タイトル2",
		Description: "試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明試験数学＆前処理の説明",
		LimitMin:    10,
		Code:        "math_prep",
		Group:       1,		
		ExaminationQuestions: []*ExaminationQuestion{
			{Sequence: 1, CategoryID: categoryMath.ID, Question: questionMath1},
			{Sequence: 2, CategoryID: categoryPrep.ID, Question: questionPrep1},
			{Sequence: 3, CategoryID: categoryMath.ID, Question: questionMath2},
			{Sequence: 4, CategoryID: categoryPrep.ID, Question: questionPrep2},
			{Sequence: 5, CategoryID: categoryMath.ID, Question: questionMath3},
		},
	}
	if err := db.Create(examinationMathPrep2).Error; err != nil {
		panic(err)
	}

	examinationAll := &Examination{
		Name:        "試験全問題タイトル",
		Description: "試験全問題の説明試験全問題の説明試験全問題の説明試験全問題の説明試験全問題の説明試験全問題の説明試験全問題の説明試験全問題の説明",
		LimitMin:    20,
		Group:       1,		
		ExaminationQuestions: []*ExaminationQuestion{
			{Sequence: 1, CategoryID: categoryMath.ID, Question: questionMath1},
			{Sequence: 2, CategoryID: categoryMath.ID, Question: questionMath2},
			{Sequence: 3, CategoryID: categoryMath.ID, Question: questionMath3},
			{Sequence: 4, CategoryID: categoryPrep.ID, Question: questionPrep1},
			{Sequence: 5, CategoryID: categoryPrep.ID, Question: questionPrep2},
			{Sequence: 6, CategoryID: categoryPrep.ID, Question: questionPrep3},
			{Sequence: 7, CategoryID: categoryAlgo.ID, Question: questionAlgo1},
			{Sequence: 8, CategoryID: categoryAlgo.ID, Question: questionAlgo2},
			{Sequence: 9, CategoryID: categoryAlgo.ID, Question: questionAlgo3},
		},
	}
	if err := db.Create(examinationAll).Error; err != nil {
		panic(err)
	}

	examinationMath := &Examination{
		Name:        "試験数学タイトル",
		Description: "試験数学の説明試験数学の説明試験数学の説明試験数学の説明試験数学の説明試験数学の説明試験数学の説明試験数学の説明",
		LimitMin:    10,
		Group:       1,		
		ExaminationQuestions: []*ExaminationQuestion{
			{Sequence: 1, CategoryID: categoryMath.ID, Question: questionMath1},
			{Sequence: 2, CategoryID: categoryMath.ID, Question: questionMath2},
		},
	}
	if err := db.Create(examinationMath).Error; err != nil {
		panic(err)
	}

	examinationCode := &Examination{
		Name:        "コード試験タイトル",
		Description: "コード試験の説明",
		LimitMin:    60,
		Group:       1,		
		ExaminationQuestions: []*ExaminationQuestion{
			{Sequence: 1, CategoryID: categoryAlgo.ID, Question: questionCodeQuiz},
		},
	}
	if err := db.Create(examinationCode).Error; err != nil {
		panic(err)
	}

	hash, err := bcrypt.GenerateFromPassword([]byte("Passw0rd!"), 10)
	organizationSampleOrganizer1 := &Organizer{
		Name:           "サンプル組織担当者1",
		Email:          "organizer_1@example.com",
		Password:       string(hash),
		OrganizationID: organizationSample.ID,
	}
	if err := db.Create(organizationSampleOrganizer1).Error; err != nil {
		panic(err)
	}

	organizationSampleOrganizer2 := &Organizer{
		Name:           "サンプル組織担当者1",
		Email:          "organizer_2@example.com",
		Password:       string(hash),
		OrganizationID: organizationSample.ID,
	}
	if err := db.Create(organizationSampleOrganizer2).Error; err != nil {
		panic(err)
	}

	if err != nil {
		panic(err)
	}
	admin := &Admin{
		Name:     "管理者",
		Email:    "admin@example.com",
		Password: string(hash),
	}
	if err := db.Create(admin).Error; err != nil {
		panic(err)
	}

	operator := &Operator{
		Name:     "オペレーター",
		Email:    "operator@example.com",
		Password: string(hash),
	}
	if err := db.Create(operator).Error; err != nil {
		panic(err)
	}

	manager := &Manager{
		Name:     "サービス管理者",
		Email:    "manager@example.com",
		Group:    1,
		Password: string(hash),
	}
	if err := db.Create(manager).Error; err != nil {
		panic(err)
	}

	startDateTime := time.Now()
	endDateTime := startDateTime.Add(time.Hour * 24 * 10)
	license := &License{
		Count:          10,
		StartDateTime:  &startDateTime,
		EndDateTime:    &endDateTime,
		OrganizationID: organizationSample.ID,
		ExaminationID:  examinationMathPrep.ID,
	}
	if err := db.Create(license).Error; err != nil {
		panic(err)
	}
	license2 := &License{
		Count:          10,
		StartDateTime:  &startDateTime,
		EndDateTime:    &endDateTime,
		OrganizationID: organizationSample.ID,
		ExaminationID:  examinationMathPrep2.ID,
	}
	if err := db.Create(license2).Error; err != nil {
		panic(err)
	}
	license3 := &License{
		Count:          10,
		StartDateTime:  &startDateTime,
		EndDateTime:    &endDateTime,
		OrganizationID: organizationSample.ID,
		ExaminationID:  examinationAll.ID,
	}
	if err := db.Create(license3).Error; err != nil {
		panic(err)
	}
	license4 := &License{
		Count:          10,
		StartDateTime:  &startDateTime,
		EndDateTime:    &endDateTime,
		OrganizationID: organizationSample.ID,
		ExaminationID:  examinationCode.ID,
	}
	if err := db.Create(license4).Error; err != nil {
		panic(err)
	}
	license5 := &License{
		Count:          10,
		StartDateTime:  &startDateTime,
		EndDateTime:    &endDateTime,
		OrganizationID: organizationSample.ID,
		ExaminationID:  examinationCode.ID,
	}
	if err := db.Create(license5).Error; err != nil {
		panic(err)
	}
	user, err := UserSignUp("user", "user@example.com", "passw0rd!")
	if err != nil {
		panic(err)
	}
	if err := user.Verify(*user.VerifyToken); err != nil {
		panic(err)
	}
	user.OrganizationID = organizationSample.ID
	if err := db.Model(&user).Update(user).Error; err != nil {
		panic(err)
	}

	startLimitAt := time.Now().Add(time.Hour * 24 * 10)
	userExamination1 := &UserExamination{
		UserID:        user.ID,
		ExaminationID: license.ExaminationID,
		LicenseID:     license.ID,
		StartLimitAt:  &startLimitAt,
	}
	if err := db.Create(userExamination1).Error; err != nil {
		panic(err)
	}
	userExamination1.License = license
	if err := userExamination1.Start(); err != nil {
		panic(err)
	}
	if err := userExamination1.Answer(1, 1, 1); err != nil {
		panic(err)
	}
	if err := userExamination1.Answer(2, 3, 7); err != nil {
		panic(err)
	}
	userExamination2 := &UserExamination{
		UserID:        user.ID,
		ExaminationID: license3.ExaminationID,
		LicenseID:     license3.ID,
		StartLimitAt:  &startLimitAt,
	}
	if err := db.Create(userExamination2).Error; err != nil {
		panic(err)
	}
	userExamination3 := &UserExamination{
		UserID:        user.ID,
		ExaminationID: license2.ExaminationID,
		LicenseID:     license2.ID,
		StartLimitAt:  &startLimitAt,
	}
	if err := db.Create(userExamination3).Error; err != nil {
		panic(err)
	}
	userExamination4 := &UserExamination{
		UserID:        user.ID,
		ExaminationID: license4.ExaminationID,
		LicenseID:     license4.ID,
		StartLimitAt:  &startLimitAt,
	}
	if err := db.Create(userExamination4).Error; err != nil {
		panic(err)
	}
	userExamination4.License = license4
	if err := userExamination4.Start(); err != nil {
		panic(err)
	}
	finishedAt := startLimitAt.Add(time.Minute * 10)
	userExamination5 := &UserExamination{
		UserID:        user.ID,
		ExaminationID: license5.ExaminationID,
		LicenseID:     license5.ID,
		StartLimitAt:  &startLimitAt,
		StartedAt:     &startLimitAt,
		SubmittedAt:   &finishedAt,
		FinishedAt:    &finishedAt,
	}
	if err := db.Create(userExamination5).Error; err != nil {
		panic(err)
	}

	codeQuiz1 := questionCodeQuiz.CodeQuizzes[0]
	submissionID1 := uuid.New().String()
	codeQuizAnswer1 := &CodeQuizAnswer{
		UserExaminationID: userExamination5.ID,
		QuestionID:        QuestionID(questionCodeQuiz.ID),
		CodeQuizID:        codeQuiz1.ID,
		Lang:              CodeQuizAnswerLangPython,
		Code:              "python code",
		SubmissionID:      &submissionID1,
	}
	if err := db.Create(codeQuizAnswer1).Error; err != nil {
		panic(err)
	}
	codeQuizResultScore1 := "9/10"
	codeQuizResultStatistics1 := "AC:9,WA:0,TLE:1,MLE:0,RE:0,CE:0,FE:0"
	userExamination5CodeQuizResult1 := &UserExaminationCodeQuizResult{
		UserExaminationID: UserExaminationID(userExamination5.ID),
		ExaminationID:     userExamination5.ExaminationID,
		CodeQuizID:        codeQuiz1.ID,
		SubmissionID:      *codeQuizAnswer1.SubmissionID,
		Result:            "OK",
		Score:             &codeQuizResultScore1,
		Statistics:        &codeQuizResultStatistics1,
	}
	if err := db.Create(userExamination5CodeQuizResult1).Error; err != nil {
		panic(err)
	}

	codeQuiz2 := questionCodeQuiz.CodeQuizzes[1]
	submissionID2 := uuid.New().String()
	codeQuizAnswer2 := &CodeQuizAnswer{
		UserExaminationID: userExamination5.ID,
		QuestionID:        QuestionID(questionCodeQuiz.ID),
		CodeQuizID:        codeQuiz2.ID,
		Lang:              CodeQuizAnswerLangPython,
		Code:              "python code",
		SubmissionID:      &submissionID2,
	}
	if err := db.Create(codeQuizAnswer2).Error; err != nil {
		panic(err)
	}
	codeQuizResultScore2 := "10/10"
	codeQuizResultStatistics2 := "AC:10,WA:0,TLE:1,MLE:0,RE:0,CE:0,FE:0"
	userExamination5CodeQuizResult2 := &UserExaminationCodeQuizResult{
		UserExaminationID: UserExaminationID(userExamination5.ID),
		ExaminationID:     userExamination5.ExaminationID,
		CodeQuizID:        codeQuiz2.ID,
		SubmissionID:      *codeQuizAnswer2.SubmissionID,
		Result:            "OK",
		Score:             &codeQuizResultScore2,
		Statistics:        &codeQuizResultStatistics2,
	}
	if err := db.Create(userExamination5CodeQuizResult2).Error; err != nil {
		panic(err)
	}

	user2, err := UserSignUp("user2", "user2@example.com", "passw0rd!")
	if err != nil {
		panic(err)
	}
	if err := user2.Verify(*user2.VerifyToken); err != nil {
		panic(err)
	}
}

// https://github.com/jinzhu/gorm/blob/master/callback_delete.go
// deleteCallback deleted_atだけで論理削除管理するとUNIQUE INDEXが貼れない対策
func deleteCallback(scope *gorm.Scope) {
	if !scope.HasError() {
		var extraOption string
		if str, ok := scope.Get("gorm:delete_option"); ok {
			extraOption = fmt.Sprint(str)
		}

		deletedAtField, hasDeletedAtField := scope.FieldByName("DeletedAt")

		if !scope.Search.Unscoped && hasDeletedAtField {
			scope.Raw(fmt.Sprintf(
				"UPDATE %v SET is_not_deleted=NULL, %v=%v%v%v", // 元メソッド書き換え
				scope.QuotedTableName(),
				scope.Quote(deletedAtField.DBName),
				scope.AddToVars(gorm.NowFunc()), // 元メソッド書き換え
				addExtraSpaceIfExist(scope.CombinedConditionSql()),
				addExtraSpaceIfExist(extraOption),
			)).Exec()
		} else {
			scope.Raw(fmt.Sprintf(
				"DELETE FROM %v%v%v",
				scope.QuotedTableName(),
				addExtraSpaceIfExist(scope.CombinedConditionSql()),
				addExtraSpaceIfExist(extraOption),
			)).Exec()
		}
	}
}

// https://github.com/jinzhu/gorm/blob/master/utils.go
func addExtraSpaceIfExist(str string) string {
	if str != "" {
		return " " + str
	}
	return ""
}
