package model

import "github.com/jinzhu/gorm"

// 組織を中心としたデータ構成となっているので、所属無し組織データを用意し、
// 組織に属していないユーザーは所属無し組織に属すことで、本システムを利用できるようにする
const IndependentOrganizationID = -1

// Organization 組織
type Organization struct {
	Model
	Name                   string                `json:"name"           gorm:"not null;unique_index:is_not_deleted" validate:"required,min=1,max=255"`
	Address                string                `json:"address"        gorm:"not null"                             validate:"required,min=1,max=255"`
	Email                  string                `json:"email"          gorm:"not null"                             validate:"required,min=1,max=255,email"`
	Tel                    string                `json:"tel"            gorm:"not null"                             validate:"required,min=1,max=255"`
	ContactPerson          string                `json:"contact_person" gorm:"not null"                             validate:"required,min=1,max=255"`
	OrganizationCategoryID int                   `json:"category_id"    gorm:"not null;unique_index:is_not_deleted" validate:"required,omitempty,min=1,max=4294967295"`
	Comparable             bool                  `json:"comparable"     gorm:"not null;default:false"               validate:""`
	OrganizationCategory   *OrganizationCategory `json:"-"              gorm:""                                     validate:""`
	Users                  []*User               `json:"-"              gorm:""                                     validate:""`
	Licenses               []*License            `json:"-"              gorm:""                                     validate:""`
	Organizers             []*Organizer          `json:"-"              gorm:""                                     validate:""`
}

type OrganizationID int

// OrganizationPreload preloadするリレーション
type OrganizationPreload struct {
	LicensesExamination          bool
	LicensesUserExaminations     bool
	LicensesUserExaminationsUser bool
	LicensesOrganization         bool
	Organizers                   bool
}

func appendOrganizationSearchQuery(db *gorm.DB, searchWord string) *gorm.DB {
	return db.Where("name LIKE ?", "%"+searchWord+"%")
}

// TODO: FindOrganizationByIDを利用する
func OrganizationFindByID(id int, preload OrganizationPreload) (*Organization, error) {
	organization := &Organization{}
	// TODO: Preloadする範囲を絞れるほうが良い
	tx := db.Preload("Licenses.Organization").
		Preload("Licenses.Examination")

	if preload.Organizers {
		tx = tx.Preload("Organizers")
	}

	if err := tx.First(&organization, id).Error; err != nil {
		return nil, err
	}

	return organization, nil
}

func FindOrganizationByID(id int, preload OrganizationPreload) (*Organization, error) {
	organization := &Organization{}
	tx := db

	if preload.LicensesExamination {
		tx = tx.Preload("Licenses.Examination")
	}

	if preload.LicensesUserExaminations {
		tx = tx.Preload("Licenses.UserExaminations")
	}

	if preload.LicensesUserExaminationsUser {
		tx = tx.Preload("Licenses.UserExaminations.User").
			Preload("Licenses.UserExaminations.License")
	}

	if preload.LicensesOrganization {
		tx = tx.Preload("Licenses.Organization")
	}

	if preload.Organizers {
		tx = tx.Preload("Organizers")
	}

	if err := tx.First(&organization, id).Error; err != nil {
		return nil, err
	}

	return organization, nil
}

// CountOrganization count organization
func CountOrganization(searchWord string) (count int, err error) {
	var organizations []*Organization

	tx := db
	if searchWord != "" {
		tx = appendOrganizationSearchQuery(tx, searchWord)
	}

	if err := tx.Find(&organizations).Count(&count).Error; err != nil {
		return 0, err
	}

	return count, nil
}

// FilterByOrganization filter organization
func FilterByOrganization(searchWord string, page int, pageSize int) (organizations []*Organization, err error) {
	tx := db
	if searchWord != "" {
		tx = appendOrganizationSearchQuery(tx, searchWord)
	}

	tx = appendPagerQuery(tx, page, pageSize)
	if err := tx.Find(&organizations).Error; err != nil {
		return nil, err
	}

	return organizations, nil
}

// CreateOrganization create organization
func CreateOrganization(organization *Organization) error {
	return db.Create(organization).Error
}

// Update update
func (m *Organization) Update(data *Organization) error {
	return db.First(m).Updates(
		map[string]interface{}{
			"name":                     data.Name,
			"address":                  data.Address,
			"email":                    data.Email,
			"tel":                      data.Tel,
			"contact_person":           data.ContactPerson,
			"organization_category_id": data.OrganizationCategoryID,
			"comparable":               data.Comparable,
		},
	).Error
}

func (m *Organization) Delete() error {
	return db.Delete(&m).Error
}

func (m *Organization) AppendUser(user *User) error {
	return db.Model(&m).Association("Users").Append(user).Error
}

func (m *Organization) DeleteUser(user *User) error {
	return db.Model(&m).Association("Users").Delete(user).Error
}

func (m *Organization) FindLicenseByID(id int) (*License, error) {
	license := &License{}
	if err := db.Model(&m).Where("id = ?", id).Association("Licenses").Find(&license).Error; err != nil {
		return nil, err
	}
	return license, nil
}

func (m *Organization) AppendLicense(license *License) error {
	return db.Model(&m).Association("Licenses").Append(license).Error
}

func (m *Organization) IsIndependent() bool {
	return m.ID == IndependentOrganizationID
}
