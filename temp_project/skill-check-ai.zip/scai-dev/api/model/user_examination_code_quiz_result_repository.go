package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
)

type UserExaminationCodeQuizResultRepository struct {
	db *gorm.DB
}

func NewUserExaminationCodeQuizResultRepository() *UserExaminationCodeQuizResultRepository {
	return &UserExaminationCodeQuizResultRepository{db: db}
}

func (r *UserExaminationCodeQuizResultRepository) FindByID(id UserExaminationCodeQuizResultID) (*UserExaminationCodeQuizResult, error) {
	entity := &UserExaminationCodeQuizResult{}
	err := r.db.First(entity, id.ToInt()).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *UserExaminationCodeQuizResultRepository) Insert(entity *UserExaminationCodeQuizResult) error {
	err := r.db.Create(&entity).Error
	return errors.WithStack(err)
}

func (r *UserExaminationCodeQuizResultRepository) Update(entity *UserExaminationCodeQuizResult) error {
	err := r.db.Set("gorm:save_associations", false).
		Model(&UserExaminationCodeQuizResult{}).
		Where("id = ?", entity.ID.ToInt()).
		Updates(map[string]interface{}{
			"UserExaminationID": entity.UserExaminationID,
			"ExaminationID":     entity.ExaminationID,
			"CodeQuizID":        entity.CodeQuizID,
			"SubmissionID":      entity.SubmissionID,
			"Result":            entity.Result,
			"Score":             entity.Score,
			"Statistics":        entity.Statistics,
		}).Error
	return errors.WithStack(err)
}

func (r *UserExaminationCodeQuizResultRepository) WithPreload() *UserExaminationCodeQuizResultRepository {
	r.db = r.db.Preload("CodeQuiz").
		Preload("CodeQuiz.Question")
	return r
}

func (r *UserExaminationCodeQuizResultRepository) FindBySubmissionID(submissionID string) (*UserExaminationCodeQuizResult, error) {
	entity := &UserExaminationCodeQuizResult{}
	err := r.db.Where("submission_id = ?", submissionID).
		First(entity).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *UserExaminationCodeQuizResultRepository) FilterByUserExaminationID(userExaminationID UserExaminationID) ([]UserExaminationCodeQuizResult, error) {
	var entities []UserExaminationCodeQuizResult
	err := r.db.Where("user_examination_id = ?", userExaminationID.ToInt()).
		Find(&entities).Error
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return entities, nil
}
