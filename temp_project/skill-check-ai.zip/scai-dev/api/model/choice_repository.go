package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
)

type ChoiceRepository struct {
	db *gorm.DB
}

func NewChoiceRepository() *ChoiceRepository {
	return &ChoiceRepository{db: db}
}

func (r *ChoiceRepository) FindByID(id ChoiceID) (*Choice, error) {
	entity := &Choice{}
	err := r.db.First(entity, int(id)).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *ChoiceRepository) FilterByQuizID(quizID QuizID) ([]Choice, error) {
	var entities []Choice
	err := r.db.Order("id").
		Where(&Choice{QuizID: int(quizID)}).
		Find(&entities).Error
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return entities, nil
}

func (r *ChoiceRepository) Insert(entity *Choice) error {
	err := r.db.Create(&entity).Error
	return errors.WithStack(err)
}

func (r *ChoiceRepository) Update(entity Choice) error {
	err := r.db.Model(&Choice{}).
		Where("id = ?", entity.ID).
		Updates(map[string]interface{}{
			"QuizID":   entity.QuizID,
			"Sequence": entity.Sequence,
			"Name":     entity.Name,
			"Point":    entity.Point,
		}).Error
	return errors.WithStack(err)
}

func (r *ChoiceRepository) DeleteByID(id ChoiceID) error {
	err := r.db.Delete(&Choice{}, int(id)).Error
	return errors.WithStack(err)
}
