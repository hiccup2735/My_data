package model

import "golang.org/x/crypto/bcrypt"

// Organizer 組織管理者
type Organizer struct {
	Model
	Name           string        `json:"name"            gorm:"not null"                             validate:"min=1,max=255"`
	Email          string        `json:"email"           gorm:"not null;unique_index:is_not_deleted" validate:"min=1,max=255,email"`
	Password       string        `json:"-"               gorm:"not null"                             validate:"min=1,max=255"`
	OrganizationID int           `json:"organization_id" gorm:"not null;unique_index:is_not_deleted" validate:"required,min=1,max=4294967295"`
	Organization   *Organization `json:"-"               gorm:""                                     validate:""`
}

// OrganizerPreload preloadするリレーション
type OrganizerPreload struct {
	Organizations bool
}

func CreateOrganizer(organizer *Organizer) error {
	return db.Create(organizer).Error
}

func FindOrganizerByID(id int, preload OrganizerPreload) (*Organizer, error) {
	organizer := &Organizer{}
	tx := db

	if preload.Organizations {
		tx = tx.Preload("Organization")
	}

	if err := tx.First(&organizer, id).Error; err != nil {
		return nil, err
	}

	return organizer, nil
}

// TODO: userに関数を生やす方が良いか検討する
func (m *Organizer) FindUserByID(id int) (*User, error) {
	user := &User{}

	if err := db.Preload("Organization").
		Preload("Examinations").
		Preload("UserExaminations.License.Examination").
		Where("organization_id = ?", m.OrganizationID).
		First(user, id).Error; err != nil {
		return nil, err
	}

	return user, nil
}

func (m *Organizer) Update(data *Organizer) error {
	return db.First(m).Updates(data).Error
}

func OrganizerSignIn(email string, password string) (*Organizer, error) {
	organizer := &Organizer{Email: email}
	if err := db.Where(organizer).First(organizer).Error; err != nil {
		return nil, err
	}
	if err := bcrypt.CompareHashAndPassword([]byte(organizer.Password), []byte(password)); err != nil {
		return nil, err
	}
	return organizer, nil
}
