package model

import "time"

type CodeQuizFileID int

type CodeQuizFileType string

const (
	CodeQuizFileTypeInput  CodeQuizFileType = "input"
	CodeQuizFileTypeOutput CodeQuizFileType = "output"
	CodeQuizFileTypeNgList CodeQuizFileType = "ng_list"
	CodeQuizFileTypeOkList CodeQuizFileType = "ok_list"
	CodeQuizFileTypeSetup  CodeQuizFileType = "setup"
)

func GetAllCodeQuizFileType() []CodeQuizFileType {
	return []CodeQuizFileType{
		CodeQuizFileTypeInput,
		CodeQuizFileTypeOutput,
		CodeQuizFileTypeNgList,
		CodeQuizFileTypeOkList,
		CodeQuizFileTypeSetup,
	}
}

func (t CodeQuizFileType) ToString() string {
	return string(t)
}

func (t CodeQuizFileType) IsValid() bool {
	switch t {
	case CodeQuizFileTypeInput, CodeQuizFileTypeOutput, CodeQuizFileTypeNgList, CodeQuizFileTypeOkList, CodeQuizFileTypeSetup:
		return true
	}
	return false
}

type CodeQuizFile struct {
	ID         CodeQuizFileID   `json:"id,omitempty" gorm:"primary_key"                                                                   validate:""`
	CodeQuizID CodeQuizID       `json:"code_quiz_id" gorm:"index;not null"                                                                validate:"min=1,max=4294967295"`
	Type       CodeQuizFileType `json:"type"         gorm:"not null"                                                                      validate:""`
	URL        string           `json:"url"          gorm:"not null"                                                                      validate:""`
	CreatedAt  *time.Time       `json:"-"            gorm:"type:timestamp;not null;default:CURRENT_TIMESTAMP"                             validate:""`
	UpdatedAt  *time.Time       `json:"-"            gorm:"type:timestamp;not null;default:CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" validate:""`
}
