package middleware

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

// APIError apiエラー時のレスポンス用構造体
type APIError struct {
	HTTPCode int
	Message  string
}

// ErrorHandler controllerで設定されたエラーコンテキストのハンドラ
func ErrorHandler() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Next()

		err := c.Errors.ByType(gin.ErrorTypePublic).Last()
		if err != nil {
			meta, ok := err.Meta.(APIError)
			if ok {
				c.AbortWithStatusJSON(meta.HTTPCode, gin.H{
					"message": meta.Message,
				})
			} else {
				c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
					"message": err.Error(),
				})
			}
		}
	}
}
