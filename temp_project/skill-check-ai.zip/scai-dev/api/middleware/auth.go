package middleware

import (
	"app/model"
	"app/session"
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
)

// RequireLogin ログインチェック
func RequireLogin() gin.HandlerFunc {
	return func(c *gin.Context) {
		userID, err := session.GetUserID(c)
		if err != nil {
			_ = c.AbortWithError(http.StatusForbidden, err)
			return
		}
		user, err := model.UserFindByID(userID, model.UserPreload{})
		if err != nil {
			_ = c.AbortWithError(http.StatusForbidden, err)
			return
		}
		session.SetContextUser(c, user)
	}
}

// RequireVerify メールアドレス確認済みチェック
func RequireVerify() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, err := session.GetContextUser(c)
		if err != nil {
			_ = c.AbortWithError(http.StatusForbidden, err)
			return
		}
		if !user.IsVerified() {
			_ = c.AbortWithError(http.StatusForbidden, fmt.Errorf("require verify"))
			return
		}
	}
}

// UpdateFinishedAt 試験の状態を最新化
func UpdateFinishedAt() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, err := session.GetContextUser(c)
		if err != nil {
			_ = c.AbortWithError(http.StatusForbidden, err)
			return
		}
		if err := user.FinishExpiredUserExaminations(); err != nil {
			_ = c.AbortWithError(http.StatusInternalServerError, err)
		}
	}
}

// RequireUserExamination 指定されたExaminationにアクセス可能かどうか
func RequireUserExamination() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, err := session.GetContextUser(c)
		if err != nil {
			_ = c.AbortWithError(http.StatusForbidden, err)
			return
		}
		userExaminationID, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			_ = c.AbortWithError(http.StatusBadRequest, err)
			return
		}
		userExamination, err := model.FindUserExaminationByID(userExaminationID)
		if err != nil {
			_ = c.AbortWithError(http.StatusForbidden, err)
			return
		}
		if userExamination.UserID != user.ID {
			_ = c.AbortWithError(http.StatusForbidden, err)
			return
		}
		if !userExamination.Visible(user) {
			_ = c.AbortWithError(http.StatusForbidden, fmt.Errorf("not visible"))
			return
		}

		session.SetContextUserExamination(c, userExamination)
	}
}

// RequireAdminLogin 管理者ログインチェック
func RequireAdminLogin() gin.HandlerFunc {
	return func(c *gin.Context) {
		adminID, err := session.GetAdminID(c)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, err)
			return
		}
		admin, err := model.AdminFindByID(adminID)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, err)
			return
		}
		session.SetContextAdmin(c, admin)
	}
}

// RequireOrganizerLogin 組織管理者ログインチェック
func RequireOrganizerLogin() gin.HandlerFunc {
	return func(c *gin.Context) {
		organizerID, err := session.GetOrganizerID(c)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, err)
			return
		}
		organizer, err := model.FindOrganizerByID(organizerID, model.OrganizerPreload{Organizations: true})
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, err)
			return
		}
		session.SetContextOrganizer(c, organizer)
	}
}

func RequireOperatorLogin() gin.HandlerFunc {
	return func(c *gin.Context) {
		operatorID, err := session.GetOperatorID(c)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, err)
			return
		}
		operator, err := model.FindOperatorByID(operatorID)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, err)
			return
		}
		session.SetContextOperator(c, operator)
	}
}

func RequireAdminOrOperatorLogin() gin.HandlerFunc {
	return func(c *gin.Context) {
		adminID, err := session.GetAdminID(c)
		if err != nil {
			RequireOperatorLogin()
			return
		}
		admin, err := model.AdminFindByID(adminID)
		if err != nil {
			RequireOperatorLogin()
			return
		}
		session.SetContextAdmin(c, admin)
	}
}

// Admin、オペレーター、サービス管理者の権限確認
func RequireServiceManagerLogin() gin.HandlerFunc {
	return func(c *gin.Context) {
		adminID, err := session.GetAdminID(c)
		if err != nil {
			RequireOperatorOrManagerLogin()
			return
		}
		admin, err := model.AdminFindByID(adminID)
		if err != nil {
			RequireOperatorOrManagerLogin()
			return
		}
		session.SetContextAdmin(c, admin)
	}
}

func RequireOperatorOrManagerLogin() gin.HandlerFunc {
	return func(c *gin.Context) {
		operatorID, err := session.GetOperatorID(c)
		if err != nil {
			RequireManagerLogin()
			return
		}
		operator, err := model.FindOperatorByID(operatorID)
		if err != nil {
			RequireManagerLogin()
			return
		}
		session.SetContextOperator(c, operator)
	}
}

func RequireManagerLogin() gin.HandlerFunc {
	return func(c *gin.Context) {
		managerID, err := session.GetManagerID(c)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, err)
			return
		}
		manager, err := model.FindManagerByID(managerID)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, err)
			return
		}
		session.SetContextManager(c, manager)
	}
}
