package middleware

import (
	"app/env"
	"app/session"
	"github.com/gin-contrib/sessions"
	"github.com/gin-contrib/sessions/cookie"
	"github.com/gin-gonic/gin"
	"net/http"
	"time"
)

// InitializeSession セッションを使えるように初期化
func InitializeSession() gin.HandlerFunc {
	store := cookie.NewStore([]byte(env.Config.Secret), []byte(env.Config.Secret[:32]))
	return sessions.Sessions("session", store)
}

// UpdateSessionExpires セッション内に有効期限を持たせる
// cookieのExpires/Max-Ageはユーザー側で変更可能なので独自に管理する
func UpdateSessionExpires() gin.HandlerFunc {
	return func(c *gin.Context) {
		now := int(time.Now().Unix())
		if expires, err := session.GetSessionExpires(c); err != nil || now > expires {
			if err := session.Clear(c); err != nil {
				_ = c.AbortWithError(http.StatusInternalServerError, err)
			}
		}
		newExpires := now + session.SessionTimeoutSec
		if err := session.SetSessionExpires(c, newExpires); err != nil {
			_ = c.AbortWithError(http.StatusInternalServerError, err)
		}
	}
}
