import React ,{useState,useContext,useEffect} from 'react'
import '../styles/home.css'
import propertiesBuy from '../shared/listingsData';
import { Pagination } from '@mui/material';
const Home = () => {
   const [cardCount,setCardCount]=useState(propertiesBuy.length)
   const [newCards,setNewCards]=useState(propertiesBuy)
   const [currentPage,setCurrentPage]=useState(1)
   const [displayedCards,setDisplayedCards]=useState([propertiesBuy])
   const [totalPages,setTotalPages]=useState(10)
   useEffect(()=>{
      console.log("ok")
      const initMap=async()=> {
         const { Map } = await window.google.maps.importLibrary("maps");
         const { AdvancedMarkerElement } = await window.google.maps.importLibrary("marker");
         const map = new Map(document.getElementById("map"), {
            center: { lat: 30.289011, lng: -97.751134 },
            zoom: 13,
            mapId: "4504f8b37365c3d0",
         });
         map.setOptions({
            streetViewControl: false,
            fullscreenControl:false,  
            mapTypeControl:false,
            zoomControlOptions: {
               position: window.google.maps.ControlPosition.TOP_LEFT // set zoomControlOptions to position zoom in and out button on top left
               }
            });
         const markers=propertiesBuy.map((property)=>{
            const priceTag = document.createElement("div");
            priceTag.className = "bg-blue-500 font-bold text-xl h-8 w-28 rounded-md text-white text-center px-auto pt-1 ";
            priceTag.textContent = property.price
            return new AdvancedMarkerElement({
               map, 
               position: { lat: property.lat, lng: property.lng },
               content: priceTag,
            });
         })
         new markerClusterer.MarkerClusterer({markers,map})
         map.addListener("center_changed",()=>{
            const bound=map.getBounds()
            const newCards=propertiesBuy.filter((property)=>bound.contains({lat:property.lat,lng:property.lng}))
            setNewCards(newCards)
            setCardCount(newCards.length)
            setCurrentPage(1)
         })
         map.addListener("zoom_changed",()=>{
            const bound=map.getBounds()
            const newCards=propertiesBuy.filter((property)=>bound.contains({lat:property.lat,lng:property.lng}))
            setNewCards(newCards)
            setCardCount(newCards.length)
            setCurrentPage(1)
         })
      }
      initMap();
   },[propertiesBuy])
   useEffect(() => {
   
      const cardsPerPage = 10;
      setTotalPages(()=>Math.ceil(cardCount / cardsPerPage));
      const startIndex = (currentPage - 1) * cardsPerPage;
      const endIndex = startIndex + cardsPerPage;
      const currentCards = newCards.slice(startIndex, endIndex);
      setDisplayedCards(currentCards)
   }, [cardCount,newCards,currentPage]);
   const handlePageChange = (event,value) => {
      setCurrentPage(value);
      console.log(currentPage)
   };
   return(
      <div>
         <div className='w-screen h-[90px] bg-white  shadow-md shadow-gray-200 flex'>
            <div className='ml-56 mt-2'>
               <p className='font-normal text-sm ml-5'>Search</p>
               <input type='text' className='mt-1 w-72 h-10 rounded-md border border-gray-400 focus:outline-3 focus:outline-offset-0 focus:outline-blue-300' placeholder='City, Neighbourhood,Zip, Address'></input>
            </div>
            <div className='ml-5 mt-2.5'>
               <p className='font-normal text-sm ml-5'>Max Rent</p>
               <select id="prices" className="bg-gray-50 hover:cursor-pointer mt-1 pl-2 h-10 border-gray-300 rounded-md text-gray-700 text-md block w-36 ">
                  <option value="No Max" defaultValue>No Max</option>
                  <option value="$1,750">$1,750</option>
                  <option value="$2,000">$2,000</option>
                  <option value="$2,250">$2,250</option>
                  <option value="$2,500">$2,500</option>
                  <option value="$2,750">$2,750</option>
                  <option value="$3,000">$3,000</option>
                  <option value="$3,250">$3,250</option>
               </select>
            </div>
            <div className='ml-5 mt-2.5'>
               <p className='font-normal text-sm ml-5'>Bed</p>
               <select id="prices" className="bg-gray-50 hover:cursor-pointer mt-1 pl-2 h-10 border-gray-300 rounded-md text-gray-700 text-md block w-24">
                  <option value="Any" defaultValue>Any</option>
                  <option value="3+bd">3+bd</option>
                  <option value="4+bd">4+bd</option>
                  <option value="5+bd">5+bd</option>
               </select>
            </div>
            <div className='ml-5 mt-2.5'>
               <p className='font-normal text-sm ml-5'>Bath</p>
               <select id="prices" className="bg-gray-50 hover:cursor-pointer mt-1 pl-2 h-10 border-gray-300 rounded-md text-gray-700 text-md block w-24">
                  <option className='py-2' value="Any" defaultValue>Any</option>
                  <option className='py-2' value="2+ba">2+ba</option>
                  <option className='py-2' value="3+ba">3+ba</option>
                  <option className='py-2' value="4+ba">4+ba</option>
                  <option className='py-2' value="5+ba">5+ba</option>
               </select>
            </div>
         </div>
         <div className='flex w-screen'>
            
            <div id="map" className='w-[55%] h-[758px]'>
               
            </div>
            <div className='w-[45%] h-[758px]  overflow-y-auto overflow-x-hidden'>
               <h1 className='mt-4 ml-8 text-3xl font-medium text-gray-600'>Nearest Rental Homes</h1>
               <label className='mt-2 ml-8 text-xl font-medium text-gray-600'>{cardCount} results</label>
               <div className='row'>
               {
                     displayedCards.map((card,index)=>{
                        return (
                           <div key={index} className='col-5  ml-12 mt-6  shadow-md shadow-gray-500 text-gray-500 rounded-md animate-pulse transform transition duration-1000 hover:animate-none hover:cursor-pointer hover:text-blue-500 hover:scale-105'>
                              <img className='h-[200px] w-[100%] rounded-t-md' src={card.image} /> 
                              <div className='flex mt-2 align-items-center'>
                                 <label className='text-2xl font-medium  ml-2'>{card.price}</label>
                                 <label className='text-sm  font-medium  pt-2 pl-1 ml-4'>{card.bedrooms}|</label>
                                 <label className='text-sm  font-medium  pt-2 pl-1'> {card.bathrooms}|</label>
                                 <label className='text-sm  font-medium  pt-2 pl-1'> {card.size}</label>
                              </div>
                              <label className='text-md text-left ml-2 font-medium  mb-2'>{card.address}</label>
                           </div>
                        )
                     })
               }
               </div>
               <div className='xl:ml-[30%] mt-5 '>
                  <Pagination count={totalPages} page={currentPage} onChange={handlePageChange}/>
               </div>
               <p className='text-gray-600 mt-20 text-md mx-8'>
                  Simply put, Sparrow is the next generation single-family home rental company. We offer truly exceptional homes in prime neighborhoods to the growing share of Americans who choose to lease a house. Worry-free. Mortgage-free. Now that’s a great way of life. With Sparrow, you enjoy the benefits of a home without the worry, hassles and financial burdens of ownership.
               </p>
               <p className='text-gray-600 mt-10 text-md mx-8'>
                  A Sparrow home is much more than a typical rental. Each of our quality properties is beautifully renovated, upgraded with SmartHome features, professionally managed and regularly maintained. We take care of details like property taxes, insurance and HOA fees for our residents, so they’re free to enjoy where they live, without the hassles and worries of ownership. When you rent with Sparrow, you can feel good knowing you’ve found a clean, comfortable, cared-for home.
               </p>
               <div className='mx-8 row  text-gray-700 text-lg mt-10'>
                  <div className='col-4 px-0'>
                     <label className='text-3xl text-blue-500 italic'>Blaccz</label>
                  </div>
                  <div className='col-4 px-0'>
                     <p >Rent a Home</p>
                     <p className='mt-3'>Sell Your Home</p>
                     <p className='mt-3'>Request An Offer</p>
                     <p className='mt-3'>Agent Registration</p>
                     <p className='mt-3'>FAQs</p>
                     <p className='mt-3'>About Us</p>
                     <p className='mt-3'>Future Residents</p>
                     <p className='mt-3'>Rental Qualifications</p>
                     <p className='mt-3'>SmartHome Features</p>
                  </div>
                  <div className='col-4 px-0'>
                     <p >Current Residents</p>
                     <p className='mt-3'>Maintenance Responsibilities</p>
                     <p className='mt-3'>Resident Green Guide</p>
                     <p className='mt-3'>Contact Us</p>
                     <p className='mt-3'>Resident Login</p>
                     <p className='mt-3'>Terms of Service</p>
                     <p className='mt-3'>Privacy Policy</p>
                     <p className='mt-3'>Fraud Awareness</p>
                     <p className='mt-3'>Careers</p>
                  </div>
               </div>
               <img src='https://sparrownow.com/wp-content/themes/sparrow/static/img/equal-housing.svg' className='-mt-5 ml-8 w-10 h-10'/>
               <p className='mt-5 text-gray-700 text-md ml-8 mb-12'>© 2023 Imajn Services, LLC. All Rights Reserved.</p>
            </div>
         </div>
         
      </div>
   )
}

export default Home
