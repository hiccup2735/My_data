import React, {  useState, useRef,useEffect, useContext } from 'react'
import { Container, Row, Button } from 'reactstrap'
import {  Link, useNavigate } from 'react-router-dom'

import "./header.css"
const Header = () => {
   const dropdownRef = useRef(null);
   const [isActive, setIsActive] = useState(false);
   const onClick = () => setIsActive(!isActive);
   return (
      <header className='sticky_header items-center border border-gray-500' >
         <Container>
            <Row>
               <div className=" d-flex align-items-center justify-content-between m-3 items-center"  >
                  <div  >
                     <Link to='#' className="text-blue-500 font-medium text-4xl italic -ml-20">Blaccz</Link>
                  </div>
                  <div className="nav__right d-flex align-items-center gap-4 ">
                     <div className=" d-flex align-items-center gap-4">
                        <button id="rentButton" data-dropdown-toggle="rent" data-dropdown-trigger="hover" className='btn border-none font-normal text-lg hover:text-blue-500'><Link to='#'> Rent a Home</Link></button>
                        <button id="sellButton" data-dropdown-toggle="sell" data-dropdown-trigger="hover" className='btn border-none font-normal text-lg hover:text-blue-500'><Link to='#'> Sell Your Home</Link></button>
                        <button id="futureButton" data-dropdown-toggle="future" data-dropdown-trigger="hover" className='btn border-none font-normal text-lg hover:text-blue-500'><Link to='#'> Future Residents</Link></button>
                        <button id="currentButton" data-dropdown-toggle="current" data-dropdown-trigger="hover" className='btn border-none font-normal text-lg hover:text-blue-500'><Link to='#'> Current Residents</Link></button>
                        <button id="aboutButton" data-dropdown-toggle="about" data-dropdown-trigger="hover" className='btn border-none font-normal text-lg hover:text-blue-500'><Link to='#'> About Us</Link></button>
                        <button className='btn border-none font-normal text-lg hover:text-blue-500'><Link to='#'> Log In</Link></button>
                        <button className='btn border-none font-normal text-lg hover:text-blue-500'>
                           <Link to='#'>
                              <svg fill="#228BE6" xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 64 64" width="24px" height="24px"><path d="M 27 9 C 17.075 9 9 17.075 9 27 C 9 36.925 17.075 45 27 45 C 31.129213 45 34.9263 43.587367 37.966797 41.240234 L 51.048828 54.322266 C 51.952828 55.226266 53.418266 55.226266 54.322266 54.322266 C 55.226266 53.418266 55.226266 51.952828 54.322266 51.048828 L 41.240234 37.966797 C 43.587367 34.9263 45 31.129213 45 27 C 45 17.075 36.925 9 27 9 z M 27 13 C 34.719 13 41 19.281 41 27 C 41 34.719 34.719 41 27 41 C 19.281 41 13 34.719 13 27 C 13 19.281 19.281 13 27 13 z"/></svg>
                           </Link>
                        </button>
                        <div id="rent" className="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                           <ul className="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="rentButton">
                              <li>
                                 <button  className="pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Rent a Home</button>
                              </li>
                              <li>
                                 <button  className="pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Areas We Serve</button>
                              </li>
                           </ul>
                        </div>
                        <div id="sell" className="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                           <ul className="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="sellButton">
                              <li>
                                 <button  className="pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Sell Your Home</button>
                              </li>
                              <li>
                                 <button  className="pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Request An Offer</button>
                              </li>
                           </ul>
                        </div>
                        <div id="future" className="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                           <ul className="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="futureButton">
                              <li>
                                 <button  className="text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Future Residents</button>
                              </li>
                              <li>
                                 <button  className=" text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Rental Qualification Criteria</button>
                              </li>
                              <li>
                                 <button  className="text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Move-In Guide</button>
                              </li>
                              <li>
                                 <button  className="text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">SmartHome Features</button>
                              </li>
                           </ul>
                        </div>
                        <div id="current" className="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                           <ul className="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="cuttentButton">
                              <li>
                                 <button  className="text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Current Residents</button>
                              </li>
                              <li>
                                 <button  className="text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Maintenance Responsibilities</button>
                              </li>
                              <li>
                                 <button  className="text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Pay Your Rent</button>
                              </li>
                              <li>
                                 <button  className="text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Maintenance Request</button>
                              </li>
                           </ul>
                        </div>
                        <div id="about" className="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                           <ul className="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="aboutButton">
                              <li>
                                 <button  className="text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">About Us</button>
                              </li>
                              <li>
                                 <button  className="text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Sustainability</button>
                              </li>
                              <li>
                                 <button  className="text-left pl-4 py-2 font-normal text-lg  dark:hover:bg-gray-600 dark:hover:text-white">Contact Us</button>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </Row>
         </Container>
      </header>
   )
}

export default Header