import React from 'react'
import './footer.css'
import { Container, Row, Col, ListGroup, ListGroupItem } from 'reactstrap'
import { Link } from 'react-router-dom'


const quick__links = [
   {
      path: '/home',
      display: 'Home'
   },
   {
      path: '/about',
      display: 'About'
   },
   {
      path: '/tours',
      display: 'Tours'
   },
]

const quick__links2 = [
   {
      path: '/gallery',
      display: 'Gallery'
   },
   {
      path: '/login',
      display: 'Login'
   },
   {
      path: '/register',
      display: 'Register'
   },
]

const quick__links3 = [
   {
      path: '/gallery',
      display: 'Gallery'
   },
   {
      path: '/login',
      display: 'Login'
   },
   {
      path: '/register',
      display: 'Register'
   },
]

const Footer = () => {
   const year = new Date().getFullYear()

   return (
      <footer className='footer mt-[200px] bg-white'>
         <Container className=' text-center'>
            <Row>
            <Col lg='3'>
                  <div className="logo w-[200px]">

                     <div className="social__link d-flex align-items-center gap-4">
                        <span>
                           <Link to='http://youtube.com'>
                              <i className='ri-youtube-line text-green-400'></i>
                           </Link>
                        </span>
                        <span>
                           <Link to='http://linkedin.com'>
                              <i className='ri-linkedin-fill text-green-400'></i>
                           </Link>
                        </span>
                        <span>
                           <Link to='http://facebook.com'>
                              <i className='ri-facebook-circle-line text-green-400'></i>
                           </Link>
                        </span>
                        <span>
                           <Link to='http://instagram.com'>
                              <i className='ri-instagram-line text-green-400'></i>
                           </Link>
                        </span>
                        <span>
                           <Link to='http://twitter.com'>
                              <i className='ri-twitter-line text-green-400'></i>
                           </Link>
                        </span>
                     </div>
                  </div>
               </Col>
               <Col lg='3'>
                  <h1 className="footer__link-title">All directories</h1>
                  <ListGroup className='footer__quick-links '>
                     {
                        quick__links.map((item, index) => (
                           <ListGroupItem key={index} className='ps-0 border-0 '>
                              <Link to={item.path}>{item.display}</Link>
                           </ListGroupItem>
                        ))
                     }
                  </ListGroup>
               </Col>
               <Col lg='3'>
                  <h1 className="footer__link-title">Top carpool routes</h1>
                  <ListGroup className='footer__quick-links'>
                     {
                        quick__links2.map((item, index) => (
                           <ListGroupItem key={index} className='ps-0 border-0'>
                              <Link to={item.path}>{item.display}</Link>
                           </ListGroupItem>
                        ))
                     }
                  </ListGroup>
               </Col>
               <Col lg='3'>
                  <h1 className="footer__link-title">About</h1>
                  <ListGroup className='footer__quick-links'>
                     {
                        quick__links3.map((item, index) => (
                           <ListGroupItem key={index} className='ps-0 border-0'>
                              <Link to={item.path}>{item.display}</Link>
                           </ListGroupItem>
                        ))
                     }
                  </ListGroup>
               </Col>
            </Row>
         </Container>
      </footer>
   )
}

export default Footer