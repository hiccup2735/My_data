import React from "react";

const DappContext = React.createContext();
export default DappContext;
