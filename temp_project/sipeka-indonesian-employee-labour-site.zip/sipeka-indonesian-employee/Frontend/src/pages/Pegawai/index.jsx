import DataGajiPegawai from "./DataGajiPegawai";
import UbahPasswordPegawai from "./PengaturanPegawai/UbahPasswordPegawai";

export {
    DataGajiPegawai,
    UbahPasswordPegawai
};