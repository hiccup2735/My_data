export * from './About';
export * from './Admin';
export * from './Contact';
export * from './Dashboard'
export * from './Home'
export * from './Login'
export * from './Pegawai';