import { setMaxParserCache, clearParserCache } from './ParserCache.js';

export { setMaxParserCache, clearParserCache };
