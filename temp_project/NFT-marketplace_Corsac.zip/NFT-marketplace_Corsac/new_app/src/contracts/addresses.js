export const CSNFT = '0xc8cd7297985d42db984f39abf9f0b6a375cb9e9d' //'0xf336d9b316b11448e6c786f25e0d017e485f59b9' 
export const CSCT = '0x48e1723209d34427587cf113c95d9f1fd0e631c3'
export const CSAUT = '0x725cbfe2aa1f424f595ceb012b8a4b338a365108'
export const chainId = '0x61'