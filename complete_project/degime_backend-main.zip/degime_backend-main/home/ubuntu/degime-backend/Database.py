{
    "user" : {
        
        "account":{
            "username": "",
            "email": "",
            "password": "",
            "password2": "",
        },
        
        "OnlineBusinessCard" : {
            # object User
            'url_name': '',
            'faceImg' : '',
            'realName' : '',
            'company_url' : '',
            'companyName' : '',
            'position' : '',
            'phoneNumber' : '',
            'mobilePhoneNumber' : '',
            'mailAddress' : '',
            'address' : '',            
            'onlineCard_Data': {
                'idCard' : [
                    '',
                    '',
                ],
                'socialLink' : [
                    {'FaceBook' : '',},
                    {'Twitter' : '',}
                ],
                'imgLink1' : [
                    {
                        'title' : '',
                        'text' : '',
                        'url' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                        },
                ],
                'imgLink2' : [
                    {
                        'title1' : '',
                        'text1' : '',
                        'url1' : '',
                        'title2' : '',
                        'text2' : '',
                        'url2' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                        }
                ],
                'imgLink3' : [
                    {
                        'title1' : '',
                        'text1' : '',
                        'url1' : '',
                        'title2' : '',
                        'text2' : '',
                        'url2' : '',
                        'title3' : '',
                        'text3' : '',
                        'url3' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                        }
                ],
                'imgLink4' : [
                    {
                        'title1' : '',
                        'text1' : '',
                        'url1' : '',
                        'title2' : '',
                        'text2' : '',
                        'url2' : '',
                        'title3' : '',
                        'text3' : '',
                        'url3' : '',
                        'title4' : '',
                        'text4' : '',
                        'url4' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                        }
                ],
                'videoLink' : [
                    {
                        'url' : '',
                        'order' : 1,
                        'size' : 1,        
                        'startTime': '',
                        'endTime': '',        
                    }
                ],
                'textLink' : [
                    {
                        'text':[
                            {
                                'insert': '',
                                'attributes': {
                                    'font': '',
                                    'italic': True, 
                                    'underline': True, 
                                    'background': '', 
                                    'bold': True, 
                                    'size': '', 
                                    'color': '',
                                    'align': '' 
                                }
                            },                        
                        ],
                        'text-alignment':'',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                    }
                ],
                'mapLink' : [
                    {
                        'imgLink' : '',
                        'mapLink' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                    }
                ],
                'selfProfile' : [
                    {
                        'title' : '',
                        'content' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                    }
                ],
                'dataLink' : [
                    {
                        'imgLink' : '',
                        'title' : '',
                        'content' : '',
                        'link' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                    }
                ],
                'slideLink' : [
                    {
                        'imgLink' : [
                            '',
                            '',
                            ],
                        'title' : '',
                        'content' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                    }
                ],
            }            
        },
        
        'snsTree' : {
            # object User
            'url_name': '',
            'faceImg' : '',
            'accountName' : '',
            'profile' : '',            
            'snsTree_Data': {
                'idCard' : [
                    '',
                    '',
                ],
                'dataLink' : [
                    {
                        'imgLink' : '',
                        'title' : '',
                        'content' : '',
                        'link' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                    }
                ],
                'imgLink1' : [
                    {
                        'title' : '',
                        'text' : '',
                        'url' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                        },
                ],
                'imgLink2' : [
                    {
                        'title1' : '',
                        'text1' : '',
                        'url1' : '',
                        'title2' : '',
                        'text2' : '',
                        'url2' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                        }
                ],
                'imgLink3' : [
                    {
                        'title1' : '',
                        'text1' : '',
                        'url1' : '',
                        'title2' : '',
                        'text2' : '',
                        'url2' : '',
                        'title3' : '',
                        'text3' : '',
                        'url3' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                        }
                ],
                'imgLink4' : [
                    {
                        'title1' : '',
                        'text1' : '',
                        'url1' : '',
                        'title2' : '',
                        'text2' : '',
                        'url2' : '',
                        'title3' : '',
                        'text3' : '',
                        'url3' : '',
                        'title4' : '',
                        'text4' : '',
                        'url4' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                        }
                ],
                'videoLink' : [
                    {
                        'url' : '',
                        'order' : 1,
                        'size' : 1,        
                        'startTime': '',
                        'endTime': '',        
                    }
                ],
                'textLink' : [
                    {
                        'text':[
                            {
                                'insert': '',
                                'attributes': {
                                    'font': '',
                                    'italic': True, 
                                    'underline': True, 
                                    'background': '', 
                                    'bold': True, 
                                    'size': '', 
                                    'color': '',
                                    'align': '' 
                                }
                            },                        
                        ],
                        'text-alignment':'',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                    }
                ],
                'selfProfile' : [
                    {
                        'title' : '',
                        'content' : '',
                        'order' : 1,
                        'size' : 1,
                        'startTime': '',
                        'endTime': '',
                    }
                ],
            }            
        },
    
        'log_db': {
            # object User
            "login_time": ""
        },
    
        "group_db": {
            "groupName": "",
            "memeberUserName": "",
            "is_nonnotification": False,
            "is_block": False,
            "is_trash": False,
        },
        
        'view_db': {
            
        }
    },
    
    'manager' : '',
    
    'chat' : '',
    
    'ecmol' : '',
}

#   ------------------  Chat WebSocket

#   ws://   domain.com  /chat/<room_name>/<token>/<username>

#   Connect  ==>>   {"is_Connected": "True", "sender": "username"} To all in room

#   Disconnect  ==>>   {"is_Connected": "False", "sender": "username"} To all in room

#   Connect Failed  ==>>   {"msg_type": "ERROR_OCCURED", "error_message": "UN_AUTHENTICATED", "user": "username"}

#   {"msg_type": "TEXT_MESSAGE", "message": "message", "user": "username"}
#   ==>>   {"msg_type": "TEXT_MESSAGE", "message": "message", "user": "username", "timestampe": "time", "msg_id": "123"}

#   message length > MESSAGE_MAX_LENGTH
#   ==>>   {"msg_type": "ERROR_OCCURED", "error_message": "MESSAGE_OUT_OF_LENGTH" "message": "message", "user": "username", "timestampe": "time"}

#   {"msg_type": "MESSAGE_READ", "msg_id": "123123", "user": "username"}
#   ==>>   {"msg_type": "MESSAGE_READ", "user": "username", "msg_id": "123"}

#   {"msg_type": "ALL_MESSAGE_READ", "user": "username"}
#   ==>>   {"msg_type": "ALL_MESSAGE_READ", "user": "username"}

#   {"msg_type": "IS_TYPING", "user": "username"}
#   ==>>   {"msg_type": "IS_TYPING", "user": "username"}

#   {"msg_type": "NOT_TYPING", "user": "username"}
#   ==>>   {"msg_type": "NOT_TYPING", "user": "username"}



#   ------------------  Personal WebSocket

#   ws://   domain.com  /personal_chat/<room_name>/<token>/<username>

#   Connect  ==>>   {"is_Connected": "True", "sender": "username"} To all in room

#  --------chat------ {"msg_type": "TEXT_MESSAGE", "message": "message", "user": "username"} To members in room
#   ==>>   {"msg_type": "MESSAGE_COUNTER", "overall_unread_msg": "unread_message_number", "unread_room": "unread room number", [{"room_name":"unread message number"}...]}

#   {"msg_type": "WENT_ONLINE", "user_name": "username"}
#   ==>>   {"msg_type": "WENT_ONLINE", "user_name": "username"} To friends

#   {"msg_type": "WENT_OFFLINE", "user_name": "username"}
#   ==>>   {"msg_type": "WENT_OFFLINE", "user_name": "username"} To friends

#   {"msg_type": "PROFILE_UPDATED", "user_name": "username"}
#   ==>>   {"msg_type": "PROFILE_UPDATED", "user_name": "username", "friend_group": "friend_group"} To friends

#   {"msg_type": "PROFILE_READ", "friend_name":"friend_name", "user_name": "username"}
#   ==>>   {"msg_type": "PROFILE_READ", "friend_name":"friend_name", "user_name": "username"} To friends

#   {"msg_type": "SEND_REQUEST", "friend_name":"friend_name", "user_name": "username"}
#   ==>>   {"msg_type": "SEND_REQUEST", "friend_name":"friend_name", "user_name": "username"} To friends

#   {"msg_type": "ALLOW_REQUEST", "friend_name":"friend_name", "user_name": "username"}
#   ==>>   {"msg_type": "ALLOW_REQUEST", "user_name": "username"} To friends

