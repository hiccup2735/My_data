Microsoft.Web.XmlTransform.dll

This file is used to transform the XML file.

Until 2015, this file is in the C:\Program Files (x86)\MSBuild\Microsoft\VisualStudio\v14.0\Web

But 2022, you should install Microsoft.Web.Xdt package from NuGet Package.