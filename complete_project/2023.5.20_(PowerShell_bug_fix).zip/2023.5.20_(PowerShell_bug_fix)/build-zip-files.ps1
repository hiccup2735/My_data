function Get-ScriptDirectory { Split-Path $MyInvocation.ScriptName }

function WriteHeader()
{
	write-host "#################################################"
	write-host "######### MRS build and package utility #########"
	write-host "#################################################"
	write-host
}

function XmlDocTransform($xml, $xdt)
{
    if (!$xml -or !(Test-Path -path $xml -PathType Leaf)) {
        throw "File not found. $xml";
    }
    if (!$xdt -or !(Test-Path -path $xdt -PathType Leaf)) {
        throw "File not found. $xdt";
    }

    Add-Type -LiteralPath "C:\Program Files (x86)\MSBuild\Microsoft\VisualStudio\v14.0\Web\Microsoft.Web.XmlTransform.dll"

    $xmldoc = New-Object Microsoft.Web.XmlTransform.XmlTransformableDocument;
    $xmldoc.PreserveWhitespace = $true
    $xmldoc.Load($xml);

    $transf = New-Object Microsoft.Web.XmlTransform.XmlTransformation($xdt);
    if ($transf.Apply($xmldoc) -eq $false)
    {
        throw "Transformation failed."
    }
    $xmldoc.Save($xml);
}

clear-host

WriteHeader

$deployPath = '..\deploy'
$buildEnv = 'dev'

# list subdirectories (version numbers only)
$versions = @(Get-ChildItem | ?{ $_.PSIsContainer } | Select -expand Name | where {$_ -match 'MRS+' -or $_ -match '[0-9]+[.][0-9]+'} | sort-object -descending)
#$versions = @(Get-ChildItem | ?{ $_.PSIsContainer } | Select -expand Name | where {$_ -match '[0-9]+[.][0-9]+'} | sort-object -descending)

$i = 1
$availableVersions = @()
foreach ($version in $versions) {
	write-host "[$($i)] for version $($version)"

	$availableVersions += $i
	$i++
}

write-host

$validVersionSelected = $false
while (!$validVersionSelected) {
	write-host "Which version do you want to build?"
	$selectedVersion = read-host

	if ($selectedVersion -in $availableVersions) {
		$validVersionSelected = $true
	} else {
		write-host "Please select a valid version from the above list."
	}
}

clear-host
WriteHeader

$environments = @('[d] development', '[q] QA/test', '[p] production')
foreach ($env in $environments) {
	write-host "$($env)"
}

write-host

$validVersionSelected = $false
while (!$validVersionSelected) {
	write-host "Which environment are you targeting?"
	$selectedBuildEnv = read-host

	if ($selectedBuildEnv -in @('d', 'q', 'p')) {
		$validVersionSelected = $true

		if ($selectedBuildEnv -eq 'd') {
			$buildEnv = 'dev'
		} elseif ($selectedBuildEnv -eq 'q') {
			$buildEnv = 'qa'
		} elseif ($selectedBuildEnv -eq 'p') {
			$buildEnv = 'prod'
		}

	} else {
		write-host "Please select a valid environment from the above list."
	}
}

clear-host
WriteHeader


######## clean deploy directory
$deployWildcard = join-path -path $deployPath -childpath "*"
$fullWildcardDeployPath = (join-path -path (Get-ScriptDirectory) -childpath $deployWildcard)
remove-item -path $fullWildcardDeployPath -recurse






######## MRSReports.zip

write-host "Creating MRSReports.zip..."
# create MRSReports.zip
compress-archive -force -path ($versions[$selectedVersion-1] + '\Reports\performance\*') -destinationpath ($deployPath + '\MRSReports.zip') | out-null





######## MRSServer.zip

write-host "Creating MRSServer.zip..."

# transform server XML files with environment specific values
write-host "Transforming configuration files..."

## import.xml
write-host "   import.xml"
XmlDocTransform (join-path (Get-ScriptDirectory) "$($versions[$selectedVersion-1])\config\mrxtest\server\import.xml") (join-path (Get-ScriptDirectory) "Resources\import.$($buildEnv).xml.xdt")

## export.xml
write-host "   export.xml"
XmlDocTransform (join-path (Get-ScriptDirectory) "$($versions[$selectedVersion-1])\config\mrxtest\server\export.xml") (join-path (Get-ScriptDirectory) "Resources\export.$($buildEnv).xml.xdt")

## demo.xml
write-host "   demo.xml"
XmlDocTransform (join-path (Get-ScriptDirectory) "$($versions[$selectedVersion-1])\config\mrxtest\server\demo.xml") (join-path (Get-ScriptDirectory) "Resources\demo.$($buildEnv).xml.xdt")

## report.xml
write-host "   report.xml"
XmlDocTransform (join-path (Get-ScriptDirectory) "$($versions[$selectedVersion-1])\config\mrxtest\server\report.xml") (join-path (Get-ScriptDirectory) "Resources\report.$($buildEnv).xml.xdt")

## NCPCP.dll.config
write-host "   NCPDP.dll.config"
XmlDocTransform (join-path (Get-ScriptDirectory) "$($versions[$selectedVersion-1])\Import\bin\Release\NCPDP.dll.config") (join-path (Get-ScriptDirectory) "Resources\NCPDP.$($buildEnv).dll.config.xdt")


## copy Import\bin\Release into "bin" folder
new-item -type directory -force (join-path -path $versions[$selectedVersion-1] -childpath '\Import\bin\Release\bin\') | out-null
copy-item (join-path -path $versions[$selectedVersion-1] -childpath '\Import\bin\Release\*.*') (join-path -path $versions[$selectedVersion-1] -childpath '\Import\bin\Release\bin\') -force


## copy server.bat into "bin" folder
copy-item 'Resources\server.bat' (join-path -path $versions[$selectedVersion-1] -childpath '\Import\bin\Release\bin\') -force


# create MRSServer.zip
compress-archive -force -path ($versions[$selectedVersion-1] + '\Import\bin\Release\bin\'),($versions[$selectedVersion-1] + '\config\common\server\*.*'),($versions[$selectedVersion-1] + '\config\mrxtest\server\*.*') -destinationpath ($deployPath + '\MRSServer.zip') | out-null

# clean up
remove-item -path (join-path -path $versions[$selectedVersion-1] -childpath '\Import\bin\Release\bin') -recurse






######## MRSWeb.zip

write-host "Creating MRSWeb.zip..."

# transform web XML files with environment specific values
write-host "Transforming configuration files..."

## cdmi.config
write-host "   cdmi.config"
XmlDocTransform (join-path (Get-ScriptDirectory) "$($versions[$selectedVersion-1])\ProcessingApplication\bin\Release\Publish\cdmi.config") (join-path (Get-ScriptDirectory) "Resources\cdmi.$($buildEnv).config.xdt")

## import.config
write-host "   import.config"
XmlDocTransform (join-path (Get-ScriptDirectory) "$($versions[$selectedVersion-1])\ProcessingApplication\bin\Release\Publish\import.config") (join-path (Get-ScriptDirectory) "Resources\import.$($buildEnv).config.xdt")

# expand ScriptsLib.zip
# expand-archive -force -path 'Resources\ScriptsLib.zip' -destinationpath 'Resources\ScriptsLib\' | out-null

# create MRSWeb.zip
compress-archive -force -path ($versions[$selectedVersion-1] + '\ProcessingApplication\bin\Release\Publish\*') -destinationpath ($deployPath + '\MRSWeb.zip') | out-null
# compress-archive -force -path ($versions[$selectedVersion-1] + '\ProcessingApplication\bin\Release\Publish\*'),'Resources\ScriptsLib\ScriptsLib' -destinationpath ($deployPath + '\MRSWeb.zip') | out-null


# clean-up
remove-item -path (join-path (Get-ScriptDirectory) 'Resources\ScriptsLib') -recurse

write-host "Zip file creation for MRS deploy is complete!" 
