import React from 'react';

const ModuleShopContent = () => {
    return <div className="ps-shop__content-wrapper"></div>;
};

export default ModuleShopContent;
