import React from 'react';

const RelatedPosts = () => {
    return <div></div>;
};

export default RelatedPosts;
