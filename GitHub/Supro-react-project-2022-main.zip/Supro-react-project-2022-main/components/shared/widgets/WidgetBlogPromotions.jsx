import React from 'react';

const WidgetBlogPromotions = () => {
    return (
        <aside className="widget widget_blog">
            <img src="/static/img/blog/img-widget.jpg" alt="" />
        </aside>
    );
};

export default WidgetBlogPromotions;
