# Intellitek Company project using React, TypeScript, Tailwindcss
![Screenshot_5](https://user-images.githubusercontent.com/101833474/194467841-1f7c4ad3-d8f0-49ec-bddb-80ef73b21318.png)


This is figma file for this project. <br>
https://www.figma.com/file/pdDGXdXWzQqdpAp7BnlcVb/Intellitek-Website?node-id=767%3A3532
