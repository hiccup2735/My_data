import ContactUs from './contactus';
import Home from './home';
import Pricing from './pricing';
import RequestDemo from './requeestdemo';
import RequestTrial from './requesttrial';
import Resources from './resources';
import OurSolutions from './oursolutions';


export{
    ContactUs,
    Home,
    Pricing,
    RequestDemo,
    Resources,
    OurSolutions,
    RequestTrial
}