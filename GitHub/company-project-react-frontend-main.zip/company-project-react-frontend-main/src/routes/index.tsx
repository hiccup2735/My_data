import MainRouter from "./MainRouter";

export{
    MainRouter
}