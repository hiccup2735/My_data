export const images = {
    faq: "/imgs/faq_bg.png"
}