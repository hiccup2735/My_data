export const Questions = [
  {
    question: "when mint",
    desc: "minting soon by 3 month time",
  },
  {
    question: "What's total supply",
    desc: "minting soon by 3 month time",
  },
  {
    question: "How Much",
    desc: "minting soon by 3 month time",
  },
  {
    question: "what's max mint amount",
    desc: "minting soon by 3 month time",
  },
];
