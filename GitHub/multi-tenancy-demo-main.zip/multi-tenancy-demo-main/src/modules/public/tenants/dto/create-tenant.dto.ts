export class CreateTenantDto {
  name: string;
}
