export const CONNECTION = Symbol('CONNECTION');
