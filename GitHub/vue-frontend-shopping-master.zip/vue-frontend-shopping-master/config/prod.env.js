'use strict'
module.exports = {
  NODE_ENV: '"production"',
  ROOT_API: '"https://api.easy.restaurant/site/data"',
  CALC_API: '"https://api.easy.restaurant/order/calc"'
}
