import * as constants from './constants'

export const saveBook = (payload) => ({ type: constants.SAVE_BOOK, payload })
