
export const SAVE_TICKER = "SAVE_TICKER"
