import * as constants from './constants'

export const saveTicker = (payload) => ({ type: constants.SAVE_TICKER, payload })
