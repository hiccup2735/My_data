
	<h2 class="center"><?php _e('Not Found', 'od'); ?></h2>
	<p class="center"><?php _e("Sorry, but you are looking for something that isn't here.", 'od'); ?></p>
	<?php get_search_form(); ?>
