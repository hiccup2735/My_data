	<nav class="page-navigation">
		<div class="prev-link"><?php next_posts_link( '&laquo; '.OLDERENTRIESTEXT); ?></div>
		<div class="next-link"><?php previous_posts_link( NEWERENTRIESTEXT.' &raquo;' ); ?></div>
	</nav>
