<?php
/*
You can note your changes in the WordPress admin / database / plugins / htaccess / wp-config (all not in git) here so they can be reproduced on other environments (dev/acc/live)
Add the last change at the bottom. Put everything in comments, but copy-paste-ready (if possible).

Example:
//  (voorbeeld) GVR-395-84096 - meer items in RSS feed
admin -> Instellingen -> "RSS-feeds tonen de meest recente" op 20 gezet
//  (voorbeeld) HHJ-765-453666 - e-mailadres van alle occhio-gebruikers naar occhio@ aangepast
UPDATE FROM wp_users SET user_email = 'occhio@occhiuo.nl' WHERE user_login LIKE 'occhio%'










*/