<?php
// list all constants

define( 'NEWERENTRIESTEXT', __('More items', 'od') );
define( 'OLDERENTRIESTEXT', __('Back', 'od') );
