<?php

class Sidebar_Footer extends Sidebar {

	/**
	 * Required variables
	 */
	protected $columnAmount = 5;
	protected $name = 'Footer';
	protected $args;
	protected $template = 'snippet-footer-widgets';
	protected $className;
}
