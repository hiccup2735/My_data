<?php
return [
    'bookmarks' => 'Bookmarks',
    'following' => 'Following',
    'unlock-post' => 'Unlock Post',
    'unlock-message' => 'Unlock Message',
    'tip' => 'Tip',
    'subscription-to-x' => ':site Subscription - :user - :months month(s)',
    'subscription-info' => 'Subscription gives access to all locked content of a particular user.',
    'main-agreement' => 'Main Agreement',
];
