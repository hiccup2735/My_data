import MainPage from './MainPage';

export {
    MainPage
}