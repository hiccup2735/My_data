import lightTheme from "./theme/lightTheme";

export {
    lightTheme
}