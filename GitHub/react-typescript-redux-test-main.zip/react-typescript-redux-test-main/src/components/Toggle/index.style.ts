// import mui modules
import {
    styled,
} from '@mui/material';

export const ToggleStyle = styled('main')(({ theme }: any ) => {
    return {
        height: '3rem'
    }
})