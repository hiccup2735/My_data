// import mui modules
import {
    styled,
} from '@mui/material';

export const SortButtonStyle = styled('main')(({ theme }: any ) => {
    return {
        '.button-box': {
            height: '3rem'
        }
    }
})