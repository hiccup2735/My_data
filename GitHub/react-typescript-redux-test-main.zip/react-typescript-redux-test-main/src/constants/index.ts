import * as PATH from './path';

export {
    PATH
}