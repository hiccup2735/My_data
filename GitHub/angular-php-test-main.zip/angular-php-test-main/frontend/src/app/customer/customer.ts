export interface Customer {
    id: number;
    name: string;
    state: string;
    zip: string;
    amount: string;
    qty: string;
    item: string;
}
