# jquerybased-webpage
 
A single page web app using Vanilla Javascript, HTML and jQuery.

