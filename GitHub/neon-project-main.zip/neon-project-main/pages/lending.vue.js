var lendingvue = Vue.extend({
  template: `<div class="main-wrapper">
  
    <main class="main users">

    <iframe id="frame" src="/lending"  loading="lazy"></iframe>

    </main>

   </div>`,
   
   mounted() {

 
  },
  methods: {

  }
});
