var swapvue = Vue.extend({
  template: `<div class="main-wrapper">
  
    <main class="main users">

    <iframe id="frame" src="/swap"  loading="lazy"></iframe>

    </main>

   </div>`,

   mounted() {

 
  },
  methods: {

  }
});
