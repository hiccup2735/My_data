var fleekvue = Vue.extend({
  template: `<div class="main-wrapper">
  
    <main class="main users">

    <iframe id="frame" src="https://fleek.co"  loading="lazy"></iframe>

    </main>

   </div>`,
   
   mounted() {

 
  },
  methods: {

  }
});
