var svue = Vue.extend({
  template: `<div class="main-wrapper">
  
    <main class="main users">

    <iframe id="frame" src="https://synapseprotocol.com/?inputCurrency=USDC&outputCurrency=MIM&outputChain=42161"  loading="lazy"></iframe>

    </main>

   </div>`,
   
   mounted() {

 
  },
  methods: {

  }
});
