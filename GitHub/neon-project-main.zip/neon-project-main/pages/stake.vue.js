var stakevue = Vue.extend({
  template: `<div class="main-wrapper">
  
    <main class="main users">

    <iframe id="frame" src="/swap#/add/0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270/0xa10a1e274360c2573ee356173b132b33c774eb34"  loading="lazy"></iframe>

    </main>

   </div>`,
   
   mounted() {

 
  },
  methods: {

  }
});
