var snapshotvue = Vue.extend({
  template: `<div class="main-wrapper">
  
    <main class="main users">

    <iframe id="frame" src="https://snapshot.org"  loading="lazy"></iframe>

    </main>

   </div>`,
   
   mounted() {

 
  },
  methods: {

  }
});
