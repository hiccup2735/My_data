var portfoliovue = Vue.extend({
  template: `<div class="main-wrapper">
  
    <main class="main users">

     <iframe id="frame" src="/portfolio"  loading="lazy"></iframe>
  
    </main>

   </div>`,
   
   mounted() {

  },
  methods: {


  }
});
