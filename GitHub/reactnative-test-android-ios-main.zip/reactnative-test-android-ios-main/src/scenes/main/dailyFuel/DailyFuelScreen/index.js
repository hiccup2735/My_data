import React, { useState, useEffect } from "react";
import { Image, Text, View } from "react-native";
import styles from "./styles";

const DailyFuelScreen = props => {
  return (
    <View style={styles.container}>
      <Text style={styles.description}>Daily fuel Page</Text>
    </View>
  );
};


export default DailyFuelScreen;
