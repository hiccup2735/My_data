# Mobile App Test using React Native for Android and iOS
I built this using React Native based on Figma Design. <br>
I coded in Visual Studio Code and tested at Android Studio Emulator.<br>
Through building this app to debug-version apk, I finally built it to release-version apk.<br>
Then, I passed the apk through lots of mobile devices at Browserstack to check out the full responsibility of this app.<br>
Following is Figma design.

![Screenshot_3](https://user-images.githubusercontent.com/101833474/194223915-39fa35bc-8848-44a8-8576-18c7def05627.png)
