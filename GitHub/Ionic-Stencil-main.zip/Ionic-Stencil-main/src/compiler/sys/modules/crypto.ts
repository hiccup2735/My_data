//@ts-ignore
import sha256 from 'hash.js/lib/hash/sha/256';
export const createHash = () => sha256();
