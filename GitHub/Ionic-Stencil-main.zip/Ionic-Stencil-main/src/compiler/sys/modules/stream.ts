export const Stream = function () {
  /**/
};

export default {
  Stream,
};
