const coreDts = `/* core dts placeholder */`;
export default coreDts;
