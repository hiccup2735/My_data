export class EventEmitter {}

export default {
  EventEmitter,
};
