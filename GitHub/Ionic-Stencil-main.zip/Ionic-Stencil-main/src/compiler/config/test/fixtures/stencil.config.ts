import { Config } from '../../../../declarations';

export const config: Config = {
  hashedFileNameLength: 13,
};
