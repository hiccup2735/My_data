const { ScreenshotConnector } = require('./index.js');
module.exports = ScreenshotConnector;
