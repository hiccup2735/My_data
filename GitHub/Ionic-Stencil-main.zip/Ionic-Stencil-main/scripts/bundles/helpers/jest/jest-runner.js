const { createTestRunner } = require('./index.js');

module.exports = createTestRunner();
