if (typeof module !== 'undefined' && module.exports) {
  module.exports = exports;
}
globalThis.stencil = exports;
})({});