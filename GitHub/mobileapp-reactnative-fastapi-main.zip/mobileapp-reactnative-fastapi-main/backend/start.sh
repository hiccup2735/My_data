cd src && uvicorn main:app --reload
