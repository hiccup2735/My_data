from modules.delete_product.usecase import DeleteProductUsecase

def make_delete_product_usecase():
  return DeleteProductUsecase()