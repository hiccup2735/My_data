
from modules.update_product.usecase import UpdateProductUsecase

def make_update_product_usecase():
  return UpdateProductUsecase()