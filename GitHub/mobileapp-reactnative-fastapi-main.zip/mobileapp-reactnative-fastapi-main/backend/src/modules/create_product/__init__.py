from  modules.create_product.usecase.create_product_usecase import CreateProductUsecase

def make_create_product_usecase():
  return CreateProductUsecase()