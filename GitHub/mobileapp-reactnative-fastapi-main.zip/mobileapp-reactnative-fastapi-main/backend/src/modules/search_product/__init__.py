from modules.search_product.usecase import SearchProductusecase

def make_search_product_usecase():
  return SearchProductusecase()