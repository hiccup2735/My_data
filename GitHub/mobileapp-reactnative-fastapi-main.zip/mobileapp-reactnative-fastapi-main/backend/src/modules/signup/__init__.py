from .usecase import SignUpUsecase


def make_sign_up_usecase():
    return SignUpUsecase()
