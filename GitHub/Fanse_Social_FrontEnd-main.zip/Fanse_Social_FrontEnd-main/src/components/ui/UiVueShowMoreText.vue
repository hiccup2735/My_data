<template>
  <div  v-bind:style="additionalContainerCss">
    <!-- eslint-disable -->  
    <div ref="detail" v-bind:class="{'default': !expanded, 'expanded': expanded}" 
      v-bind:style="`--lines: ${lines}`">
      <div v-bind:style="additionalCss" 
        v-html="text">
      </div>
    </div>
    <!-- eslint-enable -->
    <a
      v-if="hasMore && triggerShowMore"
      class="anchor"
      :style="additionalAnchorCss" 
      @click="onClick"
      >{{ moreText }}</a
    >
    <a
      v-if="hasMore && expanded"
      class="anchor"
      :style="additionalAnchorCss" 
      @click="onClick"
      >{{ lessText }}</a
    >
  </div>
</template>

<script>
export default {
  name: 'VueShowMoreText',
  props: {
    lines: {
      type: Number,
      default: 3,
    },
    text: {
      type: String,
      default: '',
    },
    additionalContainerCss:{
      type: String, 
      default: '',
    },
    additionalContentCss: {
      type: String,
      default: '',
    },
    additionalContentExpandedCss: {
      type: String,
      default: '',
    },
    hasMore: {
      type: Boolean,
      default: true,
    },
    moreText: {
      type: String,
      default: 'Show more',
    },
    lessText: {
      type: String,
      default: 'Show less',
    },
    additionalAnchorCss: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      expanded: false,
      triggerShowMore: false,
    }
  },
  computed: {
    additionalCss: function () {
      if(this.expanded) {
        return this.additionalContentCss
      }else{
        return this.additionalContentExpandedCss
      }
    }
  },
  mounted() {
    this.$nextTick(function () {
      this.determineShowMore()
    })
  },
  updated() {
    this.$nextTick(function () {
      this.determineShowMore()
    })
  },
  methods: {
    onClick() {
      this.expanded = !this.expanded
      this.$emit('click', this.expanded);
    },
    determineShowMore() {
      // 文字列が省略ellipsis(...)されているかをチェックする
      // scrollWidth、scrollHeight：現在スクロール領域の外側に隠れている部分を含む、ボックスのすべてのコンテンツのサイズ。
      // offsetWidth、offsetHeight：すべての境界線を含むビジュアルボックスのサイズ。
      if (
        this.$refs.detail &&
        this.$refs.detail.offsetHeight < this.$refs.detail.scrollHeight
      ) {
        this.triggerShowMore = true
      } else {
        this.triggerShowMore = false
      }
    },
  },
}
</script>
<style scoped>
.default{
  --lines: 3;
  white-space: pre-line; 
  display: -webkit-box; 
  max-width:100%; 
  -webkit-line-clamp: var(--lines); 
  -webkit-box-orient: vertical; 
  overflow: hidden; 
  text-overflow: ellipsis;
}
.expanded{
  display: block; 
  display: -webkit-box; 
  white-space: pre-line;
}
.anchor{
  display: block; 
  text-align: left; 
  color: #1976d2;
  cursor: pointer;
}
.container{
  padding: 10px;
}
</style>