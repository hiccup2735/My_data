<template>
  <div>
<div style="text-align: center;margin-top:20px">
<svg width="200px" height="132px" viewBox="0 0 903 232" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <title>Group 4</title>
    <g id="Page-2" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Group-4" transform="translate(1.000000, 1.000000)" fill-rule="nonzero">
            <g id="Group-3" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="0.5">
                <path d="M51.9827071,204.461851 L51.9827071,178.923701 C51.9827071,153.385552 51.1830398,153.385552 77.9740606,153.385552 C103.965414,153.385552 155.948121,153.385552 155.948121,153.385552 L155.948121,102.309254 L155.948121,102.309254 C155.948121,102.309254 103.965414,102.309254 77.9740606,102.309254 C51.9827071,102.309254 51.9827071,102.309254 51.9827071,76.7711044 C51.9827071,51.2329552 51.9827071,51.2329552 77.9740606,51.2329552 C103.965414,51.2329552 157.045823,50.7383663 157.045823,50.7383663 L157.045823,50.7383663 L157.710335,0.191558767 C157.710335,0.191558767 92.0362493,-0.357511442 46.7879019,0.403525406 C1.53955451,1.16456225 1.44685201,49.0264591 1.44685201,49.0264591 L0,230 L0,230 L51.9827071,204.461851 Z" id="Path"></path>
                <path d="M238.913535,51.2329552 C186.930828,51.2329552 186.930828,102.309254 186.930828,102.309254 C186.930828,102.309254 186.930828,102.309254 186.930828,153.385552 C186.930828,204.461851 238.913535,204.461851 238.913535,204.461851 L290.896243,204.461851 L290.896243,230 L342.87895,204.461851 C342.87895,204.461851 342.87895,159.700285 342.87895,116.674463 C342.87895,118.270597 342.87895,115.078328 342.87895,102.309254 C342.87895,51.2329552 290.896243,51.2329552 290.896243,51.2329552 C290.896243,51.2329552 290.896243,51.2329552 238.913535,51.2329552 Z M264.904889,102.309254 C279.259914,102.309254 290.896243,113.742683 290.896243,127.847403 C290.896243,141.952123 279.259914,153.385552 264.904889,153.385552 C250.549864,153.385552 238.913535,141.952123 238.913535,127.847403 C238.913535,113.742683 250.549864,102.309254 264.904889,102.309254 Z" id="Shape" opacity="0"></path>
                <path d="M264.904889,51.2329552 C221.840682,51.2329552 186.930828,85.5340947 186.930828,127.847403 C186.930828,170.160711 221.840682,204.461851 264.904889,204.461851 C274.035651,204.461851 282.754018,202.852947 290.896243,200.019064 L290.896243,204.461851 L342.87895,204.461851 L342.87895,127.847403 C342.87895,85.5340947 307.969096,51.2329552 264.904889,51.2329552 Z M264.904889,102.309254 C279.259914,102.309254 290.896243,113.742683 290.896243,127.847403 C290.896243,141.952123 279.259914,153.385552 264.904889,153.385552 C250.549864,153.385552 238.913535,141.952123 238.913535,127.847403 C238.913535,113.742683 250.549864,102.309254 264.904889,102.309254 Z" id="Shape"></path>
                <path d="M372.861657,203.461851 L372.861657,24.6948059 L372.861657,24.6948059 C372.861657,24.6948059 398.85301,50.2329552 424.844364,50.2329552 C451.635385,50.2329552 476.827071,50.2329552 476.827071,50.2329552 C476.827071,50.2329552 528.809778,50.2329552 528.809778,101.309254 C528.809778,152.385552 528.809778,203.461851 528.809778,203.461851 L476.827071,203.461851 L476.827071,126.847403 C476.827071,126.847403 476.827071,101.309254 450.835717,101.309254 C424.844364,101.309254 424.844364,126.847403 424.844364,126.847403 L424.844364,203.461851 L424.844364,203.461851 L372.861657,203.461851 Z" id="Path"></path>
                <path d="M636.766546,51.2329552 C585.416295,51.2329552 558.792485,74.1006653 558.792485,102.309254 C559.173692,127.520515 590.718531,131.477225 601.643563,134.019974 C616.060101,137.373133 629.081769,141.04637 636.948485,143.585713 C644.156754,145.911387 652.422004,149.910661 655.272389,151.639594 C660.799884,154.997861 663.347037,168.462424 637.338355,168.655663 C611.329674,168.84805 610.775192,153.385552 610.775192,153.385552 L558.792485,153.385552 C558.792485,178.923701 585.52026,204.236264 639.556284,204.355835 C688.991839,204.464405 715.979527,181.911665 715.684959,153.704779 C715.667631,143.176251 715.121813,125.624733 663.728243,112.684552 L655.965492,110.582763 C641.159084,106.911228 651.096445,109.625933 636.489305,106.214888 C631.35168,105.014595 623.614921,103.186063 615.78286,100.713119 C607.959462,98.2401752 609.25903,86.9574209 635.267711,87.0238201 C661.276392,87.0902193 662.757899,102.309254 662.757899,102.309254 L714.740606,102.309254 C715.684959,76.7711044 688.437357,51.2329552 636.766546,51.2329552 Z" id="Path"></path>
                <path d="M800.829982,103.182658 C800.829982,95.8140511 811.902299,88.3134966 824.248191,88.3134966 C836.594084,88.3134966 846.609419,94.287721 846.609419,101.656328 C846.609419,109.025787 837.373825,110.044759 825.027932,110.044759 C812.673375,110.044759 800.829982,110.552117 800.829982,103.182658 Z M822.697374,51.2329552 C779.629701,51.2329552 744.723313,85.5340947 744.723313,127.847403 C744.723313,170.160711 779.629701,204.461851 822.697374,204.461851 C858.565442,204.461851 898.039475,196.393087 898.039475,190.958336 C898.039475,185.523586 892.016314,150.262237 879.46249,153.261267 C871.994308,155.046383 852.691396,161.722055 837.47779,160.988259 C827.401809,160.502183 806.678036,157.51422 802.675368,150.708303 C800.041578,146.223804 824.066252,142.988972 838.985289,140.949325 C850.768036,139.338719 871.821032,137.634473 890.058299,131.142675 C898.037644,128.301982 901.771735,127.453264 900.671435,110.050718 C898.566135,76.7711044 861.623758,51.2329552 822.697374,51.2329552 Z" id="Shape"></path>
            </g>
            <g id="Group" transform="translate(231.000000, 96.000000)" fill="#2081E2">
                <path d="M32.4994583,0 C14.5507092,0 0,14.5511425 0,32.4994583 C0,50.4477741 14.5507092,65 32.4994583,65 C50.4482075,65 65,50.4477741 65,32.4994583 C65,14.5511425 50.4482075,0 32.4994583,0 Z M48.5859264,36.0576176 C44.9068651,40.1453191 34.058401,48.9752829 33.5979766,49.3488225 C33.2753546,49.6112102 32.8859981,49.7444624 32.4994583,49.7258288 C32.4877581,49.7264788 32.4751913,49.7264788 32.462841,49.7264788 C32.0890848,49.7264788 31.7131619,49.60276 31.4007233,49.3488225 C30.9405157,48.9750663 20.0931349,40.1451024 16.4151569,36.058051 C12.3824897,31.5753596 12.4089235,25.1281188 16.4764746,21.0605677 C20.6280938,16.9082985 27.3845231,16.9082985 31.5363589,21.0605677 L32.5001083,22.0243171 L33.4645077,21.0599177 C37.6161269,16.9082985 44.3719062,16.9087318 48.5248254,21.0599177 C52.5915099,25.1283355 52.6179436,31.5755763 48.5859264,36.0576176 Z" id="Shape"></path>
            </g>
        </g>
    </g>
</svg></div>
    <button @click="AuthProvider('google')" class="btn btn-lg btn-block" style="border: solid 1px #CED4DA;border-radius: 30px;">
      <img width="30px" style="float:left" alt="Google login" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Google_%22G%22_Logo.svg/512px-Google_%22G%22_Logo.svg.png" />
      <div style="font-size: 1rem;">Sign In With Google</div>
    </button>
    <small class="btn-block text-center my-3 text-uppercase or">or</small>

    <div v-if="errors._ && errors._.length > 0">
      <div class="alert alert-danger" v-for="error in errors._" :key="error">
        {{ error }}
      </div>
    </div>

    <ui-form-input
      type="text"
      name="email"
      v-model="email"
      :errors="errors"
      :label="$t('general.email')"
    />

    <ui-form-input
      type="password"
      name="password"
      v-model="password"
      :errors="errors"
      :label="$t('general.password')"
    />

    <b-button
      variant="primary"
      class="w-100 mb-3"
      @click.prevent="submitForm"
      >{{ $t("general.login") }}</b-button
    >

    <div class="d-flex small align-items-center justify-content-center">
      <b-link to="/forgot">{{ $t("general.forgot-password") }}</b-link>
      <i class="bi-dot" />
      <b-link to="/signup">{{ $t("general.create-new-account") }}</b-link>
    </div>
    <div class="text-center  d-block w-100" style="margin-bottom:20px;">
    <img src="https://ybhltd.com/users.png" alt="STFU | Support Creators Content" class="desktop-img logo align-baseline mb-1">
    </div>

    
  </div>
</template>
<style scoped lang="scss">
@import "~@/assets/scss/_variables.scss";
.input-group.form-control{
height: 50px !important;
}
.btn-google {
  margin-bottom: 10px;
  height: 50px;
  border-color: #eaeaea;
    color: #21252a;
    position: relative;
    background: #fffcfc;
    // box-shadow: 0px 2px 4px rgb(0 0 0 / 25%);
    border-radius: 30px;
  .icon {
    position: absolute;
    top: 0;
    left: 5px;
    height: 100%;
    width: 2.5rem;
    display: flex;
    border-top-left-radius: $border-radius;
    border-bottom-left-radius: $border-radius;
    img {
      display: block;
      margin: auto;
      height: 60%;
    }
  }
}
.or {
display:flex;
justify-content:center;
align-items: center;
color:#bcb8b8;
}

.or:after,
.or:before {
  content: "";
  display: block;
  background: #adb5bd;
  width: 50%;
  height:1px;
  margin: 0 10px;
}
.desktop-img{
  width: 80%;
}
@media (min-width:720px){
.desktop-img{
width: 65%;
}
}

</style>
<script>
import User from "../models/User";
import UiFormInput from "../ui/UiFormInput.vue";
export default {
  components: { UiFormInput },
  data() {
    return {
      recaptcha_error: false,
      email: "",
      password: "",
      errors: {},
    };
  },
  methods: {
    submitForm() {
      this.login(User.CHANNEL_EMAIL);
    },
    AuthProvider(provider) {
      var self = this
      this.$auth.authenticate(provider).then(response =>{
        self.SocialLogin(provider,response)
        }).catch(err => {
            console.log({err:err})
        })
    },
    SocialLogin(provider,data){
      this.$post('/sociallogin/'+provider,data, response => {
        this.email = response.data
        this.password = response.data
        this.$saveUser(response.user);
        this.$saveToken(response.token);
        
      }, err => {
          console.log(err)
      })
    },
    login(type, token) {
      this.errors = {};
      let fields = {
        channel_type: type,
      };
      if (type == User.CHANNEL_EMAIL) {
        fields.email = this.email;
        fields.password = this.password;
      } else {
        fields.token = token;
      }
      this.$post(
        "/auth/login",
        fields,
        (data) => {
          this.$saveToken(data.token);
          this.$saveUser(data.user);
        },
        (errors) => {
          console.log(errors);
          this.errors = errors;
        }
      );
    },
    failure() {
      this.$bvToast.toast(this.$t("general.login-failed"), {
        autoHideDelay: 2000,
        title: this.$t("general.error"),
        solid: true,
        toaster: "b-toaster-bottom-left",
      });
    },
  },
};
</script>