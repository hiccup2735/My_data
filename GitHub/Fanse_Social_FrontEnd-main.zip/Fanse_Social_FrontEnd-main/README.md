# Fanse.io Front-end

![Screenshot_4](https://user-images.githubusercontent.com/101833474/194226682-9c710e9f-e2d9-410d-9e99-a23c0336b928.png)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
