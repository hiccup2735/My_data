# MEVN-site CRUD
Building a webiste based on the MongoDB, Express, Vue and NodeJS stack
