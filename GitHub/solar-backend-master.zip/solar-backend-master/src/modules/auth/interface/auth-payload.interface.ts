export interface AuthPayload {
  id: number | string;
  address: null | string;
}
