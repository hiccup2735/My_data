import ScrollTop from './ScrollTop'

export default ScrollTop