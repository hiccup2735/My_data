def get_filename(filename):
    return filename.upper()