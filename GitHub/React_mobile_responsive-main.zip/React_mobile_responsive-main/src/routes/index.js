import HomePage from "../components/homepage";

export const Routes = [
  {
    path: "/",
    element: <HomePage />,
  },
];
