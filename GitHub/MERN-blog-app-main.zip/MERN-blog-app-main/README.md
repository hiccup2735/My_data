# Blog REST API

## Installing required packages

```
npm install
```
### What is this project for?
* Learn and control HTTP methods with good way.
* Work both front-end project & back-end project
* Gain self-convidence


## Authors

* *Senior fullstack developer* - [climax1115](https://github.com/climax1115)

