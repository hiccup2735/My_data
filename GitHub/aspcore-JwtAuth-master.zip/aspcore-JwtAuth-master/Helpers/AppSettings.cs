﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Onesoftdev.AspCoreJwtAuth.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
