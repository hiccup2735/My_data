﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Text;

namespace Onesoftdev.AspCoreJwtAuth.Auth
{
    public class AuthToken
    {
        public string Token { get; set; }
    }
}
