<?php

class IntlException extends Exception
{
}
