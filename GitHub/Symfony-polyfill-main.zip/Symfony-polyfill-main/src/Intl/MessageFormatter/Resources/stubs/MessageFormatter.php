<?php

class MessageFormatter extends Symfony\Polyfill\Intl\MessageFormatter\MessageFormatter
{
}
