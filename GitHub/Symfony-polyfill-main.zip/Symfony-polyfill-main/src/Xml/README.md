Symfony Polyfill / XML
======================

This polyfill is deprecated.
Use the `symfony/polyfill-php72` package instead.
