from db.models.chat_room import ChatRoom
