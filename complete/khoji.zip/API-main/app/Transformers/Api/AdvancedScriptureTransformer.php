<?php

namespace App\Transformers\Api;

use App\Models\Scripture;
use App\Presenters\TransformerAbstract;
use App\Transformers\Api\TblAuthorTransformer;
use App\Transformers\Api\TblMelodyTransformer;

class AdvancedScriptureTransformer extends TransformerAbstract
{
    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $availableIncludes = [];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $defaultIncludes = ['author', 'melody'];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Scripture $resource)
    {
        
        $fields = [
            'id'                        => $resource->id,
            'scripture'                 => $resource->Scripture,
            'scripture_original'        => $resource->ScriptureOriginal,
            'info_id'                   => $resource->InfoID,
            'melody_id'                 => $resource->MelodyID,
            'author_id'                 => $resource->AuthorID,
            'page'                      => $resource->Page,
            'line'                      => $resource->Line,
            'section'                   => $resource->Section,
            'scripture_roman'           => $resource->ScriptureRoman,
            'scripture_roman_english'   => $resource->ScriptureRomanEnglish,
            'scripture_vowel'           => $resource->ScriptureVowel,
            'shabad_id'                 => $resource->ShabadID,
            'commentary'                 => $resource->commentary,
            'manmohan_singh_punjabi'    => '',
            'manmohan_singh_english'    => '',
            'sahib_singh_punjabi'       => '',
            'harbans_singh_punjabi'     => '',
            'sant_singh_khalsa_english' => '',
            'title'                     => '',
            'details'                   => '',
            'shabadtitle'               => '',
            'singer_name'               => '',
        ];

        if(isset($resource->ManmohanSinghPunjabi)) {
            $fields['manmohan_singh_punjabi'] = $resource->ManmohanSinghPunjabi;
        }
        if(isset($resource->ManmohanSinghEnglish)) {
            $fields['manmohan_singh_english'] = $resource->ManmohanSinghEnglish;
        }
        if(isset($resource->SahibSinghPunjabi)) {
            $fields['sahib_singh_punjabi'] = $resource->SahibSinghPunjabi;
        }
        if(isset($resource->HarbansSinghPunjabi)) {
            $fields['harbans_singh_punjabi'] = $resource->HarbansSinghPunjabi;
        }
        if(isset($resource->SantSinghKhalsaEnglish)) {
            $fields['sant_singh_khalsa_english'] = $resource->SantSinghKhalsaEnglish;
        }
        if(isset($resource->title)) {
            $fields['title'] = $resource->title;
        }
        if(isset($resource->details)) {
            $fields['details'] = $resource->details;
        }
        if(isset($resource->shabadtitle)) {
            $fields['shabadtitle'] = $resource->shabadtitle;
        }
        if(isset($resource->singer_name)) {
            $fields['singer_name'] = $resource->singer_name;
        }

        return $this->applySparseFieldsets($fields);
    }

    /**
     * Include Author
     *
     * @return League\Fractal\ItemResource
     */
    public function includeAuthor(Scripture $resource)
    {
        $item = $resource->author;
        if(!$item) {
            return null;
        }
        return $this->item($item, new TblAuthorTransformer, 'author');
    }

    /**
     * Include Melody
     *
     * @return League\Fractal\ItemResource
     */
    public function includeMelody(Scripture $resource)
    {
        $item = $resource->melody;
        if(!$item) {
            return null;
        }
        return $this->item($item, new TblMelodyTransformer, 'melody');
    }
}
