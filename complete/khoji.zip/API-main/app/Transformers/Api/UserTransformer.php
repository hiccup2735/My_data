<?php

namespace App\Transformers\Api;

use App\User;
use App\Presenters\TransformerAbstract;

class UserTransformer extends TransformerAbstract
{
    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $availableIncludes = [];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $defaultIncludes = [];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(User $resource)
    {
        $fields = [
            'id'                => $resource->id,
            'role_id'           => $resource->role_id,
            'name'              => $resource->name,
            'email'             => $resource->email,
            'email_verified_at' => $resource->email_verified_at,
            'is_active'         => $resource->is_active,
            'photo_url'         => $resource->photo_url,
            'city'              => $resource->city,
            'state'             => $resource->state,
            'country'           => $resource->country,
            'provider'          => $resource->provider,
            'google_id'         => $resource->google_id,
            'fb_id'             => $resource->fb_id,
            'last_login'        => $resource->last_login,
            'is_block'          => $resource->is_block,
            'auto_approve'      => $resource->auto_approve
        ];

        return $this->applySparseFieldsets($fields);
    }
}
