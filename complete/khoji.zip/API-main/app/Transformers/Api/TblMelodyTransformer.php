<?php

namespace App\Transformers\Api;

use App\Models\TblMelody;
use App\Presenters\TransformerAbstract;

class TblMelodyTransformer extends TransformerAbstract
{
    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $availableIncludes = [];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $defaultIncludes = [];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(TblMelody $resource)
    {
        $fields = [
            'id'                => $resource->getKey(),
            'melody'            => $resource->getMelody(),
            'melody_gurmukhi'   => $resource->getMelodyGurmukhi(),
            'description'       => $resource->getMelodyDescription()
        ];

        return $this->applySparseFieldsets($fields);
    }
}
