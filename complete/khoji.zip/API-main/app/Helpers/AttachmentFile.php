<?php 

namespace App\Helpers;

use Carbon\Carbon;
use Image;

class AttachmentFile
{

	protected $file;
	// protected $mimeType;
	protected $location;
	protected $filename;
	protected $is_move_file = false;

	public function __construct($file, $folder = null) {
		$this->file = $file;
		$this->location = $folder;
	}

	/**
	 *	upload file and set its parameters.
	 */
	public function upload()
	{
		$folderPath = $this->setTargetPath();
		// $this->mimeType = $this->file->getMimeType();
		$this->makeDir($folderPath);
		$attachment_name = $this->file->getClientOriginalName();
		$this->filename = $this->setFileName($attachment_name);
		$destinationPath = $folderPath . DIRECTORY_SEPARATOR;
		$this->file->move($destinationPath, $this->filename);
		
		return $this;
	}

	public function getName()
	{
		return $this->filename;
	}

	/*public function getMimeType()
	{
		return $this->mimeType;
	}*/

	public function isImage()
	{
		$imageExt = ['png', 'jpeg', 'jpg', 'gif'];
		if(in_array($this->file->getClientOriginalExtension(), $imageExt)) {
			return true;
		}
		return false;
	}

	/**
	 * gemerate image copy.
	 * 
	 * @param  $width: integer image width for cropping
	 * @param  $height: integer image height for cropping
	 * @param  $x: integer vertical prosition for cropping
	 * @param  $y: integer horizontal prosition for cropping
	 * @param  $location: string of location where need to copy image.
	 * @return object.
	 */
	public function generateCopy(int $width, int $height, int $x = 25, int $y = 25, $location)
	{
		$path = $this->setTargetPath() . DIRECTORY_SEPARATOR;
		$file = $path . $this->filename;

		$thumbnailPath = $path . $location;
		
		$this->makeDir($thumbnailPath);
		$imageObj = Image::make($file);
		$imageObj->fit($width, $height);
		$imageObj->save($thumbnailPath . DIRECTORY_SEPARATOR . $this->filename);
		
		return $this;
	}

	/**
	 * clean up destination folder.
	 * 
	 * @return boolean true.
	 */
	public function deleteAttachment($attachment_name = null, $path = null)
	{
		if(!$attachment_name) {
			return $this;
		}

		$test = false;
		if(!$path) {
			$path = $this->setTargetPath();
		} else {
			$test = true;
		}

		$files = glob($path.'/*');

		if(empty($files)) {
			return $this;
		}

		foreach ($files as $key => $file) {
			if(is_dir($file)) { 
				$this->deleteAttachment($attachment_name, $file);
			} else {

				$baseName = basename($file);
				if($attachment_name == $baseName) {
					unlink($file);
				}
			}
		}

		return $this;
	}

	/**
	 * 	delete attachment file.
	 * 	
	 *  @param  $attachment_name: optional attachment file name.
	 *  @return boolean wheather file deleted or not.
	 */
	/*public function deleteAttachment($attachment_name = null) {

		if(!$attachment_name) {
			$attachment_name = $this->node->image;
		}

		$folderPath = $this->setTargetPath();

		if(!$attachment_name) {
			return false;
		}

		$filePath = $folderPath . DIRECTORY_SEPARATOR . $attachment_name;
		if(!\File::delete($filePath)) {
			return false;
		}

		return true;
	}*/

	/**
	 *	change folder name where file will upload.
	 */
	public function changeLocation($location) {
		$this->location = $location;
	}


	/**
	 *	set file upload target path.
	 */
	protected function setTargetPath() {
		$uploads = config('global.uploads.path');
		$basePath = $uploads . DIRECTORY_SEPARATOR . $this->location;
		//$basePath = 'uploads' . DIRECTORY_SEPARATOR.'blogs';
		return public_path() . DIRECTORY_SEPARATOR . $basePath;
	}

	/**
	 *	set filename
	 */
	protected function setFileName($name) {
		$now = Carbon::parse(Carbon::now());
		$timestamp = $now->timestamp;

		$name = str_replace(' ', '_', $name);
		$name = preg_replace('/[^A-Za-z0-9\-.]/', '_', $name);
		$filename = $timestamp . '_' . $name;
		return $filename;
	}

	/**
	 *	check is directory exists if not then create new directory.
	 */
	protected function makeDir($path) {
		if(!file_exists($path)){
			return \File::makeDirectory($path, 0755);
		}

		return true;
	}
}