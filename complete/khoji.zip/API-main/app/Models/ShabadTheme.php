<?php

namespace App\Models;

use App\Models\AppModel;

class ShabadTheme extends AppModel
{
    protected $table = 'shabad_theme';
}
