<?php

namespace App\Models;

use App\Models\AppModel;

class QnaAnswer extends AppModel
{
    protected $table = 'qna_answers';

    public $timestamps = false;
}
