<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Katha extends Model
{
    /**
	 * The table associated with the model
	 */
    protected $table = "katha";

    /**
     * Get the singer record associated with audio
     */
    public function singer()
    {
    	return $this->hasOne(Singer::class, 'singer_id', 'singer_id');
    }
}
