<?php

namespace App\Models;

use App\Models\AppModel;

class MediaTracking extends AppModel
{
    protected $table = 'media_trackings';

    protected $fillable = [
    	'media_id', 'user_id', 'last_accessed'
    ];

    /**
     * @param mixed $media_id
     *
     * @return self
     */
    public function setMediaId($media_id)
    {
        $this->media_id = $media_id;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getMediaId()
    {
        return $this->media_id;
    }

    /**
     * @param mixed $user_id
     *
     * @return self
     */
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * @param mixed $last_accessed
     *
     * @return self
     */
    public function setLastAccessed($last_accessed)
    {
        $this->last_accessed = $last_accessed;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getLastAccessed()
    {
        return $this->last_accessed;
    }
}
