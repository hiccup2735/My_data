<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Video extends Model
{
    /**
	 * The table associated with the model
	 */
    protected $table = "video";

    public $timestamps = false;

    /**
     * Get the singer record associated with audio
     */
    public function user()
    {
        return $this->hasOne(User::class, 'id', 'user_id_fk');
    }
}
