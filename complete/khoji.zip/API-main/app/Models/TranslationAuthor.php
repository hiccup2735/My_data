<?php

namespace App\Models;

use App\Models\AppModel;

class TranslationAuthor extends AppModel
{
    protected $table = 'translation_author';

    /**
     * @param mixed $ReferredColumn
     *
     * @return self
     */
    public function setReferredColumn($ReferredColumn)
    {
        $this->ReferredColumn = $ReferredColumn;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getReferredColumn()
    {
        return $this->ReferredColumn;
    }
}
