<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Authors extends Model
{
    /**
	 * The table associated with the model
	 */
    protected $table = "translation_author";

     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'Author', 'Language', 'Active', 'Default', 'ReferredColumn'
    ];

    public $timestamps = false;
    
    /**
     * @param mixed $Author
     *
     * @return self
     */
    public function setAuthor($Author)
    {
        $this->Author = $Author;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getAuthor()
    {
        return $this->Author;
    }

    /**
     * @param mixed $Language
     *
     * @return self
     */
    public function setLanguage($Language)
    {
        $this->Language = $Language;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getLanguage()
    {
        return $this->Language;
    }

    /**
     * @param mixed $Active
     *
     * @return self
     */
    public function setActive($Active)
    {
        $this->Active = $Active;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getActive()
    {
        return $this->Active;
    }

    /**
     * @param mixed $Default
     *
     * @return self
     */
    public function setDefault($Default)
    {
        $this->Default = $Default;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getDefault()
    {
        return $this->Default;
    }

    /**
     * @param mixed $ReferredColumn
     *
     * @return self
     */
    public function setReferredColumn($ReferredColumn)
    {
        $this->ReferredColumn = $ReferredColumn;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getReferredColumn()
    {
        return $this->ReferredColumn;
    }
}
