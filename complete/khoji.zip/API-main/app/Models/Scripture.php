<?php

namespace App\Models;

use App\Models\ShabadTheme;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Scripture extends Model
{
	/**
	 * The table associated with the model
	 */
    protected $table = "tblscripture";

    protected $fillable = [
        'Scripture', 'ScriptureOriginal', 'InfoID', 'MelodyID', 
        'AuthorID', 'Page', 'Line', 'Section', 'ScriptureRoman', 
        'ScriptureRomanEnglish', 'ScriptureVowel', 'ShabadID'
    ];

    /**
     * Get the translation record associated with scripture
     */
    public function translation()
    {
    	return $this->hasOne(Translation::class, 'ScriptureID');
    }

    /**
     * Get the author
     */
    public function author()
    {
        return $this->belongsTo(TblAuthor::class, 'AuthorID', 'id');
    }

    /**
     * Get the melody
     */
    public function melody()
    {
        return $this->belongsTo(TblMelody::class, 'MelodyID', 'id');
    }

    /**
     * add filtering.
     *
     * @param  $builder: query builder.
     * @param  $filters: array of filters.
     * @return query builder.
     */
    public function scopeFilter($builder, $filters = [])
    {
        if(!$filters) {
            return $builder;
        }
        $tableName = $this->getTable();

        $author = $filters['author'] ?? null;
        $raag = $filters['raag'] ?? null;
        $pageF = $filters['pageF'] ?? null;
        $pageT = $filters['pageT'] ?? null;
        $theme = $filters['theme'] ?? null;

        if($author) {
            $builder->where('AuthorID', $author);
        }
        if($raag) {
            $builder->where('MelodyID', $raag);
        }
        if($pageF) {
            $builder->where('Page', '>=', $pageF);
        }
        if($pageT) {
            $builder->where('Page', '<=', $pageT);
        }

        if($theme) {
            $shabadIds = ShabadTheme::where('theme_id', $theme)->pluck('shabad_id')->all();
            $builder->whereIn("$tableName.id", $shabadIds);
        }

        return $builder;
    }
}
