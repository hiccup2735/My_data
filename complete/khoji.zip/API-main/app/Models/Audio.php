<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Audio extends Model
{
    /**
	 * The table associated with the model
	 */
    protected $table = "audio";

    /**
     * Get the singer record associated with audio
     */
    public function singer()
    {
    	return $this->hasOne(Singer::class, 'singer_id', 'singer_id');
    }

    /**
     * Get the singer record associated with audio
     */
    public function user()
    {
        return $this->hasOne(User::class, 'id', 'user_id_fk');
    }
}
