<?php

namespace App\Models;

use App\Models\AppModel;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Kyslik\ColumnSortable\Sortable;
use Laracasts\Presenter\PresentableTrait;

class MediaAuthor extends AppModel
{
	use HasSlug, Sortable, PresentableTrait;

    protected $presenter = '\App\Presenters\MediaAuthorPresenter';

    protected $table = "media_authors";

    protected $fillable = ['slug','image', 'name', 'status', 'featured', 'featured_display_order'];

    /**
     * set string fields for filtering 
     * @var array
     */
    protected $likeFilterFields = ['name'];

    /**
     * set boolean fields for filtering 
     * @var array
     */
    protected $boolFilterFields = ['status', 'featured'];

    public $sortable = ['id', 'name', 'status', 'featured', 'featured_display_order'];

    /**
     * Get the options for generating the slug.
     */
    public function getSlugOptions() : SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('name')
            ->saveSlugsTo('slug');
    }

    /**
     * @return mixed
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * @param mixed $name
     *
     * @return self
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }
    
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param mixed $status
     *
     * @return self
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $featured
     *
     * @return self
     */
    public function setFeatured($featured)
    {
        $this->featured = $featured;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getFeatured()
    {
        return $this->featured;
    }

    /**
     * @param mixed $featured_display_order
     *
     * @return self
     */
    public function setFeaturedDisplayOrder($featured_display_order)
    {
        $this->featured_display_order = $featured_display_order;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getFeaturedDisplayOrder()
    {
        return $this->featured_display_order;
    }
}
