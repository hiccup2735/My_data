<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    /**
	 * The table associated with the model
	 */
    protected $table = "permissions";

    public function roles() {
	   return $this->belongsToMany(Role::class, 'role_permissions', 'permission_id', 'role_id');
	}
}
