<?php

namespace App\Models;

use App\Models\AppModel;

class QnaComment extends AppModel
{
    protected $table = 'qna_comments';

    public $timestamps = false;
}
