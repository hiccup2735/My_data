<?php

namespace App\Presenters;

use Laracasts\Presenter\Presenter;

class MediaAuthorPresenter extends Presenter
{

    public function name()
    {
    	return $this->entity->getName();
    }

    /**
     * get link for change status.
     * 
     * @return html for status link
     */
    public function statusLink()
    {
    	$status = $this->entity->getStatus();
        $iconClass = "fa-times";
        if($status) {
   		   $iconClass = "fa-check";
    	}
    	$route = route('admin.media.authors.toggle-status', $this->entity->getKey());
    	$link = "<a href='$route'><i class='fa $iconClass'></i></a>";
    	return $link;
    }

    /**
     * get link to delete service.
     * 
     * @return html for delete link
     */
    public function deleteLink()
    {
    	$route = route('admin.media.authors.delete', $this->entity->getKey());
    	$html = "<a href='#' class='delete-link btn btn-danger'><i class='fa fa-trash'></i></a>";
    	$html .= "<form action='$route' method='post' class='delete-form' data-confirm='Do you really want to delete this Author?'>";
    		$html .= "<input type='hidden' name='_method' value='DELETE'>";
    		$html .= "<input type='hidden' name='_token' value='".csrf_token()."'>";
    	$html .= "</form>";
    	return $html;
    }

    /**
     * get link to delete service.
     * 
     * @return html for delete link
     */
    public function editLink()
    {
    	$route = route('admin.media.authors.index', $this->entity->getKey());
    	$html = "<a href='$route' class='btn btn-primary fa fa-edit'></a>";
    	return $html;
    }
}
