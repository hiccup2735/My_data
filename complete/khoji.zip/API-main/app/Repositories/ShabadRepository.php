<?php

namespace App\Repositories;

use App\Models\Shabad;
use App\Models\Scripture;

class ShabadRepository extends Repository
{

	private $blogRepo;

	function __construct(BlogRepository $blogRepo)
	{
		$this->blogRepo = $blogRepo;
	}
	/**
	 * Get shabad data
	 */
	public function getShabad($id)
	{
		$shabad = Shabad::with(['scriptures' => function($q) {
							$q->select('id', 'ShabadID', 'Scripture', 'ScriptureOriginal', 'ScriptureRoman');
						}, 'scriptures.translation',
							'blog' => function($q) {
								$q->where('is_approved', 1);
							},
							'video' => function($q) {
								// $q->where('approved', 1);
							},
							'santhya',
							'audio' => function($q) {
								$q->where('approved', 1);
							}, 'audio.singer',
							'katha', 'katha.singer' ])
						->where('id', $id)
						->first();

		$shabad->blog->map(function ($blog) {
		    $blog['news_short_text'] = $this->blogRepo->getBlogShortText($blog->news_text);
	    	$blog['news_date_formated']	= date('F j, Y', $blog->news_date);

		    return $blog;
		});

		$shabad->video->map(function ($video) {
			$video['youtube_video_url'] = $video->video_code;

			$video_id = explode("v=", $video->video_code);
			if (count($video_id) > 1) {
				$video_id = $video_id[1];
			    $video['youtube_video_url'] = "https://www.youtube.com/embed/" . $video_id;
			}

		    return $video;
		});


		return $shabad;
	}

	/**
	 * Get shabad page ID
	 *
	 * @param  int  $shabadId
	 * @return int  page number
	 */
	public static function getShabadPage($shabadId)
	{
		$scripture = Scripture::where('ShabadID', $shabadId)->first();

		if($scripture) {
			return $scripture->Page;
		}
		return $scripture;
	}
}