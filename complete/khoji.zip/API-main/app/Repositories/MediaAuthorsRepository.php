<?php

namespace App\Repositories;

use App\Models\MediaAuthor;
use Illuminate\Http\Request;

class MediaAuthorsRepository extends Repository
{
	protected $model;


	public function __construct(MediaAuthor $model)
	{
		$this->model = $model;
	}

	public function storeAuthor($name)
	{
		$item = $this->model->where('name', $name)->first();
		if($item) {
			return $item;
		}

		$item = new MediaAuthor;
		$item->fill(['name' => $name, 'status' => true]);
		$item->save();
		return $item;
	}

	/**
	 * get list of comments.
	 *
	 * @param  $request: Illuminate\Http\Request
	 * @return collection of App\Models\Comment
	 */
	public function getFeaturedItems(Request $request)
	{
		$builder = $this->model;
		$builder = $builder->filter($request->all());
		
		$builder = $builder->where('featured', true)
                        ->whereNotNull('featured_display_order')
						->orderBy('featured_display_order', 'ASC');
						
		return $builder->get();
	}
	/**
	 * set payload of data.
	 *
	 * @param  $item: App\Models\Comment
	 * @return array of data.
	 */
	public function setDataPayload($item)
	{
		return [
			'name' 			=> $item->getName(),
			'status' 		=> $item->getStatus()
		];
	}
}

