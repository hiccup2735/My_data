<?php

namespace App\Repositories;

use App\Models\Blog;
use App\Repositories\ShabadRepository;
use Exception, Auth;

class BlogRepository extends Repository
{

	public function getBlog($id)
	{
		/*$blog = Blog::with(['comments',
							'comments.user' => function($q) {
								$q->select('id', 'name', 'role_id');
							}])
					->where('news_id', $id)
	    			->first();*/
		
		$q = Blog::with(['comments',
							'comments.user' => function($q) {
								$q->select('id', 'name', 'role_id', 'photo_url');
							}]);
							
		if(is_numeric($id)) 
		{
			$blog = $q->where('news_id', $id)->first();
		}
		else
		{
			//$blog = $q->where('news_title','like','%'.urldecode($id).'%')->orWhere('news_text','like','%'.urldecode($id).'%')->first();
			//echo urldecode($id);exit;
			$blog = $q->where('news_title',urldecode($id))->first();
		}
		
		
		
	   	if ($blog->news_shabad) {
	    	$blog['shabad_page'] = ShabadRepository::getShabadPage($blog->news_shabad);
	   	}

	    if (!$blog) {
    		throw new Exception("Blog not found", 404);
    	}

	    $this->blogsFieldsSetting($blog);

	   	return $blog;
	}
	
	public function getBlogs($request)
	{
		$blogLimit = 5;
    	if ($request->has('limit')) {
    		$blogLimit = $request->get('limit');
    	}
    	

    	$builder = Blog::with(['comments',
    						 'comments.user' => function($q) {
								$q->select('id', 'name');
							 }]);

    	if ($request->has('is_approved')) {
    		$builder = $builder->where('is_approved', $request->get('is_approved'));
    	}

    	$builder = $builder->orderBy('news_id', 'desc');

    	if ($request->has('paginate') && $request->get('paginate')) {
			$blogs = $builder->paginate($blogLimit);
		} else {
			$blogs = $builder->get();
		}

    	$blogs->map(function ($blog) {
    		$this->blogsFieldsSetting($blog);

		    return $blog;
		});

    	return $blogs;
	}

	public function getBlogSearch($request){
		$blogLimit = 5;
    	if ($request->has('limit')) {
    		$blogLimit = $request->get('limit');
    	}
    	
		$keyword = $request->search_keyword;

    	$builder = Blog::with(['comments',
    						 'comments.user' => function($q) {
								$q->select('id', 'name');
							 }])
							 ->where('news_title','like','%'.$keyword.'%')
							 ->orWhere('news_text','like','%'.$keyword.'%')
							 ->where('is_approved','=','1');
    	if ($request->has('is_approved')) {
    		$builder = $builder->where('is_approved', $request->get('is_approved'));
    	}

    	$builder = $builder->orderBy('news_id', 'desc');

    	if ($request->has('paginate') && $request->get('paginate')) {
			$blogs = $builder->paginate($blogLimit);
		} else {
			$blogs = $builder->get();
		}

    	$blogs->map(function ($blog) {
    		$this->blogsFieldsSetting($blog);

		    return $blog;
		});

    	return $blogs;
	}
	private function blogsFieldsSetting($blog)
	{
		$blog['news_short_text'] = $this->getBlogShortText($blog->news_text);
	    // $blog['news_short_text'] = mb_convert_encoding($blog['news_short_text'], 'UTF-8', 'UTF-8');
    	$blog['news_date_formated']	= date('F j, Y', $blog->news_date);

    	if ($blog->comments && count($blog->comments) > 0) {
    		$blog->comments->map(function($comment) {
    			$comment['comment_formated_date']	= date('F j, Y', $comment->comment_date);
    		});
    	}
	}

	public function getBlogShortText($string, $limit=200)
	{
		$string = strip_tags($string);

		if (strlen($string) > $limit) {
			$string = mb_substr($string, 0, $limit, "UTF-8") . '...';
		}

		return strip_tags($string);
	}

	public function storeBlog($request)
	{
		$imageName = null;
		if ($request->has('image') && $request->get('image')) {
			$imageName = $request->get('image');
		}

		$user = Auth::user();
		$isApproved = 0;
		if ($user && $user->auto_approve) {
			$isApproved = 1;
		}

		$blog = new Blog();

		$blog->news_title 	= $request->input('title');
		$blog->news_author 	= $request->input('author');
		$blog->news_text 	= $request->input('content');
		$blog->news_shabad 	= $request->input('news_shabad');
		$blog->news_date 	= strtotime(now());
		$blog->image 		= $imageName;
		$blog->is_approved 	= $isApproved;

		if (!$blog->save()) {
			throw new Exception("Blog not successfully saved", 422);
		}

		return $blog;
	}

	public function updateBlog($id, $request)
	{
		$blog = Blog::findOrFail($id);

		$isApproved = 0;
		if ($request->has('is_approved')) {
			$isApproved = $request->input('is_approved');
		}
		$imageName = null;
		if ($request->has('image') && $request->get('image')) {
			$imageName = $request->get('image');
		}
		
		$blog->news_title 	= $request->input('title');
		$blog->news_author 	= $request->input('author');
		$blog->news_text 	= $request->input('content');
		$blog->news_shabad 	= $request->input('news_shabad');
		if($imageName) $blog->image 		= $imageName;

		if (!$blog->save()) {
    		throw new Exception("Blog not successfully updated", 422);
    	}

    	$this->blogsFieldsSetting($blog);

    	return $blog;
	}
	public function deleteBlog($id){
		$status = Blog::where('news_id',$id)->delete();
		if($status){
			return true;
		}else{
			return false;
		}

	}

}