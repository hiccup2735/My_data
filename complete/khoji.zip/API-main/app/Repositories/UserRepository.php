<?php

namespace App\Repositories;

use App\User;

class UserRepository extends Repository
{

	protected $model;

	public function __construct(User $model)
	{
		$this->model = $model;
	}

	/**
	 * Get all users list
	 *
	 * @return collection
	 */
	public function getUsers()
	{
		return User::get();
	}

	/**
	 * Create user and save in database
	 *
	 * @param  User  user model
	 * @return Model item
	 */
	public function createUser(User $user)
	{
		$data = $this->setPayload($user);

		$model = $this->model;
		$model->fill($data);
		$model->save();

		return $model;
	}

	/**
	 * set data in user model getters
	 *
	 * @param User  user model ref
	 */
	private function setPayload(User $user)
	{
		$data = [
			'role_id' 	=> $user->getRole(),
			'name' 		=> $user->getName(),
			'email' 	=> $user->getEmail(),
			'password' 	=> bcrypt($user->getPassword()),
			'state' 	=> $user->getState(),
			'city' 		=> $user->getCity(),
			'country' 	=> $user->getCountry(),
			'verification_code' => $user->getVerificationCode()
		];

		return $data;
	}

	/**
	 * Check is user varified
	 *
	 * @param  User model item
	 * @return boolean
	 */
	public function isUserVarified($user)
	{
		return ($user->is_active && $user->email_verified_at);
	}

	/**
	 * Update user detail
	 *
	 * @param  Int user id
	 * @param  Request $request
	 * @return Item
	 */
	public function updateUser($id, $request)
	{
		$user = User::findOrFail($id);

    	$user->role_id 	= $request->input('role_id');
    	$user->name 	= $request->input('name');
    	// $user->email 	= $request->input('email');
    	$user->city 	= $request->input('city');
    	$user->state 	= $request->input('state');
    	$user->country 	= $request->input('country');
    	$user->is_active = ($request->has('is_active')) ? $request->input('is_active') : 0;
    	$user->is_block = ($request->has('is_block')) ? $request->input('is_block') : 0;
    	// $user->auto_approve = ($request->has('auto_approve')) ? $request->input('auto_approve') : 0;
    // 	$user->auto_approve = ($request->input('role_id') == 3 || $request->input('role_id') == 4) ? 1 : (($request->input('role_id') == 2) ? 0 : (($request->has('auto_approve')) ? $request->input('auto_approve') : 0));
    	$user->auto_approve = ($request->input('role_id') == 3 || $request->input('role_id') == 4) ? 1 : (($request->input('role_id') == 2) ? $request->input('auto_approve') : 0);
    	if (!$user->save()) {
    		throw new Exception("User not successfully updated", 422);
    	}

    	return $user;
	}

	/**
	 * set static user roles
	 *
	 * @param array
	 */
	public function setUserRoles($user)
    {
        /*$roles = ['user', 'add_comment', 'edit_own_comment', 'add_video', 'add_audio', 'add_video'];

        if ($user->role_id == 4 || $user->role_id == 3) {
            $adminRoles = [
                'user_ad',
                'blog_comments',
                'approve_comment',
                'authors',
                'resources',
                'edit_post',
                'approve_post'
            ];
            $roles = array_merge($roles, $adminRoles);
        }
        if ($user->role_id == 4) {
            $adminRoles = ['users', 'edit_user', 'permissions'];
            $roles = array_merge($roles, $adminRoles);
        }*/

        $roles = ["empty"];

        $permissions = $user->role->permissions();

        if (!$user['is_block']) {
            $roles = $permissions->pluck('slug')->all();
        }

        return $roles;
    }
}