<?php

namespace App\Repositories;

use App\Models\Category;
use App\Models\Media;
use App\Models\Scripture;
use App\Models\Tag;
use App\Repositories\Repository;
use Illuminate\Http\Request;

class MediaRepository extends Repository
{
	protected $model;
    protected $category;
    protected $tag;

	public function __construct(Media $model, 
                            Category $category, 
                            Tag $tag)
	{
		$this->model = $model;
        $this->category = $category;
        $this->tag = $tag;
	}

    /**
     * get list of media.
     *
     * @param  $request: Illuminate\Http\Request
     * @return collection of App\Models\Media
     */
    public function paginate(Request $request)
    {
        $scriptureTableName = (new Scripture)->getTable();
        $mediaTableName = (new Media)->getTable();
        $builder = $this->model;
        $builder = $builder->filter($request->all());
        $builder = $builder->leftJoin("$scriptureTableName as scrip", function($join) use($mediaTableName) {
            $join->on('scrip.ShabadID', '=', "$mediaTableName.shabad_id");
        });

        $builder = $builder->selectRaw("$mediaTableName.*, scrip.Page as page_number")
                        ->groupBy("$mediaTableName.id")
                        ->sortable();

        $includes = request()->input('includes', []);
        if($includes) {
            $builder = $builder->with(explode(',', $includes));
        }
        return $builder->paginate($request->input('limit', 10));
    }

    /**
     * get featured items
     *
     * @param  $request: Illuminate\Http\Request
     * @return collection of App\Models\Media
     */
    public function paginateFeatured(Request $request)
    {
        $scriptureTableName = (new Scripture)->getTable();
        $mediaTableName = (new Media)->getTable();
        $builder = $this->model;
        $builder = $builder->filter($request->all());
        $builder = $builder->leftJoin("$scriptureTableName as scrip", function($join) use($mediaTableName) {
            $join->on('scrip.ShabadID', '=', "$mediaTableName.shabad_id");
        });

        $builder = $builder->where('featured', true)
                        ->whereNotNull('featured_display_order');
        $builder = $builder->selectRaw("$mediaTableName.*, scrip.Page as page_number")
                        ->groupBy("$mediaTableName.id")
                        ->orderBy('featured_display_order', 'ASC');
        
        $includes = request()->input('includes', []);
        if($includes) {
            $builder = $builder->with(explode(',', $includes));
        }
        
        return $builder->paginate($request->input('limit', 10));
    }

    /**
     * assign categories to media.
     * 
     * @param  $item: App\Models\Media
     * @param  $categoryIds: array of category ids.
     * @return App\Models\Media
     */
    public function assignCategories($item, $categoryIds = [])
    {
        $media = Media::findOrFail($item->getKey());

        $cate = $this->category->whereIn('id', $categoryIds)->get();

        $media->categories()->saveMany($cate);
        return $media;
    }

    /**
     * assign tags to media.
     * 
     * @param  $item: App\Models\Media
     * @param  $tagIds: array of tag ids.
     * @return App\Models\Media
     */
    public function assignTags($item, $tagIds = [])
    {
        $media = Media::findOrFail($item->getKey());

        $tags = $this->tag->whereIn('id', $tagIds)->get();

        $media->tags()->saveMany($tags);
        return $media;
    }

    /**
     * toggle media status.
     * 
     * @param  $id: integer of media id.
     * @return App\Models\Media
     */
    public function toggleStatus($id)
    {
        $media = Media::findOrFail($id);
        $media->status = !$media->status;
        $media->save();
        return $media;
    }

	/**
     * set payload of data.
     *
     * @param  $item: App\Models\Comment
     * @return array of data.
     */
    public function setDataPayload($item)
    {

        return [
            'author_id'             => $item->getAuthorId(),
            'shabad_id'             => $item->getShabadId(),
            'ref_type'              => $item->getRefType(),
            'title'                 => $item->getTitle(),
            'description'           => $item->getDescription(),
            'attachment_name'       => $item->getAttachmentName(),
            'attachment_mime_type'  => $item->getAttachmentMimeType(),
            'type'                  => $item->getType(),
            'status'                => $item->getStatus(),
            'created_by'            => $item->getCreatedBy(),
            'updated_by'            => $item->getUpdatedBy(),
        ];
    }
}

