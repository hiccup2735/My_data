<?php

namespace App\Repositories;

use App\Models\TblAuthor;
use Illuminate\Http\Request;

class TblAuthorsRepository extends Repository
{
	protected $model;


	public function __construct(TblAuthor $model)
	{
		$this->model = $model;
	}

	/**
	 * get list of tbl Authors.
	 *
	 * @param  $request: Illuminate\Http\Request
	 * @return collection of App\Models\TblAuthor
	 */
	public function paginate(Request $request)
	{
		$builder = $this->model;

		if($request->filled('author')) {
			$builder = $builder->where('Author', 'LIKE', '%'. $request->input('author') .'%');
		}

		if($request->filled('author_gurmukhi')) {
			$builder = $builder->where('AuthorGurmukhi', 'LIKE', '%'. $request->input('author_gurmukhi') .'%');
		}

		$builder = $builder->sortable();
		if($request->filled('paginate')) {

			return $builder->paginate($request->input('limit', 10));
		}
		return $builder->get();
	}

	/**
	 * set payload of data.
	 *
	 * @param  $item: App\Models\Comment
	 * @return array of data.
	 */
	public function setDataPayload($item)
	{

		return [
			'Author' 			=> $item->getAuthor(),
			'AuthorGurmukhi' 	=> $item->getAuthorGurmukhi(),
			'AuthorDescription' => $item->getAuthorDescription()
		];
	}
}

