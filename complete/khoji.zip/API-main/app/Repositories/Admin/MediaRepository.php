<?php

namespace App\Repositories\Admin;

use App\Helpers\AttachmentFile;
use App\Models\Category;
use App\Models\Media;
use App\Models\Scripture;
use App\Models\Tag;
use App\Repositories\Admin\AdminRepository;
use Illuminate\Http\Request;

class MediaRepository extends AdminRepository {

    protected $model;
    protected $category;
    protected $tag;

    public function __construct(Media $model, Category $category, Tag $tag) {
        $this->model = $model;
        $this->category = $category;
        $this->tag = $tag;
    }

    /**
     * get list of media.
     *
     * @param  $request: Illuminate\Http\Request
     * @return collection of App\Models\Media
     */
    public function paginate(Request $request) {
        $scriptureTableName = (new Scripture)->getTable();
        $mediaTableName = (new Media)->getTable();
        $builder = $this->model;
        $builder = $builder->filter($request->all())
                ->with([
            'author' => function($q) {
                return $q->select('id', 'name');
            },
            'created_by_user' => function($q) {
                return $q->select('id', 'name');
            },
            'categories', 'tags'
        ]);
        $builder = $builder->leftJoin("$scriptureTableName as scrip", function($join) use($mediaTableName) {
            $join->on('scrip.ShabadID', '=', "$mediaTableName.shabad_id");
        });

        $builder = $builder->selectRaw("$mediaTableName.*, scrip.Page as page_number")
                ->groupBy("$mediaTableName.id")
                 
                ->sortable();

        $includes = request()->input('includes', []);
        if ($includes) {
            $builder = $builder->with(explode(',', $includes));
        }

        return $builder->paginate($request->input('limit', 10));
    }

    /**
     * get list of media items.
     * 
     * @return array of media list.
     */
    public function getMediaPaginateList($request) {
        $builder = $this->model->where('status', true)
                 ->orderBy('featured_display_order', 'asc')
                ->selectRaw("id, title as text");

        return $builder->paginate($request->input('limit', 10));
    }

    public function uploadFile($file, $oldAttachmentName = null) {
        if (!$file) {
            return null;
        }
        $mediaDir = config('global.uploads.media.main_dir');
        $attachment = new AttachmentFile($file, $mediaDir);
        $attachment->upload();

        if ($attachment->isImage()) {
            $thumbWidth = config('global.uploads.media_sizes.thumbnail.width');
            $thumbHeight = config('global.uploads.media_sizes.thumbnail.height');
            $thumbLocation = config('global.uploads.media.thumb_dir');

            $mediumWidth = config('global.uploads.media_sizes.medium.width');
            $mediumHeight = config('global.uploads.media_sizes.medium.height');
            $mediumLocation = config('global.uploads.media.medium_dir');

            $largeWidth = config('global.uploads.media_sizes.large.width');
            $largeHeight = config('global.uploads.media_sizes.large.height');
            $largeLocation = config('global.uploads.media.large_dir');

            $attachment->generateCopy($thumbWidth, $thumbHeight, 25, 25, $thumbLocation)
                    ->generateCopy($mediumWidth, $mediumHeight, 25, 25, $mediumLocation)
                    ->generateCopy($largeWidth, $largeHeight, 25, 25, $largeLocation);
        }

        if ($oldAttachmentName) {
            $attachment->deleteAttachment($oldAttachmentName);
        }

        return $attachment->getName();
    }

    public function deleteAttachment($attachmentName = null) {
        if (!$attachmentName) {
            return true;
        }
        $mediaDir = config('global.uploads.media.main_dir');
        $attachment = new AttachmentFile($attachmentName, $mediaDir);
        $attachment->deleteAttachment($attachmentName);
        return true;
    }

    /**
     * assign categories to media.
     * 
     * @param  $item: App\Models\Media
     * @param  $categoryIds: array of category ids.
     * @return App\Models\Media
     */
    public function assignCategories($item, $categoryIds = []) {
        $media = Media::findOrFail($item->getKey());

        // $cate = $this->category->whereIn('id', $categoryIds)->p();

        if (!$categoryIds) {
            $categoryIds = $media->categories()->pluck('id');
        }

        $media->categories()->sync($categoryIds);
        return $media;
    }

    /**
     * assign tags to media.
     * 
     * @param  $item: App\Models\Media
     * @param  $tagIds: array of tag ids.
     * @return App\Models\Media
     */
    public function assignTags($item, $tagIds = []) {
        $media = Media::findOrFail($item->getKey());

        // $tags = $this->tag->whereIn('id', $tagIds)->get();
        if (!$tagIds) {
            $tagIds = $media->tags()->pluck('id');
        }

        $media->tags()->sync($tagIds);
        return $media;
    }

    public function detachCategories($mediaId, $categoryIds = []) {
        if (!$categoryIds) {
            return true;
        }

        $media = Media::findOrFail($mediaId);

        $media->categories()->detach($categoryIds);
        return $media;
    }

    public function detachTags($mediaId, $tagIds = []) {
        if (!$tagIds) {
            return true;
        }

        $media = Media::findOrFail($mediaId);

        $media->tags()->detach($tagIds);
        return $media;
    }

    /**
     * toggle media status.
     * 
     * @param  $id: integer of media id.
     * @return App\Models\Media
     */
    public function toggleStatus($id) {
        $media = Media::findOrFail($id);
        $media->status = !$media->status;
        $media->save();
        return $media;
    }

    /**
     * set payload of data.
     *
     * @param  $item: App\Models\Comment
     * @return array of data.
     */
    public function setDataPayload($item) {
        $attachmentName = $item->getAttachmentName();
        $attachmentType = $item->getAttachmentMimeType();
        if ($item->getType() == Media::VIMEO_TYPE && $item->getVimeoUrl()) {
            $attachmentName = $item->getVimeoUrl();
            $attachmentType = null;
        } else if ($item->getType() == Media::YOUTUBE_TYPE && $item->getYoutubeUrl()) {
            $attachmentName = $item->getYoutubeUrl();
            $attachmentType = null;
        }

        return [
            'author_id' => $item->getAuthorId(),
            'shabad_id' => $item->getShabadId(),
            'ref_type' => $item->getRefType(),
            'title' => $item->getTitle(),
            'description' => $item->getDescription(),
            'attachment_name' => $attachmentName,
            'attachment_mime_type' => $attachmentType,
            'thumbnail' => $item->getThumbnail(),
            'type' => $item->getType(),
            'status' => (bool) $item->getStatus(),
            'created_by' => $item->getCreatedBy(),
            'updated_by' => $item->getUpdatedBy(),
        ];
    }

    /**
     * mark media as featured.
     * 
     * @param  $mediaIds: array of media ids.
     * @return boolean true.
     */
    public function markAsFeatured($mediaIds = []) {
        $builder = Media::where('featured', 1);
        $builder->update(['featured' => false, 'featured_display_order' => null]);

        foreach ($mediaIds as $key => $id) {
            $item = Media::findOrFail($id);
            $item->featured = true;
            $item->featured_display_order = $key + 1;
            $item->save();
        }

        return true;
    }

    public function getFeaturedMediaList() {
        $builder = $this->model->where('featured', true)->orderBy('featured_display_order', 'asc');
        return $builder->pluck('title', 'id')->all();
    }

}
