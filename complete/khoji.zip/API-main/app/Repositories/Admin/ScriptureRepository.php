<?php

namespace App\Repositories\Admin;

use App\Models\Scripture;
use Illuminate\Http\Request;

class ScriptureRepository extends AdminRepository
{
	protected $model;
	
	public function __construct(Scripture $model)
	{
		$this->model = $model;
	}

	public function getShabadList(Request $request)
	{
		$builder = $this->model;
		if($request->filled('search')) {
			$term = $request->input('search');
			$builder = $builder->where(function($q) use($term) {
				$q->where('ShabadID', $term)
					->orWhere('Scripture', 'LIKE', "%$term%")
					->orWhere('ScriptureOriginal', 'LIKE', "%$term%")
					->orWhere('ScriptureRoman', 'LIKE', "%$term%")
					->orWhere('ScriptureRomanEnglish', 'LIKE', "%$term%")
					->orWhere('ScriptureVowel', 'LIKE', "%$term%");
			});
		}
//		$builder = $builder->selectRaw("CONCAT(ShabadID, ' - ', GROUP_CONCAT(Scripture SEPARATOR ' ')) as text, ShabadID as id")
                $builder = $builder->selectRaw("ShabadID as text, ShabadID as id")
						->groupBy('ShabadID')
						->orderBy('ShabadID', 'ASC');

		return $builder->paginate($request->input('limit', 10));
	}

	public function getShabadNameById($shabadId = null)
	{
		if(!$shabadId) {
			return null;
		}

		$builder = $this->model->where('ShabadID', $shabadId);
		$builder = $builder->selectRaw("CONCAT(ShabadID, ' - ', GROUP_CONCAT(Scripture SEPARATOR ' ')) as text, ShabadID as id");
		$list = $builder->pluck('text')->all();
		if(!$list) {
			return null;
		}
		return array_pop($list);
	}
}