<?php

namespace App\Repositories;

use App\Models\Comment;
use Illuminate\Http\Request;

class CommentsRepository extends Repository
{
	protected $model;

	public function __construct(Comment $model)
	{
		$this->model = $model;
	}

	/**
	 * get list of comments.
	 *
	 * @param  $request: Illuminate\Http\Request
	 * @return collection of App\Models\Comment
	 */
	public function paginate(Request $request)
	{
		$builder = $this->model;
		$builder = $builder->filter($request->all())
						->sortable();
		return $builder->paginate($request->input('limit', 10));
	}

	/**
	 * update comment status.
	 *
	 * @param  $id: integer of comment status.
	 * @param  $status: string of status (approve/reject)
	 * @return App\Models\Comment
	 */
	public function updateStatus($id, $status)
	{

		$commentStatus = false;
		$deleteStatus = '1';
		if($status == 'approve') {
			$commentStatus = true;
			$deleteStatus = '0';
		}
		$item = $this->model->findOrFail($id);
		$item->setCommentApprove($commentStatus)->save();
		$item->setDeleteApprove($deleteStatus)->save();
		return $item;
	}

	/**
	 * set payload of data.
	 *
	 * @param  $item: App\Models\Comment
	 * @return array of data.
	 */
	public function setDataPayload($item)
	{
		return [
			'comment_author_id' => $item->getCommentAuthorId(),
			'comment_text' 		=> $item->getCommentText(),
			'comment_date' 		=> $item->getCommentDate(),
			'comment_post_id' 	=> $item->getCommentPostId(),
			'comment_approve' 	=> (bool)$item->getCommentApprove(),
			'delete_approve' 	=> $item->getDeleteApprove(),
		];
	}

	public function getAllComments($request)
	{
        $builder = new Comment();

        $comments = $builder->with(['user'])
        					->filter($request->all())
        					->sortable()
        					->get();
        
        $comments->map(function($comment) {
			$comment['comment_formated_date']	= date('F j, Y', $comment->comment_date);
		});
        
        return $comments;
	}
}

