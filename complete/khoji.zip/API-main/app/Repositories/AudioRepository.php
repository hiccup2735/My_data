<?php

namespace App\Repositories;

use App\Models\Audio;
use App\Models\Singer;
use Exception;

class AudioRepository extends Repository
{
	public function get($request)
	{
		$builder = Audio::with(['user' => function($q) {
			$q->select('id', 'name');
		}]);

		if ($request->has('approved')) {
			$builder = $builder->where('approved', $request->get('approved'));
		}

		$limit = 50;
		if ($request->has('limit')) {
			$limit = $request->get('limit');
		}

		if ($request->has('paginate') && $request->get('paginate')) {
			$audios = $builder->paginate($limit);
		} else {
			$audios = $builder->get();
		}

		foreach ($audios as $key => $audio) {
			if ($audio->shabad_id) {
		    	$audio['shabad_page'] = ShabadRepository::getShabadPage($audio->shabad_id);
		   	}
		}

		return $audios;

	}

	public function getSingers($request)
	{
		return Singer::orderBy('singer_name')
					 ->get();
	}
	public function deleteAudio($id=null){

		$status = Audio::where('audio_id',$id)->delete();
		if($status){
			return true;
		}else{
			return false;
		}
	}
	
}