<?php

namespace App\Http\Middleware;

use Closure;

class BasicAuthentification
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $path = $request->path();
        $current_route_name = \Route::currentRouteName();
        $allowed_route_names = ['user_verify', 'download_config'];

        if(!in_array($current_route_name, $allowed_route_names) && $request->header('api-key')!=='64EA089F-9D9E-41F3-864A-790C2658EE98' && strpos($path, '/user/verify/') === false && !request()->wantsJson()){
            return response()->json([
                'error' => true,
                'message' => 'Unathorized.']
            , 401);
        }

        return $next($request);
    }
}
