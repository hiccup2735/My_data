<?php

namespace App\Http\Requests\Api;

use App\Models\Media;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CreateMediaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            // 'author_id' => 'required|numeric',
            'shabad_id' => 'required|numeric',
            'ref_type' => [
                'required',
                Rule::in([Media::POST_REF_TYPE, Media::RESOURCE_REF_TYPE])
            ],
            'title' => 'required',
            'attachment_name' => 'required',
            'type' => [
                'required',
                Rule::in([
                    Media::IMAGE_TYPE, 
                    Media::VIDEO_TYPE,
                    Media::YOUTUBE_TYPE,
                    Media::VIMEO_TYPE,
                    Media::AUDIO_TYPE,
                ])
            ],
        ];
    }
}
