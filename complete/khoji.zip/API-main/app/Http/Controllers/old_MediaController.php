<?php

namespace App\Http\Controllers;

use App\Http\Controllers\ApiController;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Requests\Api\CreateMediaRequest;
use App\Models\Media;
use App\Repositories\MediaAuthorsRepository;
use App\Repositories\MediaRepository;
use App\Transformers\Api\MediaTransformer;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use Exception;
use DB;

class MediaController extends ApiController {

    protected $repository;
    protected $mediaAuthorRepository;

    public function __construct(MediaRepository $repository, MediaAuthorsRepository $mediaAuthorRepository) {
        $this->repository = $repository;
        $this->mediaAuthorRepository = $mediaAuthorRepository;
    }

    public function index(Request $request) {
        $items = $this->repository->paginate($request);
        if (count($items) > 0) {
            $items = $items;
        } else {
            $items = [];
        }
        return $this->paginate($items, new MediaTransformer, 'media');
    }

    public function getFeaturedItems(Request $request) {

//        $items = $this->repository->paginateFeatured($request);
//        return $this->paginate($items, new MediaTransformer, 'media');
        if ($_GET['type'] == 'AUDIO') {
            $items = DB::table('media')->where('featured', '1')->orderBy('featured_display_order', 'asc')->paginate(10);
            if (count($items) > 0) {
                foreach ($items as $item) {
                    $result12 = substr($item->attachment_name, 0, 5);
                    if ($result12 == 'https') {
                        $attachment_file = $item->attachment_name;
                        //s3 starts here
                        $exists = Storage::disk('s3katha')->exists($item->attachment_name);
                  
                        if($exists){
                         $attachment_file = Storage::disk('s3katha')->url($item->attachment_name);
                        }else{
                            $attachment_file = $item->attachment_name;
                        }
                        //s3 end here
                    } else {
                        $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        //S3 appended here
                        $exists = Storage::disk('s3katha')->exists($item->attachment_name);
                     if($exists){
                         $attachment_file = Storage::disk('s3katha')->url($item->attachment_name);
                        }else{
                            $attachment_file = $item->attachment_name;
                        }
                        //s3 ended here
                    }
                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'type' => $item->type,
                        'attachment_name' => $attachment_file,
                    );
                }
            } else {
                $data = [];
            }


            return json_encode(array('featured_media' => $data));
//            return $this->paginate($items, new MediaTransformer, 'media');
        }
    }

    public function category_media(Request $request, $id) {
//        die('hi');
        $cat_medias = DB::table('media_categories')->where('category_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('media')->where('id', $cat_media->media_id)->where('status','1')->first();
            }
            $itemd_data = array_filter($items);
            
            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {
                    
                    if ($item->attachment_name == null || $item->attachment_name == '') {
                    $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $media_url = url('uploads/media/') . '/' . $item->attachment_name;
                        } else {
                            $media_url = $item->attachment_name;
                        }
                    }
                    
                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'type' => $item->type,
                        'status' => $item->status,
                        'attachment_name' => $media_url,
                    );
                }
            } else {
                $data = [];
            }
        } else {
            $data = [];
        }


//            echo "<pre>"; print_r($items); die;
        return json_encode(array('category_media' => $data));
    }
    
    public function subcategory_media(Request $request, $id) {
//        die('hi');
        $cat_medias = DB::table('podcast_media_subcategories')->where('subcategory_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('podcast_media')->where('id', $cat_media->media_id)->where('status','1')->first();
            }
            $itemd_data = array_filter($items);
            
            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {
                    
                    if ($item->attachment_name == null || $item->attachment_name == '') {
                    $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $media_url = url('uploads/podcast_media/') . '/' . $item->attachment_name;
                        } else {
                            $media_url = $item->attachment_name;
                        }
                    }
                    
                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'type' => $item->type,
                        'status' => $item->status,
                        'attachment_name' => $media_url,
                    );
                }
            } else {
                $data = [];
            }
        } else {
            $data = [];
        }


//            echo "<pre>"; print_r($items); die;
        return json_encode(array('subcategory_media' => $data));
    }

    public function media_play(Request $request) {
        $media_id = $request->media_id;
        $user_id = $request->user_id;
        $machine_id = $request->machine_id;
        $view_date = $request->view_date;
        if ($media_id == '' || $machine_id == '' || $view_date == '') {
            return json_encode(array('error' => true));
        }
        $media_user_null = DB::table('media_play')->where('machine_id', $machine_id)->where('media_id', $media_id)->whereNull('user_id')->get();
        $media_get_data = DB::table('media')->where('id', $media_id)->first();

        if ($media_get_data->play_start_date == '' || $media_get_data->play_start_time == '') {
            $play_start_date = date("Y-m-d");
            $play_start_time = date("h:i:sa");
            DB::table('media')->where('id', $media_id)->update(['play_start_date' => $play_start_date, 'play_start_time' => $play_start_time]);
        }
        $play_last_date = date("Y-m-d");
        $play_last_time = date("h:i:sa");
        DB::table('media')->where('id', $media_id)->update(['play_last_date' => $play_last_date, 'play_last_time' => $play_last_time]);
        
        if($media_get_data->play_count==0){
            //die('here');
            $media_play_count = '1';
        }else{
            //print_r($media_get_data->play_count); die;
            $media_play_count = $media_get_data->play_count + '1' ;
        }
        
        DB::table('media')->where('id', $media_id)->update(['play_count' => $media_play_count]);
        if ($user_id != '') {
            if (count($media_user_null) > 0) {
                DB::table('media_play')->where('id', $media_user_null[0]->id)->update([
                    'user_id' => $request->user_id
                ]);
                return json_encode(array('success' => true));
            }
        }
        $media_machine_null = DB::table('media_play')->where('machine_id', $machine_id)->where('media_id', $media_id)->get();
        if (count($media_machine_null) > 0) {
            return json_encode(array('success' => true));
        } else {
            DB::table('media_play')->insert([
                'media_id' => $media_id,
                'user_id' => $user_id,
                'machine_id' => $machine_id,
                'view_date' => $view_date,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => true));
        }
    }

    /**
     * create tag
     *
     * @param  $request: App\Http\Requests\Api\CreateTagRequest
     * @param  $entity: App\Models\Tag
     * @return json response.
     */
    public function store(CreateMediaRequest $request, Media $entity) {
        try {
            $authorId = $request->input('author_id');
            if ($authorId && !is_int($authorId)) {
                $author = $this->mediaAuthorRepository->storeAuthor($authorId);
                $authorId = $author->getKey();
            }

            $user = $request->user();
            $status = (bool) $request->input('status');

            if ($user->isSuperAdmin()) {
                $status = true;
            }
            $request['includes'] = 'categories,tags';
            $userId = $request->user()->id;
            $entity->setAuthorId($authorId)
                    ->setShabadId($request->input('shabad_id'))
                    ->setRefType($request->input('ref_type'))
                    ->setTitle($request->input('title'))
                    ->setDescription($request->input('description'))
                    ->setAttachmentName($request->input('attachment_name'))
                    ->setAttachmentMimeType($request->input('attachment_mime_type'))
                    ->setType($request->input('type'))
                    ->setStatus($status)
                    ->setCreatedBy($userId)
                    ->setUpdatedBy($userId);

            $item = $this->repository->save($entity);

            if ($request->filled('category_ids')) {

                $item = $this->repository->assignCategories($item, $request->input('category_ids'));
            }

            if ($request->filled('tag_ids')) {

                $item = $this->repository->assignTags($item, $request->input('tag_ids'));
            }
            return $this->getItem($item, new MediaTransformer, 'media');
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    /**
     * change status with previous status
     *     if previously status was active then mark as inactive and vice-versa
     *     
     * @param  $media: App\Models\Media
     * @return json response.
     */
    public function toggleStatus(Media $media) {
        try {

            $item = $this->repository->toggleStatus($media->getKey());
            return $this->getItem($item, new MediaTransformer, 'media');
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    /**
     * delete category
     *
     * @param  $entity: App\Models\Media
     * @return json response.
     */
    public function delete(Media $entity, Request $request) {
        try {

            if (!$entity->canDelete($request->user())) {
                throw new Exception("You have not permission to delete this media", Response::HTTP_UNAUTHORIZED);
            }

            $entity->delete();
            return $this->respondDeleted([]);
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    //podcast list START
    public function podcast(Request $request) {
        $feed = 'https://feed.podbean.com/khojgurbani/feed.xml';
        $feed_to_array = (array) simplexml_load_file($feed);
        $feddarrayData = json_decode(json_encode((array) $feed_to_array), TRUE);
        $final_feed_data = $feddarrayData['channel']['item'];

        foreach ($final_feed_data as $final_feeds) {
            $data[] = array(
                'title' => $final_feeds['title'],
                'date' => $final_feeds['pubDate'],
                'media_data' => $final_feeds['enclosure']['@attributes'],
            );
        }
        return json_encode(array('status' => '200', 'message' => 'podcast list', 'result' => $data));
    }

    //podcast list END
    //podcast index START
    public function podcast_index(Request $request) {
        $data =array();
        $final_feeds_count = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->count();
        if ($final_feeds_count > 0) {
            $final_feeds = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->first();

            $result12 = substr($final_feeds->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $attachment_file = $final_feeds->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
            }
             //s3 starts here
             $exists = Storage::disk('s3')->exists($final_feeds->attachment_name);
                  
             if($exists){
              $attachment_file = Storage::disk('s3')->url($final_feeds->attachment_name);
             }else{
                 $attachment_file = $final_feeds->attachment_name;
             }
             //s3 ends here
            $data[] = array(
                'id' => $final_feeds->id,
                'title' => $final_feeds->title,
                'media_data' => $attachment_file,
                'updated_at' =>$final_feeds->updated_at,
                'time' => '00:50:29'
            );
        } else {
            $final_feeds = DB::table('podcast_media')->orderBy('id', 'desc')->first();
            $result12 = substr($final_feeds->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $attachment_file = $final_feeds->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
            }
             //s3 starts here
             $exists = Storage::disk('s3')->exists($final_feeds->attachment_name);
                  
             if($exists){
              $attachment_file = Storage::disk('s3')->url($final_feeds->attachment_name);
             }else{
                 $attachment_file = $final_feeds->attachment_name;
             }
             //s3 ends here
            $data[] = array(
                'id' => $final_feeds->id,
                'title' => $final_feeds->title,
                'media_data' => $attachment_file,
                'updated_at' =>$final_feeds->updated_at,
                'time' => '00:50:29'
            );
        }


        return json_encode(array('status' => '200', 'message' => 'Today Podcast', 'result' => $data));
    }

    //podcast index END
    //latest archive START
    public function latest_archive() {
        $data =array();
        $last_media_podcast = DB::table('podcast_media')->orderBy('id', 'desc')->first();
        $last_5_archive_c = DB::table('podcast_media')->where('today_approval', '0')->count();
        if ($last_5_archive_c > 0) {
            $last_5_archives = DB::table('podcast_media')->where('today_approval', '0')->orderBy('id', 'desc')->take(5)->get();
            foreach ($last_5_archives as $last_5_archive) {
                //s3 starts here
                $exists = Storage::disk('s3')->exists($last_5_archive->attachment_name);
                  
                if($exists){
                 $archiveName = Storage::disk('s3')->url($last_5_archive->attachment_name);
                }else{
                    $archiveName = $last_5_archive->attachment_name;
                }
                //ends here
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $archiveName,
                    'time' => '00:50:29'
                );
            }
        } else {
            $last_5_archives = DB::table('podcast_media')->where('today_approval', '0')->orderBy('id', 'desc')->take(5)->get();
            foreach ($last_5_archives as $last_5_archive) {
                $exists = Storage::disk('s3')->exists($last_5_archive->attachment_name);
                  
                if($exists){
                 $archiveName = Storage::disk('s3')->url($last_5_archive->attachment_name);
                }else{
                    $archiveName = $last_5_archive->attachment_name;
                }
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $archiveName,
                    'time' => '00:50:29'
                );
            }
        }


        return json_encode(array('status' => '200', 'message' => 'Last 5 Archive', 'result' => $data));
    }

    //latest archive END
    //all archive START
    public function all_archive() {
        $last_media_podcast = DB::table('podcast_media')->orderBy('id', 'desc')->first();
        $last_5_archive_c = DB::table('podcast_media')->where('id', '!=', $last_media_podcast->id)->orderBy('id', 'desc')->count();
        if ($last_5_archive_c > 0) {
            $last_5_archives = DB::table('podcast_media')->where('id', '!=', $last_media_podcast->id)->orderBy('id', 'desc')->get();
            foreach ($last_5_archives as $last_5_archive) {
                $exists = Storage::disk('s3')->exists($last_5_archive->attachment_name);
                  
                if($exists){
                 $archiveName = Storage::disk('s3')->url($last_5_archive->attachment_name);
                }else{
                    $archiveName = $last_5_archive->attachment_name;
                }
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $archiveName,
                    'time' => '00:50:29'
                );
            }
        } else {
            $last_5_archives = DB::table('podcast_media')->where('id', '!=', $last_media_podcast->id)->orderBy('id', 'desc')->get();
            foreach ($last_5_archives as $last_5_archive) {
                $exists = Storage::disk('s3')->exists($last_5_archive->attachment_name);
                  
                if($exists){
                 $archiveName = Storage::disk('s3')->url($last_5_archive->attachment_name);
                }else{
                    $archiveName = $last_5_archive->attachment_name;
                }
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $archiveName,
                    'time' => '00:50:29'
                );
            }
        }


        return json_encode(array('status' => '200', 'message' => 'All Archives', 'result' => $data));
    }

    //all archive END
    //podcast list START
    public function podcast_list(Request $request) {
        $feed = 'https://feed.podbean.com/khojgurbani/feed.xml';
        $feed_to_array = (array) simplexml_load_file($feed);
        $feddarrayData = json_decode(json_encode((array) $feed_to_array), TRUE);
        $final_feed_data = $feddarrayData['channel']['item'];
//        echo "<pre>"; print_r($final_feed_data); die;
        foreach ($final_feed_data as $final_feeds) {
            $description1 = "In this episode, Chetandeep Singh presents his understanding of the shabad " . "'" . $final_feeds['title'] . "'" . " followed by a discussion and Q&A with the panelists of Khoj Gurbani.";

            $description2 = "KhojGurbani is an online platform with a mission to make the Guru Granth Sahib accessible to and exciting for the common Sikh, who wants to read Gurbani but does not have the tools and a support network to do so. While KhojGurbani will engage Sikhs globally in discussion on specific sections of Guru Granth Sahib every week, it will also spearhead the development of a crowdsourced commentary and a new idiomatic English translation.";

            $visit = "Visit http://www.khojgurbani.org/ for more information";
            $today_podcast_first = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->first();
            if ($today_podcast_first->attachment_name == $final_feeds['enclosure']['@attributes']['url']) {
                $today_approval = '1';
            } else {
                $today_approval = '0';
            }
            $datas[] = array(
                'title' => $final_feeds['title'],
                'date' => $final_feeds['pubDate'],
                'media_data' => $final_feeds['enclosure']['@attributes'],
                'description1' => $description1,
                'description2' => $description2,
                'visit' => $visit,
                'date' => $final_feeds['pubDate'],
                'today_approva' => $today_approval,
            );
        }
        $a = 1;

        if (isset($_GET['search']) && $_GET['search'] != '') {
            foreach ($datas as $ke => $datass) {
                if ((strpos($datass['description1'], ucfirst($_GET['search'])) == 0 && strpos($datass['description1'], $_GET['search']) == 0) && (strpos($datass['title'], ucfirst($_GET['search'])) == 0 && strpos($datass['title'], $_GET['search']) == 0) && (strpos($datass['description2'], ucfirst($_GET['search'])) == 0 && strpos($datass['description2'], $_GET['search']) == 0)) {
                    unset($datas[$ke]);
                }
            }
        }
//        echo "<pre>";
//        print_r($datas);
//        die;
        if (count($datas) > 0) {
            foreach ($datas as $ke => $datass) {
                $today_podcast_first = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->first();
                if ($today_podcast_first->attachment_name == $datass['media_data']['url']) {
                    $today_approval = '1';
                } else {
                    $today_approval = '0';
                }
                $title = $datass['title'];
                $media = $datass['media_data']['url'];
                $data[] = array(
                    'id' => $a,
                    'title' => $title,
                    'media' => $media,
                    'description1' => $datass['description1'],
                    'description2' => $datass['description2'],
                    'visit' => $datass['visit'],
                    'date' => $datass['date'],
                    'today_approval' => $today_approval,
                );
                $a++;
            }
        } else {
            $data = [];
        }
//        echo "<pre>"; print_r($descr1); die;
        return json_encode(array('status' => '200', 'message' => 'podcast list', 'result' => $data));
    }

    //podcast list END
    //Recenty played function START
    public function recently_played(Request $request) {
        if ($request->user_id == '' || $request->user_id == null) {
            $recent_media_count = DB::table('media_play')->where('machine_id', $request->machine_id)->count();
            if ($recent_media_count > 0) {
                $recent_media = DB::table('media_play')->where('machine_id', $request->machine_id)->get();
                foreach ($recent_media as $recent_medias) {
                    $items = DB::table('media')->where('id', $recent_medias->media_id)->get();
                    foreach ($items as $item) {
                        $result12 = substr($item->attachment_name, 0, 5);
                        if ($result12 == 'https') {
                            $attachment_file = $item->attachment_name;
                        } else {
                            $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        }
                        $data[] = array(
                            'id' => $item->id,
                            'title' => $item->title,
                            'type' => $item->type,
                            'attachment_name' => $attachment_file,
                        );
                    }
                }
            } else {
                $data = [];
            }
        } else {
            $recent_media_count = DB::table('media_play')->where('user_id', $request->user_id)->count();
            if ($recent_media_count > 0) {
                $recent_media = DB::table('media_play')->where('user_id', $request->user_id)->get();
                foreach ($recent_media as $recent_medias) {
                    $items = DB::table('media')->where('id', $recent_medias->media_id)->get();
                    foreach ($items as $item) {
                        $result12 = substr($item->attachment_name, 0, 5);
                        if ($result12 == 'https') {
                            $attachment_file = $item->attachment_name;
                        } else {
                            $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        }
                        $data[] = array(
                            'id' => $item->id,
                            'title' => $item->title,
                            'type' => $item->type,
                            'attachment_name' => $attachment_file,
                        );
                    }
                }
            } else {
                $data = [];
            }
        }
        return json_encode(array('recently_played' => $data));
    }

    //Recenty played function END
    //featured artist gurbaani START
    public function featured_artist_gurbani(Request $request, $id) {
        $items = DB::table('media')->where('author_id', $id)->get();
        if (count($items) > 0) {
            foreach ($items as $item) {
                $data[] = array(
                    'id' => $item->id,
                    'title' => $item->title,
                    'attachment_name' => url('uploads/media/') . '/' . $item->attachment_name,
                );
            }
        } else {
            $data = [];
        }

        return json_encode(array('status' => '200', 'message' => 'featured artist gurbaani', 'result' => $data));
    }

    //featured artist gurbaani END
    //Add today 
    public function add_today() 
    {
        
        $url = $_GET['url'];
        $title = $_GET['title'];
        $podcast_exist = DB::table('podcast_media')->where('attachment_name', $url)->count();
        if ($podcast_exist > 0) {
            DB::table('podcast_media')->where('attachment_name', '!=', $url)->update([
                'today_approval' => '0'
            ]);
            DB::table('podcast_media')->where('attachment_name', $url)->update([
                'today_approval' => '1'
            ]);
        } else {
            DB::table('podcast_media')->update([
                'today_approval' => '0'
            ]);
            DB::table('podcast_media')->insert([
//                'author_id' => Auth::user()->id,
                'shabad_id' => '1',
                'ref_type' => 'RESOURCE',
                'title' => $title,
                'attachment_name' => $url,
                'type' => 'IMAGE',
                'today_approval' => '1',
                'status' => '1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }
        return json_encode(array('status' => '200', 'message' => 'Podcast Media as been marked for today successfully.'));
    }

    public function updatePodcastStatus()
    {
        $id = $_GET['id'];
        DB::table('podcast_media')->where('id', $id)->update([
                'today_approval' => '1'
        ]);
        DB::table('podcast_media')->where('id', '!=', $id)->update([
            'today_approval' => '0'
        ]);
        return json_encode(array('status' => '200', 'message' => 'Podcast Media status updated successfully.'));
    }

    ///////////// Media Management APIs ///////////////////////
    //Add media START
    public function podcast_add(Request $request) {
//        $author_id = $request->author_id;
        $shabad_id = $request->shabad_id;
        $language = $request->language;
        $ref_type = $request->ref_type;
        $title = $request->title;
        $description = $request->description;
        $type = $request->type; //AUDIO,YOUTUBE,IMAGE
        $youtube_url = $request->youtube_url;
        $podbean_url = $request->podbean_url;
        $external_url = $request->external_url;
        if ($type == 'AUDIO') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ","_",$fileNameO);

                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/podcast_media/';
                 Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                // die;
                //$file->move($destinationPath, $fileNameUnique);
                $image = $fileNameUnique;
            } else {
                return json_encode(array('success' => '201', 'message' => 'MP3 File is required'));
            }
        } elseif ($type == 'IMAGE') {
            if ($podbean_url == '') {
                return json_encode(array('success' => '201', 'message' => 'Podbean URL is required'));
            }
            $image = $podbean_url;
        } elseif ($type == 'YOUTUBE') {
            if ($youtube_url == '') {
                return json_encode(array('success' => '201', 'message' => 'Youtube URL is required'));
            }
            $image = $youtube_url;
        }
        elseif ($type == 'EXTERNAL') {
            if ($external_url == '') {
                return json_encode(array('success' => '201', 'message' => 'External URL is required'));
            }
            $image = $external_url;
        }


        if ($title == '') {
            return json_encode(array('success' => '201', 'message' => 'Title is required'));
        }
        
        if ($description == '') {
            return json_encode(array('success' => '201', 'message' => 'Descriprtion is required'));
        }


        if ($request->file('thumbnail')) {
                $file = $request->file('thumbnail');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ","_",$fileNameO);

                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/thumbnail/';
                $file->move($destinationPath, $fileNameUnique);
                $imagethumb = $fileNameUnique;
            } else {
                $imagethumb = '';
            } 

//            $slug = str_slug($title, '-');
        if(isset($shabad_id) && !empty($shabad_id)){
            $podcast_media_cou=DB::table('podcast_media')->where('shabad_id',$shabad_id)->where('language',$language)->count();
            if($podcast_media_cou>0){
                DB::table('podcast_media')->where('shabad_id',$shabad_id)->update([
                    'over_right'=>'0'
                ]);
            }
        }    
        $media_id = DB::table('podcast_media')->insertGetId([
            'title' => $title,
            'language' => $language,
            'description' => $description,
            'thumbnail' => $imagethumb,
            'shabad_id' => $shabad_id,
            'ref_type' => 'RESOURCE',
            'type' => $type,
            'attachment_name' => $image,
            'status' => '1',
            'today_approval' => '0',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        if ($request->tag_id) {
            DB::table('podcast_media_tags')->insert([
                'media_id' => $media_id,
                'tag_id' => $request->tag_id,
            ]);
        }

        if ($request->input('category')) {
            $all_cats = json_decode($request->input('category'));
            foreach ($all_cats as $all_cat) {
                DB::table('podcast_media_categories')->insertGetId([
                    'media_id' => $media_id,
                    'category_id' => $all_cat->cat_id
                        ]
                );
            }
        }

        if ($request->new_category != null) {
            $slug = str_slug($request->new_category, '-');
            $new_cat_id = DB::table('podcast_categories')->insertGetId([
                'slug' => $slug,
                'name' => $request->new_category,
                'status' => '1'
                    ]
            );

            DB::table('podcast_media_categories')->insertGetId([
                'media_id' => $media_id,
                'category_id' => $new_cat_id
                    ]
            );
        }

        if ($request->input('sub_category')) {
            $all_subcats = json_decode($request->input('sub_category'));
            foreach ($all_subcats as $all_subcat) {
                $subcats_data = DB::table('podcast_subcategories')->where('id', $all_subcat->sub_cat_id)->first();
                DB::table('podcast_media_subcategories')->insertGetId([
                    'media_id' => $media_id,
                    'subcategory_id' => $all_subcat->sub_cat_id
                        ]
                );
                DB::table('podcast_media_categories')->insertGetId([
                    'media_id' => $media_id,
                    'category_id' => $subcats_data->category_id
                        ]
                );
            }
        }

        return json_encode(array('success' => '200', 'message' => 'New media created successfully.'));
    }

    //Add media END
    //Add media START
    public function add(Request $request) {
        $tag_id = $request->tag_id;
        $author_id = $request->author_id;
        $shabad_id = $request->shabad_id;
        $ref_type = $request->ref_type;
        $title = $request->title;
        $type = $request->type; //AUDIO,YOUTUBE,IMAGE
        $youtube_url = $request->youtube_url;
        $podbean_url = $request->podbean_url;
        $external_url = $request->external_url;

        $media_exist = DB::table('media')->where('title', $title)->count();
        if ($media_exist > 0) {
            return json_encode(array('success' => '201', 'message' => 'Media with title already exist. Please try with new one.'));
        }
        if ($type == 'AUDIO') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ","_",$fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';
                // $file->move($destinationPath, $fileNameUnique);
                //add to s3
                if($tag_id==1){
                     Storage::disk('s3santhya')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                }
                if($tag_id==2){
                    Storage::disk('s3kirtan')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+')); 
                }
                if($tag_id==4){
                    Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                 }
                if($tag_id==15){
                    Storage::disk('s3katha')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                }
                //end s3
                $image = $fileNameUnique;
            } else {
                return json_encode(array('success' => '201', 'message' => 'MP3 File is required'));
            }
        } elseif ($type == 'IMAGE') {
            if ($podbean_url == '') {
                return json_encode(array('success' => '201', 'message' => 'Podbean URL is required'));
            }
            $image = $podbean_url;
        } elseif ($type == 'YOUTUBE') {
            if ($youtube_url == '') {
                return json_encode(array('success' => '201', 'message' => 'Youtube URL is required'));
            }
            $image = $youtube_url;
        } elseif ($type == 'EXTERNAL') {
            if ($external_url == '') {
                return json_encode(array('success' => '201', 'message' => 'External URL is required'));
            }
            $image = $external_url;
        }


        if ($title == '') {
            return json_encode(array('success' => '201', 'message' => 'Title is required'));
        }

        if ($author_id == '') {
            return json_encode(array('success' => '201', 'message' => 'Author is required'));
        }


//            $slug = str_slug($title, '-');
        $media_id = DB::table('media')->insertGetId([
            'title' => $title,
            'author_id' => $author_id,
            'shabad_id' => $shabad_id,
            'ref_type' => 'RESOURCE',
            'type' => $type,
            'attachment_name' => $image,
            'status' => '1',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        if ($request->tag_id) {
            DB::table('media_tags')->insert([
                'media_id' => $media_id,
                'tag_id' => $request->tag_id,
            ]);
        }

        if ($request->input('category')) {
            $all_cats = json_decode($request->input('category'));
            foreach ($all_cats as $all_cat) {
                DB::table('media_categories')->insertGetId([
                    'media_id' => $media_id,
                    'category_id' => $all_cat->cat_id
                        ]
                );
            }
        }

        if ($request->new_category != null) {
            $slug = str_slug($request->new_category, '-');
            $new_cat_id = DB::table('categories')->insertGetId([
                'slug' => $slug,
                'name' => $request->new_category,
                'status' => '1'
                    ]
            );

            DB::table('media_categories')->insertGetId([
                'media_id' => $media_id,
                'category_id' => $new_cat_id
                    ]
            );
        }

        if ($request->input('sub_category')) {
            $all_subcats = json_decode($request->input('sub_category'));
            foreach ($all_subcats as $all_subcat) {
                $subcats_data = DB::table('subcategories')->where('id', $all_subcat->sub_cat_id)->first();
                DB::table('media_subcategories')->insertGetId([
                    'media_id' => $media_id,
                    'subcategory_id' => $all_subcat->sub_cat_id
                        ]
                );
                $cat_exist = DB::table('media_categories')->where('media_id', $media_id)->where('category_id', $subcats_data->category_id)->count();
                if ($cat_exist == 0) {
                    DB::table('media_categories')->insertGetId([
                        'media_id' => $media_id,
                        'category_id' => $subcats_data->category_id
                            ]
                    );
                }
            }
        }

        return json_encode(array('success' => '200', 'message' => 'New media created successfully.'));
    }

    //Add media END
    //Media listing API START    
    public function media_list(Request $request) {
        $medias = DB::table('media')->get();
        $all_cats_media = [];
        $all_categories_media = '';
        if (count($medias) > 0) {
//            echo "<pre>"; print_r($medias); die;
            foreach ($medias as $media) {
                $author_data = DB::select("select * from media_authors where id='$media->author_id' LIMIT 1");
                //->where('id',$media->author_id)->first();
                $author_tags_count = DB::table('media_tags')->where('media_id', $media->id)->count();
                if ($author_tags_count > 0) {
//                die('here');
                    $author_tags = DB::table('media_tags')->where('media_id', $media->id)->first();
                    $tags_data = DB::table('tags')->where('id', $author_tags->tag_id)->first();
                } else {
//                die('ff');
                    $author_tags = [];
                    $tags_data = [];
                }
                // echo $author_tags->tag_id; die;
                //$tags_data_count=DB::table('tags')->where('id',$author_tags->tag_id)->count();
                //print_r($tags_data_count); die;
//            if($tags_data_count>0){
//                $tags_data=DB::table('tags')->where('id',$author_tags->tag_id)->first();
//            }else{
//                $tags_data = [];
//            }
//            if(!isset($tags_data) && empty($tags_data)){
//                
//            }
                $all_media_cats = DB::table('categories')
                        ->leftjoin('media_categories', 'media_categories.category_id', '=', 'categories.id')
                        ->select('categories.name')
                        ->where('media_categories.media_id', '=', $media->id)
                        ->get();
                
                $all_media_subcats = DB::table('subcategories')
                        ->leftjoin('media_subcategories', 'media_subcategories.subcategory_id', '=', 'subcategories.id')
                        ->select('subcategories.name')
                        ->where('media_subcategories.media_id', '=', $media->id)
                        ->get();
//            echo "<pre>"; print_r($all_media_subcats); die; 
                $all_cats_media = [];
                $all_subcats_media = [];
                if (count($all_media_cats) > 0) {
                    foreach ($all_media_cats as $all_media_cat) {
                        $all_cats_media[] = $all_media_cat->name;
                    }
                    $all_categories_media = implode(',', $all_cats_media);
                    $all_comma_cats = rtrim($all_categories_media, ',');
                } else {
                    $all_comma_cats = [];
                }
                
                if (count($all_media_subcats) > 0) {
                    foreach ($all_media_subcats as $all_media_subcat) {
                        $all_subcats_media[] = $all_media_subcat->name;
                    }
                    $all_subcategories_media = implode(',', $all_subcats_media);
                    $all_comma_subcats = rtrim($all_subcategories_media, ',');
                } else {
                    $all_comma_subcats = [];
                }
                $type = $media->type;
                if ($type == 'IMAGE') {
                    $image = $media->attachment_name;
                } elseif ($type == 'YOUTUBE') {
                    $image = $media->attachment_name;
                } elseif ($type == 'EXTERNAL') {
                    $image = $media->attachment_name;
                } elseif ($type == 'AUDIO') {
                    $image = url('uploads/media/') . '/' . $media->attachment_name;
                     $tagName = $tags_data->name;
                    if($tagName=='Kirtan'){
                        $exists = Storage::disk('s3kirtan')->exists($media->attachment_name);
                        if($exists){
                            $image = Storage::disk('s3kirtan')->url($media->attachment_name);
                        }
                       
                    }
                    if($tagName=='Santhiya'){
                        $exists = Storage::disk('s3santhya')->exists($media->attachment_name);
                        if($exists){
                            $image = Storage::disk('s3santhya')->url($media->attachment_name);
                        }
                       
                    }
                    if($tagName=='Podcast'){
                        $exists = Storage::disk('s3')->exists($media->attachment_name);
                        if($exists){
                            $image = Storage::disk('s3')->url($media->attachment_name);
                        }
                      
                    }
                    if($tagName=='Katha'){
                        $exists = Storage::disk('s3katha')->exists($media->attachment_name);
                        if($exists){
                            $image = Storage::disk('s3katha')->url($media->attachment_name);
                        }
                       
                    }
                   
                }
                if (isset($tags_data->name) && !empty($tags_data->name)) {
                    $data[] = array(
                        'id' => $media->id,
                        'shabad_id' => $media->shabad_id,
                        'title' => $media->title,
                        'type' => $media->type,
                        'status' => $media->status,
                        'author_name' => $author_data[0]->name,
                        'attachment_name' => $image,
                        'media_categories' => $all_comma_cats,
                        'media_subcategories' => $all_comma_subcats,
                        'media_tag' => $tags_data->name
                    );
                } else {
                    $data[] = array(
                        'id' => $media->id,
                        'shabad_id' => $media->shabad_id,
                        'title' => $media->title,
                        'type' => $media->type,
                        'status' => $media->status,
                        'author_name' => $author_data[0]->name,
                        'attachment_name' => $image,
                        'media_categories' => $all_comma_cats,
                        'media_subcategories' => $all_comma_subcats,
                        'media_tag' => ''
                    );
                }
            }
        } else {
            $data = [];
        }

        return json_encode(array('status' => '200', 'message' => 'Media List', 'result' => $data));
    }

    //Media listing API END    
    //Media listing API START    
    public function podcast_media_list(Request $request) {
        $medias = DB::table('podcast_media')->get();
        $all_cats_media = [];
        $all_categories_media = '';
//        echo "<pre>"; print_r($medias); die;
        foreach ($medias as $media) {
//            $author_data=DB::table('media_authors')->where('id',$media->author_id)->first();
//            $author_tags=DB::table('media_tags')->where('media_id',$media->id)->first();
//            echo "<pre>"; print_r($author_tags); die;
//            $tags_data=DB::table('tags')->where('id',$author_tags->tag_id)->first();
            $all_media_cats = DB::table('podcast_categories')
                    ->leftjoin('podcast_media_categories', 'podcast_media_categories.category_id', '=', 'podcast_categories.id')
                    ->select('podcast_categories.name')
                    ->where('podcast_media_categories.media_id', '=', $media->id)
                    ->get();
//            echo "<pre>"; print_r($author_tags); die; 
            $all_cats_media = [];
            if (count($all_media_cats) > 0) {
                foreach ($all_media_cats as $all_media_cat) {
                    $all_cats_media[] = $all_media_cat->name;
                }
                $all_categories_media = implode(',', $all_cats_media);
                $all_comma_cats = rtrim($all_categories_media, ',');
            } else {
                $all_comma_cats = [];
            }
            
            ///////////////////////////////
            $all_media_subcats = DB::table('podcast_subcategories')
                    ->leftjoin('podcast_media_subcategories', 'podcast_media_subcategories.subcategory_id', '=', 'podcast_subcategories.id')
                    ->select('podcast_subcategories.name')
                    ->where('podcast_media_subcategories.media_id', '=', $media->id)
                    ->get();
//            echo "<pre>"; print_r($author_tags); die; 
            $all_subcats_media = [];
            if (count($all_media_subcats) > 0) {
                foreach ($all_media_subcats as $all_media_subcat) {
                    $all_subcats_media[] = $all_media_subcat->name;
                }
                $all_subcategories_media = implode(',', $all_subcats_media);
                $all_comma_subcats = rtrim($all_subcategories_media, ',');
            } else {
                $all_comma_subcats = [];
            }
            

            $type = $media->type;
                if ($type == 'IMAGE') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'YOUTUBE') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'EXTERNAL') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'AUDIO') {
                    $image_a = url('uploads/podcast_media/') . '/' . $media->attachment_name;
                    //will uncomment this afterward as still all files are on localhost
                    $exists = Storage::disk('s3')->exists($media->attachment_name);
                  
                   if($exists){
                    $image = Storage::disk('s3')->url($media->attachment_name);
                   }
                    
                }
            if ($media->thumbnail == null || $media->thumbnail == '') {
                    $thumbnail_pod = '';
                } else {
                    $thumbnail_pod = url('uploads/thumbnail/') . '/' . $media->thumbnail;
                }
            $data[] = array(
                'id' => $media->id,
                'type' => $media->type,
                'shabad_id' => $media->shabad_id,
                'description' => $media->description,
                'language' => $media->language,
                'title' => $media->title,
                'thumbnail_pod' => $thumbnail_pod,
                'status' => $media->status,
                'today_approval' => $media->today_approval,
                'attachment_name' => $image_a,
                'media_categories' => $all_comma_cats,
                'media_subcategories' => $all_comma_subcats,
//                'media_tag'=>$tags_data->name
            );
        }
        return json_encode(array('status' => '200', 'message' => 'Podcast Media List', 'result' => $data));
    }

    //Media listing API END    
    //update Media Author status START
    public function update_podcast_status_media(Request $request, $id) {
        $status = $request->status;
        $podcast_cat_check = DB::table('podcast_media')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1') {
                DB::table('podcast_media')->where('id', $id)->update([
                    'status' => $status
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if ($status == '0') {
                DB::table('podcast_media')->where('id', $id)->update([
                    'status' => $status
                ]);
                DB::table('podcast_media')->where('id', $id)->update([
                    'status' => $status,
                    'featured'=>'0',
                    'featured_display_order'=>NULL
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if($status!='0' || $status!='1') {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No media Exist with this detail'));
        }
    }

    //update Media Author status END
    //Update media START
    public function update_media(Request $request, $id) {
        $tag_id =$request->tag_id;
        $get_last_media = DB::table('media')->where('id', $id)->first();
        $author_id = $request->author_id;
        $shabad_id = $request->shabad_id;
        $ref_type = $request->ref_type;
        $title = $request->title;
        $type = $request->type; //AUDIO,YOUTUBE,IMAGE
        $youtube_url = $request->youtube_url;
        $podbean_url = $request->podbean_url;
        $external_url = $request->external_url;

        $media_exist = DB::table('media')->where('id', '!=', $id)->where('title', $title)->count();
        if ($media_exist > 0) {
            return json_encode(array('success' => '201', 'message' => 'Media with title already exist. Please try with new one.'));
        }

        if ($type == 'AUDIO') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ","_",$fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';
                //$file->move($destinationPath, $fileNameUnique);

                if($tag_id==1){
                    Storage::disk('s3santhya')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
               }
               if($tag_id==2){
                   Storage::disk('s3kirtan')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+')); 
               }
               if($tag_id==4){
                   Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                }
               if($tag_id==15){
                   Storage::disk('s3katha')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
               }
                
                $image = $fileNameUnique;
            } else {
                $image = $get_last_media->attachment_name;
            }
        } elseif ($type == 'IMAGE') {
            if ($podbean_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $podbean_url;
            }
        } elseif ($type == 'YOUTUBE') {
            if ($youtube_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $youtube_url;
            }
        } elseif ($type == 'EXTERNAL') {
            if ($external_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $external_url;
            }
        }


        if ($title == null) {
            return json_encode(array('success' => '201', 'message' => 'Title is required'));
        }

        if ($author_id == null) {
            return json_encode(array('success' => '201', 'message' => 'Author is required'));
        }


//            $slug = str_slug($title, '-');
        //echo $get_last_media; die;
        DB::table('media')->where('id', $id)->update([
            'title' => $title,
            'author_id' => $author_id,
            'shabad_id' => $shabad_id,
            'ref_type' => 'RESOURCE',
            'type' => $type,
            'attachment_name' => $image,
            'status' => '1',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        DB::table('media_tags')->where('media_id', $id)->delete();
        DB::table('media_categories')->where('media_id', $id)->delete();
        DB::table('media_subcategories')->where('media_id', $id)->delete();

        if ($request->tag_id) {
            DB::table('media_tags')->insert([
                'media_id' => $id,
                'tag_id' => $request->tag_id,
            ]);
        }

        if ($request->input('category')) {
            $all_cats = json_decode($request->input('category'));
            foreach ($all_cats as $all_cat) {
                DB::table('media_categories')->insertGetId([
                    'media_id' => $id,
                    'category_id' => $all_cat->cat_id
                        ]
                );
            }
        }

        if ($request->new_category != null) {
            $slug = str_slug($request->new_category, '-');
            $new_cat_id = DB::table('categories')->insertGetId([
                'slug' => $slug,
                'name' => $request->new_category,
                'status' => '1'
                    ]
            );

            DB::table('media_categories')->insertGetId([
                'media_id' => $id,
                'category_id' => $new_cat_id
                    ]
            );
        }

        if ($request->input('sub_category')) {
            $all_subcats = json_decode($request->input('sub_category'));
            foreach ($all_subcats as $all_subcat) {
                $subcats_data = DB::table('subcategories')->where('id', $all_subcat->sub_cat_id)->first();
                DB::table('media_subcategories')->insertGetId([
                    'media_id' => $id,
                    'subcategory_id' => $all_subcat->sub_cat_id
                        ]
                );

                $cat_exist = DB::table('media_categories')->where('media_id', $id)->where('category_id', $subcats_data->category_id)->count();
                if ($cat_exist == 0) {
                    DB::table('media_categories')->insertGetId([
                        'media_id' => $id,
                        'category_id' => $subcats_data->category_id
                            ]
                    );
                }

//                    DB::table('media_categories')->insertGetId([
//                        'media_id' => $id,
//                        'category_id' => $subcats_data->category_id
//                            ]
//                    );
            }
        }

        return json_encode(array('success' => '200', 'message' => 'New media updated successfully.'));
    }

    //Update media END
    
    //Update media START
    public function update_podcast_media(Request $request, $id) {
        $get_last_media = DB::table('podcast_media')->where('id', $id)->first();
        $author_id = $request->author_id;
        $shabad_id = $request->shabad_id;
        $language = $request->language;
        $ref_type = $request->ref_type;
        $title = $request->title;
        $type = $request->type; //AUDIO,YOUTUBE,IMAGE
        $youtube_url = $request->youtube_url;
        $podbean_url = $request->podbean_url;
        $external_url = $request->external_url;
        $description = $request->description;
        $media_exist = DB::table('podcast_media')->where('id', '!=', $id)->where('title', $title)->count();
        if ($media_exist > 0) {
            return json_encode(array('success' => '201', 'message' => 'Media with title already exist. Please try with new one.'));
        }

        if ($type == 'AUDIO') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ","_",$fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';
                
                Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                //$file->move($destinationPath, $fileNameUnique);
                $image = $fileNameUnique;
            } else {
                $image = $get_last_media->attachment_name;
            }
        } elseif ($type == 'IMAGE') {
            if ($podbean_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $podbean_url;
            }
        } elseif ($type == 'YOUTUBE') {
            if ($youtube_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $youtube_url;
            }
        } elseif ($type == 'EXTERNAL') {
            if ($external_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $external_url;
            }
        }


        if ($title == null) {
            return json_encode(array('success' => '201', 'message' => 'Title is required'));
        }

        if ($description == '') {
            return json_encode(array('success' => '201', 'message' => 'Descriprtion is required'));
        }
        if ($request->file('thumbnail')) {
                $file = $request->file('thumbnail');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ","_",$fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/thumbnail/';
                $file->move($destinationPath, $fileNameUnique);
                $imagethumb = $fileNameUnique;
            }else{
                $imagethumb = $get_last_media->thumbnail;
            } 

//            $slug = str_slug($title, '-');
        //echo $get_last_media; die;
       
        if(isset($shabad_id) && !empty($shabad_id)){
            $podcast_media_cou=DB::table('podcast_media')->where('id', '!=', $id)->where('shabad_id',$shabad_id)->where('language',$language)->count();
            if($podcast_media_cou>0){
                DB::table('podcast_media')->where('shabad_id',$shabad_id)->update([
                    'over_right'=>'0'
                ]);
            }
        }    
        
        DB::table('podcast_media')->where('id', $id)->update([
            'title' => $title,
            'description' => $description,
            'language' => $language,
            'thumbnail' => $imagethumb,
            'shabad_id' => $shabad_id,
            'ref_type' => 'RESOURCE',
            'type' => $type,
            'attachment_name' => $image,
            'status' => '1',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        DB::table('podcast_media_tags')->where('media_id', $id)->delete();
        DB::table('podcast_media_categories')->where('media_id', $id)->delete();
        DB::table('podcast_media_subcategories')->where('media_id', $id)->delete();

        if ($request->tag_id) {
            DB::table('podcast_media_tags')->insert([
                'media_id' => $id,
                'tag_id' => $request->tag_id,
            ]);
        }

        if ($request->input('category')) {
            $all_cats = json_decode($request->input('category'));
            foreach ($all_cats as $all_cat) {
                DB::table('podcast_media_categories')->insertGetId([
                    'media_id' => $id,
                    'category_id' => $all_cat->cat_id
                        ]
                );
            }
        }

        if ($request->new_category != null) {
            $slug = str_slug($request->new_category, '-');
            $new_cat_id = DB::table('podcast_categories')->insertGetId([
                'slug' => $slug,
                'name' => $request->new_category,
                'status' => '1'
                    ]
            );

            DB::table('podcast_media_subcategories')->insertGetId([
                'media_id' => $id,
                'category_id' => $new_cat_id
                    ]
            );
        }

        if ($request->input('sub_category')) {
            $all_subcats = json_decode($request->input('sub_category'));
            foreach ($all_subcats as $all_subcat) {
                $subcats_data = DB::table('podcast_subcategories')->where('id', $all_subcat->sub_cat_id)->first();
                DB::table('podcast_media_subcategories')->insertGetId([
                    'media_id' => $id,
                    'subcategory_id' => $all_subcat->sub_cat_id
                        ]
                );

                $cat_exist = DB::table('podcast_media_categories')->where('media_id', $id)->where('category_id', $subcats_data->category_id)->count();
                if ($cat_exist == 0) {
                    DB::table('podcast_media_categories')->insertGetId([
                        'media_id' => $id,
                        'category_id' => $subcats_data->category_id
                            ]
                    );
                }

//                    DB::table('media_categories')->insertGetId([
//                        'media_id' => $id,
//                        'category_id' => $subcats_data->category_id
//                            ]
//                    );
            }
        }

        return json_encode(array('success' => '200', 'message' => 'New media updated successfully.'));
    }

    //Update media END
    //update Media Author status START
    public function update_status_media(Request $request, $id) {
        $status = $request->status;
        $podcast_cat_check = DB::table('media')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1') {
                DB::table('media')->where('id', $id)->update([
                    'status' => $status
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if ($status == '0') {
                DB::table('media')->where('id', $id)->update([
                    'status' => $status
                ]);
                DB::table('media')->where('id', $id)->update([
                    'status' => $status,
                    'featured'=>'0',
                    'featured_display_order'=>NULL
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if($status!='0' || $status!='1') {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No media Exist with this detail'));
        }
    }

    //update Media Author status END
    //delete media author START
    public function delete_media(Request $request, $id) {
        $podcast_cat_check = DB::table('media')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('media')->where('id', $id)->delete();
            DB::table('media_tags')->where('media_id', $id)->delete();
            DB::table('media_categories')->where('media_id', $id)->delete();
            DB::table('media_subcategories')->where('media_id', $id)->delete();
            return json_encode(array('success' => '200', 'message' => 'Media author has been deleted successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'No author Exist with this detail'));
        }
    }

    //delete media author END    
    //delete media author START
    public function delete_podcast_media(Request $request, $id) {
        $podcast_cat_check = DB::table('podcast_media')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('podcast_media')->where('id', $id)->delete();
//            DB::table('media_tags')->where('media_id',$id)->delete();
            DB::table('podcast_media_categories')->where('media_id', $id)->delete();
            DB::table('podcast_media_subcategories')->where('media_id', $id)->delete();
            return json_encode(array('success' => '200', 'message' => 'Podcast Media has been deleted successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'No podcast media Exist with this detail'));
        }
    }

    //delete media author END  
    //Get media audit list START
    public function audit_list(Request $request) {
        $all_medias = DB::table('media')->get();
        if (count($all_medias) > 0) {
            foreach ($all_medias as $all_media) {
                if ($all_media->attachment_name == null || $all_media->attachment_name == '') {
                    $media_url = '';
                } else {
                    if ($all_media->type == 'AUDIO') {
                        $media_url = url('uploads/media/') . '/' . $all_media->attachment_name;
                    } else {
                        $media_url = $all_media->attachment_name;
                    }
                }
                $media_distinct_count = DB::table('media_play')->where('media_id', $all_media->id)->count();
                $result [] = array(
                    'media_id' => $all_media->id,
                    'media_title' => $all_media->title,
                    'media_url' => $media_url,
                    'media_start_date' => $all_media->play_start_date,
                    'media_start_time' => $all_media->play_start_time,
                    'media_last_date' => $all_media->play_last_date,
                    'media_last_time' => $all_media->play_last_time,
                    'media_distinct_count' => $media_distinct_count,
                );
            }
        }else{
            $result = [];
        }

        return json_encode(array('status' => '200', 'message' => 'Media Audit List', 'result' => $result));
    }

    //Get media audit list END
    
    //shabad data START
    public function shabad_data(Request $request,$id){
        $medias = DB::table('podcast_media')->where('shabad_id',$id)->where('over_right','1')->get();
        $all_cats_media = [];
        $all_categories_media = '';
//        echo "<pre>"; print_r($medias); die;
        foreach ($medias as $media) {
//            $author_data=DB::table('media_authors')->where('id',$media->author_id)->first();
//            $author_tags=DB::table('media_tags')->where('media_id',$media->id)->first();
//            echo "<pre>"; print_r($author_tags); die;
//            $tags_data=DB::table('tags')->where('id',$author_tags->tag_id)->first();
            $all_media_cats = DB::table('podcast_categories')
                    ->leftjoin('podcast_media_categories', 'podcast_media_categories.category_id', '=', 'podcast_categories.id')
                    ->select('podcast_categories.name')
                    ->where('podcast_media_categories.media_id', '=', $media->id)
                    ->get();
//            echo "<pre>"; print_r($author_tags); die; 
            $all_cats_media = [];
            if (count($all_media_cats) > 0) {
                foreach ($all_media_cats as $all_media_cat) {
                    $all_cats_media[] = $all_media_cat->name;
                }
                $all_categories_media = implode(',', $all_cats_media);
                $all_comma_cats = rtrim($all_categories_media, ',');
            } else {
                $all_comma_cats = [];
            }
            
            ///////////////////////////////
            $all_media_subcats = DB::table('podcast_subcategories')
                    ->leftjoin('podcast_media_subcategories', 'podcast_media_subcategories.subcategory_id', '=', 'podcast_subcategories.id')
                    ->select('podcast_subcategories.name')
                    ->where('podcast_media_subcategories.media_id', '=', $media->id)
                    ->get();
//            echo "<pre>"; print_r($author_tags); die; 
            $all_subcats_media = [];
            if (count($all_media_subcats) > 0) {
                foreach ($all_media_subcats as $all_media_subcat) {
                    $all_subcats_media[] = $all_media_subcat->name;
                }
                $all_subcategories_media = implode(',', $all_subcats_media);
                $all_comma_subcats = rtrim($all_subcategories_media, ',');
            } else {
                $all_comma_subcats = [];
            }
            

            $type = $media->type;
                if ($type == 'IMAGE') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'YOUTUBE') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'EXTERNAL') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'AUDIO') {
                    $image_a = url('uploads/podcast_media/') . '/' . $media->attachment_name;
                }
            if ($media->thumbnail == null || $media->thumbnail == '') {
                    $thumbnail_pod = '';
                } else {
                    $thumbnail_pod = url('uploads/thumbnail/') . '/' . $media->thumbnail;
                } 
            $data[] = array(
                'id' => $media->id,
                'type' => $media->type,
                'description' => $media->description,
                'shabad_id' => $media->shabad_id,
                'language' => $media->language,
                'title' => $media->title,
                'thumbnail_pod' => $thumbnail_pod,
                'status' => $media->status,
                'today_approval' => $media->today_approval,
                'attachment_name' => $image_a,
                'media_categories' => $all_comma_cats,
                'media_subcategories' => $all_comma_subcats,
//                'media_tag'=>$tags_data->name
            );
        }
        return json_encode(array('status' => '200', 'message' => 'Podcast Media List', 'result' => $data));
    }
    //shabad data END  
    ///////////// Media Management APIs ///////////////////////
}
