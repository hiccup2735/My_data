<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\AdminController;
use App\Http\Requests\Admin\StoreMediaAuthorRequest;
use App\Http\Requests\Admin\UpdateMediaAuthorRequest;
use App\Models\MediaAuthor;
use App\Repositories\Admin\MediaAuthorsRepository;
use Illuminate\Http\Request;
use DB;
use Auth;
class MediaAuthorsController extends AdminController
{
    protected $repository;

	public function __construct(MediaAuthorsRepository $repository)
	{
		$this->repository = $repository;
	}

	/**
     * get list of all the categories.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function index($item = null, Request $request)
    {
    	$items = $this->repository->paginate($request);

    	return view('admin.media-authors.index', [
    		'items' => $items,
            'item' => $item
    	]);
    }

    public function store(StoreMediaAuthorRequest $request, MediaAuthor $entity)
    {
        if ($request->file('image')) {
//            echo 'true';die;
            $file = $request->file('image');
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/author/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
//             echo 'false';die;
            $image = "";
        }
        try {
            if(Auth::user()->id=='1'){
                $status_cat = '1';
            }else{
                $status_cat = $request->input('status');
            }
            $entity->setName($request->input('name'))
                ->setImage($image)
                ->setStatus($status_cat);
//            echo "<pre>";print_r($entity); die;
            $item = $this->repository->save($entity);
            return redirect()->route('admin.media.authors.index')
                            ->with('success','Author has been created sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.authors.index')
                            ->with('error','Author could not be created. Please try again.');
        }
    }

    public function update($item, UpdateMediaAuthorRequest $request)
    {
        if ($request->file('image')) {
//            echo 'true';die;
            $file = $request->file('image');
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/author/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
//             echo 'false';die;
            $image = $item->image;
        }
        try {
            if(Auth::user()->id=='1'){
                $status_cat = '1';
            }else{
                $status_cat = $request->input('status');
            }
            $item->setName($request->input('name'))
                ->setImage($image)
                ->setStatus($status_cat);

            $item = $this->repository->update($item->getKey(), $item);
            return redirect()->route('admin.media.authors.index')
                            ->with('success','Author has been updated sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.authors.index')
                            ->with('error','Author could not be updated. Please try again.');
        }
    }

    /**
     * delete category
     *
     * @param  $entity: App\Models\MediaAuthor
     * @return json response.
     */
    public function delete(MediaAuthor $entity)
    {
        try {
            
            $entity->delete();
            return redirect()->route('admin.media.authors.index')
                            ->with('success','Author has been deleted sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.authors.index')
                            ->with('error','Author could not be deleted. Please try again.');
        }
        return $this->respondDeleted([]);
        
    }

    /**
     * change status with previous status
     *     if previously status was active then mark as inactive and vice-versa
     *     
     * @param  $media: App\Models\MediaAuthor
     * @return json response.
     */
    public function toggleStatus(MediaAuthor $item)
    {
        try {
            
            $item = $this->repository->toggleStatus($item->getKey());
            return redirect()->route('admin.media.authors.index')
                            ->with('success','Status has been updated sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.authors.index')
                            ->with('error','Status could not be updated!');
        }
    }
}
