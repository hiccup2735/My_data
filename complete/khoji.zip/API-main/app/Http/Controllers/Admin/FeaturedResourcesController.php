<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\AdminController;
use App\Repositories\Admin\MediaAuthorsRepository;
use App\Repositories\Admin\MediaCategoriesRepository;
use App\Repositories\Admin\MediaRepository;
use Illuminate\Http\Request;
use DB;
use Auth;

class FeaturedResourcesController extends AdminController {

    protected $mediaRepo;
    protected $mediaAuthorRepo;
    protected $mediaCategoriesRepo;

    public function __construct(MediaRepository $mediaRepo, MediaAuthorsRepository $mediaAuthorRepo, MediaCategoriesRepository $mediaCategoriesRepo) {
        $this->mediaRepo = $mediaRepo;
        $this->mediaAuthorRepo = $mediaAuthorRepo;
        $this->mediaCategoriesRepo = $mediaCategoriesRepo;
    }

    /**
     * show featured items resources view.
     * 
     * @param  Request $request: Illuminate\Http\Request
     * @return html view.
     */
    public function index(Request $request) {
        $featuredMedia = $this->mediaRepo->getFeaturedMediaList();
        $featuredAuthor = $this->mediaAuthorRepo->getFeaturedAuthorList();
        $featuredCategories = $this->mediaCategoriesRepo->getFeaturedCategoriesList();
//        $a=0;
//        $dataCat=[];
//        foreach($featuredCategories as $key=>$featuredCategori){
//            $dataCat[$a]['id'] = $key;
//            $dataCat[$a]['text'] = $featuredCategori;
//            $a++;
//        }
//        
//        $usersAuthors = DB::table('media_authors')
//                        ->join('media', 'media.author_id', '=', 'media_authors.id')
//                        ->select('media_authors.id', 'media_authors.name')
//                        ->where('media.featured', true)
//                        ->get();
//        $featuredAuthor = [];
//        foreach($usersAuthors as $ke1=>$usersAuthor){
//            $featuredAuthor[$usersAuthor->id] = $usersAuthor->name;
//        }
        //dd($featuredCategories);
        return view('admin.featured-resources.index', [
            'featuredMedia' => $featuredMedia,
            'featuredAuthor' => $featuredAuthor,
            'featuredCategories' => $featuredCategories,
        ]);
    }

    /**
     * get list of media items.
     * 
     * @param  Request $request: Illuminate\Http\Request
     * @return json list of media
     */
    public function getMediaList(Request $request) {
        $items = $this->mediaRepo->getMediaPaginateList($request);
        return $this->respond($items);
    }

    public function getAuthorsList(Request $request) {
        $items = $this->mediaAuthorRepo->getAuthorPaginateList($request);
        //echo"<pre>";print_r($items); die;
        return $this->respond($items);
    }

    public function getCategoriesList(Request $request) {
        $items = $this->mediaCategoriesRepo->getCategoriesPaginateList($request);
        return $this->respond($items);
    }

    /**
     * store featured media items.
     * 
     * @param  Request $request: Illuminate\Http\Request
     * @return redirect to featured view.
     */
    public function storeFeaturedMedia(Request $request) {
        $mediaIds = $request->input('media');
//        die;
        if (!$mediaIds) {
            return redirect()->back()
                            ->with('error', 'Please select atleast one media.');
        }
//        echo "<pre>"; print_r($mediaIds); die;
        try {

            DB::table('media')->update([
                'featured' => '0',
                'featured_display_order' => null,
            ]);
            //die;
            $this->mediaRepo->markAsFeatured($mediaIds);
            return redirect()->route('admin.featured.resources.index')
                            ->with('success', 'Selected media items are marked as featured.');
        } catch (Exception $e) {
            return redirect()->route('admin.featured.resources.index')
                            ->with('error', $e->getMessage());
        }
    }

    /**
     * store featured author items.
     * 
     * @param  Request $request: Illuminate\Http\Request
     * @return redirect to featured view.
     */
    public function storeFeaturedAuthor(Request $request) {

        $authorIds = $request->input('authors');
        if (!$authorIds) {
            return redirect()->back()
                            ->with('error', 'Please select atleast one artist.');
        }

        try {
            //echo "<pre>";print_r($authorIds); die;
            DB::table('media_authors')->update([
                'featured' => '0',
                'featured_display_order' => null,
            ]);
//            die;
            $this->mediaAuthorRepo->markAsFeatured($authorIds);
            return redirect()->route('admin.featured.resources.index')
                            ->with('success', 'Selected artists are marked as featured.');
        } catch (Exception $e) {
            return redirect()->route('admin.featured.resources.index')
                            ->with('error', $e->getMessage());
        }
    }

    /**
     * store featured category items.
     * 
     * @param  Request $request: Illuminate\Http\Request
     * @return redirect to featured view.
     */
    public function storeFeaturedCategories(Request $request) {
        $categoryIds = $request->input('categories');
        //dd($categoryIds);
        if (!$categoryIds) {
            return redirect()->back()
                            ->with('error', 'Please select atleast one category.');
        }

        try {
            DB::table('categories')->update([
                'featured' => '0',
                'featured_display_order' => null,
            ]);
            $this->mediaCategoriesRepo->markAsFeatured($categoryIds);
            return redirect()->route('admin.featured.resources.index')
                            ->with('success', 'Selected categories are marked as featured.');
        } catch (Exception $e) {
            return redirect()->route('admin.featured.resources.index')
                            ->with('error', $e->getMessage());
        }
    }

    public function podcast_list(Request $request) {
        
        $feed = 'https://feed.podbean.com/khojgurbani/feed.xml';
        $feed_to_array = (array) simplexml_load_file($feed);
        $feddarrayData = json_decode(json_encode((array) $feed_to_array), TRUE);
        $final_feed_data = $feddarrayData['channel']['item'];
        $a = 1;
        foreach ($final_feed_data as $final_feeds) {
            $items[] = array(
                '_id' => $a,
                'title' => $final_feeds['title'],
                'date' => $final_feeds['pubDate'],
                'media_data' => $final_feeds['enclosure']['@attributes'],
            );
            $a++;
        }
        return view('admin.podcast.index', get_defined_vars());
    }

    public function add_today(Request $request, $id, $title) {

        $url = $_GET['url'];
        $podcast_exist = DB::table('podcast_media')->where('attachment_name', $url)->count();
        if ($podcast_exist > 0) {
            DB::table('podcast_media')->where('attachment_name','!=', $url)->update([
                'today_approval' => '0'
            ]);
            DB::table('podcast_media')->where('attachment_name', $url)->update([
                'today_approval' => '1'
            ]);
        } else {
            DB::table('podcast_media')->update([
                'today_approval' => '0'
            ]);
            DB::table('podcast_media')->insert([
                'author_id' => Auth::user()->id,
                'shabad_id' => '1',
                'ref_type' => 'RESOURCE',
                'title' => $title,
                'attachment_name' => $url,
                'type' => 'IMAGE',
                'today_approval' => '1',
                'status' => '1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }

        return redirect()->back()
                        ->with('success', 'Podcast Media as been marked for today successfully.');
    }

    public function remove_today(Request $request) {
        DB::table('podcast_media')->update([
            'today_approval' => '0'
        ]);
        return redirect()->back()
                        ->with('success', 'Podcast Media as been un-marked for today successfully.');
    }

}
