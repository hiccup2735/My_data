<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\AdminController;
use App\Http\Requests\Admin\StoreCategoryRequest;
use App\Http\Requests\Admin\UpdateCategoryRequest;
use App\Models\Category;
use App\Repositories\Admin\MediaCategoriesRepository;
use Exception;
use Illuminate\Http\Request;
use Auth;
class MediaCategoriesController extends AdminController {

    protected $repository;

    public function __construct(MediaCategoriesRepository $repository) {
        $this->repository = $repository;
    }

    /**
     * get list of all the categories.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function index($category = null, Request $request) {
        $items = $this->repository->paginate($request);
//        echo "<pre>"; print_r($category); die;
        return view('admin.media-categories.index', [
            'items' => $items,
            'category' => $category
        ]);
    }

    public function store(StoreCategoryRequest $request, Category $entity) {
        if ($request->file('image')) {
//            echo 'true';die;
            $file = $request->file('image');
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/category/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
//             echo 'false';die;
            $image = "";
        }
        try {
            if(Auth::user()->id=='1'){
                $status_cat = '1';
            }else{
                $status_cat = $request->input('status');
            }
            $entity->setName($request->input('name'))
                    ->setDescription($request->input('description'))
                    ->setImage($image)
                    ->setStatus($status_cat);
           
            $item = $this->repository->save($entity);
           
            return redirect()->route('admin.media.categories.index')
                            ->with('success', 'Category has been created sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.categories.index')
                            ->with('error', 'Category could not be created. Please try again.');
        }
    }

    public function update($category, UpdateCategoryRequest $request) {
         if ($request->file('image')) {
//            echo 'true';die;
            $file = $request->file('image');
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/category/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
//             echo 'false';die;
            $image = $category->image;
        }
        try {
            $category->setName($request->input('name'))
                    ->setDescription($request->input('description'))
                    ->setImage($image)
                    ->setStatus((bool) $request->input('status'));

            $item = $this->repository->update($category->getKey(), $category);
            return redirect()->route('admin.media.categories.index')
                            ->with('success', 'Category has been updated sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.categories.index')
                            ->with('error', 'Category could not be updated. Please try again.');
        }
    }

    /**
     * delete category
     *
     * @param  $entity: App\Models\Category
     * @return json response.
     */
    public function delete(Category $entity) {
        try {

            $entity->delete();
            return redirect()->route('admin.media.categories.index')
                            ->with('success', 'Category has been deleted sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.categories.index')
                            ->with('error', 'Category could not be deleted. Please try again.');
        }
        return $this->respondDeleted([]);
    }

    /**
     * change status with previous status
     *     if previously status was active then mark as inactive and vice-versa
     *     
     * @param  $media: App\Models\Category
     * @return json response.
     */
    public function toggleStatus(Category $category) {
        try {

            $item = $this->repository->toggleStatus($category->getKey());
            return redirect()->route('admin.media.categories.index')
                            ->with('success', 'Status has been updated sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.categories.index')
                            ->with('error', 'Status could not be updated!');
        }
    }

}
