<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\AdminController;
use App\Repositories\Admin\ScriptureRepository;
use Illuminate\Http\Request;

class ShabadsController extends AdminController
{
    protected $scriptureRepo;

	public function __construct(ScriptureRepository $scriptureRepo)
	{
		$this->scriptureRepo = $scriptureRepo;
	}

	public function getList(Request $request)
	{
		$shabads = $this->scriptureRepo->getShabadList($request);
//                echo "<pre>"; print_r($shabads); die;
		return $this->respond($shabads);
	}

	public function create()
	{
		$authors = $this->mediaAuthorRepo->getList();
		
		return view('admin.media.create', [
			'authors' => $authors,
			'shabads' => []//$shabads
		]);
	}
}
