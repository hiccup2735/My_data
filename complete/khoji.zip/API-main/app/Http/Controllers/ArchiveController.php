<?php

namespace App\Http\Controllers;

use App\Http\Controllers\ApiController;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Requests\Api\CreateMediaRequest;
use App\Models\Media;
use App\Repositories\MediaAuthorsRepository;
use App\Repositories\MediaRepository;
use App\Transformers\Api\MediaTransformer;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use Exception;
use DB;

class ArchiveController extends ApiController {

    protected $repository;
    protected $mediaAuthorRepository;

    public function __construct(MediaRepository $repository, MediaAuthorsRepository $mediaAuthorRepository) {
        $this->repository = $repository;
        $this->mediaAuthorRepository = $mediaAuthorRepository;
    }
      //archive list START
      public function archive(Request $request) {
        $feed = 'https://feed.podbean.com/khojgurbani/feed.xml';
        $feed_to_array = (array) simplexml_load_file($feed);
        $feddarrayData = json_decode(json_encode((array) $feed_to_array), TRUE);
        $final_feed_data = $feddarrayData['channel']['item'];

        foreach ($final_feed_data as $final_feeds) {
            $data[] = array(
                'title' => $final_feeds['title'],
                'date' => $final_feeds['pubDate'],
                'media_data' => $final_feeds['enclosure']['@attributes'],
            );
        }
        return json_encode(array('status' => '200', 'message' => 'archive list', 'result' => $data));
    }

    //podcast list END
     //archive index START
     public function archive_index(Request $request) {

        $final_feeds_count = DB::table('archive_media')->where('today_approval', '1')->orderBy('id', 'desc')->count();
        if ($final_feeds_count > 0) {
            $final_feeds = DB::table('archive_media')->where('today_approval', '1')->orderBy('id', 'desc')->first();

            $result12 = substr($final_feeds->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $attachment_file = $final_feeds->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/archive_media/') . '/' . $final_feeds->attachment_name;
            }
            //s3 starts here
            // $exists = Storage::disk('s3archive')->exists($final_feeds->attachment_name);
                  
            // if($exists){
            //  $attachment_file = Storage::disk('s3archive')->url($final_feeds->attachment_name);
            // }else{
            //     $attachment_file = $final_feeds->attachment_name;
            // }
            //s3 ends here
            $data[] = array(
                'id' => $final_feeds->id,
                'title' => $final_feeds->title,
                'media_data' => $attachment_file,
                'updated_at' =>$final_feeds->updated_at,
                'time' => '00:50:29'
            );
        } else {
            $final_feeds = DB::table('archive_media')->orderBy('id', 'desc')->first();
            $result12 = substr($final_feeds->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $attachment_file = $final_feeds->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/archive_media/') . '/' . $final_feeds->attachment_name;
            }
            //s3 starts here
            // $exists = Storage::disk('s3archive')->exists($final_feeds->attachment_name);
                  
            //     if($exists){
            //      $attachment_file = Storage::disk('s3archive')->url($final_feeds->attachment_name);
            //     }else{
            //         $attachment_file = $final_feeds->attachment_name;
            //     }
                //s3 ends here
            $data[] = array(
                'id' => $final_feeds->id,
                'title' => $final_feeds->title,
                'media_data' => $attachment_file,
                'updated_at' =>$final_feeds->updated_at,
                'time' => '00:50:29'
            );
        }


        return json_encode(array('status' => '200', 'message' => 'Today archive', 'result' => $data));
    }

    //podcast index END

      //latest archive START
      public function latest_archive_second() {
           $data = array();
        $last_media_podcast = DB::table('archive_media')->orderBy('id', 'desc')->first();
        $last_5_archive_c = DB::table('archive_media')->where('today_approval', '0')->count();
        if ($last_5_archive_c > 0) {
            $last_5_archives = DB::table('archive_media')->where('today_approval', '0')->orderBy('id', 'desc')->take(5)->get();
            foreach ($last_5_archives as $last_5_archive) {
                
                // $exists = Storage::disk('s3archive')->exists($last_5_archive->attachment_name);
                  
                // if($exists){
                //  $archiveName = Storage::disk('s3archive')->url($last_5_archive->attachment_name);
                // }else{
                    $archiveName = $last_5_archive->attachment_name;
                //}
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $archiveName,
                    'time' => '00:50:29'
                );
            }
        } else {
            $last_5_archives = DB::table('archive_media')->where('today_approval', '0')->orderBy('id', 'desc')->take(5)->get();
            foreach ($last_5_archives as $last_5_archive) {
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $last_5_archive->attachment_name,
                    'time' => '00:50:29'
                );
            }
        }


        return json_encode(array('status' => '200', 'message' => 'Last 5 Archive', 'result' => $data));
    }

    //latest archive END
    //all archive START
    public function all_archive_second() {
        $data = array();
        $last_media_podcast = DB::table('archive_media')->orderBy('id', 'desc')->first();
        $last_5_archive_c = DB::table('archive_media')->where('id', '!=', $last_media_podcast->id)->orderBy('id', 'desc')->count();
        if ($last_5_archive_c > 0) {
            $last_5_archives = DB::table('archive_media')->where('id', '!=', $last_media_podcast->id)->orderBy('id', 'desc')->get();
            foreach ($last_5_archives as $last_5_archive) {
                // $exists = Storage::disk('s3archive')->exists($last_5_archive->attachment_name);
                  
                // if($exists){
                //  $archiveName = Storage::disk('s3archive')->url($last_5_archive->attachment_name);
                // }else{
                    $archiveName = $last_5_archive->attachment_name;
               // }
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $archiveName,
                    'time' => '00:50:29'
                );
            }
        } else {
            $last_5_archives = DB::table('archive_media')->where('id', '!=', $last_media_podcast->id)->orderBy('id', 'desc')->get();
            foreach ($last_5_archives as $last_5_archive) {
                // $exists = Storage::disk('s3archive')->exists($last_5_archive->attachment_name);
                  
                // if($exists){
                //  $archiveName = Storage::disk('s3archive')->url($last_5_archive->attachment_name);
                // }else{
                    $archiveName = $last_5_archive->attachment_name;
                // }
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $archiveName,
                    'time' => '00:50:29'
                );
            }
        }


        return json_encode(array('status' => '200', 'message' => 'All Archives', 'result' => $data));
    }

    //all archive END
     //Archive list START
     public function archive_list(Request $request) {
        $feed = 'https://feed.podbean.com/khojgurbani/feed.xml';
        $feed_to_array = (array) simplexml_load_file($feed);
        $feddarrayData = json_decode(json_encode((array) $feed_to_array), TRUE);
        $final_feed_data = $feddarrayData['channel']['item'];
//        echo "<pre>"; print_r($final_feed_data); die;
        foreach ($final_feed_data as $final_feeds) {
            $description1 = "In this episode, Chetandeep Singh presents his understanding of the shabad " . "'" . $final_feeds['title'] . "'" . " followed by a discussion and Q&A with the panelists of Khoj Gurbani.";

            $description2 = "KhojGurbani is an online platform with a mission to make the Guru Granth Sahib accessible to and exciting for the common Sikh, who wants to read Gurbani but does not have the tools and a support network to do so. While KhojGurbani will engage Sikhs globally in discussion on specific sections of Guru Granth Sahib every week, it will also spearhead the development of a crowdsourced commentary and a new idiomatic English translation.";

            $visit = "Visit http://www.khojgurbani.org/ for more information";
            $today_podcast_first = DB::table('archive_media')->where('today_approval', '1')->orderBy('id', 'desc')->first();
            if ($today_podcast_first->attachment_name == $final_feeds['enclosure']['@attributes']['url']) {
                $today_approval = '1';
            } else {
                $today_approval = '0';
            }
            $datas[] = array(
                'title' => $final_feeds['title'],
                'date' => $final_feeds['pubDate'],
                'media_data' => $final_feeds['enclosure']['@attributes'],
                'description1' => $description1,
                'description2' => $description2,
                'visit' => $visit,
                'date' => $final_feeds['pubDate'],
                'today_approva' => $today_approval,
            );
        }
        $a = 1;

        if (isset($_GET['search']) && $_GET['search'] != '') {
            foreach ($datas as $ke => $datass) {
                if ((strpos($datass['description1'], ucfirst($_GET['search'])) == 0 && strpos($datass['description1'], $_GET['search']) == 0) && (strpos($datass['title'], ucfirst($_GET['search'])) == 0 && strpos($datass['title'], $_GET['search']) == 0) && (strpos($datass['description2'], ucfirst($_GET['search'])) == 0 && strpos($datass['description2'], $_GET['search']) == 0)) {
                    unset($datas[$ke]);
                }
            }
        }
//        echo "<pre>";
//        print_r($datas);
//        die;
        if (count($datas) > 0) {
            foreach ($datas as $ke => $datass) {
                $today_podcast_first = DB::table('archive_media')->where('today_approval', '1')->orderBy('id', 'desc')->first();
                if ($today_podcast_first->attachment_name == $datass['media_data']['url']) {
                    $today_approval = '1';
                } else {
                    $today_approval = '0';
                }
                $title = $datass['title'];
                $media = $datass['media_data']['url'];
                $data[] = array(
                    'id' => $a,
                    'title' => $title,
                    'media' => $media,
                    'description1' => $datass['description1'],
                    'description2' => $datass['description2'],
                    'visit' => $datass['visit'],
                    'date' => $datass['date'],
                    'today_approval' => $today_approval,
                );
                $a++;
            }
        } else {
            $data = [];
        }
//        echo "<pre>"; print_r($descr1); die;
        return json_encode(array('status' => '200', 'message' => 'archive list', 'result' => $data));
    }

    //podcast list END
     //Add today 
     public function add_today_archive() 
     {
         
         $url = $_GET['url'];
         $title = $_GET['title'];
         $podcast_exist = DB::table('archive_media')->where('attachment_name', $url)->count();
         if ($podcast_exist > 0) {
             DB::table('archive_media')->where('attachment_name', '!=', $url)->update([
                 'today_approval' => '0'
             ]);
             DB::table('archive_media')->where('attachment_name', $url)->update([
                 'today_approval' => '1'
             ]);
         } else {
             DB::table('archive_media')->update([
                 'today_approval' => '0'
             ]);
             DB::table('archive_media')->insert([
 //                'author_id' => Auth::user()->id,
                 'shabad_id' => '1',
                 'ref_type' => 'RESOURCE',
                 'title' => $title,
                 'attachment_name' => $url,
                 'type' => 'IMAGE',
                 'today_approval' => '1',
                 'status' => '1',
                 'created_at' => date('Y-m-d H:i:s'),
             ]);
         }
         return json_encode(array('status' => '200', 'message' => 'Archive Media as been marked for today successfully.'));
     }
 
     public function updateArchiveStatus()
     {
         $id = $_GET['id'];
         DB::table('archive_media')->where('id', $id)->update([
                 'today_approval' => '1'
         ]);
         DB::table('archive_media')->where('id', '!=', $id)->update([
             'today_approval' => '0'
         ]);
         return json_encode(array('status' => '200', 'message' => 'Archive Media status updated successfully.'));
     }

      ///////////// Archive Management APIs ///////////////////////
    //Add archive START
    public function archive_add(Request $request) {
        //        $author_id = $request->author_id;
                $shabad_id = $request->shabad_id;
                $language = $request->language;
                $ref_type = $request->ref_type;
                $title = $request->title;
                $description = $request->description;
                $type = $request->type; //AUDIO,YOUTUBE,IMAGE
                $youtube_url = $request->youtube_url;
                $podbean_url = $request->podbean_url;
                $external_url = $request->external_url;
                if ($type == 'AUDIO') {
                    if ($request->file('attachment_name')) {
                        $file = $request->file('attachment_name');
                        $imageType = $file->getClientmimeType();
                        $fileNameO = $file->getClientOriginalName();
                        $fileName = str_replace(" ","_",$fileNameO);
        
                        $fileNameUnique = time() . '_' . $fileName;
                        $destinationPath = public_path() . '/uploads/archive_media/';
                         Storage::disk('s3archive')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                         $fileNameUnique = Storage::disk('s3archive')->url($fileNameUnique);
                         // die;
                        //$file->move($destinationPath, $fileNameUnique);
                        $image = $fileNameUnique;
                    } else {
                        return json_encode(array('success' => '201', 'message' => 'MP3 File is required'));
                    }
                } elseif ($type == 'IMAGE') {
                    if ($podbean_url == '') {
                        return json_encode(array('success' => '201', 'message' => 'Podbean URL is required'));
                    }
                    $image = $podbean_url;
                } elseif ($type == 'YOUTUBE') {
                    if ($youtube_url == '') {
                        return json_encode(array('success' => '201', 'message' => 'Youtube URL is required'));
                    }
                    $image = $youtube_url;
                }
                elseif ($type == 'EXTERNAL') {
                    if ($external_url == '') {
                        return json_encode(array('success' => '201', 'message' => 'External URL is required'));
                    }
                    $image = $external_url;
                }
        
        
                if ($title == '') {
                    return json_encode(array('success' => '201', 'message' => 'Title is required'));
                }
                
                if ($description == '') {
                    return json_encode(array('success' => '201', 'message' => 'Descriprtion is required'));
                }
        
        
                if ($request->file('thumbnail')) {
                        $file = $request->file('thumbnail');
                        $imageType = $file->getClientmimeType();
                        $fileNameO = $file->getClientOriginalName();
                        $fileName = str_replace(" ","_",$fileNameO);
        
                        $fileNameUnique = time() . '_' . $fileName;
                        $destinationPath = public_path() . '/uploads/thumbnail/';
                        $file->move($destinationPath, $fileNameUnique);
                        $imagethumb = $fileNameUnique;
                    } else {
                        $imagethumb = '';
                    } 
        
        //            $slug = str_slug($title, '-');
                if(isset($shabad_id) && !empty($shabad_id)){
                    $podcast_media_cou=DB::table('archive_media')->where('shabad_id',$shabad_id)->where('language',$language)->count();
                    if($podcast_media_cou>0){
                        DB::table('archive_media')->where('shabad_id',$shabad_id)->update([
                            'over_right'=>'0'
                        ]);
                    }
                }    
                $media_id = DB::table('archive_media')->insertGetId([
                    'title' => $title,
                    'language' => $language,
                    'description' => $description,
                    'thumbnail' => $imagethumb,
                    'shabad_id' => $shabad_id,
                    'ref_type' => 'RESOURCE',
                    'type' => $type,
                    'attachment_name' => $image,
                    'status' => '1',
                    'today_approval' => '0',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
        
                if ($request->tag_id) {
                    DB::table('archive_media_tags')->insert([
                        'media_id' => $media_id,
                        'tag_id' => $request->tag_id,
                    ]);
                }
        
                if ($request->input('category')) {
                    $all_cats = json_decode($request->input('category'));
                    foreach ($all_cats as $all_cat) {
                        DB::table('archive_media_categories')->insertGetId([
                            'media_id' => $media_id,
                            'category_id' => $all_cat->cat_id
                                ]
                        );
                    }
                }
        
                if ($request->new_category != null) {
                    $slug = str_slug($request->new_category, '-');
                    $new_cat_id = DB::table('archive_categories')->insertGetId([
                        'slug' => $slug,
                        'name' => $request->new_category,
                        'status' => '1'
                            ]
                    );
        
                    DB::table('archive_media_categories')->insertGetId([
                        'media_id' => $media_id,
                        'category_id' => $new_cat_id
                            ]
                    );
                }
        
                if ($request->input('sub_category')) {
                    $all_subcats = json_decode($request->input('sub_category'));
                    foreach ($all_subcats as $all_subcat) {
                        $subcats_data = DB::table('archive_subcategories')->where('id', $all_subcat->sub_cat_id)->first();
                        DB::table('archive_media_subcategories')->insertGetId([
                            'media_id' => $media_id,
                            'subcategory_id' => $all_subcat->sub_cat_id
                                ]
                        );
                        DB::table('archive_media_categories')->insertGetId([
                            'media_id' => $media_id,
                            'category_id' => $subcats_data->category_id
                                ]
                        );
                    }
                }
        
                return json_encode(array('success' => '200', 'message' => 'New archive created successfully.'));
            }
        
            //Add Archive END.

              //Media listing API START    
    public function archive_media_list(Request $request) {
        $data = array();
        $medias = DB::table('archive_media')->get();
        $all_cats_media = [];
        $all_categories_media = '';
//        echo "<pre>"; print_r($medias); die;
        foreach ($medias as $media) {
//            $author_data=DB::table('media_authors')->where('id',$media->author_id)->first();
//            $author_tags=DB::table('media_tags')->where('media_id',$media->id)->first();
//            echo "<pre>"; print_r($author_tags); die;
//            $tags_data=DB::table('tags')->where('id',$author_tags->tag_id)->first();
            $all_media_cats = DB::table('archive_categories')
                    ->leftjoin('archive_media_categories', 'archive_media_categories.category_id', '=', 'archive_categories.id')
                    ->select('archive_categories.name')
                    ->where('archive_media_categories.media_id', '=', $media->id)
                    ->get();
//            echo "<pre>"; print_r($author_tags); die; 
            $all_cats_media = [];
            if (count($all_media_cats) > 0) {
                foreach ($all_media_cats as $all_media_cat) {
                    $all_cats_media[] = $all_media_cat->name;
                }
                $all_categories_media = implode(',', $all_cats_media);
                $all_comma_cats = rtrim($all_categories_media, ',');
            } else {
                $all_comma_cats = [];
            }
            
            ///////////////////////////////
            $all_media_subcats = DB::table('archive_subcategories')
                    ->leftjoin('archive_media_subcategories', 'archive_media_subcategories.subcategory_id', '=', 'archive_subcategories.id')
                    ->select('archive_subcategories.name')
                    ->where('archive_media_subcategories.media_id', '=', $media->id)
                    ->get();
//            echo "<pre>"; print_r($author_tags); die; 
            $all_subcats_media = [];
            if (count($all_media_subcats) > 0) {
                foreach ($all_media_subcats as $all_media_subcat) {
                    $all_subcats_media[] = $all_media_subcat->name;
                }
                $all_subcategories_media = implode(',', $all_subcats_media);
                $all_comma_subcats = rtrim($all_subcategories_media, ',');
            } else {
                $all_comma_subcats = [];
            }
            

            $type = $media->type;
                if ($type == 'IMAGE') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'YOUTUBE') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'EXTERNAL') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'AUDIO') {
                   
                    //will uncomment this afterward as still all files are on localhost
                    //Aakash start
                    $result12 = substr($media->attachment_name, 0, 5);
                    if ($result12 == 'https') {
                        $image_a = $media->attachment_name;
                    } else {
                        $image_a = url('uploads/archive_media/') . '/' . $media->attachment_name;
                    }
                    //Aakash end
                //     $exists = Storage::disk('s3archive')->exists($media->attachment_name);
                  
                //    if($exists){
                //     $image = Storage::disk('s3archive')->url($media->attachment_name);
                //    }
                    
                }
            if ($media->thumbnail == null || $media->thumbnail == '') {
                    $thumbnail_pod = '';
                } else {
                    $thumbnail_pod = url('uploads/thumbnail/') . '/' . $media->thumbnail;
                }
            $data[] = array(
                'id' => $media->id,
                'type' => $media->type,
                'shabad_id' => $media->shabad_id,
                'description' => $media->description,
                'language' => $media->language,
                'title' => $media->title,
                'thumbnail_pod' => $thumbnail_pod,
                'status' => $media->status,
                'today_approval' => $media->today_approval,
                'attachment_name' => $image_a,
                'media_categories' => $all_comma_cats,
                'media_subcategories' => $all_comma_subcats,
//                'media_tag'=>$tags_data->name
            );
        }
        return json_encode(array('status' => '200', 'message' => 'archive Media List', 'result' => $data));
    }

    //Media listing API END  

     //update Media Author status START
     public function update_archive_status_media(Request $request, $id) {
        $status = $request->status;
        $podcast_cat_check = DB::table('archive_media')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1') {
                DB::table('archive_media')->where('id', $id)->update([
                    'status' => $status
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if ($status == '0') {
                DB::table('archive_media')->where('id', $id)->update([
                    'status' => $status
                ]);
                DB::table('archive_media')->where('id', $id)->update([
                    'status' => $status,
                    'featured'=>'0',
                    'featured_display_order'=>NULL
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if($status!='0' || $status!='1') {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No archive Exist with this detail'));
        }
    }

    //update Media Author status END
     //Update archive START
     public function update_archive_media(Request $request, $id) {
        $get_last_media = DB::table('archive_media')->where('id', $id)->first();
        $author_id = $request->author_id;
        $shabad_id = $request->shabad_id;
        $language = $request->language;
        $ref_type = $request->ref_type;
        $title = $request->title;
        $type = $request->type; //AUDIO,YOUTUBE,IMAGE
        $youtube_url = $request->youtube_url;
        $podbean_url = $request->podbean_url;
        $external_url = $request->external_url;
        $description = $request->description;
        $media_exist = DB::table('archive_media')->where('id', '!=', $id)->where('title', $title)->count();
        if ($media_exist > 0) {
            return json_encode(array('success' => '201', 'message' => 'archive with title already exist. Please try with new one.'));
        }

        if ($type == 'AUDIO') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ","_",$fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';
                
                Storage::disk('s3archive')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                $fileNameUnique = Storage::disk('s3archive')->url($fileNameUnique);
                //$file->move($destinationPath, $fileNameUnique);
                $image = $fileNameUnique;
            } else {
                $image = $get_last_media->attachment_name;
            }
        } elseif ($type == 'IMAGE') {
            if ($podbean_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $podbean_url;
            }
        } elseif ($type == 'YOUTUBE') {
            if ($youtube_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $youtube_url;
            }
        } elseif ($type == 'EXTERNAL') {
            if ($external_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $external_url;
            }
        }


        if ($title == null) {
            return json_encode(array('success' => '201', 'message' => 'Title is required'));
        }

        if ($description == '') {
            return json_encode(array('success' => '201', 'message' => 'Descriprtion is required'));
        }
        if ($request->file('thumbnail')) {
                $file = $request->file('thumbnail');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ","_",$fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/thumbnail/';
                $file->move($destinationPath, $fileNameUnique);
                $imagethumb = $fileNameUnique;
            }else{
                $imagethumb = $get_last_media->thumbnail;
            } 

//            $slug = str_slug($title, '-');
        //echo $get_last_media; die;
       
        if(isset($shabad_id) && !empty($shabad_id)){
            $podcast_media_cou=DB::table('archive_media')->where('id', '!=', $id)->where('shabad_id',$shabad_id)->where('language',$language)->count();
            if($podcast_media_cou>0){
                DB::table('archive_media')->where('shabad_id',$shabad_id)->update([
                    'over_right'=>'0'
                ]);
            }
        }    
        
        DB::table('archive_media')->where('id', $id)->update([
            'title' => $title,
            'description' => $description,
            'language' => $language,
            'thumbnail' => $imagethumb,
            'shabad_id' => $shabad_id,
            'ref_type' => 'RESOURCE',
            'type' => $type,
            'attachment_name' => $image,
            'status' => '1',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        DB::table('archive_media_tags')->where('media_id', $id)->delete();
        DB::table('archive_media_categories')->where('media_id', $id)->delete();
        DB::table('archive_media_subcategories')->where('media_id', $id)->delete();

        if ($request->tag_id) {
            DB::table('archive_media_tags')->insert([
                'media_id' => $id,
                'tag_id' => $request->tag_id,
            ]);
        }

        if ($request->input('category')) {
            $all_cats = json_decode($request->input('category'));
            foreach ($all_cats as $all_cat) {
                DB::table('archive_media_categories')->insertGetId([
                    'media_id' => $id,
                    'category_id' => $all_cat->cat_id
                        ]
                );
            }
        }

        if ($request->new_category != null) {
            $slug = str_slug($request->new_category, '-');
            $new_cat_id = DB::table('archive_categories')->insertGetId([
                'slug' => $slug,
                'name' => $request->new_category,
                'status' => '1'
                    ]
            );

            DB::table('archive_media_subcategories')->insertGetId([
                'media_id' => $id,
                'category_id' => $new_cat_id
                    ]
            );
        }

        if ($request->input('sub_category')) {
            $all_subcats = json_decode($request->input('sub_category'));
            foreach ($all_subcats as $all_subcat) {
                $subcats_data = DB::table('archive_subcategories')->where('id', $all_subcat->sub_cat_id)->first();
                DB::table('archive_media_subcategories')->insertGetId([
                    'media_id' => $id,
                    'subcategory_id' => $all_subcat->sub_cat_id
                        ]
                );

                $cat_exist = DB::table('archive_media_categories')->where('media_id', $id)->where('category_id', $subcats_data->category_id)->count();
                if ($cat_exist == 0) {
                    DB::table('archive_media_categories')->insertGetId([
                        'media_id' => $id,
                        'category_id' => $subcats_data->category_id
                            ]
                    );
                }

//                    DB::table('media_categories')->insertGetId([
//                        'media_id' => $id,
//                        'category_id' => $subcats_data->category_id
//                            ]
//                    );
            }
        }

        return json_encode(array('success' => '200', 'message' => 'New media updated successfully.'));
    }

    //Update archive END

       //delete archive author START
       public function delete_archive_media(Request $request, $id) {
        $podcast_cat_check = DB::table('archive_media')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('archive_media')->where('id', $id)->delete();
//            DB::table('media_tags')->where('media_id',$id)->delete();
            DB::table('archive_media_categories')->where('media_id', $id)->delete();
            DB::table('archive_media_subcategories')->where('media_id', $id)->delete();
            return json_encode(array('success' => '200', 'message' => 'archive Media has been deleted successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'No archive media Exist with this detail'));
        }
    }

    //delete media author END 

     //shabad data START
     public function shabad_data_archive(Request $request,$id){
        $medias = DB::table('archive_media')->where('shabad_id',$id)->where('over_right','1')->get();
        $all_cats_media = [];
        $all_categories_media = '';
//        echo "<pre>"; print_r($medias); die;
        foreach ($medias as $media) {
//            $author_data=DB::table('media_authors')->where('id',$media->author_id)->first();
//            $author_tags=DB::table('media_tags')->where('media_id',$media->id)->first();
//            echo "<pre>"; print_r($author_tags); die;
//            $tags_data=DB::table('tags')->where('id',$author_tags->tag_id)->first();
            $all_media_cats = DB::table('archive_categories')
                    ->leftjoin('archive_media_categories', 'archive_media_categories.category_id', '=', 'archive_categories.id')
                    ->select('archive_categories.name')
                    ->where('archive_media_categories.media_id', '=', $media->id)
                    ->get();
//            echo "<pre>"; print_r($author_tags); die; 
            $all_cats_media = [];
            if (count($all_media_cats) > 0) {
                foreach ($all_media_cats as $all_media_cat) {
                    $all_cats_media[] = $all_media_cat->name;
                }
                $all_categories_media = implode(',', $all_cats_media);
                $all_comma_cats = rtrim($all_categories_media, ',');
            } else {
                $all_comma_cats = [];
            }
            
            ///////////////////////////////
            $all_media_subcats = DB::table('archive_subcategories')
                    ->leftjoin('archive_media_subcategories', 'archive_media_subcategories.subcategory_id', '=', 'archive_subcategories.id')
                    ->select('archive_subcategories.name')
                    ->where('archive_media_subcategories.media_id', '=', $media->id)
                    ->get();
//            echo "<pre>"; print_r($author_tags); die; 
            $all_subcats_media = [];
            if (count($all_media_subcats) > 0) {
                foreach ($all_media_subcats as $all_media_subcat) {
                    $all_subcats_media[] = $all_media_subcat->name;
                }
                $all_subcategories_media = implode(',', $all_subcats_media);
                $all_comma_subcats = rtrim($all_subcategories_media, ',');
            } else {
                $all_comma_subcats = [];
            }
            

            $type = $media->type;
                if ($type == 'IMAGE') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'YOUTUBE') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'EXTERNAL') {
                    $image_a = $media->attachment_name;
                } elseif ($type == 'AUDIO') {
                 
                    $result12 = substr($media->attachment_name, 0, 5);
                    if ($result12 == 'https') {
                        $image_a = $media->attachment_name;
                    } else {
                        $image_a = url('uploads/archive_media/') . '/' . $media->attachment_name;
                    }
                }
            if ($media->thumbnail == null || $media->thumbnail == '') {
                    $thumbnail_pod = '';
                } else {
                    $thumbnail_pod = url('uploads/thumbnail/') . '/' . $media->thumbnail;
                } 
            $data[] = array(
                'id' => $media->id,
                'type' => $media->type,
                'description' => $media->description,
                'shabad_id' => $media->shabad_id,
                'language' => $media->language,
                'title' => $media->title,
                'thumbnail_pod' => $thumbnail_pod,
                'status' => $media->status,
                'today_approval' => $media->today_approval,
                'attachment_name' => $image_a,
                'media_categories' => $all_comma_cats,
                'media_subcategories' => $all_comma_subcats,
//                'media_tag'=>$tags_data->name
            );
        }
        return json_encode(array('status' => '200', 'message' => 'archive Media List', 'result' => $data));
    }
    //shabad data END  

}