<?php

namespace App\Http\Controllers;

use App\Http\Controllers\ApiController;
use App\Http\Requests\Api\CreateCategoryRequest;
use App\Http\Requests\Api\UpdateCategoryRequest;
use Intervention\Image\ImageManagerStatic as Image;
use App\Models\Category;
use App\Repositories\CategoriesRepository;
use App\Transformers\Api\CategoryTransformer;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use DB;

class CategoriesController extends ApiController {

    protected $repository;

    public function __construct(CategoriesRepository $repository) {
        $this->repository = $repository;
    }

    /**
     * get list of all the categories.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function index(Request $request) {
        $items = $this->repository->paginate($request);

        return $this->paginate($items, new CategoryTransformer, 'categories');
    }

    /**
     * get list of featured categories.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function getFeaturedItems(Request $request) {
//        $items = $this->repository->paginateFeaturedItems($request);
//
//        return $this->paginate($items, new CategoryTransformer, 'categories');
        $items = DB::table('categories')->where('featured', '1')->orderBy('featured_display_order', 'asc')->paginate(10);
        if(count($items)>0){
            foreach ($items as $item) {
            $sub_cat_counts = DB::table('subcategories')->where('category_id', $item->id)->where('status', '1')->count();
            if ($item->image == null || $item->image == '') {
                $category_image = '';
            } else {
                $category_image = url('uploads/category/') . '/' . $item->image;
            }
            $data[] = array(
                'id' => $item->id,
                'name' => $item->name,
                'slug' => $item->slug,
                'sub_category_count' => $sub_cat_counts,
                'attachment_name' => $category_image,
            );
        }
        }else{
            $data = [];
        }
        
//            echo "<pre>"; print_r($items); die;
        return json_encode(array('featured_categories' => $data));
    }

    /**
     * create Category
     *
     * @param  $request: App\Http\Requests\Api\CreateCategoryRequest
     * @param  $entity: App\Models\Tag
     * @return json response.
     */
    public function store(CreateCategoryRequest $request, Category $entity) {
        try {

            $entity->setName($request->input('name'))
                    ->setDescription($request->input('description'))
                    ->setStatus((bool) $request->input('status'));

            $item = $this->repository->save($entity);
            return $this->getItem($item, new CategoryTransformer, 'categories');
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    /**
     * Update category
     *
     * @param  $entity: App\Models\Category
     * @param  $request: App\Http\Requests\Api\UpdateCategoryRequest
     * @return json response.
     */
    public function update(Category $category, UpdateCategoryRequest $request) {
        try {

            $category->setName($request->input('name'))
                    ->setDescription($request->input('description'))
                    ->setStatus((bool) $request->input('status'));

            $item = $this->repository->update($category->getKey(), $category);
            return $this->getItem($item, new CategoryTransformer, 'categories');
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    /**
     * delete category
     *
     * @param  $entity: App\Models\Category
     * @return json response.
     */
    public function delete(Category $entity) {
        $entity->delete();
        return $this->respondDeleted([]);
    }

    public function sub_cats(Request $request, $id) {
        $items = DB::table('subcategories')->where('category_id', $id)->where('status', '1')->where('featured', '0')->orderBy('name', 'asc')->paginate(10);
        // print_r($items);die;
        if (count($items) > 0) {
            foreach ($items as $item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/subcategory/') . '/' . $item->image;
                }
                $data[] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'slug' => $item->slug,
                    'attachment_name' => $category_image,
                );
            }
        } else {
            $data = [];
        }

//            echo "<pre>"; print_r($items); die;
        return json_encode(array('featured_sub_categories' => $data));
    }

    //add podcast category START
    public function add_podcast_category(Request $request) {
        $name = $request->name;
        $description = $request->description;
        if ($request->file('image')) {
            $file = $request->file('image');
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/podcast_category/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
            $image = "";
        }
        $podcast_cat_count = DB::table('podcast_categories')->where('name', $name)->count();
        if ($podcast_cat_count > 0) {
            return json_encode(array('success' => '201', 'message' => 'Name with this podcast already exist. Please try with new one.'));
        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('podcast_categories')->insert([
                'name' => $name,
                'description' => $description,
                'slug' => $slug,
                'image' => $image,
                'status' => '1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'New podcast category created successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }

    //add podcast category END
    //update podcast category START
    public function update_podcast_category(Request $request, $id) {
        $podcast_detail = DB::table('podcast_categories')->where('id', $id)->first();
        $name = $request->name;
        $description = $request->description;
        
        if ($request->file('image')) {
            $file = $request->file('image');
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/podcast_category/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
            $image = $podcast_detail->image;
        }
//        $podcast_cat_count=DB::table('podcast_categories')->where('name',$name)->count();
//        if($podcast_cat_count>0){
//            return json_encode(array('success' => '201','message'=>'Name with this podcast already exist. Please try with new one.'));
//        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('podcast_categories')->where('id', $id)->update([
                'name' => $name,
                'description' => $description,
                'slug' => $slug,
                'image' => $image,
                'status' => '1',
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'Podcast category has been updated successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }

    //update podcast category END
    //List podcast Category START
    public function podcast_catetgory_list(Request $request) {
        $items = DB::table('podcast_categories')->get();

        if (count($items) > 0) {
            foreach ($items as $item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/podcast_category/') . '/' . $item->image;
                }
                $subcats_count=DB::table('podcast_subcategories')->where('category_id',$item->id)->where('status','1')->count();
                $data[] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'description' => $item->description,
                    'status' => $item->status,
                    'attachment_name' => $category_image,
                    'subcats_count'=>$subcats_count
                );
            }
        } else {
            $data = [];
        }
        return json_encode(array('success' => '200', 'message' => 'Podcast Categories List', 'result' => $data));
    }

    //List podcast Category END
    //update podcast status START
    public function update_podcast_status(Request $request, $id) {
        $status = $request->status;
        $podcast_cat_check = DB::table('podcast_categories')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1') {
                DB::table('podcast_categories')->where('id', $id)->update([
                    'status' => $status
                ]);
                DB::table('podcast_subcategories')->where('category_id',$id)->update(['status' => $status]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if ($status == '0'){
                DB::table('podcast_categories')->where('id', $id)->update([
                    'status' => $status,
                    'featured'=>'0',
                    'featured_display_order'=>NULL
                ]);
                DB::table('podcast_subcategories')->where('category_id',$id)->update([
                    'status' => $status,
                    'featured'=>'0',
                    'featured_display_order'=>NULL
                        ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if($status!='0' || $status!='1') {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No category Exist with this detail'));
        }
    }

    //update podcast status END
    
    //delete podcast category START
    public function delete_podcast_category(Request $request,$id){
        $podcast_cat_check = DB::table('podcast_categories')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('podcast_categories')->where('id',$id)->delete();
            return json_encode(array('success' => '200', 'message' => 'Podcast category has been deleted successfully.'));
        }else{
            return json_encode(array('success' => '201', 'message' => 'No podcast category Exist with this detail'));
        }
    }
    //delete podcast category END
    
    
    //add podcast subcategory START
    public function add_podcast_subcategory(Request $request) {
        $name = $request->name;
        $description = $request->description;
        $category_id = $request->category_id;
        if ($request->file('image')) {
            $file = $request->file('image');
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/podcast_category/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
            $image = "";
        }
        $podcast_cat_count = DB::table('podcast_subcategories')->where('name', $name)->count();
        if ($podcast_cat_count > 0) {
            return json_encode(array('success' => '201', 'message' => 'Name with this podcast already exist. Please try with new one.'));
        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('podcast_subcategories')->insert([
                'name' => $name,
                'description' => $description,
                'category_id' => $category_id,
                'slug' => $slug,
                'image' => $image,
                'status' => '1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'New podcast subcategory created successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }

    //add podcast subcategory END
    //update podcast subcategory START
    public function update_podcast_subcategory(Request $request, $id) {
        $podcast_detail = DB::table('podcast_subcategories')->where('id', $id)->first();
        $name = $request->name;
        $description = $request->description;
        $category_id = $request->category_id;
        if ($request->file('image')) {
            $file = $request->file('image');
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/podcast_category/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
            $image = $podcast_detail->image;
        }
//        $podcast_cat_count=DB::table('podcast_categories')->where('name',$name)->count();
//        if($podcast_cat_count>0){
//            return json_encode(array('success' => '201','message'=>'Name with this podcast already exist. Please try with new one.'));
//        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('podcast_subcategories')->where('id', $id)->update([
                'name' => $name,
                'description' => $description,
                'category_id' => $category_id,
                'slug' => $slug,
                'image' => $image,
                'status' => '1',
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'Podcast category has been updated successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }

    //update podcast subcategory END
    //List podcast subcategory START
    public function podcast_subcatetgory_list(Request $request) {
        $items = DB::table('podcast_subcategories')->get();

        if (count($items) > 0) {
            foreach ($items as $item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/podcast_category/') . '/' . $item->image;
                }
                $data[] = array(
                    'id' => $item->id, 
                    'name' => $item->name,
                    'description' => $item->description,
                    'status' => $item->status,
                    'attachment_name' => $category_image,
                    'category_id' => $item->category_id,
                );
            }
        } else {
            $data = [];
        }
        return json_encode(array('success' => '200', 'message' => 'Podcast Sub Categories List', 'result' => $data));
    }

    //List podcast subcategory END
    //update podcast status START
    public function update_podcast_substatus(Request $request, $id) {
        $status = $request->status;
        $podcast_cat_check = DB::table('podcast_subcategories')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1' || $status == '0') {
                DB::table('podcast_subcategories')->where('id', $id)->update([
                    'status' => $status
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            } else {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No podcast category Exist with this detail'));
        }
    }

    //update podcast status END
    
    //delete podcast subcategory START
    public function delete_podcast_subcategory(Request $request,$id){
        $podcast_cat_check = DB::table('podcast_subcategories')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('podcast_subcategories')->where('id',$id)->delete();
            return json_encode(array('success' => '200', 'message' => 'Podcast category has been deleted successfully.'));
        }else{
            return json_encode(array('success' => '201', 'message' => 'No podcast category Exist with this detail'));
        }
    }
    //delete podcast subcategory END  
    
    ///////////////////// Resources Category APIs START ///////////////////
    //add resources category START
    public function add_resources_category(Request $request) {
        $name = $request->name;
        if ($request->file('image')) {
            $file = $request->file('image');
            Image::make($file)->resize(500, 500)->save();
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/category/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
            $image = "";
        }
        $podcast_cat_count = DB::table('categories')->where('name', $name)->count();
        if ($podcast_cat_count > 0) {
            return json_encode(array('success' => '201', 'message' => 'Name with this already exist. Please try with new one.'));
        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('categories')->insert([
                'name' => $name,
                'slug' => $slug,
                'image' => $image,
                'status' => '1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'New category created successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }

    //add resources category END
    //update resources category START
    public function update_resources_category(Request $request, $id) {
        $podcast_detail = DB::table('categories')->where('id', $id)->first();
        $name = $request->name;
        if ($request->file('image')) {
            $file = $request->file('image');
            Image::make($file)->resize(500, 500)->save();
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/category/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
            $image = $podcast_detail->image;
        }
//        $podcast_cat_count=DB::table('podcast_categories')->where('name',$name)->count();
//        if($podcast_cat_count>0){
//            return json_encode(array('success' => '201','message'=>'Name with this podcast already exist. Please try with new one.'));
//        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('categories')->where('id', $id)->update([
                'name' => $name,
                'slug' => $slug,
                'image' => $image,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'Resources category has been updated successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }

    //update resources category END
    //List resources Category START
    public function resources_catetgory_list(Request $request) {
        $items = DB::table('categories')->orderBy('name')->get();

        if (count($items) > 0) {
            foreach ($items as $item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/category/') . '/' . $item->image;
                }
                $subcats_count=DB::table('subcategories')->where('category_id',$item->id)->where('status','1')->count();
                $data[] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'status' => $item->status,
                    'attachment_name' => $category_image,
                    'subcats_count'=>$subcats_count
                );
            }
        } else {
            $data = [];
        }
        return json_encode(array('success' => '200', 'message' => 'Categories List', 'result' => $data));
    }

    //List resources Category END
    //update resources status START
    public function update_resources_status(Request $request, $id) {
        $status = $request->status;
        $podcast_cat_check = DB::table('categories')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1') {
                DB::table('categories')->where('id', $id)->update([
                    'status' => $status
                ]);
                DB::table('subcategories')->where('category_id',$id)->update(['status' => $status]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if ($status == '0'){
                DB::table('categories')->where('id', $id)->update([
                    'status' => $status,
                    'featured'=>'0',
                    'featured_display_order'=>NULL
                ]);
                DB::table('subcategories')->where('category_id',$id)->update([
                    'status' => $status,
                    'featured'=>'0',
                    'featured_display_order'=>NULL
                        ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if($status!='0' || $status!='1') {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No category Exist with this detail'));
        }
    }

    //update resources status END
    
    //delete resources category START
    public function delete_resources_category(Request $request,$id){
        $podcast_cat_check = DB::table('categories')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('categories')->where('id',$id)->delete();
            DB::table('subcategories')->where('category_id',$id)->delete();
            DB::table('media_categories')->where('category_id',$id)->delete();
            return json_encode(array('success' => '200', 'message' => 'category has been deleted successfully.'));
        }else{
            return json_encode(array('success' => '201', 'message' => 'No category Exist with this detail'));
        }
    }
    //delete resources category END
    ///////////////////// Resources Category APIs END /////////////////////
    
    
    ///////////////////// Resources Sub Category APIs START ///////////////////
    //add resources subcategory START
    public function add_resources_subcategory(Request $request) {
        $name = $request->name;
        $category_id = $request->category_id;
        if ($request->file('image')) {
            $file = $request->file('image');
            Image::make($file)->resize(500, 500)->save();
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/subcategory/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
            $image = "";
        }
        $podcast_cat_count = DB::table('subcategories')->where('name', $name)->count();
        if ($podcast_cat_count > 0) {
            return json_encode(array('success' => '201', 'message' => 'Name with this subcategory already exist. Please try with new one.'));
        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('subcategories')->insert([
                'name' => $name,
                'category_id' => $category_id,
                'slug' => $slug,
                'image' => $image,
                'status' => '1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'New subcategory created successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }

    //add resources subcategory END
    //update resources subcategory START
    public function update_resources_subcategory(Request $request, $id) {
        $podcast_detail = DB::table('subcategories')->where('id', $id)->first();
        $name = $request->name;
        $category_id = $request->category_id;
        if ($request->file('image')) {
            $file = $request->file('image');
            Image::make($file)->resize(500, 500)->save();
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/subcategory/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
            $image = $podcast_detail->image;
        }
//        $podcast_cat_count=DB::table('podcast_categories')->where('name',$name)->count();
//        if($podcast_cat_count>0){
//            return json_encode(array('success' => '201','message'=>'Name with this podcast already exist. Please try with new one.'));
//        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('subcategories')->where('id', $id)->update([
                'name' => $name,
                'category_id' => $category_id,
                'slug' => $slug,
                'image' => $image,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'Resources subcategory has been updated successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }

    //update resources subcategory END
    //List resources subcategory START
    public function resources_subcatetgory_list(Request $request) {
        $items = DB::table('subcategories')->orderBy('name')->get();

        if (count($items) > 0) {
            foreach ($items as $item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/subcategory/') . '/' . $item->image;
                }
                $data[] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'category_id' => $item->category_id,
                    'status' => $item->status,
                    'attachment_name' => $category_image,
                );
            }
        } else {
            $data = [];
        }
        return json_encode(array('success' => '200', 'message' => 'Sub Categories List', 'result' => $data));
    }

    //List resources subcategory END
    //update resources status START
    public function update_resources_substatus(Request $request, $id) {
        $status = $request->status;
        $podcast_cat_check = DB::table('subcategories')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1' || $status == '0') {
                DB::table('subcategories')->where('id', $id)->update([
                    'status' => $status
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            } else {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No subcategory Exist with this detail'));
        }
    }

    //update resources status END
    
    //delete resources subcategory START
    public function delete_resources_subcategory(Request $request,$id){
        $podcast_cat_check = DB::table('subcategories')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('subcategories')->where('id',$id)->delete();
            return json_encode(array('success' => '200', 'message' => 'Subcategory has been deleted successfully.'));
        }else{
            return json_encode(array('success' => '201', 'message' => 'Subcategory Exist with this detail'));
        }
    }
    //delete resources subcategory END 
    ///////////////////// Resources Sub Category APIs END /////////////////////
}
