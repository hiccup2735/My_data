<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\AuthorRepository;
use Response, Exception;

class AuthorController extends Controller
{

    private $repository;

    function __construct(AuthorRepository $repository)
    {
    	$this->repository = $repository;
    }

    /**
     * Get translations authors data
     */
    public function getTranslationAuthors()
    {
    	$authors = $this->repository->getTranslationAuthors();

    	return Response::json([
			'status' => 'success',
			'data'=>$authors
		]);
    }

    public function updateStatus($id, $status)
    {
    	try {
    		$this->repository->updateActiveStatus($id, $status);

    		return Response::json([
				'status' => 'success',
				'message' => "Author's status successfully updated."
			]);

    	} catch (Exception $e) {
    		return Response::json([
				'status' => 'error',
				'message'=> $e->getMessage()
			], 422);
    	}
    }

    /**
     * mark author as default and all are mark non-default.
     * 
     * @param  $id: integer of author id.
     * @return json response.
     */
    public function markDefault($id)
    {

        try {
            $this->repository->markAllNonDefault();
            $item = $this->repository->markDefaultById($id);

            return Response::json([
                'status' => 'success',
                'data' => [
                    'item' => $item
                ],
                'message' => "Author's status successfully updated."
            ]);

        } catch (Exception $e) {
            return Response::json([
                'status' => 'error',
                'message'=> $e->getMessage()
            ], 422);
        }
    }
}
