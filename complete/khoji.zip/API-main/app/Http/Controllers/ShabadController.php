<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Shabad;
use App\Models\Scripture;
use App\Repositories\ScriptureRepository;
use App\Repositories\ShabadRepository;
use DB, Response, Exception;
use App\Mail\ContentMail;
use App\Mail\UserContentMail;
use Illuminate\Support\Facades\Mail;

class ShabadController extends Controller
{

    private $repository;
    private $scriptureRepo;

    function __construct(ScriptureRepository $scriptureRepo, ShabadRepository $repository)
    {
        $this->repository = $repository;
        $this->scriptureRepo = $scriptureRepo;
    }

    /**
     * Get shabads data with scriptures
     */
    public function getShabad($pageId, $shabadId = null)
    {
        try
        {
            $pages = $this
                ->scriptureRepo
                ->getScripturePagesForShabad($pageId);

            if (!$shabadId)
            {
                $shabadId = $pages->first();
            }

            $shabad = $this
                ->repository
                ->getShabad($shabadId);

            if (!in_array($shabad->id, $pages->toArray()))
            {
                throw new Exception("Shabad $shabadId is not found in page $pageId", 400);
            }

            return Response::json(['status' => 'success', 'data' => $shabad, 'pages' => $pages]);
        }
        catch(Exception $e)
        {
            return Response::json(['status' => 'error', 'message' => $e->getMessage() ], $e->getCode());
        }
    }

    public function getShabadPages($pageId)
    {
        $pages = $this
            ->scriptureRepo
            ->getScripturePagesForShabad($pageId);

        return Response::json(['status' => 'success', 'data' => $pages]);
    }

    //get shabad list API
    public function shabad_list(Request $request)
    {
        $shabads = DB::table('shabad')->get();
        return json_encode(array(
            'status' => '200',
            'message' => 'shabad list',
            'result' => $shabads
        ));
    }
    public function getTagId($id = null)
    {
        $tag = DB::table('media')->join('media_tags', 'media_tags.media_id', '=', 'media.id')
            ->select('media_tags.tag_id')
            ->where('media.shabad_id', '=', $id)->first()->tag_id;
        return $tag;
    }
    //get shabad santhya kirtan data START
    public function get_shabad_media(Request $request, $id)
    {
        if ($id == null || $id == 'null' || $id == '')
        {
            $Katha_data = [];
            $Kirtan_data = [];
            $Santhiya_data = [];
            return json_encode(array(
                'status' => '201',
                'message' => 'No record found',
                'katha_data' => $Katha_data,
                'Kirtan_data' => $Kirtan_data,
                'Santhiya_data' => $Santhiya_data
            ));
        }
        $shabad_media = DB::table('media')->where('shabad_id', $id)->count();
//        $tagID = $this->getTagId($id);

        if ($shabad_media > 0)
        {
            //get Katha Data
            $medias = DB::table('media')->join('media_authors', 'media_authors.id', '=', 'media.author_id')
//				->leftjoin('media_tags', 'media_tags.media_id', '=', 'media.id')
//              ->leftjoin('tags', 'tags.id', '=', 'media_tags.tag_id')
                ->select('media.*', 'media.tag_id')
                ->where('media.shabad_id', '=', $id)->where('media.tag_id', '=', '15')
                ->orderBy('media_authors.name')
                ->get();
            if (count($medias) > 0)
            {
                foreach ($medias as $media)
                {
                    $author_data = DB::select("select * from media_authors where id='$media->author_id' LIMIT 1");

                    $type = $media->type;
                    if ($type == 'IMAGE')
                    {
                        $image = $media->attachment_name;
                    }
                    elseif ($type == 'YOUTUBE')
                    {
                        $image = $media->attachment_name;
                    }
                    elseif ($type == 'EXTERNAL')
                    {
                        $image = $media->attachment_name;
                    }
                    elseif ($type == 'AUDIO')
                    {
                        $image = url('uploads/media/') . '/' . $media->attachment_name;
                    }
                    elseif ($type == 'S3')
                    {
                        $image = $media->attachment_name;
                    }
                    $podcast_media = DB::table('podcast_media')->where('shabad_id', '=', $media->shabad_id)
                        ->get();
                    $Katha_data[] = array(
                        'id' => $media->id,
                        'userid' => $media->user_id,
                        'title' => $media->title,
                        'type' => $media->type,
                        'featured' => $media->featured,
                        'media_approve' => $media->media_approve,
                        'status' => $media->status,
                        'author_name' => $author_data[0]->name,
                        'attachment_name' => $image,
                        'duration' => $media->duration,
                        'media_tag' => 'Katha',
                        'updated_at' => $media->updated_at,
                        'tag_id' => $media->tag_id
                    );
                }
            }
            else
            {
                $Katha_data = [];
            }

            //get Kirtan Data
            $kirtanmedias = DB::table('media')->join('media_authors', 'media_authors.id', '=', 'media.author_id')
//				  ->leftjoin('media_tags', 'media_tags.media_id', '=', 'media.id')
//                ->leftjoin('tags', 'tags.id', '=', 'media_tags.tag_id')
                ->select('media.*', 'media.tag_id')
                ->where('media.shabad_id', '=', $id)->where('media.tag_id', '=', '2')->where('media_authors.status', '=', '1')
                ->orderBy('media_authors.name')
                ->get();
            if (count($kirtanmedias) > 0)
            {
                foreach ($kirtanmedias as $kirtanmedia)
                {
                    $author_data = DB::select("select * from media_authors where id='$kirtanmedia->author_id' LIMIT 1");

                    $type = $kirtanmedia->type;
                    if ($type == 'IMAGE')
                    {
                        $image = $kirtanmedia->attachment_name;
                    }
                    elseif ($type == 'YOUTUBE')
                    {
                        $image = $kirtanmedia->attachment_name;
                    }
                    elseif ($type == 'EXTERNAL')
                    {
                        $image = $kirtanmedia->attachment_name;
                    }
                    elseif ($type == 'AUDIO')
                    {
                        $image = url('uploads/media/') . '/' . $kirtanmedia->attachment_name;
                    }
                    elseif ($type == 'S3')
                    {
                        $image = $kirtanmedia->attachment_name;
                    }
                    $podcast_media = DB::table('podcast_media')->where('shabad_id', '=', $kirtanmedia->shabad_id)
                        ->get();
                    $Kirtan_data[] = array(
                        'id' => $kirtanmedia->id,
                        'userid' => $kirtanmedia->user_id,
                        'title' => $kirtanmedia->title,
                        'type' => $kirtanmedia->type,
                        'featured' => $kirtanmedia->featured,
                        'media_approve' => $kirtanmedia->media_approve,
                        'status' => $kirtanmedia->status,
                        'author_name' => $author_data[0]->name,
                        'attachment_name' => $image,
                        'duration' => $kirtanmedia->duration,
                        'media_tag' => 'Kirtan',
                        'updated_at' => $kirtanmedia->updated_at,
                        'tag_id' => $kirtanmedia->tag_id
                    );
                }
            }
            else
            {
                $Kirtan_data = [];
            }

            //get Santhya Data
            $santhyamedias = DB::table('media')->join('media_authors', 'media_authors.id', '=', 'media.author_id')
//			->leftjoin('media_tags', 'media_tags.media_id', '=', 'media.id')
//                ->leftjoin('tags', 'tags.id', '=', 'media_tags.tag_id')
                ->select('media.*',  'media.tag_id')
                ->where('media.shabad_id', '=', $id)->where('media.tag_id', '=', '1')
                ->orderBy('media_authors.name')
                ->get();
            if (count($santhyamedias) > 0)
            {
                foreach ($santhyamedias as $santhyamedia)
                {
                    $author_data = DB::select("select * from media_authors where id='$santhyamedia->author_id' LIMIT 1");

                    $type = $santhyamedia->type;
                    if ($type == 'IMAGE')
                    {
                        $image = $santhyamedia->attachment_name;
                    }
                    elseif ($type == 'YOUTUBE')
                    {
                        $image = $santhyamedia->attachment_name;
                    }
                    elseif ($type == 'EXTERNAL')
                    {
                        $image = $santhyamedia->attachment_name;
                    }
                    elseif ($type == 'AUDIO')
                    {
                        $image = url('uploads/media/') . '/' . $santhyamedia->attachment_name;
                    }
                    elseif ($type == 'S3')
                    {
                        $image = $santhyamedia->attachment_name;
                    }
                    $podcast_media = DB::table('podcast_media')->where('shabad_id', '=', $santhyamedia->shabad_id)
                        ->get();
                    $Santhiya_data[] = array(
                        'id' => $santhyamedia->id,
                        'userid' => $santhyamedia->user_id,
                        'title' => $santhyamedia->title,
                        'type' => $santhyamedia->type,
                        'featured' => $santhyamedia->featured,
                        'media_approve' => $santhyamedia->media_approve,
                        'status' => $santhyamedia->status,
                        'author_name' => $author_data[0]->name,
                        'attachment_name' => $image,
                        'duration' => $santhyamedia->duration,
                        'media_tag' => 'Santhiya',
                        'updated_at' => $santhyamedia->updated_at,
                        'tag_id' => $santhyamedia->tag_id
                    );
                }
            }
            else
            {
                $Santhiya_data = [];
            }
            //get featured data Aakash
            $featuredDatas = DB::table('media')->join('media_authors', 'media_authors.id', '=', 'media.author_id')
//			->leftjoin('media_tags', 'media_tags.media_id', '=', 'media.id')
//                ->leftjoin('tags', 'tags.id', '=', 'media_tags.tag_id')
                ->select('media.*', 'media.tag_id')
                ->where('media.shabad_id', '=', $id)->where('media.tag_id', '=', '6')
                ->orderBy('media_authors.name')
                ->get();
            if (count($featuredDatas) > 0)
            {
                foreach ($featuredDatas as $featuredData)
                {
                    $author_data = DB::select("select * from media_authors where id='$featuredData->author_id' LIMIT 1");

                    $type = $featuredData->type;
                    if ($type == 'IMAGE')
                    {
                        $image = $featuredData->attachment_name;
                    }
                    elseif ($type == 'YOUTUBE')
                    {
                        $image = $featuredData->attachment_name;
                    }
                    elseif ($type == 'EXTERNAL')
                    {
                        $image = $featuredData->attachment_name;
                    }
                    elseif ($type == 'AUDIO')
                    {
                        $image = url('uploads/media/') . '/' . $featuredData->attachment_name;
                    }
                    elseif ($type == 'S3')
                    {
                        $image = $featuredData->attachment_name;
                    }
                    $podcast_media = DB::table('podcast_media')->where('shabad_id', '=', $featuredData->shabad_id)
                        ->get();
                    $Featured_data[] = array(
                        'id' => $featuredData->id,
                        'userid' => $featuredData->user_id,
                        'title' => $featuredData->title,
                        'type' => $featuredData->type,
                        'featured' => $featuredData->featured,
                        'media_approve' => $featuredData->media_approve,
                        'status' => $featuredData->status,
                        'author_name' => $author_data[0]->name,
                        'attachment_name' => $image,
                        'duration' => $featuredData->duration,
                        'media_tag' => 'featured',
                        'updated_at' => $featuredData->updated_at,
                        'tag_id' => $featuredData->tag_id
                    );
                }
            }
            else
            {
                $Featured_data = [];
            }
            //get discussion data Aakash
            $discussiondatas = DB::table('media')->join('media_authors', 'media_authors.id', '=', 'media.author_id')
//			->leftjoin('media_tags', 'media_tags.media_id', '=', 'media.id')
//                ->leftjoin('tags', 'tags.id', '=', 'media_tags.tag_id')
                ->select('media.*', 'media.tag_id')
                ->where('media.shabad_id', '=', $id)->where('media.tag_id', '=', '5')
                ->orderBy('media_authors.name')
                ->get();
            if (count($discussiondatas) > 0)
            {
                foreach ($discussiondatas as $discussiondata)
                {
                    $author_data = DB::select("select * from media_authors where id='$discussiondata->author_id' LIMIT 1");

                    $type = $discussiondata->type;
                    if ($type == 'IMAGE')
                    {
                        $image = $discussiondata->attachment_name;
                    }
                    elseif ($type == 'YOUTUBE')
                    {
                        $image = $discussiondata->attachment_name;
                    }
                    elseif ($type == 'EXTERNAL')
                    {
                        $image = $discussiondata->attachment_name;
                    }
                    elseif ($type == 'AUDIO')
                    {
                        $image = url('uploads/media/') . '/' . $discussiondata->attachment_name;
                    }
                    elseif ($type == 'S3')
                    {
                        $image = $discussiondata->attachment_name;
                    }
                    $podcast_media = DB::table('podcast_media')->where('shabad_id', '=', $discussiondata->shabad_id)
                        ->get();
                    $Discussion_data[] = array(
                        'id' => $discussiondata->id,
                        'userid' => $discussiondata->user_id,
                        'title' => $discussiondata->title,
                        'type' => $discussiondata->type,
                        'featured' => $discussiondata->featured,
                        'media_approve' => $discussiondata->media_approve,
                        'status' => $discussiondata->status,
                        'author_name' => $author_data[0]->name,
                        'attachment_name' => $image,
                        'duration' => $discussiondata->duration,
                        'media_tag' => 'discussion',
                        'updated_at' => $discussiondata->updated_at,
                        'tag_id' => $discussiondata->tag_id
                    );
                }
            }
            else
            {
                $Discussion_data = [];
            }

        }
        else
        {
            $Katha_data = [];
            $Kirtan_data = [];
            $Santhiya_data = [];
            $Featured_data = [];
            $Discussion_data = [];
			$podcast_media = [];
        }

        return json_encode(array(
            'status' => '200',
            'message' => 'Shabad Media List',
            'katha_data' => $Katha_data,
            'Kirtan_data' => $Kirtan_data,
            'Santhiya_data' => $Santhiya_data,
            'podcast_media' => $podcast_media,
            'Featured_data' => $Featured_data,
            'Discussion_data' => $Discussion_data
        ));
    }

    //get shabad santhya kirtan data END
    //add translation START
    public function add_translation(Request $request, $id)
    {
        $text = $request->text;
        $user_id = $request->user_id;
        $scripture_count = DB::table('translation')->where('ScriptureID', $id)->count();
        if ($text != '' || $text != null)
        {
            if ($scripture_count > 0)
            {
                $scripture_data = DB::table('translation')->where('ScriptureID', $id)->first();
                if (empty($user_id))
                {
                    return json_encode(array(
                        'status' => '201',
                        'message' => 'Please check user id'
                    ));
                }
                DB::table('translation_history')->insert(['KhojgurbaaniEnglish' => $scripture_data->KhojgurbaaniEnglish, 'ScriptureID' => $id, 'updated_by' => $user_id]);
                DB::table('translation')->where('ScriptureID', $id)->update(['KhojgurbaaniEnglish' => $text]);
            }
            else
            {
                DB::table('translation')->insert(['ScriptureID' => $id, 'KhojgurbaaniEnglish' => $text, 'user_id' => $user_id]);
            }
            return json_encode(array(
                'status' => '200',
                'message' => 'Translation has been added successfully.'
            ));
        }
        else
        {
            return json_encode(array(
                'status' => '201',
                'message' => 'Field is empty'
            ));
        }
    }
    //add translation END
    //Add commentary START
    public function add_commentary(Request $request, $id)
    {
        $text = $request->text;
        $user_id = $request->user_id;
        if ($text != '' || $text != null)
        {
            $comment_author = DB::table('users')->where('id', $user_id)->first();
            if (isset($comment_author) && $comment_author->role_id != '4')
            {
                if ($comment_author->auto_approve != '1')
                {
                    $appr_status = '0';
                }
                else
                {
                    $appr_status = '1';
                }
            }
            else
            {
                $appr_status = '1';
            }

            if ($comment_author->role_id == '4')
            {
                $appr_status = '1';
            }
            $scripture_count = DB::table('commentaries')->where('shabad_id', $id)->count();
            if ($scripture_count > 0)
            {
                $commentary_his = DB::table('commentaries')->where('shabad_id', $id)->first();
                DB::table('commentary_history')
                    ->insert(['shabad_id' => $commentary_his->shabad_id, 'updated_by' => $user_id, 'commentary' => $commentary_his->commentary]);
                DB::table('commentaries')
                    ->where('shabad_id', $id)->update(['commentary' => $text]);
            }
            else
            {
                DB::table('commentaries')->insert(['shabad_id' => $id, 'user_id' => $user_id, 'commentary' => $text]);
            }
          //  DB::table('shabad_comments')->insert(['shabad_id' => $id, 'user_id' => $user_id, 'comment' => $text, 'approve_status' => $appr_status]);

            $admin_emails = DB::table('users')->select(['email as email'])->whereIn('role_id', [3,4])->pluck('email')->toArray();

            if ($appr_status != '1') {
                Mail::to($admin_emails)->send(new ContentMail('commentary'));
            }
            
            return json_encode(array(
                'status' => '200',
                'message' => 'commentary has been added successfully.'
            ));
        }
        else
        {
            return json_encode(array(
                'status' => '201',
                'message' => 'Field is empty'
            ));
        }
    }
    //Add commentary END
    //Get shabad commentary START
    public function commentaries(Request $request, $id)
    {
        $scripture_count = DB::table('commentaries')->where('shabad_id', $id)->count();
        if ($scripture_count > 0)
        {
			/*$data = DB::table('commentaries')->leftjoin('users', 'users.id', '=', 'commentaries.user_id')
                ->select('commentaries.*', 'users.name', 'users.photo_url')
                ->where('commentaries.shabad_id', $id)->where('commentaries.approve_status', '1')
			 	->orderBy('id', 'desc')
                ->take(1)
                ->get();*/
			
            $data = DB::table('commentaries')->where('shabad_id', $id)->where('approve_status', '1')
                ->orderBy('id', 'desc')
                ->take(1)
                ->get();
            return json_encode(array(
                'status' => '200',
                'message' => 'Commentary List',
                'result' => $data
            ));
        }
        else
        {
            $data = [];
            return json_encode(array(
                'status' => '200',
                'message' => 'Commentary List',
                'result' => $data
            ));
        }
    }
    //Get shabad commentary END
    //Add comments START
    public function add_comment(Request $request, $id)
    {
        $text = $request->text;
        $user_id = $request->user_id;
        if ($text != '' && $user_id != '')
        {
            $comment_author = DB::table('users')->where('id', $user_id)->first();
            if($comment_author->is_block == 0){
                if (isset($comment_author) && $comment_author->role_id != '4' && $comment_author->role_id != '3')
                {
                    if ($comment_author->auto_approve != '1')
                    {
                        $appr_status = '0';

                    }
                    else
                    {
                        $appr_status = '1';
                    }
                }
                else
                {
                    $appr_status = '1';
                }

                if ($comment_author->role_id == '4' || $comment_author->role_id == '3')
                {
                    $appr_status = '1';
                }
                //echo  $appr_status; die;
                DB::table('shabad_comments')->insert(['shabad_id' => $id, 'user_id' => $user_id, 'comment' => $text, 'approve_status' => $appr_status]);

                $admin_emails = DB::table('users')->select(['email as email'])->whereIn('role_id', [3,4])->pluck('email')->toArray();

                $PageID = DB::table('tblscripture')->select('Page')->where('ShabadID', $id)->min('Page');

                $url = env('FRONT_END_APP_URL', 'https://dev.khojgurbani.org') . "/commentary/" . $PageID . '/' . $id;
                
                Mail::to($admin_emails)->send(new ContentMail('comment', $url));

                $emails = DB::table('users')
                            ->distinct('email')
                            ->join('shabad_comments', 'shabad_comments.user_id', '=', 'users.id')
                            ->leftjoin('shabad_comment_replies', 'shabad_comment_replies.comment_id', '=', 'shabad_comments.id')
                            ->where('shabad_comments.shabad_id', '=', $id)
                            ->where('users.id', '!=', $user_id)
                            ->pluck('users.email');

                foreach($emails as $email){
                    Mail::to($email)->send(new ContentMail('comment', $url));
                }

                return json_encode(array(
                    'status' => '200',
                    'message' => 'comment has been added successfully.'
                ));
            }
            return json_encode(array(
                'status' => '401',
                'message' => 'User blocked.'
            ));
        }
        else
        {
            return json_encode(array(
                'status' => '201',
                'message' => 'Field is empty'
            ));
        }
    }
    //Add comments END
    //Update comments START
    public function update_comment(Request $request, $id)
    {
        $text = $request->text;
        $user_id = $request->user_id;
        if ($text != '' && $user_id != '')
        {
            $comment_author = DB::table('users')->where('id', $user_id)->first();
            if (isset($comment_author) && $comment_author->role_id != '4')
            {
                if ($comment_author->auto_approve != '1')
                {
                    $appr_status = '0';
                }
                else
                {
                    $appr_status = '1';
                }
            }
            else
            {
                $appr_status = '1';
            }

            if ($comment_author->role_id == '4')
            {
                $appr_status = '1';
            }
            $comment_detail = DB::table('shabad_comments')->where('id', $id)->first();
            //                DB::table('shabad_comments')->where('id',$id)->update([
            //                    'status'=>'0'
            //                ]);
            //
            DB::table('shabad_comment_history')
                ->insert(['user_id' => $comment_detail->user_id, 'shabad_id' => $comment_detail->shabad_id, 'comment' => $comment_detail->comment]);

            DB::table('shabad_comments')
                ->where('id', $id)->update(['shabad_id' => $comment_detail->shabad_id, 'comment' => $text, 'approve_status' => $appr_status]);

            return json_encode(array(
                'status' => '200',
                'message' => 'comment has been updated successfully.'
            ));
        }
        else
        {
            return json_encode(array(
                'status' => '201',
                'message' => 'Field is empty'
            ));
        }
    }
    //Update comments END
    //Add replies START
    public function add_reply(Request $request, $id)
    {
        $text = $request->text;
        $user_id = $request->user_id;
        if ($text != null && $user_id != null)
        {
            $comment_author = DB::table('users')->where('id', $user_id)->first();
            if (isset($comment_author) && $comment_author->role_id != '4')
            {
                if ($comment_author->auto_approve != '1')
                {
                    $appr_status = '0';
                }
                else
                {
                    $appr_status = '1';
                }
            }
            else
            {
                $appr_status = '1';
            }

            if ($comment_author->role_id == '4')
            {
                $appr_status = '1';
            }
            DB::table('shabad_comment_replies')->insert(['comment_id' => $id, 'user_id' => $user_id, 'comment' => $text, 'approve_status' => $appr_status]);

            $admin_emails = DB::table('users')->select(['email as email'])->whereIn('role_id', [3,4])->pluck('email')->toArray();
            
            $id = DB::table('shabad_comments')->select('shabad_id')->where('id', '=', $id)->first()->shabad_id;
            
            $PageID = DB::table('tblscripture')->select('Page')->where('ShabadID', $id)->min('Page');

            $url = env('FRONT_END_APP_URL', 'https://dev.khojgurbani.org') . "/commentary/" . $PageID . '/' . $id;

            Mail::to($admin_emails)->send(new ContentMail('comment', $url));
            
            $emails = DB::table('users')
                        ->distinct('email')
                        ->join('shabad_comments', 'shabad_comments.user_id', '=', 'users.id')
                        ->leftjoin('shabad_comment_replies', 'shabad_comment_replies.comment_id', '=', 'shabad_comments.id')
                        ->where('shabad_comments.shabad_id', '=', $id)
                        ->where('users.id', '!=', $user_id)
                        ->pluck('users.email');

            foreach($emails as $email){
                Mail::to($email)->send(new ContentMail('comment', $url));
            }
            
            return json_encode(array(
                'status' => '200',
                'message' => 'reply has been added successfully.'
            ));
        }
        else
        {
            return json_encode(array(
                'status' => '201',
                'message' => 'Field is empty'
            ));
        }
    }
    //Add replies END
    //Update replies START
    public function update_reply(Request $request, $id)
    {
        $text = $request->text;
        $user_id = $request->user_id;
        if ($text != null && $user_id != null)
        {
            $comment_author = DB::table('users')->where('id', $user_id)->first();
            if (isset($comment_author) && $comment_author->role_id != '4')
            {
                if ($comment_author->auto_approve != '1')
                {
                    $appr_status = '0';
                }
                else
                {
                    $appr_status = '1';
                }
            }
            else
            {
                $appr_status = '1';
            }

            if ($comment_author->role_id == '4')
            {
                $appr_status = '1';
            }
            DB::table('shabad_comment_replies')->where('id', $id)->update(['comment' => $text, 'approve_status' => $appr_status]);

            return json_encode(array(
                'status' => '200',
                'message' => 'reply has been updated successfully.'
            ));
        }
        else
        {
            return json_encode(array(
                'status' => '201',
                'message' => 'Field is empty'
            ));
        }
    }
    //Update replies END
    //Get shabad commentary START
    public function shabad_comments(Request $request, $id)
    {
        $scripture_count = DB::table('shabad_comments')->where('shabad_id', $id)->count();
        if ($scripture_count > 0)
        {
            $data = DB::table('shabad_comments')->leftjoin('users', 'users.id', '=', 'shabad_comments.user_id')
                ->leftjoin('role', 'role.id', '=', 'users.role_id')
                ->select('shabad_comments.*', 'users.name', 'users.role_id', 'users.is_block', 'users.auto_approve', 'role.name as role_name', 'users.photo_url')
                ->where('shabad_comments.shabad_id', $id)
            // ->where('shabad_comments.approve_status','0')
            //                    ->where('shabad_comments.status','1')
            ->get();
            //$result=[];
            foreach ($data as $key => $datas)
            {
				//$data[$key]->photo_url = $datas->photo_url;
				
                $data_replies = DB::table('shabad_comment_replies')->leftjoin('users', 'users.id', '=', 'shabad_comment_replies.user_id')
                    ->leftjoin('role', 'role.id', '=', 'users.role_id')
                    ->select('shabad_comment_replies.*', 'users.name', 'users.role_id', 'users.is_block', 'users.auto_approve', 'role.name as role_name', 'users.photo_url')
                    ->where('shabad_comment_replies.comment_id', $datas->id)
                // ->where('shabad_comment_replies.approve_status','0')
                //                    ->where('shabad_comment_replies.status','1')
                
                    ->get();
					
				/*foreach ($data_replies as $key_replies => $datas_replies)
            	{
					$data_replies[$key_replies]->photo_url = $datas_replies->photo_url;
				}*/
					
                $data[$key]->replies = $data_replies;
            }

            return json_encode(array(
                'status' => '200',
                'message' => 'Commentary List',
                'result' => $data
            ));
        }
        else
        {
            $data = [];
            return json_encode(array(
                'status' => '200',
                'message' => 'Commentary List',
                'result' => $data
            ));
        }
    }
    //Get shabad commentary END
    //Delete Comment START
    public function shabad_comment_delete(Request $request, $id)
    {
        $comment_count = DB::table('shabad_comments')->where('id', $id)->count();
        if ($comment_count > 0)
        {
            DB::table('shabad_comments')->where('id', $id)->delete();
            DB::table('shabad_comment_replies')
                ->where('comment_id', $id)->delete();
            return json_encode(array(
                'status' => '200',
                'message' => 'Comment has been deleted successfully.'
            ));
        }
        else
        {
            return json_encode(array(
                'status' => '201',
                'message' => 'Somthing went wrong'
            ));
        }
    }
    //Delete Comment END
    //Comment approve START
    public function comment_status(Request $request, $id)
    {
        $status = $request->status;
        $podcast_cat_check = DB::table('shabad_comments')->where('id', $id)->count();
        if ($podcast_cat_check > 0)
        {
            if ($status == '1')
            {
                DB::table('shabad_comments')->where('id', $id)->update(['approve_status' => $status]);

                return json_encode(array(
                    'success' => '200',
                    'message' => 'Status has been updated successfully'
                ));
            }
            if ($status == '0')
            {
                DB::table('shabad_comments')->where('id', $id)->update(['approve_status' => $status]);

                return json_encode(array(
                    'success' => '200',
                    'message' => 'Status has been updated successfully'
                ));
            }
            if ($status != '0' || $status != '1')
            {
                return json_encode(array(
                    'success' => '201',
                    'message' => 'Somthing went wrong'
                ));
            }
        }
        else
        {
            return json_encode(array(
                'success' => '201',
                'message' => 'No media Exist with this detail'
            ));
        }
    }

    //Comment approve status END
    //Delete Reply START
    public function shabad_reply_delete(Request $request, $id)
    {
        $comment_count = DB::table('shabad_comment_replies')->where('id', $id)->count();
        if ($comment_count > 0)
        {
            DB::table('shabad_comment_replies')->where('id', $id)->delete();
            return json_encode(array(
                'status' => '200',
                'message' => 'Reply has been deleted successfully.'
            ));
        }
        else
        {
            return json_encode(array(
                'status' => '201',
                'message' => 'Somthing went wrong'
            ));
        }
    }
    //Delete Reply END
    

    //Reply approve START
    public function reply_status(Request $request, $id)
    {
        $status = $request->status;
        $podcast_cat_check = DB::table('shabad_comment_replies')->where('id', $id)->count();
        if ($podcast_cat_check > 0)
        {
            if ($status == '1')
            {
                DB::table('shabad_comment_replies')->where('id', $id)->update(['approve_status' => $status]);

                return json_encode(array(
                    'success' => '200',
                    'message' => 'Status has been updated successfully'
                ));
            }
            if ($status == '0')
            {
                DB::table('shabad_comment_replies')->where('id', $id)->update(['approve_status' => $status]);

                return json_encode(array(
                    'success' => '200',
                    'message' => 'Status has been updated successfully'
                ));
            }
            if ($status != '0' || $status != '1')
            {
                return json_encode(array(
                    'success' => '201',
                    'message' => 'Somthing went wrong'
                ));
            }
        }
        else
        {
            return json_encode(array(
                'success' => '201',
                'message' => 'No media Exist with this detail'
            ));
        }
    }

    //Reply approve status END
    //Export shabad START
    public function export_shabad(Request $request)
    {
        $from_shabad = $_GET['from'];
        $to_shabad = $_GET['to'];
        $sid = $_GET['sid'];
        $gurumukhi_type = json_decode($request->input('type'));
        $english_translation = json_decode($request->input('english'));
        $teeka = json_decode($request->input('teeka'));
        $format_type = $_GET['format_type'];
        $format_file = $_GET['format_file'];
        /*$shabad_from_to = DB::table('tblscripture')->whereBetween('id', array(
            $from_shabad,
            $to_shabad
        ))->get();*/
        $shabad_from_to = DB::table('tblscripture')->where('ShabadId', $sid)->get();
        // echo "<pre>"; print_r($english_translation); die;
        foreach ($shabad_from_to as $key => $shabad_from_tos)
        {
            $shabad_trans = DB::table('translation')->where('ScriptureID', $shabad_from_tos->id)
                ->first();
            $shabad_from_to[$key]->english_translation = $english_translation;
            $shabad_from_to[$key]->gurumukhi_type = $gurumukhi_type;
            $shabad_from_to[$key]->teeka = $teeka;
            $shabad_from_to[$key]->translation = $shabad_trans;
        }
        return json_encode(array(
            'success' => '200',
            'message' => 'Export shabad',
            'result' => $shabad_from_to,
            'format_file' => $format_file,
            'format_type' => $format_type
        ));
    }
    //Export shabad END
    //Get unapproved commetns'
    public function getUnapprovedComments()
    {
        $unapprovedData = DB::table('shabad_comments')->join('users', 'users.id', '=', 'shabad_comments.user_id')
            ->select('shabad_comments.*', 'users.name')
            ->where('approve_status', '=', '0')
            ->get();
        if (count($unapprovedData) > 0)
        {
            foreach ($unapprovedData as $key => $value)
            {
                @$pageID = DB::table('tblscripture')->select('Page')
                    ->where('ShabadID', $value->shabad_id)
                    ->min('Page');
                $unapprovedData[$key]->page_id = $pageID;
            }
            $data = $unapprovedData;
        }
        else
        {
            $data = array();
        }
        return json_encode(array(
            'status' => '200',
            'message' => 'UnapprovedComments',
            'result' => $data
        ));
    }
}

