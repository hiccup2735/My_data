<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Input;
use App\Http\Controllers\ApiController;
use App\Repositories\MediaAuthorsRepository;
use App\Transformers\Api\MediaAuthorTransformer;
use Illuminate\Http\Request;
// import the Intervention Image Manager Class
use Intervention\Image\ImageManagerStatic as Image;

// configure with favored image driver (gd by default)

use DB;
class MediaAuthorsController extends ApiController
{
    protected $repository;

	public function __construct(MediaAuthorsRepository $repository)
	{
		$this->repository = $repository;
	}

    /**
     * get list of all the categories.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function all(Request $request)
    {
    	$items = $this->repository->get($request)->where('status','1');
        $sorted = $items->sortBy('name');

    	return $this->get($sorted, new MediaAuthorTransformer, 'media-authors');
    }

    /**
     * get featured authors.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function getFeaturedItems(Request $request)
    {
        //$items = $this->repository->getFeaturedItems($request);

        //return $this->get($items, new MediaAuthorTransformer, 'media-authors');
        
        $items = DB::table('media_authors')->where('featured','1')->where('status','1')->orderBy('featured_display_order','asc')->get();

        if (count($items) > 0) {
            foreach ($items as $item) { 
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/author/') . '/' . $item->image;
                }
               
                $data[] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'status' => $item->status,
                    'attachment_name' => $category_image
                );
            }
        } else {
            $data = [];
        }
        return json_encode(array('success' => '200', 'message' => 'Media Author List', 'result' => $data));
    }
    ////////////// Media Author Management ////////////////
    //Add Media Author START
    public function add_media_author(Request $request) {
        $name = $request->name;
        $description = $request->description;
        if ($request->file('image')) {
            // Image::configure(array('driver' => 'imagick'));
            $file = $request->file('image');
            Image::make($file)->crop(175, 175)->save();
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/author/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
            $image = "";
        }
        $podcast_cat_count = DB::table('media_authors')->where('name', $name)->count();
        if ($podcast_cat_count > 0) {
            return json_encode(array('success' => '201', 'message' => 'Name with this already exist. Please try with new one.'));
        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('media_authors')->insert([
                'name' => $name,
                'description' => $description,
                'slug' => $slug,
                'image' => $image,
                'status' => '1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'New media author created successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }
    //Add Media Author END
    
    //update Media Author START
    public function update_media_author(Request $request, $id) {
        $podcast_detail = DB::table('media_authors')->where('id', $id)->first();
        $name = $request->name;
        $description = $request->description;
        
        $podcast_cat_count = DB::table('media_authors')->where('id','!=',$id)->where('name', $name)->count();
        if ($podcast_cat_count > 0) {
            return json_encode(array('success' => '201', 'message' => 'Name with this already exist. Please try with new one.'));
        }
        
        if ($request->file('image')) {
            $file = $request->file('image');
            Image::make($file)->resize(500, 500)->save();
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/author/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
            $image = $podcast_detail->image;
        } 
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('media_authors')->where('id', $id)->update([
                'name' => $name,
                'description' => $description,
                'slug' => $slug,
                'image' => $image,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'Media author has been updated successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }
    //update Media Author END
    
    //update Media Author status START
    public function update_status(Request $request, $id) {
        $status = $request->status;
        $podcast_cat_check = DB::table('media_authors')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1') {
                DB::table('media_authors')->where('id', $id)->update([
                    'status' => $status
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if ($status == '0') {
                DB::table('media_authors')->where('id', $id)->update([
                    'status' => $status
                ]);
                DB::table('media_authors')->where('id', $id)->update([
                    'status' => $status,
                    'featured'=>'0',
                    'featured_display_order'=>NULL
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if($status!='0' || $status!='1') {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No author Exist with this detail'));
        }
    }
    //update Media Author status END
    
    //delete media author START
    public function delete_media_author(Request $request,$id){
        $podcast_cat_check = DB::table('media_authors')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('media_authors')->where('id',$id)->delete();
            DB::table('media')->where('author_id',$id)->delete();
            return json_encode(array('success' => '200', 'message' => 'Media author has been deleted successfully.'));
        }else{
            return json_encode(array('success' => '201', 'message' => 'No author Exist with this detail'));
        }
    }
    //delete media author END
    
    //List media author START
    public function media_author_list(Request $request) {
        $items = DB::table('media_authors')->where('status','1')->get();

        if (count($items) > 0) {
            foreach ($items as $item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/author/') . '/' . $item->image;
                }
                if($item->description==null){
                    $description = 'N/A';
                }else{
                    $description = $item->description;
                }
                $data[] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'description' => $description,
                    'status' => $item->status,
                    'attachment_name' => $category_image
                );
            }
        } else {
            $data = [];
        }
        return json_encode(array('success' => '200', 'message' => 'Media Author List', 'result' => $data));
    }

    //List media author END
    
    //List media author START
    public function media_author_alphabet_list(Request $request) {
        $items = DB::table('media_authors')
        ->select('media_authors.*')
//        ->leftjoin('user_singer', 'media_authors.id', '=', 'user_singer.singer_id')
		->where('name', '!=', 'YouTube')
		->where('status', '=','1')
        ->orderBy('name')
        ->get();

        if (count($items) > 0) {
            foreach ($items as $k=>$item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/author/') . '/' . $item->image;
                }
                if($item->description==null){
                    $description = 'N/A';
                }else{
                    $description = $item->description;
                }
                $data[] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'description' => $description,
                    'status' => $item->status,
                    'attachment_name' => $category_image,
                    'user_singer_id' => 0
                );
//                $items[$k]->description=$description;
//                $items[$k]->attachment_name=$category_image;
            }
        } else {
            $data = [];
        }
        return json_encode(array('success' => '200', 'message' => 'Media Author List', 'result' => $data));
    }

    //List media author END
    
    ////////////// Media Author Management ////////////////
}
