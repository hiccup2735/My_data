<?php

namespace App\Http\Controllers;

use App\Http\Controllers\ApiController;
use App\Http\Requests\Api\StoreMediaTrackingRequest;
use App\Models\MediaTracking;
use App\Repositories\MediaTrackingsRepository;
use App\Transformers\Api\MediaTransformer;
use Auth;
use Exception;
use Illuminate\Http\Request;

class MediaTrackingsController extends ApiController
{
	protected $repository;

	public function __construct(MediaTrackingsRepository $repository)
	{
		$this->repository = $repository;
	}

	/**
	 * get media list for user recently accessed.
	 * 
	 * @param  $request: Illuminate\Http\Request
	 * @return json of media.
	 */
	public function getRecentlyAccessedMedia(Request $request)
	{
		$items = $this->repository->getRecentlyAccessedMedia($request);
		return $this->paginate($items, new MediaTransformer, 'media');
	}

	/**
	 * store tracking of media user wise.
	 * 
	 * @param  $request: App\Http\Requests\Api\StoreMediaTrackingRequest
	 * @param  $item: App\Models\MediaTracking
	 * @return json of response.
	 */
	public function store(StoreMediaTrackingRequest $request, MediaTracking $item)
	{
		if(!Auth::check()) {
			return $this->respond([], 'You are not logged in.');
		}

		try {
			
			$user = Auth::user();

			$item->setMediaId($request->input('media_id'))
				->setUserId($user->getKey());

			$item = $this->repository->save($item);
			return $this->respond($item);
		} catch (Exception $e) {
			return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
		}
	}
    
}
