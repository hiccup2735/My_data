<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Repositories\BlogRepository;
use Response, Exception;
use Symfony\Component\HttpFoundation\Response as ResponseCode;
use App\Mail\ContentMail;
use App\Mail\UserContentMail;
use Illuminate\Support\Facades\Mail;

class BlogController extends Controller
{

    private $repository;

    function __construct(BlogRepository $repository)
    {
        $this->repository = $repository;
    }

    public function index(Request $request)
    {
        $blogs = $this->repository->getBlogs($request);

    	return Response::json([
			'status' => 'success',
			'data'=>$blogs 
		]);
    }
    
    //Get Blogs by shabad ID
    public function getBlogbyShabadID(Request $request)
    {
    	try {
            $shabad_id = $request->shabad_id;
	    	$blog = DB::table('news')->where('news_shabad','=',$shabad_id)->get();
	    	return Response::json([
				'status' => 'success',
				'data'=>$blog
			]);
    	} catch (Exception $e) {
    		return Response::json([
				'status' => 'error',
				'message'=> $e->getMessage()
			], $e->getCode());
    	}
    }
    //End get blogs
    public function show($id)
    {
    	try {
	    	$blog = $this->repository->getBlog($id);
	    	//print_r(Auth::user()->role_id); die;
	    	
	   // 	foreach($blog->comments as $key=>$comments){
	   // 	    if($blog->comments[$key]->comment_approve=='0'){
	   // 	        unset($blog->comments[$key]);
	   // 	    }
	   // 	}
           
	    	return Response::json([
				'status' => 'success',
				'data'=>$blog
			]);
    	} catch (Exception $e) {
    		return Response::json([
				'status' => 'error',
				'message'=> $e->getMessage()
			], $e->getCode());
    	}
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'title' => 'required',
            'content' => 'required',
            'author' => 'required',
        ]);

        try {

            $blog = $this->repository->storeBlog($request);
            //$admin_es = DB::table('users')->select(['email as email'])->whereIn('role_id', [3,4])->pluck('email')->toArray();

            //Mail::to($admin_emails)->send(new ContentMail('blog'));

            $blogUrl = env('FRONT_END_APP_URL', 'https://dev.khojgurbani.org') . "/blog/" . $blog->news_id;
            //$non_blocked_emails = DB::table('users')->select(['email as email'])->where('is_block', 0)->whereIn('role_id', [2, 3, 4])->pluck('email')->toArray();
            //Mail::to($non_blocked_emails)->send(new UserContentMail('blog', $blogUrl));

            return Response::json([
                'status' => 'success',
                'data' => $blog,
                'message' => 'Blog successfully saved.'
            ]);
        } catch (Exception $e) {
            return Response::json([
                'status' => 'error',
                'message'=> $e->getMessage()
            ], ResponseCode::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    public function update($id, Request $request)
    {
        $validatedData = $request->validate([
            'title' => 'required',
            'content' => 'required',
            'author' => 'required',
        ]);

        try {
            $blog = $this->repository->updateBlog($id, $request);

            return Response::json([
                'status' => 'success',
                'data' => $blog,
                'message' => 'Blog successfully update.'
            ]);
        } catch (Exception $e) {
            return Response::json([
                'status' => 'error',
                'message'=> $e->getMessage()
            ], ResponseCode::HTTP_UNPROCESSABLE_ENTITY);
        }
    }
    //Aakash Started Here
    public function approveBlog(Request $request){
        $blogID = $request->media_id;
        $status = $request->status;
        if($blogID){
          
           $result =  DB::table('news')->where('news_id',$blogID)->update([
                'is_approved'=>$status
            ]);
            if($result){
                return json_encode(array('success' => '200', 'message' => 'Status updated successfully'));
            }else{
                return json_encode(array('error' => '404', 'message' => 'Status not updated'));
            }
            
        }else{
            return json_encode(array('error' => '404', 'message' => 'Status not updated'));
        }
    }
    public function delete($id,Request $request){
        if($request->id){
            $blog = $this->repository->deleteBlog($id);
            if($blog){
                return Response::json([
                    'status' => 'success',
                    'data' => $blog,
                    'message' => 'Blog successfully Deleted.'
                ]);
            }else{
                return Response::json([
                    'status' => 'error',
                    'data' => $blog,
                    'message' => 'Blog Not Deleted Succesfully.'
                ]);
            }
        }
    }
    public function searchblog(Request $request)
    {
    	try {
           
           
	    	$blog = $this->repository->getBlogSearch($request);
	    	//print_r(Auth::user()->role_id); die;
	    	
	   // 	foreach($blog->comments as $key=>$comments){
	   // 	    if($blog->comments[$key]->comment_approve=='0'){
	   // 	        unset($blog->comments[$key]);
	   // 	    }
	   // 	}
           
	    	return Response::json([
				'status' => 'success',
				'data'=>$blog
			]);
    	} catch (Exception $e) {
    		return Response::json([
				'status' => 'error',
				'message'=> $e->getMessage()
			], $e->getCode());
    	}
    }
    //Aakash eneded here
}
