<?php

namespace App\Http\Controllers\ApiAuth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\ChangePasswordRequest;
use App\Repositories\ChangePasswordRepository;
use Auth;
use Illuminate\Http\Request;

class ChangePasswordController extends Controller
{
	protected $repository;

	public function __construct(ChangePasswordRepository $repository)
	{
		$this->repository = $repository;
	}


    public function index(ChangePasswordRequest $request)
    {
    	try {
			$userId = Auth::id();
			$this->repository->changePassword($userId, $request);
		} catch (Exception $e) {
			return $this->getErrorResponse($e->getMessage(), $e->getCode());
		}

		return $this->respond([], 'Your password has been changed.');
    }
}
