@extends('admin.layouts.app', ['title' => 'Media Sub Categories'])

@section('contents')
<div class="container-fluid">

	<!-- Breadcrumbs-->
	<ol class="breadcrumb">
		<li class="breadcrumb-item">
			<a href="{{ route('admin.dashboard') }}">Dashboard</a>
		</li>
		<li class="breadcrumb-item active">Media Sub Categories</li>
	</ol>
        @include('admin.media-subcategories.partials.form')
<!--	<div class="card mb-3">
		
	</div>-->

        @include('admin.media-subcategories.partials.listing')
<!--	<div class="card mb-3">
		
	</div>-->
</div>
@endsection
