<div class="text-right" style="overflow: hidden;">
<button type="button" id="CategoryMediaListing" class="btn btn-primary">Add</button>
</div>
<!--<div class="card-header">
	<i class="fas fa-table"></i> Category Listing
        
</div>-->
<div class="">

            <table id="media_category_listing_datatable" class="table table-striped table-borderless" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Image</th>
                <!--<th>Description</th>-->
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($items as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->present()->name }}</td>
                <td>
                    @if($item->present()->image!='')
                    <img src="{{asset('uploads/category/'.$item->present()->image)}}" width="50" height="50">
                    @else
                    N/A
                    @endif
                </td>
                <!--<td>{{ $item->present()->description }}</td>-->
                <td>{!! $item->present()->statusLink !!}</td>
                <td>
                    {!! $item->present()->editLink !!}
                    &nbsp;
                    {!! $item->present()->deleteLink !!}
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
	</div>
