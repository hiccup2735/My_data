<?php
$name = \Request::old('name');
$status = \Request::old('status');
$formUrl = route('admin.media.authors.store');
$heading = '<i class="fas fa-plus"></i> Add Author';
if ($item) {
    $formUrl = route('admin.media.authors.update', $item->getKey());
    $name = \Request::old('name', $item->getName());
    $status = \Request::old('status', $item->getStatus());
    $heading = '<i class="fas fa-edit"></i> Edit Author';
}
$isChecked = $status ? "checked" : null;
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$last_parts = explode("/", $actual_link); 
?>

<div id="categoryAddForm" @if(!is_numeric(end($last_parts))) style="display: none;" @endif>
     <div class="text-left mb-3">
        {!! $heading !!}
    </div>
     <form action="{{ $formUrl }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <div class="form-row">
                <div class="col-md-12">
                    <div class="form-label-group">
                        <input type="text" 
                               id="name" 
                               name="name" 
                               class="form-control" 
                               placeholder="Name" 
                               autofocus="autofocus"
                               value="{{ $name }}">

                        <label for="name">name</label>
                        @if( $errors->has('name'))
                        <div class="alert alert-danger">{{ $errors->first('name') }}</div>

                        @endif
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="form-row">
                <div class="col-md-12">
                    <div class="form-label-group">
                        <label for="category_image_id" class="btn btn-success btn-block btn-outlined col-sm-4">Select Author Image</label>
                        <input type="file" id="category_image_id" name="image" style="display: none;"  accept="image/x-png,image/gif,image/jpeg" >
<!--                        <input type="file" name="image">-->
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="checkbox">
                <label>
                    <input type="checkbox" name="status" value="1" {{ $isChecked }}>
                    Status
                </label>
            </div>
        </div>
        <button type="submit" 
                name="login"
                class="btn btn-primary">

            Save
       	</button>
        <a href="{{ route('admin.media.authors.index') }}" class="btn btn-default">Cancel</a>
    </form>
</div>
<!--<div class="card-body">
    
</div>-->