<?php
	$name = \Request::input('name');
	$status = \Request::input('status');
?>

<div class="card-header">
	Search Media Authors
</div>
<div class="card-body">
	<form action="{{ route('admin.media.authors.index') }}" method="GET">
		<div class="form-group">
			<div class="form-row">
				<div class="col-md-6">
					<div class="form-label-group">
						<input type="text" 
							id="searchNameInput" 
							name="name" 
							class="form-control" 
							placeholder="Name" 
							autofocus="autofocus"
							value="{{ $name }}">
						
						<label for="searchNameInput">name</label>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-label-group">
						<select name="status" class="form-control">
							<option value="">--Select Status--</option>
							<option value="1" <?php echo ($status == 1) ? "selected" : ''?>>Active</option>
							<option value="0" <?php echo ($status == '0') ? "selected" : ''?>>Inactive</option>
						</select>
					</div>
				</div>
			</div>
		</div>
		<button type="submit" 
            name="search"
            class="btn btn-primary">
        	
        	Search
       	</button>
		<a href="{{ route('admin.media.authors.index') }}" class="btn btn-default">Reset</a>
	</form>
</div>