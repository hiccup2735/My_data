@extends('admin.layouts.app', ['title' => 'Media Authors'])

@section('contents')
<div class="container-fluid">

	<!-- Breadcrumbs-->
	<ol class="breadcrumb">
		<li class="breadcrumb-item">
			<a href="{{ route('admin.dashboard') }}">Dashboard</a>
		</li>
		<li class="breadcrumb-item active">Media Authors</li>
	</ol>

	
	@include('admin.media-authors.partials.form')
        
        @include('admin.media-authors.partials.listing')
	
<!--	<div class="card mb-3">
		
	</div>-->

</div>
@endsection
