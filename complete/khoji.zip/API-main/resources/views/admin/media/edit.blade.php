@extends('admin.layouts.app', ['title' => 'Edit Media'])

@section('contents')
<div class="container-fluid">

	<!-- Breadcrumbs-->
	<ol class="breadcrumb">
		<li class="breadcrumb-item">
			<a href="{{ route('admin.dashboard') }}">Dashboard</a>
		</li>
		<li class="breadcrumb-item">
			<a href="{{ route('admin.media.index') }}">Media</a>
		</li>
		<li class="breadcrumb-item active">Edit</li>
	</ol>

	<div class="card mb-3">
		<div class="card-header">
			Edit Media
		</div>
		<div class="card-body">
			<form action="{{ route('admin.media.update', ['media' => $item->getKey()]) }}" method="POST" enctype="multipart/form-data">
				<input type="hidden" name="_method" value="put">
				@csrf
				@include('admin.media.partials.form')

				<button type="submit" name="store" class="btn btn-primary">
		        	Save
		       	</button>
				<a href="{{ route('admin.media.index') }}" class="btn btn-default">
					Cancel
				</a>
			</form>
		</div>
	</div>
</div>
@endsection
