<?php
	$title = \Request::input('title');
	$status = \Request::input('status');
	$selectedAuthorId = \Request::input('author_id');
	$selectedcategoryId = \Request::input('category_id');
	$selectedTagId = \Request::input('tag_id');
        
?>


<!--<div class="card-header">
	Search Media Authors
</div>-->
<div class="card-body">
    <div class="form-group text-center">
        <div class="form-row">
            <div class="col-md-12">
                <button type="submit" name="search" class="btn btn-primary" id="show_search"  @if(isset($_GET['title'])) style="display: none;" @endif> Search </button>
                
                <a href="{{ route('admin.media.create') }}" @if(isset($_GET['title'])) style="display: none;" @endif class="btn btn-success" id="show_search2"> Add </a>
					
            </div>
        </div>
    </div>
    <form action="{{ route('admin.media.index') }}" id="show_search_option" method="GET"  @if(!isset($_GET['title'])) style="display: none;" @endif>
		<div class="form-group">
			<div class="form-row">
				<div class="col-md-1">
					<label for="searchNameInput" class="pull-right">Title</label>
				</div>
				<div class="col-md-5">
					<div class="form-label-group">
						<input type="text" 
							id="searchNameInput" 
							name="title" 
							class="form-control" 
							placeholder="Title" 
							autofocus="autofocus"
							value="{{ $title }}">
						
					</div>
				</div>
				<div class="col-md-1">
					<label for="statusInput" class="pull-right">Select Status</label>
				</div>
				<div class="col-md-5">
					<div class="form-label-group">
						<select  name="status" class="form-control js-simple-select2-clear-list">
							<option value="">--Select Status--</option>
							<option value="1" <?php echo ($status == 1) ? "selected" : ''?>>Active</option>
							<option value="0" <?php echo ($status == '0') ? "selected" : ''?>>Inactive</option>
						</select>
					</div>
				</div>
			</div>
		</div>
		<div class="form-group">
			<div class="form-row">
				<div class="col-md-1">
					<label for="authorId" class="pull-right">Select Author</label>
				</div>
				<div class="col-md-5">
					<div class="form-label-group">
                                            
						<select id="authorId" name="author_id" class="form-control js-simple-select2-clear-list">
							<option value="">--Select Author--</option>
							@foreach($authors as $authorId => $authorName)
								<?php
									$selectedAuthorType = "";
									if($selectedAuthorId == $authorId) {
										$selectedAuthorType = "selected";
									}
								?>
								<option value="{{ $authorId }}" {{ $selectedAuthorType }}>{{ $authorName }}</option>
							@endforeach
						</select>
					</div>
				</div>
				<div class="col-md-1">
					<label for="categoryInput" class="pull-right">Select Category</label>
				</div>
				<div class="col-md-5">
					<div class="form-label-group">
						<select name="category_id" class="form-control js-simple-select2-clear-list">
							<option value="">--Select Category--</option>
							@foreach($categories as $categoryId => $categoryName)
								<?php
									$selectedCategoryType = "";
									if($selectedcategoryId == $categoryId) {
										$selectedCategoryType = "selected";
									}
								?>
								<option value="{{ $categoryId }}" {{ $selectedCategoryType }}>{{ $categoryName }}</option>
							@endforeach
						</select>
					</div>
				</div>
			</div>
		</div>
		<div class="form-group">
			<div class="form-row">
				<div class="col-md-1">
					<label for="tagsId" class="pull-right">Select Tag</label>
				</div>
				<div class="col-md-5">
					<div class="form-label-group">
						<select id="tagId" name="tag_id" class="form-control js-simple-select2-clear-list">
							<option value="">--Select tag--</option>
							@foreach($tags as $tagId => $tagName)
								<?php
									$selectedTagType = "";
									if($selectedTagId == $tagId) {
										$selectedTagType = "selected";
									}
								?>
								<option value="{{ $tagId }}" {{ $selectedTagType }}>{{ $tagName }}</option>
							@endforeach
						</select>
					</div>
				</div>
				<div class="col-md-6">
					&nbsp;
				</div>
			</div>
		</div>
		<div class="form-group">
			<div class="form-row">
				<div class="col-md-4">
					&nbsp;
				</div>
				<div class="col-md-4">
					<button type="submit" 
			            name="search"
			            class="btn btn-primary">
			        	
			        	Search
			       	</button>
					<a href="{{ route('admin.media.index') }}" class="btn btn-default">Reset</a>
				</div>
				<div class="col-md-4">
					&nbsp;
				</div>
			</div>
		</div>
	</form>
</div>
