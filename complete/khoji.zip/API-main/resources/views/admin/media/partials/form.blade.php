<?php
$item = $item ?? null;
$shabadName = $shabad_name ?? null;
$refType = \App\Models\Media::RESOURCE_REF_TYPE;
$selectedTags = $selectedCategories = [];
$selectedAuthorId = \Request::old('author_id');
$selectedShabadId = \Request::old('shabad_id');
$selectedStatus = \Request::old('status');
if ($item) {
    $refType = $item->getRefType();
    $selectedTags = $item->tags->pluck('id')->all();
    $selectedCategories = $item->categories->pluck('id')->all();
    $selectedAuthorId = \Request::old('author_id', $item->getAuthorId());
    $selectedShabadId = \Request::old('shabad_id', $item->getShabadId());
    $selectedStatus = \Request::old('status', $item->getStatus());
    $getSubCatsAll = DB::table('media_subcategories')->where('media_id',$item->id)->pluck('subcategory_id')->toArray();
    
}
$statusSelected = "";
if ($selectedStatus) {
    $statusSelected = "checked";
}

?>
<input type="hidden" name="ref_type" value="{{ $refType }}">

<!--<div class="form-group attachmentThumbnail" style="display: none;">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <label>Thumbnail</label>
                <span class="btn btn-success fileinput-button">
                    <i class="glyphicon glyphicon-plus"></i>
                     The file input field used as target for the file upload widget 
                    <input id="fileupload" type="file" name="thumbnail">

                    <label for="fileupload" class="btn btn-success btn-block btn-outlined col-sm-4">Select Thumbnail Image</label>
                                            <input type="file" id="fileupload" name="thumbnail" style="display: none;"  accept="image/x-png,image/gif,image/jpeg" >
                </span>
                @if( $errors->has('thumbnail'))
                <div class="alert alert-danger">{{ $errors->first('thumbnail') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>-->

<div class="form-group attachmentName" style="display: none;">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <!--<span class="btn btn-success fileinput-button">-->
                    <i class="glyphicon glyphicon-plus"></i>
                    <span>Select files...</span>
                    <!-- The file input field used as target for the file upload widget -->
                    <!--<input id="fileupload" type="file" name="attachment_name">-->
                    
                    <label for="fileupload1" class="btn btn-success btn-block btn-outlined col-sm-4">Select Mp3 File</label>
                                            <input type="file" id="fileupload1" name="attachment_name" style="display: none;"  >
                <!--</span>-->
                @if( $errors->has('attachment_name'))
                <div class="alert alert-danger">{{ $errors->first('attachment_name') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="form-group youtubeVideo" style="display: none;">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <input type="text" 
                       id="attachmentNameYoutube" 
                       name="youtube_url" 
                       class="form-control" 
                       placeholder="YouTube Url" 
                       value="{{ \Request::old('youtube_url', $item ? $item->getAttachmentName() : '') }}">

                <label for="attachmentNameYoutube">YouTube Url</label>
                @if( $errors->has('youtube_url'))
                <div class="alert alert-danger">{{ $errors->first('youtube_url') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="form-group podbeanData" style="display: none;">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <select class="form-control" name="podbean" required="">
                    <option>--Select Podbean--</option>
                    @foreach($feed_data as $feed_datas)
                    <option value="{{$feed_datas['media_data']['url']}}">{{$feed_datas['title']}}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>
</div>
<br><br>
<div class="form-group">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <div class="form-select2-container">
                    <select name="author_id" class="form-control js-simple-select2-list">
                        <option value="">--Select Author--</option>
                        @foreach($authors as $authorId => $authorName)
                        <?php
                        $selectedType = "";
                        if ($selectedAuthorId == $authorId) {
                            $selectedType = "selected";
                        }
                        ?>
                        <option value="{{ $authorId }}" {{ $selectedType }}>{{ $authorName }}</option>
                        @endforeach
                    </select>
                </div>
                @if( $errors->has('author_id'))
                <div class="alert alert-danger">{{ $errors->first('author_id') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="form-group">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <select name="shabad_id" 
                        class="form-control shabad-list"
                        data-url="{{ route('admin.shabad.list', ['search' => $selectedShabadId, 'page' => 1]) }}"
                        data-shabad-id="{{ $selectedShabadId }}">
                    <option value="">--Select Shabad--</option>
                    @if($selectedShabadId)
                    <option value="{{ $selectedShabadId }}" selected="selected">{{ $shabadName }}</option>
                    @endif
                </select>
                <!--<input type="text" required="" name="shabad_id" id="category_new" class="form-control" value="@if($selectedShabadId){{ $selectedShabadId }}  @endif">-->
                <a href="https://dev.khojgurbani.org/shabad/1/1" target="_blank">Please Select Shabad ID</a> 
                @if( $errors->has('shabad_id'))
                <div class="alert alert-danger">{{ $errors->first('shabad_id') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="form-group">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <input type="text" 
                       id="title" 
                       name="title" 
                       class="form-control" 
                       placeholder="Title" 
                       value="{{ \Request::old('title', $item ? $item->getTitle() : '') }}">

                <label for="title">Title</label>
                @if( $errors->has('title'))
                <div class="alert alert-danger">{{ $errors->first('title') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="form-group">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <select name="type" class="form-control js-media-type">
                    <!--<option value="">--Select Type--</option>-->
                    @foreach($type as $typeKey => $typeLabel)
                    <?php
                    $type = \Request::old('type', $item ? $item->getType() : '');
                    $selectedType = "";
                    if ($type == $typeKey) {
                        $selectedType = "selected";
                    }
                    ?>
                    <option value="{{ $typeKey }}" {{ $selectedType }}>{{ $typeLabel }}</option>
                    @endforeach
                </select>
                @if( $errors->has('type'))
                <div class="alert alert-danger">{{ $errors->first('type') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>


<div class="form-group vimeoVideo" style="display: none;">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <input type="text" 
                       id="attachmentNameVimeoUrl" 
                       name="vimeo_url" 
                       class="form-control" 
                       placeholder="YouTube Url" 
                       value="{{ \Request::old('vimeo_url', $item ? $item->getAttachmentName() : '') }}">

                <label for="attachmentNameVimeoUrl">Vimeo Url</label>
                @if( $errors->has('vimeo_url'))
                <div class="alert alert-danger">{{ $errors->first('vimeo_url') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>



<!--<div class="form-group">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <textarea id="descriptionInput" rows="4" class="form-control" name="description" placeholder="Description">{{ \Request::old('description', $item ? $item->getDescription() : '') }}</textarea>
            </div>
        </div>
    </div>
</div>-->
<div class="form-group">
    <div class="checkbox">
        <label>
            <input type="hidden" name="status" value="1">
            <!--Status-->
        </label>
    </div>
</div>
<div class="form-group">
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-label-group">
                <div class="form-select2-container">
                    <label for="tagsList">Select Tags</label>
                    <select id="tagsList" name="tags[]" class="form-control js-multiple-select2-list" multiple="multiple">
                        @foreach($tags as $tagId => $tagName)
                        <?php
                        $selectedTags = \Request::old('tags', $selectedTags);
                        $selectedTag = "";
                        if (in_array($tagId, $selectedTags)) {
                            $selectedTag = "selected";
                        }
                        ?>
                        <option value="{{ $tagId }}" {{ $selectedTag }} @if($selectedTag=='') @if($tagId=='2') selected @endif @endif>{{ $tagName }}</option>
                        @endforeach
                    </select>
                </div>
                @if( $errors->has('tags'))
                <div class="alert alert-danger">{{ $errors->first('tags') }}</div>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="form-group">
    <div class="form-row">
        <div class="col-md-12" id="category_listing">
            <div class="form-label-group">
                <div class="form-select2-container">
                    <label for="categoriessList">Select Categories</label>
                    <select id="categoriessList" name="categories[]" class="form-control js-multiple-select2-list" multiple="multiple">
                        @foreach($categories as $catId => $catName)
                        <?php
                        $selectedCategories = \Request::old('categories', $selectedCategories);
                        $selectedCat = "";
                        if (in_array($catId, $selectedCategories)) {
                            $selectedCat = "selected";
                        }
                        ?>
                        <option value="{{ $catId }}" {{ $selectedCat }}>{{ $catName }}</option>
                        @endforeach
                    </select>
                    
                </div>
                
<!--                <a href="#" id="addNewCat">Add New Category</a>
                <a href="#" id="hideNewCat" style="display: none;">Hide New Category</a>-->
                    
                @if( $errors->has('categories'))
                
                <div class="alert alert-danger">{{ $errors->first('categories') }}</div>
                @endif
            </div>
        </div>
        
        <!--<div class="col-md-12" id="new_category_data" style="display: none;">-->
            <div class="col-md-12 form-label-group">
                <div class="form-select2-container">
                    <label for="categoriessList">Add New Categories</label>
                </div>
                <input type="text" name="category_new" id="category_new" class="form-control">
                <!--<a href="#" id="hideNewCat">Hide New Category</a>-->
                    
            </div>
        <!--</div>-->
        
        <div class="col-md-12" id="category_listing">
            <div class="form-label-group">
                <div class="form-select2-container">
                    <label for="categoriessList1" >Select Sub Categories</label>
                    <select id="categoriessList1" name="subcategories[]" class="form-control js-multiple-select2-list" multiple="multiple">
                        @foreach($subcategories as $subcatId => $subcatName)
                        <?php
                        if(isset($getSubCatsAll) && !empty($getSubCatsAll)){
                        $selectedsubCat = "";
                        if (in_array($subcatId, $getSubCatsAll)) {
                            $selectedsubCat = "selected";
                        }
                        }
                        ?>
                        <option value="{{ $subcatId }}" @if(isset($getSubCatsAll) && !empty($getSubCatsAll)) {{$selectedsubCat}} @endif>{{ $subcatName }}</option>
                        @endforeach
                    </select>
                    
                </div>
                
<!--                <a href="#" id="addNewCat">Add New Category</a>
                <a href="#" id="hideNewCat" style="display: none;">Hide New Category</a>-->
                    
                
            </div>
        </div>
    </div>
</div>
