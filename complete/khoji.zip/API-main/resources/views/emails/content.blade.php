<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>::Khojgurbani::</title>
        <meta name="viewport" content="width=device-width">
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
       <style type="text/css">
			body{font-family: 'Roboto', sans-serif;font-weight: 500;}	
			a{text-decoration:none;}
            @media only screen and (max-width: 550px), screen and (max-device-width: 550px) {
                body[yahoo] .buttonwrapper { background-color: transparent !important; }
                body[yahoo] .button { padding: 0 !important; }
                body[yahoo] .button a { background-color: #c6a519; padding: 15px 25px !important; }
            }
        </style>
    </head>
    <body bgcolor="#e1e1e1" style="margin: 0; padding: 0;" yahoo="fix">      
        <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; width: 100%; max-width: 600px;margin:40px auto;" class="content">
			<tbody style="box-shadow: 0px 0px 10px #ccc;">			
			<tr>
                <td bgcolor="#000" style="padding:18px 0px;border-bottom:1px solid #ece4e4;">
                    <img src="{{ asset('images/logo.png') }}" style="display:block;margin:0 auto;width:150px;">
                </td>
            </tr>
			
            <tr>
                <td align="left" bgcolor="#ffffff" style="padding:15px 20px;color:#9c9c9c;line-height:20px;font-size:17px;text-align:center; ">	
                    <span>Waheguru Ji Ka Khalsa</span><br>			
                    <span>Waheguru Ji Ke Fateh</span>			
                </td>
            </tr>
			<tr>
                <td bgcolor="#ffffff" style="padding:15px 20px;color:#000;line-height:20px;font-size:15px;">                                      
                    <table align="left" border="0" cellpadding="0" cellspacing="0" style="width:100%;">
                        <tr>
                            <td style="text-align:center;">

                            	@switch($type)
                            	    @case('commentary')
                                        <span>Commentary is posted at this link: <a href="{{ $url }}">Click Here </a></span>
                            	        @break
                            	    @case('comment')
                                        <span>Comment is posted at this link: <a href="{{ $url }}">Click Here </a></span>
                            	        @break
                        	        @case('blog')
                                        <span>Blog is posted at this link: <a href="{{ $url }}">Click Here </a></span>
                            	        @break
                        	        @case('media')
                                        <span>Media is posted at this link: <a href="{{ $url }}">Click Here </a></span>
                            	        @break
                            	    @default
                            	            <strong>Content is subject for your approval.</strong>
                            	@endswitch
                            	
							</td>
                        </tr>
                    </table>  	
                </td>
            </tr>
<tr>
            </tr>
			{{-- <tr>
                <td bgcolor="#ffffff" style="padding:15px 20px;color:#333;line-height:20px;font-size:12px;">
                    <table align="left" border="0" cellpadding="0" cellspacing="0" style="width:30%;">
                        <tr>
                            <td>
								<span>Get the App:</span>
								<ul style="margin:0px;padding-left:0px;display:flex;list-style:none;">
									<li style="margin-right:5px;font-size:15px;"><a href="javascript:void();" style="color:#333;"><i class="fa fa-apple"></i></a></li>
									<li style="margin-right:5px;font-size:15px;"><a href="javascript:void();" style="color:#333;"><i class="fa fa-android"></i></a></li>
								</ul>
							</td>
                        </tr>
                    </table>  
					<table align="right" border="0" cellpadding="0" cellspacing="0" style="width:30%;">
                        <tr>
                            <td>
								<span>Follow us:</span>
								<ul style="margin:0px;padding-left:0px;display:flex;list-style:none;">
									<li style="margin-right:5px;font-size:15px;"><a href="javascript:void();" style="color:#333;"><i class="fa fa-facebook"></i></a></li>
									<li style="margin-right:5px;font-size:15px;"><a href="javascript:void();" style="color:#333;"><i class="fa fa-twitter"></i></a></li>
									<li style="margin-right:5px;font-size:15px;"><a href="javascript:void();" style="color:#333;"><i class="fa fa-instagram"></i></a></li>
									<li style="margin-right:5px;font-size:15px;"><a href="javascript:void();" style="color:#333;"><i class="fa fa-pinterest-square"></i></a></li>
								</ul>
							</td>
                        </tr>
                    </table>	
                </td>
            </tr> --}}
            <tr>
                <td align="center" bgcolor="#FBFBFB" style="padding:15px 10px 15px 10px;color:#9c9c9c;font-size:12px;">
                   <span>© 2021 - KhojGurbani. All rights reserved.</span><br><br>
                   <span>The Khojgurbani Team</span>
                </td>
            </tr>            
			</tbody>
		</table>        
    </body>
</html>