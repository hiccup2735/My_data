<!DOCTYPE html>
<html>
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body>
	<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; width: 100%; max-width: 600px;margin:40px auto;" class="content">
		<tbody style="box-shadow: 0px 0px 10px #ccc;">			
			<tr>
                <td bgcolor="#000" style="padding:18px 0px;border-bottom:1px solid #ece4e4;">
                    <img src="{{ asset('images/logo.png') }}" style="display:block;margin:0 auto;width:150px;">
                </td>
            </tr>
			
            <tr>
                <td align="left" bgcolor="#ffffff" style="padding:15px 20px;color:#9c9c9c;line-height:20px;font-size:17px;text-align:center; ">	
                    <span>Waheguru Ji Ka Khalsa</span><br>			
                    <span>Waheguru Ji Ke Fateh</span>			
                </td>
            </tr>
			<tr>
				<td style="padding-left: 20px">					
					<h3>Welcome to the KhojGurbani</h3>
					<br/>
					<p>Dear {{$user['name']}}</p>
					<p>Your registered email-id is {{$user['email']}}</p>
					<p>Please click <a href="{!! url('api/v1/user/verify', ['code'=>$user['verification_code']]) !!}"> here</a> to confirm email</p>
				</td>
			</tr>
		</tbody>
	</table>    
</body>

</html>