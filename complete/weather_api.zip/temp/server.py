from http.server import CGIHTTPRequestHandler, ThreadingHTTPServer

HOST, PORT = '', 9999  # Default values. Can be changed through command line arguments


class Handler(CGIHTTPRequestHandler):
    cgi_directories = ["/cgi-bin"]


def main(host, port):
    httpd = ThreadingHTTPServer((host, port), Handler)  # Multiple clients handling
    httpd.serve_forever()


if __name__ == "__main__":    
    main(HOST, PORT)