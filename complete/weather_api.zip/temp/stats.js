let xhttp = new XMLHttpRequest();

function refreshStats() {
    function fillStats(stats) {
        document.getElementById("weather-icon").innerHTML = stats.city + "%";
    }
    xhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            const stats = JSON.parse(this.responseText);
            fillStats(stats);
        }
    };
    xhttp.open("GET", "/cgi-bin/weather.py?city="+encodeURI("hello"), true);
    xhttp.send();
}
