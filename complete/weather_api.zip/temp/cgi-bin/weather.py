import requests
import json
import cgi

API_KEY = "d01ed74f13d285ba9f785fb49335bf3a"

class Stats:
    def __init__(self, city):
        self.input = "Kyoto" #city 
        self.update_data()
    
    def update_data(self):
        api = "http://api.openweathermap.org/data/2.5/weather?units=metric&q={city}&APPID={key}"
        url = api.format(city=self.input, key=API_KEY)
        response = requests.get(url)
        temp = response.json()
        self.icon = temp["weather"][0]['icon']
        self.city = temp['name']
        
        
    def to_dict(self):
        return {
            "icon": self.icon,
            "city": self.city    
                }

    def to_json(self):
        return json.dumps(self.to_dict())

form = cgi.FieldStorage()
city = form.getvalue('city', 'Kyto')
stats = Stats(city)

print("Content-type: application/json\r\n\r\n")
print(stats.to_json())
