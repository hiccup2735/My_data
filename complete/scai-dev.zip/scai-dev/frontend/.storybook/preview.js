import { ThemeProvider } from '@material-ui/core/styles'
import { addDecorator } from '@storybook/react'
import { SnackbarProvider } from 'notistack'
import * as React from 'react'
import { GlobalStyle } from '../src/components/page/utils/GlobalStyle/index'
import { muiTheme } from '../src/utils/theme'

addDecorator((storyFn) => (
  <SnackbarProvider>
    <ThemeProvider theme={muiTheme}>
      <GlobalStyle />
      {storyFn()}
    </ThemeProvider>
  </SnackbarProvider>
))
