import {
  AppBar,
  IconButton,
  Menu,
  MenuItem,
  Toolbar,
  Typography,
} from '@material-ui/core'
import MenuIcon from '@material-ui/icons/Menu'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { ManagerContext } from '../../../../contexts/ManagerContext'
import { managerPaths } from '../../../../utils/paths'
import AccountCircle from '@material-ui/icons/AccountCircle'

export const ManagerHeader = () => {
  const [anchorEl, setAnchorEl] = React.useState(null)
  const history = useHistory()
  const { logout, manager } = React.useContext(ManagerContext)
  const [anchorE2, setAnchorE2] = React.useState(null)

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const goTo = (location: string) => {
    history.push(location)
    handleClose()
  }

  const handleClick1 = (event: any) => {
    setAnchorE2(event.currentTarget)
  }

  const handleClose1 = () => {
    setAnchorE2(null)
  }


  return (
    <AppBar color="default">
      <Toolbar>
        <div style={{ flexGrow: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <IconButton
              edge="start"
              color="inherit"
              aria-label="menu"
              aria-controls="admin-header-menu"
              onClick={handleClick}
              aria-haspopup="true"
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6">サービス管理者</Typography>
          </div>
          <Menu
            id="admin-header-menu"
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem onClick={() => goTo(managerPaths.users)}>
              ユーザーの管理
            </MenuItem>
            <MenuItem onClick={() => goTo(managerPaths.examinations)}>
              試験の管理
            </MenuItem>
            <MenuItem onClick={() => goTo(managerPaths.questions)}>
              問の管理
            </MenuItem>
            <MenuItem onClick={() => goTo(managerPaths.questionCategories)}>
              問カテゴリの管理
            </MenuItem>
            <MenuItem onClick={() => goTo(managerPaths.organizations)}>
              組織の管理
            </MenuItem>
            <MenuItem onClick={() => goTo(managerPaths.organizationCategories)}>
              組織カテゴリの管理
            </MenuItem>
          </Menu>
        </div>
        <div>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <IconButton
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              color="inherit"
              onClick={handleClick1}
            >
              <AccountCircle />
            </IconButton>
            <Typography>{manager?.name}</Typography>
          </div>
          
          <Menu
            id="menu-appbar"
            anchorEl={anchorE2}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={Boolean(anchorE2)}
            onClose={handleClose1}
          >
            <MenuItem
            onClick={() => {
              logout && logout()
            }}
          >
              ログアウト
            </MenuItem>
          </Menu>
        </div>
      </Toolbar>
    </AppBar>
  )
}
