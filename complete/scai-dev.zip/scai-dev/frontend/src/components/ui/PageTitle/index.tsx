import * as React from 'react'
import { Box, Typography } from '@material-ui/core'

type Props = {
  title: React.ReactNode
}

export const PageTitle = ({ title }: Props) => (
  <Box paddingBottom="24px">
    <Typography style={{ fontSize: 22 }}>{title}</Typography>
  </Box>
)
