import * as React from 'react'
import MarkdownIt from 'markdown-it'
// import mk from 'markdown-it-katex'
import mk from '@liradb2000/markdown-it-katex'

const md = new MarkdownIt()

md.use(mk, {
  throwOnError: false,
  errorColor: ' #cc0000',
  strict: 'unknownSymbol',
  macros: {
    '\\mathbm': '\\bm',
  },
})

type Props = {
  text: string
}

export const ExamDescription = ({ text }: Props) => {
  const result = md.render(text)
  return <div dangerouslySetInnerHTML={{ __html: result }} />
}
