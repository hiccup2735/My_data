import * as React from 'react'
import { CSSProperties } from '@material-ui/core/styles/withStyles'
import { colors } from '../../../utils/theme'

type Props = {
  isPrivate?: boolean
}

export const ExamPublication = ({ isPrivate = false }: Props) => {
  const tagStyle: CSSProperties = {
    width: '100%',
    backgroundColor: '#f9f6ed',
    borderRadius: 4,
    fontSize: '12px',
    lineHeight: '20px',
    textAlign: 'center',
    color: colors.primary,
    border: `1px solid ${colors.primary}`,
  }
  let label = 'オープン'
  if (isPrivate) {
    label = 'プライベート'
  }
  return <div style={tagStyle}>{label}</div>
}
