import {
  AppBar,
  IconButton,
  Menu,
  MenuItem,
  Toolbar,
  Typography,
} from '@material-ui/core'
import MenuIcon from '@material-ui/icons/Menu'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { AdminContext } from '../../../../contexts/AdminContext'
import { adminPaths } from '../../../../utils/paths'
import AccountCircle from '@material-ui/icons/AccountCircle'

export const AdminHeader = () => {
  const [anchorEl, setAnchorEl] = React.useState(null)
  const [anchorE2, setAnchorE2] = React.useState(null)
  const history = useHistory()
  const { logout, admin } = React.useContext(AdminContext)

  // eslint-disable-next-line @typescript-eslint/no-explicit-any

  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const handleClick1 = (event: any) => {
    setAnchorE2(event.currentTarget)
  }

  const handleClose1 = () => {
    setAnchorE2(null)
  }

  const goTo = (location: string) => {
    history.push(location)
    handleClose()
  }

  return (
    <AppBar color="default">
      <Toolbar>
        <div style={{ flexGrow: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <IconButton
              edge="start"
              color="inherit"
              aria-label="menu"
              aria-controls="admin-header-menu"
              aria-haspopup="true"
              onClick={handleClick}

            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" >Admin</Typography>            
          </div>
          <div>
          <Menu
            id="admin-header-menu"
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem onClick={() => goTo(adminPaths.users)}>
              ユーザーの管理
            </MenuItem>
            <MenuItem onClick={() => goTo(adminPaths.examinations)}>
              試験の管理
            </MenuItem>
            <MenuItem onClick={() => goTo(adminPaths.questions)}>
              問の管理
            </MenuItem>
            <MenuItem onClick={() => goTo(adminPaths.questionCategories)}>
              問カテゴリの管理
            </MenuItem>
            <MenuItem onClick={() => goTo(adminPaths.organizations)}>
              組織の管理
            </MenuItem>
            <MenuItem onClick={() => goTo(adminPaths.organizationCategories)}>
              組織カテゴリの管理
            </MenuItem>
            <MenuItem onClick={() => goTo(adminPaths.operators)}>
              オペレーターの管理
            </MenuItem>
            <MenuItem onClick={() => goTo(adminPaths.managers)}>
              サービス管理者の管理
            </MenuItem>
          </Menu>
          </div>
        </div>
        <div>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <IconButton
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              color="inherit"
              onClick={handleClick1}
            >
              <AccountCircle />
            </IconButton>
            <Typography>{admin?.name}</Typography>
          </div>
          <Menu
            id="menu-appbar"
            anchorEl={anchorE2}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={Boolean(anchorE2)}
            onClose={handleClose1}
          >
            <MenuItem
              onClick={() => {
                logout && logout()
              }}
            >
              ログアウト
            </MenuItem>
          </Menu>
        </div>
      </Toolbar>
    </AppBar>
  )
}
