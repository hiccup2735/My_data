import { Container } from '@material-ui/core'
import styled from '@emotion/styled'

export const AdminPageContainer = styled(Container)`
  padding-top: 88px;
  padding-bottom: 24px;
`
