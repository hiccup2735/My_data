import React from 'react'
import { Confirm } from '.'
import { action } from '@storybook/addon-actions'

export default {
  component: Confirm,
  title: 'ui/Confirm',
}

export const Default = () => (
  <Confirm
    open={true}
    onCancel={action('onCancel')}
    onConfirm={action('onConfirm')}
    label="どうしますか？"
  />
)

export const OnlyConfirmation = () => (
  <Confirm open={true} onConfirm={action('onConfirm')} label="どうしますか？" />
)

export const OnlyCancellation = () => (
  <Confirm open={true} onCancel={action('onCancel')} label="どうしますか？" />
)
