import { Fab } from '@material-ui/core'
import { Add } from '@material-ui/icons'
import * as React from 'react'
import styled from '@emotion/styled'

const StyledFab = styled(Fab)`
  position: fixed;
  bottom: 24px;
  right: 24px;
  z-index: 1000;
`

type Props = {
  onClick?: () => void
}

export const AddButton = ({ onClick }: Props) => (
  <StyledFab
    color="primary"
    onClick={() => {
      onClick && onClick()
    }}
  >
    <Add />
  </StyledFab>
)
