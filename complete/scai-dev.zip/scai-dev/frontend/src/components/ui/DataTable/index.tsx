import * as React from 'react'
import {
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
} from '@material-ui/core'
import { colors } from '../../../utils/theme'

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type RecordType = Record<string, any>

type DataTableColumnDef<TData extends RecordType> = {
  name: string
  label: React.ReactNode
  render?: (data: TData) => React.ReactNode
}

type DataTableProps<TData extends RecordType> = {
  data: TData[]
  columns: DataTableColumnDef<TData>[]
}

export function DataTable<TData extends RecordType>({
  data,
  columns,
}: DataTableProps<TData>) {
  return (
    <Table size="small">
      <TableHead>
        <TableRow>
          {columns.map((c) => (
            <TableCell
              style={{
                color: colors.table.header.color,
                backgroundColor: colors.table.header.background,
              }}
              key={`th_${c.name}`}
            >
              {c.label}
            </TableCell>
          ))}
        </TableRow>
      </TableHead>
      <TableBody>
        {data.map((d, i) => {
          const datum: RecordType = { ...d }
          return (
            <TableRow key={`r_${i}`}>
              {columns.map((c) => (
                <TableCell
                  style={{
                    color: colors.table.column.color,
                    backgroundColor: colors.table.column.background,
                  }}
                  key={`td_${c.name}`}
                >
                  {c.render ? c.render(d) : datum[c.name] || ''}
                </TableCell>
              ))}
            </TableRow>
          )
        })}
      </TableBody>
    </Table>
  )
}
