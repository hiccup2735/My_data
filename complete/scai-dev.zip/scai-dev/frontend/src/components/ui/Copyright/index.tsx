import { Box, Typography } from '@material-ui/core'
import * as React from 'react'
import { colors } from '../../../utils/theme'

export const Copyright = () => (
  <Box style={{ textAlign: 'center', width: '100%' }}>
    <Typography style={{ fontSize: 12, color: colors.copyright }}>
      © SKILLUP NeXt, Ltd.
    </Typography>
  </Box>
)
