import {
  AppBar,
  IconButton,
  Menu,
  MenuItem,
  Toolbar,
  Typography,
} from '@material-ui/core'
import MenuIcon from '@material-ui/icons/Menu'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { OrganizerContext } from '../../../../contexts/OrganizerContext'
import { organizerPaths } from '../../../../utils/paths'
import AccountCircle from '@material-ui/icons/AccountCircle'

export const OrganizerHeader = () => {
  const [anchorEl, setAnchorEl] = React.useState(null)
  const history = useHistory()
  const { logout, organizer } = React.useContext(OrganizerContext)
  const [anchorE2, setAnchorE2] = React.useState(null)

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const goTo = (location: string) => {
    history.push(location)
    handleClose()
  }

  const handleClick1 = (event: any) => {
    setAnchorE2(event.currentTarget)
  }

  const handleClose1 = () => {
    setAnchorE2(null)
  }

  return (
    <AppBar color="default">
      <Toolbar>
        <div style={{ flexGrow: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <IconButton
              edge="start"
              color="inherit"
              aria-label="menu"
              aria-controls="admin-header-menu"
              aria-haspopup="true"
              onClick={handleClick}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6">SCAI 企業管理者ツール</Typography>
          </div>
          <Menu
            id="admin-header-menu"
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem onClick={() => goTo(organizerPaths.root)}>
              試験一覧
            </MenuItem>
            <MenuItem onClick={() => goTo(organizerPaths.users)}>
              ユーザー一覧
            </MenuItem>            
          </Menu>
        </div>
        <div>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <IconButton
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              color="inherit"
              onClick={handleClick1}
            >
              <AccountCircle />
            </IconButton>
            <Typography>{organizer?.name}</Typography>
          </div>
          
          <Menu
            id="menu-appbar"
            anchorEl={anchorE2}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={Boolean(anchorE2)}
            onClose={handleClose1}
          >
            <MenuItem
            onClick={() => {
              logout && logout()
            }}
          >
              ログアウト
            </MenuItem>
          </Menu>
        </div>
      </Toolbar>
    </AppBar>
  )
}
