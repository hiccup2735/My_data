import React from 'react'
import { Loading } from '.'

export default {
  component: Loading,
  title: 'page/Loading',
}

export const Default = () => <Loading />
