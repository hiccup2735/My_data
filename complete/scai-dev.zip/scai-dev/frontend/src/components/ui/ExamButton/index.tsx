import { Button } from '@material-ui/core'
import { CSSProperties } from '@material-ui/core/styles/withStyles'
import * as React from 'react'
import { ExaminationStatus } from '../../../types/domain'

type Props = {
  status: ExaminationStatus
  onClick: () => void
  large?: boolean
}

export const ExamButton = ({ status, onClick, large }: Props) => {
  const buttonProps: {
    variant: 'contained'
    color: 'primary' | 'default'
    disabled: boolean
    style: CSSProperties
  } = {
    variant: 'contained',
    color: 'primary',
    disabled: false,
    style: {
      width: '100%',
    },
  }
  let label = '受験する'
  if (status === 'answering') {
    //    label = '続きを回答する'
  } else if (status === 'expired') {
    buttonProps.disabled = true
    buttonProps.color = 'default'
    label = '期限切れ'
  } else if (status === 'finished') {
    label = '結果の確認'
    buttonProps.color = 'default'
  } else if (status === 'before') {
    buttonProps.disabled = true
    label = '開始前です'
    buttonProps.color = 'default'
  } else if (status === 'scoring') {
    buttonProps.disabled = true
    buttonProps.color = 'default'
    label = '採点中'
  }

  if (large) {
    buttonProps.style.height = 48
  }

  return (
    <Button {...buttonProps} onClick={() => onClick && onClick()}>
      {label}
    </Button>
  )
}
