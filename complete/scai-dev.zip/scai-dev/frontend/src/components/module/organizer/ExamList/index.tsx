import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { OrganizationExamination } from '../../../../types/domain'

type RecordType = OrganizationExamination

type Props = {
  data: (query: Query<RecordType>) => Promise<QueryResult<RecordType>>
  onClick?: (examId: number) => void
}

export const OrganizationExaminationList = ({ data, onClick }: Props) => (
  <div>
    <MaterialTable<RecordType>
      options={{
        pageSize: 20,
        pageSizeOptions: [20, 50, 100],
        search: false,
      }}
      title={
        <>
          <div style={{ display: 'inline-block', paddingRight: 16 }}>
            試験一覧
          </div>
        </>
      }
      data={data}
      onRowClick={(e, row) => {
        onClick && row && onClick(row.id)
      }}
      columns={[
        { field: 'id', title: 'ID', editable: 'never', width: '50px' },
        {
          field: 'name',
          title: '試験名',
          editable: 'never',
          sorting: false,
          cellStyle: { minWidth: 200 },
        },
        {
          field: 'description',
          title: '説明文',
          sorting: false,
          editable: 'never',
        },
        {
          field: 'license_users_count',
          title: 'ライセンス数',
          type: 'numeric',
          editable: 'never',
          sorting: false,
          width: '120px',
        },
        {
          field: 'taken_users_count',
          title: '受講済み人数',
          type: 'numeric',
          sorting: false,
          editable: 'never',
          width: '120px',
        },
        {
          field: 'start_date_time',
          title: '開始日時',
          type: 'datetime',
          sorting: false,
          width: '100px',
        },
        {
          field: 'end_date_time',
          title: '終了日時',
          type: 'datetime',
          sorting: false,
          width: '100px',
        },
      ]}
    />
  </div>
)
