import { Box } from '@material-ui/core'
import MaterialTable, { Column, Query, QueryResult } from 'material-table'
import * as React from 'react'
import { AdminExaminationUser } from '../../../../types/domain'
import { ADMIN_ROOT, adminPaths, managerPaths } from '../../../../utils/paths'
import { ExamTag } from '../../../ui/ExamTag'
import { TextLink } from '../../../ui/TextLink'

type RecordType = AdminExaminationUser

type Props = {
  data: (query: Query<RecordType>) => Promise<QueryResult<RecordType>>
}

const isAdmin = window.location.pathname.includes(ADMIN_ROOT) ? true : false

const columns = () => {
  const cols: Column<RecordType>[] = [
    {
      field: 'id',
      title: 'ID',
      editable: 'never',
      sorting: false,
      width: '50px',
    },
    {
      field: 'name',
      title: '氏名',
      sorting: false,
      editable: 'never',
      render: (row) => (
        <TextLink to={isAdmin ? adminPaths.genUser(row.id) : managerPaths.genUser(row.id)}>{row.name}</TextLink>
      )
    },
    {
      field: 'organization_name',
      title: '企業名',
      editable: 'never',
    },
    {
      width: '120px',
      field: 'status',
      title: 'ステータス',
      sorting: false,
      render: (row) => <ExamTag status={row.status} />,
    },
    {
      field: 'score',
      title: '得点',
      editable: 'never',
      sorting: false,
      width: '100px',
    },
    {
      field: 'categories',
      title: 'カテゴリ別',
      sorting: false,
      width: '300px',
      render: (row) => {
        return (
          <>
            {row.scores.map((s, i) => {
              return (
                <Box key={`c_${i}`}>
                  <strong>{s.category_name}</strong>：{s.score}％
                </Box>
              )
            })}
          </>
        )
      },
    },
  ]

  return cols
}

export const UserList = ({ data }: Props) => (
  <div>
    <MaterialTable<RecordType>
      options={{
        pageSize: 20,
        pageSizeOptions: [20, 50, 100],
      }}
      title="ユーザー一覧"
      data={data}
      columns={columns()}
    />
  </div>
)
