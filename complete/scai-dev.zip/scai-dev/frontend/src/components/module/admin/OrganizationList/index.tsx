import { People, Receipt, SupervisorAccount } from '@material-ui/icons'
import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { Organization, SessionKey } from '../../../../types/domain'
import { validate, validation } from '../../../../types/validation'
type RecordType = Organization

type Props = {
  data: (query: Query<RecordType>) => Promise<QueryResult<RecordType>>
  onAdd?: (admin: RecordType) => Promise<boolean>
  onEdit?: (admin: RecordType) => Promise<boolean>
  onDelete?: (adminId: number) => Promise<boolean>
  onClickUsers?: (organizationId: number) => void
  onClickLicenses?: (organizationId: number) => void
  onClickOrganizers?: (organizationId: number) => void
}

export const OrganizationList = ({
  data,
  onAdd,
  onEdit,
  onDelete,
  onClickUsers,
  onClickLicenses,
  onClickOrganizers,
}: Props) => {
  const pageSize = Number(sessionStorage.getItem(SessionKey.OrganizationPageSize)) || 20
  const keyword = sessionStorage.getItem(SessionKey.OrganizationKeyword) || ''

  return (
    <div>
      <MaterialTable<RecordType>
        data={data}
        options={{
          search: true,
          searchText: keyword,
          pageSize: pageSize,
        }}
        title="組織一覧"
        actions={[
          {
            icon: () => <People />,
            tooltip: 'ユーザー一覧',
            onClick: (e, row) => {
              if (!Array.isArray(row)) {
                onClickUsers && onClickUsers(row.id)
              }
            },
          },
          {
            icon: () => <Receipt />,
            tooltip: 'ライセンス一覧',
            onClick: (e, row) => {
              if (!Array.isArray(row)) {
                onClickLicenses && onClickLicenses(row.id)
              }
            },
          },
          {
            icon: () => <SupervisorAccount />,
            tooltip: '企業管理者一覧',
            onClick: (e, row) => {
              if (!Array.isArray(row)) {
                onClickOrganizers && onClickOrganizers(row.id)
              }
            },
          },
        ]}
        editable={{
          onRowAdd: (row) => {
            return onAdd ? onAdd(row) : new Promise((resolve) => resolve(true))
          },
          onRowDelete: (row) => {
            return onDelete
              ? onDelete(row.id)
              : new Promise((resolve) => resolve(true))
          },
          onRowUpdate: (newRow) => {
            return onEdit
              ? onEdit(newRow)
              : new Promise((resolve) => resolve(true))
          },
        }}
        columns={[
          { field: 'id', title: 'ID', editable: 'never', width: 50 },
          {
            field: 'name',
            title: '組織名',
            sorting: false,
            cellStyle: { minWidth: 150 },
          },
          {
            field: 'address',
            title: '住所',
            sorting: false,
            cellStyle: { minWidth: 150 },
          },
          { field: 'tel', title: '電話番号', width: 120, sorting: false },
          {
            field: 'contact_person',
            title: '担当者',
            width: 120,
            sorting: false,
          },
          {
            field: 'email',
            title: 'メールアドレス',
            width: 150,
            sorting: false,
            validate: (row) => validate(validation.email, row.email),
          },
          {
            field: 'category_id',
            title: 'カテゴリID',
            type: 'numeric',
            sorting: false,
            width: 150,
          },
          {
            field: 'comparable',
            title: '比較可',
            type: 'boolean',
            sorting: false,
            width: 100,
          },
        ]}
      />
    </div>
  )
}
