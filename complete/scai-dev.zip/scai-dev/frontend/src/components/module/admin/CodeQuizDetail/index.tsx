import styled from '@emotion/styled'
import {
  Button,
  IconButton,
  TextareaAutosize,
  TextField,
} from '@material-ui/core'
import { Delete } from '@material-ui/icons'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { useDropzone } from 'react-dropzone'
import { Controller, useForm } from 'react-hook-form'
import {
  AdminCodeQuiz,
  CodeQuizFileType,
  codeQuizFileTypes,
  codeQuizTypes,
} from '../../../../types/domain'
import { colors } from '../../../../utils/theme'
import { Select } from '../../../ui/Select'

type Props = {
  codeQuiz: AdminCodeQuiz
  onUploadCodeQuizFile: (
    codeQuizId: number | string,
    fileType: CodeQuizFileType,
    file: File,
  ) => Promise<boolean>
  onUpdateCodeQuiz: (codeQuizId: number, values: FormValues) => Promise<boolean>
  onDeleteCodeQuizFile: (codeQuizId: number, fileId: number) => Promise<boolean>
}

const Container = styled.div`
  border-radius: 4px;
  background-color: white;
  padding: 10px;

  display: flex;
  flex-direction: column;
  row-gap: 20px;

  .files {
    display: flex;
    flex-direction: column;
    row-gap: 5px;

    .file {
      display: flex;
      flex-direction: row;
      column-gap: 5px;
      justify-content: space-between;
      padding: 5px 10px;
      align-items: center;

      border-radius: 4px;
      background-color: ${colors.backgroundSub};

      .name {
        flex-grow: 1;
      }

      .type {
        width: 100px;
      }

      .delete {
        width: 48px;
      }
    }
  }

  .attributes {
    display: flex;
    row-gap: 5px;
    flex-direction: column;

    .attribute {
      display: flex;
      column-gap: 20;
      align-items: center;

      .label {
        width: 150px;
      }

      .input {
        flex-grow: 1;
      }
    }
  }

  .upload-file {
    display: flex;
    flex-direction: column;
    row-gap: 10px;
    .input {
      display: flex;
      align-items: center;

      .input-label {
        width: 200px;
      }
      .input-value {
        flex-grow: 1;
      }
    }

    .upload-file-dropzone {
      width: 100%;
      border-radius: 4px;
      border: 1px solid ${colors.separator};
      padding: 20px;
      user-select: none;
    }
  }

  div {
    .label {
      font-weight: bold;
      color: ${colors.subText};
    }
  }

  .id {
    font-weight: bold;
  }
`

type FormValues = Pick<
  AdminCodeQuiz,
  | 'compare'
  | 'criteria'
  | 'time_limit'
  | 'memory_limit'
  | 'description'
  | 'type'
  | 'sequence'
>

export const CodeQuizDetail = ({
  codeQuiz,
  onUploadCodeQuizFile,
  onUpdateCodeQuiz,
  onDeleteCodeQuizFile,
}: Props) => {
  const { enqueueSnackbar } = useSnackbar()

  const [file, setFile] = React.useState<File>()
  const [fileType, setFileType] = React.useState<CodeQuizFileType>(
    codeQuizFileTypes[0],
  )
  const [fileUploading, setFileUploading] = React.useState<boolean>(false)

  const onDrop = React.useCallback(
    (acceptedFiles) => {
      console.log('acceptedFiles', acceptedFiles)
      if (acceptedFiles.length === 0) {
        enqueueSnackbar('アップロードできるのはzipのみです', {
          variant: 'warning',
        })
        return
      }

      setFile(acceptedFiles[0] as File)
    },
    [enqueueSnackbar],
  )

  const { getInputProps, getRootProps, isDragActive } = useDropzone({
    multiple: false,
    accept: '.zip',
    onDrop,
  })

  const {
    control,
    handleSubmit,
    formState: { dirty },
  } = useForm<FormValues>({
    defaultValues: {
      compare: codeQuiz.compare,
      criteria: codeQuiz.criteria,
      time_limit: codeQuiz.time_limit,
      memory_limit: codeQuiz.memory_limit,
      description: codeQuiz.description,
      type: codeQuiz.type,
      sequence: codeQuiz.sequence,
    },
  })

  return (
    <Container key={`cq_${codeQuiz.id}`}>
      <div className="id">ID: {codeQuiz.id}</div>
      <div className="description">
        <div className="label">description</div>
        <Controller
          control={control}
          name="description"
          as={<TextareaAutosize rowsMin={4} style={{ width: '100%' }} />}
        />
      </div>
      <div className="attributes">
        <div className="attribute">
          <div className="label">criteria</div>
          <div className="input">
            <Controller
              control={control}
              name="criteria"
              as={<TextField type="number" />}
            />
          </div>
        </div>
        <div className="attribute">
          <div className="label">type</div>
          <div className="input">
            <Controller
              control={control}
              name="type"
              as={
                <Select
                  fullWidth={false}
                  style={{ width: 200 }}
                  options={codeQuizTypes.map((t) => ({
                    value: t,
                    label: t,
                  }))}
                />
              }
            />
          </div>
        </div>
        <div className="attribute">
          <div className="label">compare</div>
          <div className="input">
            <Controller control={control} name="compare" as={<TextField />} />
          </div>
        </div>

        <div className="attribute">
          <div className="label">memory_limit</div>
          <div className="input">
            <Controller
              control={control}
              name="memory_limit"
              as={<TextField type="number" />}
            />
          </div>
        </div>
        <div className="attribute">
          <div className="label">time_limit</div>
          <div className="input">
            <Controller
              control={control}
              name="time_limit"
              as={<TextField type="number" />}
            />
          </div>
        </div>
      </div>

      <div>
        <Button
          variant="contained"
          color="primary"
          disabled={!dirty}
          onClick={() => {
            handleSubmit((values) => {
              const _values: FormValues = {
                ...values,
                criteria: parseInt(`${values.criteria}`),
                time_limit: parseInt(`${values.time_limit}`),
                memory_limit: parseInt(`${values.memory_limit}`),
              }
              onUpdateCodeQuiz(codeQuiz.id, _values)
            })()
          }}
        >
          更新する
        </Button>
      </div>

      <div className="files">
        <div className="label">ファイル</div>
        {codeQuiz.files.length === 0 && (
          <div className="file">アップロードされたファイルはありません</div>
        )}
        {codeQuiz.files.map((file) => (
          <div key={`file_${file.id}`} className="file">
            <div className="name">{file.url}</div>
            <div className="type">{file.type}</div>
            <div className="delete">
              <IconButton
                onClick={() => {
                  onDeleteCodeQuizFile(codeQuiz.id, file.id)
                }}
              >
                <Delete />
              </IconButton>
            </div>
          </div>
        ))}
      </div>
      <div className="upload-file">
        <div className="label">ファイルのアップロード</div>
        <div className="input">
          <div className="input-label">type</div>
          <div className="input-value">
            <Select
              options={codeQuizFileTypes.map((t) => ({
                value: t,
                label: t,
              }))}
              onChange={(v) => {
                setFileType(v as CodeQuizFileType)
              }}
              value={fileType}
            />
          </div>
        </div>
        <div className="input">
          <div className="upload-file-dropzone" {...getRootProps()}>
            <input {...getInputProps()} />
            {isDragActive ? (
              <p>ここにファイルをドロップしてください...</p>
            ) : (
              <p>
                ファイルをアップロードするにはファイルをドラッグ&amp;ドロップするかここをクリックしてファイルを選択してください
                <br />
                {file && (
                  <>
                    現在 {file.name} が選択されています。
                    <br />
                  </>
                )}
              </p>
            )}
          </div>
        </div>
      </div>
      <div className="input">
        <Button
          disabled={!file || fileUploading}
          variant="contained"
          color="primary"
          onClick={() => {
            if (!file) {
              return
            }
            setFileUploading(true)
            onUploadCodeQuizFile(codeQuiz.id, fileType, file)
              .then((res) => {
                if (res) {
                  setFile(undefined)
                }
              })
              .finally(() => {
                setFileUploading(false)
              })
          }}
        >
          ファイルを追加する
        </Button>
      </div>
    </Container>
  )
}
