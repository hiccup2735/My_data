import { Box, Breadcrumbs, Link } from '@material-ui/core'
import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { Organizer } from '../../../../types/domain'

type RecordType = Organizer & { password?: string }

type Props = {
  organization?: Organizer
  data: (query: Query<RecordType>) => Promise<QueryResult<RecordType>>
  onAdd?: (admin: RecordType & { password?: string }) => Promise<boolean>
  onEdit?: (admin: RecordType) => Promise<boolean>
  onDelete?: (adminId: number) => Promise<boolean>
  goToList?: () => void
}

export const OrganizationOrganizerList = ({
  organization,
  data,
  onAdd,
  onEdit,
  onDelete,
  goToList,
}: Props) => (
  <div>
    <Box style={{ paddingBottom: 24 }}>
      <Breadcrumbs>
        <Link
          style={{ cursor: 'pointer' }}
          onClick={() => goToList && goToList()}
        >
          企業一覧に戻る
        </Link>
      </Breadcrumbs>
    </Box>

    <MaterialTable<RecordType>
      options={{
        pageSize: 20,
        pageSizeOptions: [20, 50, 100],
      }}
      title={
        <>
          <div style={{ display: 'inline-block', paddingRight: 16 }}>
            {organization?.name} 企業管理者一覧
          </div>
        </>
      }
      data={data}
      editable={{
        onRowAdd: (row) => {
          return onAdd ? onAdd(row) : new Promise((resolve) => resolve(true))
        },
        onRowDelete: (row) => {
          return onDelete
            ? onDelete(row.id)
            : new Promise((resolve) => resolve(true))
        },
        onRowUpdate: (newRow) => {
          return onEdit
            ? onEdit(newRow)
            : new Promise((resolve) => resolve(true))
        },
      }}
      columns={[
        { field: 'id', title: 'ID', editable: 'never' },
        { field: 'name', title: '氏名', type: 'string' },
        { field: 'email', title: 'メールアドレス', type: 'string' },
        {
          field: 'password',
          title: 'パスワード',
          type: 'string',
          editable: 'onAdd',
          render: () => '****',
        },
      ]}
    />
  </div>
)
