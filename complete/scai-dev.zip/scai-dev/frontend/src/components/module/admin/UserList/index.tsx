import MaterialTable, { Column, Query, QueryResult } from 'material-table'
import * as React from 'react'
import { AdminUser } from '../../../../types/domain'
import { adminPaths, organizerPaths, operatorPaths, OPE_ROOT, ADMIN_ROOT, MGR_ROOT, managerPaths } from '../../../../utils/paths'
import { TextLink } from '../../../ui/TextLink'

type RecordType = AdminUser & { init_password?: string }

type AdminType = 'admin' | 'organizer'

type Props = {
  adminType?: AdminType
  data: (query: Query<RecordType>) => Promise<QueryResult<RecordType>>
  onEdit?: (admin: RecordType) => Promise<boolean>
  onDelete?: (adminId: number) => Promise<boolean>
  keyword: string,
  pageSize: number
}

const columns = (adminType: AdminType) => {
  const cols: Column<RecordType>[] = [
    {
      field: 'id',
      title: 'ID',
      editable: 'never',
      sorting: false,
      width: '50px',
    },
    {
      field: 'name',
      title: 'ユーザー名',
      render: (row) => {
        const isAdmin = window.location.pathname.includes(ADMIN_ROOT) ? true : false
        const isManager = window.location.pathname.includes(MGR_ROOT) ? true : false
        const isOperator = window.location.pathname.includes(OPE_ROOT) ? true : false
        const isOrganizer = adminType === 'organizer' ? true : false
        const textlink = isAdmin ? adminPaths.genUser(row.id) :
                          isManager ? managerPaths.genUser(row.id) :
                          isOperator ? operatorPaths.genUser(row.id) :
                          isOrganizer ? organizerPaths.genUser(row.id) : ''
        return (
          <TextLink
            to={textlink}
          >
            {row.name}
          </TextLink>
      )
    },
    },
  ]

  if (adminType === 'admin') {
    cols.push(
      {
        field: 'organization_name',
        title: '企業名',
        editable: 'never',
      },
      {
        field: 'is_invited',
        title: '登録状況',
        editable: 'never',
        render: (row) => (row.is_invited ? '招待済' : '招待中'),
      },
    )
  }

  cols.push(
    {
      field: 'examination_count',
      title: '受講テスト数',
      editable: 'never',
      sorting: false,
      width: 120,
    },

    {
      field: 'email',
      title: 'メールアドレス',
    },
    {
      field: 'init_password',
      title: 'パスワード',
      render: () => '****',
      sorting: false,
      width: 200,
    },
  )

  return cols
}

export const UserList = ({
  data,
  onEdit,
  onDelete,
  adminType = 'admin',
  keyword,
  pageSize
}: Props) => (
  <div>
    <MaterialTable<RecordType>
      options={{
        searchText: keyword,
        pageSize: pageSize,
        pageSizeOptions: [20, 50, 100],
      }}
      title="ユーザー一覧"
      data={data}
      editable={{
        onRowDelete:
          adminType === 'admin'
            ? (row) => {
                return onDelete
                  ? onDelete(row.id)
                  : new Promise((resolve) => resolve(true))
              }
            : undefined,
        onRowUpdate:
          adminType === 'admin'
            ? (newRow) => {
                return onEdit
                  ? onEdit(newRow)
                  : new Promise((resolve) => resolve(true))
              }
            : undefined,
      }}
      columns={columns(adminType)}
    />
  </div>
)
