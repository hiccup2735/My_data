import React from 'react'
import { QuestionList } from '.'
import { action } from '@storybook/addon-actions'
import { getAdminQuestions } from '../../../../utils/mock'

export default {
  component: QuestionList,
  title: 'module/admin/QuestionList',
}

export const Default = () => (
  <QuestionList
    data={(query) => {
      console.log('data', query)
      return new Promise((resolve) => {
        resolve({
          data: getAdminQuestions(query.page, query.pageSize),
          page: query.page,
          totalCount: 100,
        })
      })
    }}
    onClick={action('onClick')}
  />
)
