import { TextField } from '@material-ui/core'
import { Autocomplete } from '@material-ui/lab'
import * as React from 'react'

export type Option = { id: number; name: string }

type Props = {
  options: Option[]
  onChange?: (id: number) => void
}

export const OrganizationSelector = ({ options, onChange }: Props) => {
  return (
    <Autocomplete<Option>
      options={options}
      getOptionLabel={(option) => option.name}
      onChange={(_, value) => {
        onChange && value?.id && onChange(value.id)
      }}
      //filterOptions={(options) => options}
      renderInput={(params) => (
        <TextField {...params} label="組織を選択" variant="outlined" />
      )}
    />
  )
}
