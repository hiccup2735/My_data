import { Box, Breadcrumbs, Button, Link } from '@material-ui/core'
import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { AdminUser, Organization } from '../../../../types/domain'
import { MGR_ROOT, OPE_ROOT, adminPaths, managerPaths, operatorPaths } from '../../../../utils/paths'
import { TextLink } from '../../../ui/TextLink'

type RecordType = AdminUser & { init_password?: string }

type Props = {
  organizationId: string
  organization: Organization
  data: (query: Query<RecordType>) => Promise<QueryResult<RecordType>>
  onAdd?: (admin: RecordType) => Promise<boolean>
  onEdit?: (admin: RecordType) => Promise<boolean>
  onDelete?: (adminId: number) => Promise<boolean>
  goToList?: () => void
  goToImport?: () => void
}

export const OrganizationUserList = ({
  organizationId,
  organization,
  data,
  onAdd,
  onEdit,
  onDelete,
  goToList,
  goToImport,
}: Props) => (
  <div>
    <Box style={{ paddingBottom: 24 }}>
      <Breadcrumbs>
        <Link
          style={{ cursor: 'pointer' }}
          onClick={() => goToList && goToList()}
        >
          組織一覧に戻る
        </Link>
      </Breadcrumbs>
    </Box>

    <MaterialTable<RecordType>
      options={{
        pageSize: 20,
        pageSizeOptions: [20, 50, 100],
      }}
      title={
        <>
          <div style={{ display: 'inline-block', paddingRight: 24 }}>
            {organization?.name} ユーザー一覧
          </div>
          <div style={{ display: 'inline-block' }}>
            <Button
              variant="contained"
              onClick={() => goToImport && goToImport()}
            >
              一括追加
            </Button>
          </div>
        </>
      }
      data={data}
      editable={{
        onRowAdd: (row) => {
          return onAdd ? onAdd(row) : new Promise((resolve) => resolve(true))
        },
        onRowDelete: (row) => {
          return onDelete
            ? onDelete(row.id)
            : new Promise((resolve) => resolve(true))
        },
        onRowUpdate: (newRow) => {
          return onEdit
            ? onEdit(newRow)
            : new Promise((resolve) => resolve(true))
        },
      }}
      columns={[
        { field: 'id', title: 'ID', editable: 'never' },
        {
          field: 'name',
          title: 'ユーザー名',
          render: (row) => {
            const isManager = window.location.pathname.includes(MGR_ROOT) ? true : false
            const isOperator = window.location.pathname.includes(OPE_ROOT) ? true : false
            
            const path = 
              isOperator ? operatorPaths.genOrganizationUser(organizationId, row.id) 
                : isManager ? managerPaths.genOrganizationUser(organizationId, row.id) 
                    : adminPaths.genOrganizationUser(organizationId, row.id)

            return (
              <TextLink to={path}>
                {row.name}
              </TextLink>
            )
          },
        },
        { field: 'organization_name', title: '企業名', editable: 'never' },
        {
          field: 'examination_count',
          title: '受講テスト数',
          editable: 'never',
        },

        {
          field: 'email',
          title: 'メールアドレス',
        },
        {
          field: 'init_password',
          title: 'パスワード',
          render: () => '****',
        },
      ]}
    />
  </div>
)
