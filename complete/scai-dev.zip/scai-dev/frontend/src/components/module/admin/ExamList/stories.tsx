import React from 'react'
import { ExamList } from '.'
import { getAdminExams } from '../../../../utils/mock'
import { action } from '@storybook/addon-actions'

export default {
  component: ExamList,
  title: 'module/admin/ExamList',
}

export const Default = () => (
  <ExamList
    data={(query) => {
      console.log('data', query)
      return new Promise((resolve) => {
        const exams = getAdminExams(query.page, query.pageSize)
        resolve({
          data: exams,
          page: query.page,
          totalCount: 100,
        })
      })
    }}
    onClickExam={action('onClickExam')}
  />
)
