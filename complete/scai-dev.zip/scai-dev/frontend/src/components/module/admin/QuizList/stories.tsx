import React, { useState } from 'react'
import { QuizList } from '.'
import { getQuestions } from '../QuestionList/getQuestionsMock'
import { QuizDraft } from '../../../../types/draft'
import { action } from '@storybook/addon-actions'

export default {
  component: QuizList,
  title: 'module/admin/QuizList',
}

const questions = getQuestions(0, 3)

export const Default = () => {
  const [quizzes, setQuizzes] = useState<QuizDraft[]>(questions[0].quizzes)
  return (
    <QuizList
      quizzes={quizzes}
      onDeleteQuiz={(id) => {
        setQuizzes(quizzes.filter((q) => q.id !== id))
        console.log(`quiz id: ${id} has been deleted`)
      }}
      onEdit={action('onEdit')}
    />
  )
}
