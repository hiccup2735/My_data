import React, { useState } from 'react'
import { ChoiceList } from '.'
import { Choice } from '../../../../types/domain'
import { genAdminQuestion } from '../../../../utils/mock'

export default {
  component: ChoiceList,
  title: 'module/admin/ChoiceList',
}

const question = genAdminQuestion(1)

export const Default = () => {
  const [choices, setChoices] = useState<Choice[]>(question.quizzes[0].choices)
  const [id, setId] = useState<number>(question.quizzes[0].choices.length)
  return (
    <ChoiceList
      choices={choices}
      onDelete={(id) => {
        setChoices(choices.filter((c) => c.id !== id))
        console.log(`choice id: ${id} has been deleted`)
      }}
      onCreate={(newData) => {
        console.log('onCreate', newData)
        setChoices([...choices, { id, ...newData }])
        setId(id + 1)
      }}
      onEdit={(choice) => {
        console.log('onEdit', choice)
        setChoices(
          choices.map((c) => {
            if (c.id === choice.id) {
              return choice
            } else {
              return c
            }
          })
        )
      }}
    />
  )
}
