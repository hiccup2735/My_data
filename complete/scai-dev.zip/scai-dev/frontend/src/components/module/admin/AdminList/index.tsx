import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { Admin } from '../../../../types/domain'

type Props = {
  data: (query: Query<Admin>) => Promise<QueryResult<Admin>>
  onAdd?: (admin: Admin) => Promise<boolean>
  onEdit?: (admin: Admin) => Promise<boolean>
  onDelete?: (adminId: number) => Promise<boolean>
}

export const AdminList = ({ data, onAdd, onEdit, onDelete }: Props) => (
  <div>
    <MaterialTable<Admin>
      data={data}
      editable={{
        onRowAdd: (row) => {
          return onAdd ? onAdd(row) : new Promise((resolve) => resolve(true))
        },
        onRowDelete: (row) => {
          return onDelete
            ? onDelete(row.id)
            : new Promise((resolve) => resolve(true))
        },
        onRowUpdate: (newRow) => {
          return onEdit
            ? onEdit(newRow)
            : new Promise((resolve) => resolve(true))
        },
      }}
      columns={[
        { field: 'id', title: 'ID' },
        { field: 'name', title: '管理者名' },
        { field: 'email', title: 'メールアドレス' },
      ]}
    />
  </div>
)
