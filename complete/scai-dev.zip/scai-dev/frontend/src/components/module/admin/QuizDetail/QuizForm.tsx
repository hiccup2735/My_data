import { Box, Button, Paper, TextField } from '@material-ui/core'
import * as React from 'react'
import { Controller, useForm } from 'react-hook-form'
import { AdminQuiz } from '../../../../types/domain'

type FormValues = {
  description: string
}

type Props = {
  quiz: AdminQuiz
  onSubmit?: (values: FormValues) => void
  onCancel?: () => void
}

export const QuizForm = ({ quiz, onSubmit, onCancel }: Props) => {
  const { control, handleSubmit } = useForm<FormValues>({
    defaultValues: {
      description: quiz.description,
    },
  })

  return (
    <Box component={Paper} style={{ padding: 24, marginBottom: 24 }}>
      <form
        onSubmit={handleSubmit((values) => {
          onSubmit && onSubmit(values)
        })}
      >
        <Box>
          <h3>設問ID: {quiz.id}の編集</h3>
        </Box>
        <Box style={{ paddingBottom: 24 }}>
          <h4>description</h4>
          <Box>
            <Controller
              as={
                <TextField
                  fullWidth
                  rows={5}
                  multiline
                  variant="outlined"
                  type="textarea"
                />
              }
              control={control}
              name="description"
            />
          </Box>
        </Box>
        <Box style={{ textAlign: 'right' }}>
          <Button
            variant="contained"
            onClick={() => {
              onCancel && onCancel()
            }}
            style={{ marginRight: 8 }}
          >
            キャンセル
          </Button>
          <Button variant="contained" color="primary" type="submit">
            保存する
          </Button>
        </Box>
      </form>
    </Box>
  )
}
