import { TextField } from '@material-ui/core'
import { Autocomplete } from '@material-ui/lab'
import * as React from 'react'

export type QuestionOption = { id: number; name: string }

type Props = {
  options: QuestionOption[]
  onChange?: (id: number) => void
  onInputChanged?: (text: string) => void
}

export const QuestionSelector = ({
  options,
  onChange,
  onInputChanged,
}: Props) => {
  const [timerId, setTimerId] = React.useState<number | undefined>(undefined)
  return (
    <Autocomplete<QuestionOption>
      options={options}
      getOptionLabel={(option) => option.name}
      onChange={(e, value) => {
        onChange && value?.id && onChange(value.id)
      }}
      filterOptions={(options) => options}
      renderInput={(params) => (
        <TextField
          {...params}
          label="問を選択"
          onChange={(e) => {
            if (timerId !== undefined) {
              window.clearTimeout(timerId)
            }
            const value = e.currentTarget.value
            setTimerId(
              window.setTimeout(() => {
                onInputChanged && onInputChanged(value)
              }, 500),
            )
          }}
          variant="outlined"
        />
      )}
    />
  )
}
