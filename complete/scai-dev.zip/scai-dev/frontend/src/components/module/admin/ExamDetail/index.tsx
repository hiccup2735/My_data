import styled from '@emotion/styled'
import {
  Box,
  Breadcrumbs,
  Button,
  Divider,
  Grid,
  IconButton,
  Link,
  Paper,
} from '@material-ui/core'
import { GetApp, LinkOff, Lock } from '@material-ui/icons'
import { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { DragDropContext, Draggable, Droppable } from 'react-beautiful-dnd'
import {
  AdminExamination,
  AdminExaminationUser,
  AdminQuestionTag,
  Organization,
  QuestionCategory,
  GroupNames,
} from '../../../../types/domain'
import { PageContainer } from '../../../ui/PageContainer'
import { TagSelector } from '../../TagSelector'
import { CategorySelector } from '../CategorySelector'
import { OrganizationSelector } from '../OrganizationSelector'
import { QuestionOption, QuestionSelector } from '../QuestionSelector'
import { QuestionItem } from './QuestionItem'
import { UserList } from './UserList'

const Table = styled.table`
  width: 300px;
  border: 1px solid #ccc;
  border-collapse: collapse;

  tbody {
    tr {
      td {
        padding: 10px;
        border: 1px solid #ccc;
      }
    }
  }
`

type Props = {
  exam: AdminExamination
  onEdit?: () => void
  goToList?: () => void
  onAddQuestion?: (questionId: number) => void
  onRemoveQuestion?: (questionId: number) => void
  onSearchQuestion?: (query: string) => void
  questionOptions?: QuestionOption[]
  selectedQuestionCategory?: QuestionCategory
  questionCategories: QuestionCategory[]
  onQuestionCategoryChanged: (id: number) => void
  users: (
    query: Query<AdminExaminationUser>,
  ) => Promise<QueryResult<AdminExaminationUser>>
  downloadUsers: () => void
  organizations: Organization[]
  attachOrganization: (
    organizationId: string | number,
    detach?: boolean,
  ) => void
  onReorderQuestion: (questionId: number, to: number) => void
  tags: AdminQuestionTag[]
  onChangeTags: (tags: string[]) => void
  isOperator: boolean
}

export const ExamDetail = ({
  exam,
  onEdit,
  goToList,
  questionOptions,
  onAddQuestion,
  onSearchQuestion,
  onRemoveQuestion,
  users,
  downloadUsers,
  questionCategories,
  selectedQuestionCategory,
  onQuestionCategoryChanged,
  organizations,
  attachOrganization,
  onReorderQuestion,
  tags,
  onChangeTags,
  isOperator,
}: Props) => (
  <PageContainer>
    {goToList && (
      <Box style={{ paddingBottom: 24 }}>
        <Breadcrumbs>
          <Link style={{ cursor: 'pointer' }} onClick={() => goToList()}>
            試験一覧に戻る
          </Link>
        </Breadcrumbs>
      </Box>
    )}
    <Grid style={{ padding: 24 }} component={Paper}>
      <Grid container>
        <Grid md={8} item>
          <h3>
            id: {exam.id}{' '}
            {exam.scope === 'private' && (
              <Lock style={{ verticalAlign: -4, paddingLeft: 8 }} />
            )}
          </h3>
        </Grid>
        <Grid md={4} item>
          <Box textAlign="right">
            <Button variant="contained" onClick={() => onEdit && onEdit()} disabled={isOperator}>
              編集
            </Button>
          </Box>
        </Grid>
      </Grid>
      <Grid>
        <Box>
          <h4>名称</h4>
          <Box>{exam.name} </Box>
        </Box>
        <Box>
          <h4>description</h4>
          <Box>{exam.description}</Box>
        </Box>
        <Box>
          <h4>グループ</h4>
          <Box>{GroupNames[exam.group]}</Box>
        </Box>
        <Box>
          <h4>制限時間</h4>
          <Box>{exam.limit_min}分</Box>
        </Box>
        <Box>
          <Box>
            <h4>試験コード</h4>
            <Box>{exam.code || '未設定'}</Box>
          </Box>
          <Box>
            <h4>試験タイプ</h4>
            {exam.scope === 'global' ? '公開' : '非公開'}
          </Box>
          <Box>
            <h5>組織への紐付け</h5>
            <OrganizationSelector
              options={organizations
                .filter(
                  (org) =>
                    org.id >= 0 && !exam.organization_ids.includes(org.id),
                )
                .map((org) => ({
                  name: org.name,
                  id: org.id,
                }))}
              onChange={(v) => {
                attachOrganization(v)
              }}
            />
          </Box>
          <Box>
            {exam.organization_ids.map((orgId) => (
              <Box
                key={`o_${orgId}`}
                style={{ display: 'flex', alignItems: 'center' }}
              >
                <IconButton onClick={() => attachOrganization(orgId, true)}>
                  <LinkOff />
                </IconButton>
                <Box>
                  {organizations.find((org) => org.id === orgId)?.name ||
                    `名称不明(id: ${orgId})`}
                </Box>
              </Box>
            ))}
          </Box>
        </Box>
        {
          !isOperator && (<Box>
            <Divider style={{ marginTop: 16 }} />
          <Box>
              <h4>問の追加</h4>
            </Box>
            <Box
              style={{ display: 'flex', alignItems: 'center', paddingBottom: 10 }}
            >
              <Box style={{ flexGrow: 1 }}>
                <CategorySelector
                  categories={questionCategories}
                  value={selectedQuestionCategory?.id}
                  onChange={(id) => onQuestionCategoryChanged(id)}
                />
              </Box>
              <Box style={{ width: 150, paddingLeft: 20 }}>
                カテゴリとして追加
              </Box>
            </Box>
            <Grid container spacing={2}>
              <Grid item xs={12} md={4}>
                <TagSelector
                  tags={tags}
                  onChange={(tags) => onChangeTags(tags)}
                />
              </Grid>
              <Grid item xs={12} md={8}>
                <QuestionSelector
                  options={questionOptions || []}
                  onChange={(id) => onAddQuestion && onAddQuestion(id)}
                  onInputChanged={(query) =>
                    onSearchQuestion && onSearchQuestion(query)
                  }
                />
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={12} sm={8}>
                <h4>カテゴリ毎の点数</h4>
                <Table>
                  <tbody>
                    {exam.categories.map((c) => (
                      <tr key={`c_${c.id}`}>
                        <td>{c.name}</td>
                        <td>{c.score}</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </Grid>
              <Grid item xs={12} sm={4}>
                <h4>難易度</h4>
                {exam.level}
              </Grid>
            </Grid>
          </Box>)
        }
        {
         !isOperator && (<Box><Box>
          <h4>受験状況</h4>
          <Table>
            <tbody>
              <tr>
                <td>平均点</td>
                <td>{exam.average_score}</td>
              </tr>
              <tr>
                <td>最高点</td>
                <td>{exam.best_score}</td>
              </tr>
              <tr>
                <td>最低点</td>
                <td>{exam.worst_score}</td>
              </tr>
              <tr>
                <td>受験率</td>
                <td>{exam.attendance_rate}%</td>
              </tr>
            </tbody>
          </Table>
        </Box>
        <Box>
          <Box>
            <h4>関連付けられた問({exam.questions.length}問)</h4>
          </Box>
          <DragDropContext
            onDragEnd={(res) => {
              console.log('onDragEnd', res)
              res.destination &&
                onReorderQuestion(
                  parseInt(res.draggableId, 10),
                  res.destination.index,
                )
            }}
          >
            <Droppable droppableId="questions">
              {(provided) => {
                return (
                  <div {...provided.droppableProps} ref={provided.innerRef}>
                    {exam.questions.map((q, index) => {
                      return (
                        <Draggable
                          key={`q_${q.id}`}
                          draggableId={`${q.id}`}
                          index={index}
                        >
                          {(provided) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                            >
                              <QuestionItem
                                categories={questionCategories}
                                question={{ ...q }}
                                onRemove={(questionId) =>
                                  onRemoveQuestion &&
                                  onRemoveQuestion(questionId)
                                }
                              />
                            </div>
                          )}
                        </Draggable>
                      )
                    })}
                    {provided.placeholder}
                  </div>
                )
              }}
            </Droppable>
          </DragDropContext>
        </Box></Box>)
        }
        <Box style={{ paddingTop: 20 }}>
          <UserList data={users} />
          <Box style={{ textAlign: 'right', paddingTop: 20 }}>
            <Button
              variant="contained"
              startIcon={<GetApp />}
              onClick={() => downloadUsers()}
              disabled={isOperator}
            >
              全ユーザーの結果をダウンロード
            </Button>
          </Box>
        </Box>
      </Grid>
    </Grid>
  </PageContainer>
)
