import { Box, IconButton } from '@material-ui/core'
import { FileCopy } from '@material-ui/icons'
import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { AdminQuestion, GroupNames, SessionKey } from '../../../../types/domain'
import { adminPaths } from '../../../../utils/paths'
import { tableHeaderStyle } from '../../../../utils/theme'
import { AddButton } from '../../../ui/AddButton'
import { ExamDescription } from '../../../ui/ExamDescription'

type Props = {
  data: (query: Query<AdminQuestion>) => Promise<QueryResult<AdminQuestion>>
  onClick?: (id: number) => void
  onCreate?: () => void
  onDelete?: (questionId: number) => Promise<boolean>
  onDuplicate?: (questionId: number) => void
  reloadCount?: number
}

export const QuestionList = ({
  onClick,
  data,
  onCreate,
  onDelete,
  onDuplicate,
  reloadCount,
}: Props) => {

  const pageSize = Number(sessionStorage.getItem(SessionKey.QuestionPageSize)) || 20
  const keyword = sessionStorage.getItem(SessionKey.QuestionKeyword) || ''

  return (
    <div style={{ paddingBottom: 80 }}>
      <AddButton
        onClick={() => {
          onCreate && onCreate()
        }}
      />
      <MaterialTable<AdminQuestion>
        key={`r_${reloadCount}`}
        title="問一覧"
        data={data}
        options={{
          search: true,
          searchText: keyword,
          headerStyle: tableHeaderStyle,
          pageSize: pageSize,
          rowStyle: {
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
          },
        }}
        editable={{
          onRowDelete: (row) => {
            console.log('onRowDelete', row)
            return onDelete
              ? onDelete(row.id)
              : new Promise((resolve) => {
                  resolve(true)
                })
          },
        }}
        onRowClick={(e, row) => {
          onClick && row && onClick(row.id)
        }}
        columns={[
          { field: 'id', title: 'ID', width: '80px' },
          {
            field: 'group',
            title: 'グループ',
            width: '140px',
            render: (rowData: any) => GroupNames[rowData.group]
          },
          {
            field: 'name',
            title: '問名',
            render: (row) => (
              <a
                href={adminPaths.genQuestion(row.id)}
                onClick={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                  onClick && onClick(row.id)
                }}
              >
                {row.name}
              </a>
            ),
          },
          {
            field: 'description',
            title: '問題文',
            width: '60%',
            render: (question) => (
              <Box
                style={{
                  fontSize: 'small',
                  overflow: 'hidden',
                  maxWidth: '300px',
                }}
              >
                <ExamDescription text={question.description} />
              </Box>
            ),
          },
          {
            field: 'level',
            title: '難易度',
          },
          {
            field: 'tags',
            title: 'タグ',
            render: (row) => {
              return row.tags.join('/')
            },
          },
          {
            field: 'answer_info',
            title: '正答率',
            width: '120px',
            render: (row) => {
              return (
                <Box>
                  <Box>
                    {row.correct_answer_count}/{row.answer_count}
                  </Box>
                  <Box>{row.correct_answer_rate}%</Box>
                </Box>
              )
            },
          },
          {
            field: 'actions',
            title: '複製',
            sorting: false,
            width: '80px',
            render: (row) => {
              return (
                <Box textAlign="center">
                  <IconButton
                    onClick={(e) => {
                      e.stopPropagation()
                      onDuplicate && onDuplicate(row.id)
                    }}
                  >
                    <FileCopy />
                  </IconButton>
                </Box>
              )
            },
          },
        ]}
      />
    </div>
  )
}
