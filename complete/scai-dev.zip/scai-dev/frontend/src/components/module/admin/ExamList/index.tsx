import { Box, IconButton } from '@material-ui/core'
import { FileCopy, Lock } from '@material-ui/icons'
import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { AdminExamination, GroupNames, SessionKey } from '../../../../types/domain'
import { tableHeaderStyle } from '../../../../utils/theme'
import { AddButton } from '../../../ui/AddButton'
import { ClickableText } from '../../../ui/ClickableText'

type Props = {
  loading?: boolean
  data: (
    query: Query<AdminExamination>,
  ) => Promise<QueryResult<AdminExamination>>
  onClickExam?: (id: number) => void
  onChangePage?: (page: number, pageSize: number) => void
  onClickAddButton?: () => void
  onDelete?: (examId: number) => Promise<boolean>
  onDuplicate?: (examId: number) => void
  reloadCount?: number
  viewOnly: boolean
}

export const ExamList = ({
  data,
  onClickExam = () => {
    return
  },
  onChangePage,
  onClickAddButton,
  onDelete,
  onDuplicate,
  reloadCount = 0,
  viewOnly = false
}: Props) => {

  const pageSize = Number(sessionStorage.getItem(SessionKey.ExamPageSize)) || 20
  const keyword = sessionStorage.getItem(SessionKey.ExamKeyword) || ''
  const columns = [
    { field: 'id', title: 'ID', width: '80px' },
    { field: 'group', title: 'グループ', render: (rowData: any) => GroupNames[rowData.group] },
    {
      field: 'name',
      title: '試験名',
      // eslint-disable-next-line react/display-name
      render: (exam: any) => {
        return (
          <ClickableText onClick={() => onClickExam(exam.id)}>
            {exam.name}{' '}
            {exam.scope === 'private' && (
              <Lock style={{ verticalAlign: -6, paddingLeft: 8 }} />
            )}
          </ClickableText>
        )
      },
    },
    {
      field: 'description',
      title: '概要',
      width: '300px',
      render: (exam: any) => {
        return (
          <div
            style={{
              width: '300px',
              textOverflow: 'ellipsis',
              overflow: 'hidden',
              whiteSpace: 'nowrap',
            }}
          >
            {exam.description}
          </div>
        )
      },
    },
    {
      field: 'questions_count',
      title: '問題数',
      width: '120px',
      sorting: false,
    },
    {
      field: 'average_score',
      title: '平均点',
      sorting: false,
    },
    {
      field: 'best_score',
      title: '最高点',
      sorting: false,
    },
    {
      field: 'worst_score',
      title: '最低点',
      sorting: false,
    },
    {
      field: 'attendance_rate',
      title: '受験率',
      sorting: false,
      render: (row: any) => `${row.attendance_rate}%`,
    },
    {
      field: 'actions',
      title: '複製',
      sorting: false,
      width: '80px',
      render: (row: any) => {
        return (
          <Box textAlign="center">
            <IconButton
              onClick={() => onDuplicate && onDuplicate(row.id)}
            >
              <FileCopy />
            </IconButton>
          </Box>
        )
      },
    },
  ]
  const filteredColumns = viewOnly ? columns.filter(f => f.field != 'actions') : columns

  return (
    <div style={{ paddingBottom: 80 }}>
      {viewOnly ? null : <AddButton onClick={onClickAddButton} />}
      <MaterialTable<AdminExamination>
        key={`r_${reloadCount}`}
        title="試験一覧"
        data={data}
        onChangePage={(page, pageSize) => {
          console.log('nextPage', page, pageSize)
          onChangePage && onChangePage(page, pageSize)
        }}
        onChangeRowsPerPage={(pageSize) => {
          onChangePage && onChangePage(0, pageSize)
        }}
        editable={viewOnly ? {} : {
          onRowDelete: (row: any) => {
            return onDelete
              ? onDelete(row.id)
              : new Promise((resolve) => {
                  resolve(true)
                })
          }
        }}
        options={{
          search: true,
          searchText: keyword,
          pageSize: pageSize,
          pageSizeOptions: [20, 50, 100],
          headerStyle: tableHeaderStyle,
        }}
        columns={filteredColumns}
      />
    </div>
  )
}
