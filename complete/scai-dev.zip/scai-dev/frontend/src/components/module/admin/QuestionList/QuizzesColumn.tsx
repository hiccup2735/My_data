import * as React from 'react'
import { Box } from '@material-ui/core'
import { AdminQuestion } from '../../../../types/domain'

type Props = {
  question: AdminQuestion
}

export const QuizzesColumn = ({ question: { quizzes } }: Props) => (
  <Box>
    {(quizzes || []).map((q, i) => (
      <Box key={`q_${i}`}>{q.description}</Box>
    ))}
  </Box>
)
