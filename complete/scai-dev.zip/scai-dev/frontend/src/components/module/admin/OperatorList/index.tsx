import MaterialTable, { Query, QueryResult } from 'material-table'
import * as React from 'react'
import { Operator } from '../../../../types/domain'

type Props = {
  data: (query: Query<Operator>) => Promise<QueryResult<Operator>>
  onAdd?: (operator: Operator) => Promise<boolean>
  onEdit?: (operator: Operator) => Promise<boolean>
  onDelete?: (operatorId: number) => Promise<boolean>
  pageSize: number
  keyword: string
}

export const OperatorList = ({ data, onAdd, onEdit, onDelete, pageSize, keyword }: Props) => (
  <div>
    <MaterialTable<Operator>
      title="オペレーター一覧"
      options={{
        searchText: keyword,
        pageSize: pageSize,
        pageSizeOptions: [10, 20, 50],
      }}
      data={data}
      editable={{
        onRowAdd: (row) => {
          return onAdd ? onAdd(row) : new Promise((resolve) => resolve(true))
        },
        onRowDelete: (row) => {
          return onDelete
            ? onDelete(row.id)
            : new Promise((resolve) => resolve(true))
        },
        onRowUpdate: (newRow) => {
          return onEdit
            ? onEdit(newRow)
            : new Promise((resolve) => resolve(true))
        },
      }}
      columns={[
        { field: 'id', title: 'ID', editable: 'never' },
        { field: 'name', title: 'ユーザー名' },
        { field: 'email', title: 'メールアドレス' },
        { field: 'password', title: 'パスワード', render: () => '****' }
      ]}
    />
  </div>
)
