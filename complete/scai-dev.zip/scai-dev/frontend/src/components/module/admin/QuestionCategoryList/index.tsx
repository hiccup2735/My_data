import MaterialTable, { Column, Query, QueryResult } from 'material-table'
import * as React from 'react'
import { GroupNames, QuestionCategory } from '../../../../types/domain'
import { ManagerContext } from '../../../../contexts/ManagerContext'
import { Select, MenuItem } from '@material-ui/core'

type RecordType = QuestionCategory

type Props = {
  data: (query: Query<RecordType>) => Promise<QueryResult<RecordType>>
  onAdd?: (admin: RecordType) => Promise<boolean>
  onEdit?: (admin: RecordType) => Promise<boolean>
  onDelete?: (adminId: number) => Promise<boolean>
}

export const QuestionCategoryList = ({ data, onAdd, onEdit }: Props) => {
  const { authenticated } = React.useContext(ManagerContext)
  const columns = () => {
    const columns: Column<RecordType>[] = [
      { field: 'id', title: 'ID', editable: 'never', },
      { field: 'name', title: 'カテゴリ名' },
      { 
        field: 'group', 
        title: 'グループ',
        render: rowData => GroupNames[rowData.group],
        /* eslint-disable react/prop-types */
        editComponent: (props: any) => (
          <Select
            value={props.value || 0}
            onChange={(e) => props.onChange(e.target.value)}
            style={{ width: '120px' }}
          >
            <MenuItem value={0}>未設定</MenuItem>
            <MenuItem value={1}>(GX)検定</MenuItem>
            <MenuItem value={2}>(GX/DX)研修</MenuItem>
          </Select>
        )
      },
    ]
    const filteredColumns = authenticated ? columns.filter(f => f.field != 'group') : columns
    return filteredColumns
  }
  return (
    <div>
      <MaterialTable<RecordType>
        title="問カテゴリ一覧"
        data={data}
        options={{
          paging: false,
        }}
        editable={{
          onRowAdd: (row) => {
            return onAdd ? onAdd(row) : new Promise((resolve) => resolve(true))
          },
          /*
          onRowDelete: (row) => {
            return onDelete
              ? onDelete(row.id)
              : new Promise((resolve) => resolve(true))
          },
          */
          onRowUpdate: (newRow) => {
            return onEdit
              ? onEdit(newRow)
              : new Promise((resolve) => resolve(true))
          },
        }}
        columns={columns()}
      />
    </div>
  )
}