import styled from '@emotion/styled'
import { Box } from '@material-ui/core'
import * as React from 'react'
import { AdminQuestionDetail } from '../../../../types/domain'
import { adminPaths } from '../../../../utils/paths'
import { TextLink } from '../../../ui/TextLink'

type Props = {
  question: AdminQuestionDetail
}

const StyledBox = styled(Box)`
  .exam {
    padding-bottom: 8px;
  }
`

export const QuestionExaminations = ({ question }: Props) => {
  return (
    <StyledBox>
      <h4>関連づけられた試験({question.examinations.length}件)</h4>
      {question.examinations.map((exam) => {
        return (
          <Box className="exam" key={`e_${exam.id}`}>
            <TextLink to={adminPaths.genExamination(exam.id)}>
              ID:{exam.id} {exam.name}
            </TextLink>
          </Box>
        )
      })}
    </StyledBox>
  )
}
