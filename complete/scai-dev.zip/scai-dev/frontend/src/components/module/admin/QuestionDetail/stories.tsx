import { action } from '@storybook/addon-actions'
import React from 'react'
import { QuestionDetail } from '.'
import { CodeQuiz } from '../../../../types/domain'
import { genAdminQuestion } from '../../../../utils/mock'
import { QuestionForm } from './QuestionForm'

export default {
  component: QuestionDetail,
  title: 'module/admin/QuestionDetail',
}

const question = genAdminQuestion(1)

const codeQuiz: CodeQuiz = {
  id: 10,
  question_id: question.id,
  description: 'description',
  criteria: 40,
  sequence: 0,
  type: 'standard_io',
  memory_limit: 128,
  time_limit: 100,
  compare: 'standard',
  files: [
    {
      id: 0,
      code_quiz_id: 10,
      type: 'input',
      url:
        'https://scai-dev-code-runner-app.s3.ap-northeast-1.amazonaws.com/code-runner/1/input/input.zip',
    },
  ],
}

const math = `$\\parallel \\mathbf{x} - \\sigma' (\\mathbf{W'}(\\mathbf{\\sigma (\\mathbf{W}\\mathbf{x}+\\mathbf{b})})+\\mathbf{b'}) \\parallel ^2$`

export const Default = () => (
  <QuestionDetail
    question={{
      ...question,
      quizzes: [
        {
          ...question.quizzes[0],
          choices: [{ ...question.quizzes[0].choices[0], name: math }],
        },
      ],
      code_quizzes: [codeQuiz],
      examinations: [],
    }}
    onEdit={action('onEdit')}
    onEditedQuiz={action('onEditQuiz')}
    onCreateChoice={action('onCreateChoice')}
    onEditChoice={action('onEditChoice')}
    onDeleteChoice={action('onDeleteChoice')}
    onEditQuiz={action('onEditQuiz')}
    onDeleteMetadata={() => new Promise((r) => r(true))}
    onCreateCodeQuiz={() => new Promise((r) => r(true))}
    onAddMetadata={() => new Promise((r) => r(true))}
    onAddTag={() => new Promise((r) => r(true))}
    onDeleteTag={() => new Promise((r) => r(true))}
    onCreateQuiz={() => new Promise((r) => r(true))}
    onDeleteQuiz={() => new Promise((r) => r(true))}
    onUploadCodeQuizFile={() => new Promise((r) => r(true))}
    onUpdateCodeQuiz={(values) => {
      console.log(values)
      return new Promise((r) => r(true))
    }}
    onDeleteCodeQuizFile={(...args) => {
      console.log(args)
      return new Promise((r) => r(true))
    }}
  />
)

export const EditQuestion = () => (
  <QuestionForm
    question={question}
    onSubmit={action('onSubmit')}
    onCancel={action('onCancel')}
  />
)

export const CreateQuestion = () => (
  <QuestionForm
    question={undefined}
    onSubmit={action('onSubmit')}
    onCancel={action('onCancel')}
  />
)
