import { action } from '@storybook/addon-actions'
import React, { useState } from 'react'
import { QuestionSelector, QuestionOption } from '.'

export default {
  component: QuestionSelector,
  title: 'module/admin/QuestionSelector',
}

export const Default = () => {
  const [options, setOptions] = useState<QuestionOption[]>([
    { id: 1, name: 'default #1' },
    { id: 2, name: 'default #2' },
  ])
  return (
    <QuestionSelector
      options={options}
      onChange={action('onChange')}
      onInputChanged={(text) => {
        setOptions([
          { id: 11, name: `${text} #11` },
          { id: 12, name: `${text} #12` },
        ])
      }}
    />
  )
}
