import { action } from '@storybook/addon-actions'
import React from 'react'
import { ExamDetail } from '.'
import { adminExam } from '../../../../utils/mock'
import { ExamForm } from './ExamForm'

export default {
  component: ExamDetail,
  title: 'module/admin/ExamDetail',
}

export const Default = () => (
  <ExamDetail
    exam={adminExam}
    oraganizations={[]}
    questionCategories={[]}
    onQuestionCategoryChanged={action('e')}
    downloadUsers={action('e')}
    users={() =>
      new Promise((resolve) => resolve({ data: [], page: 0, totalCount: 0 }))
    }
  />
)

export const Edit = () => (
  <ExamForm exam={adminExam} onSubmit={action('onSubmit')} />
)
export const Create = () => <ExamForm onSubmit={action('onSubmit')} />
