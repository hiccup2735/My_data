import { css, Global } from '@emotion/core'
import 'katex/dist/katex.min.css'
import * as React from 'react'
import { colors } from '../../../../utils/theme'

export const GlobalStyle = () => (
  <Global
    styles={css`
      body {
        background-color: ${colors.backgroundSub};
        margin: 0;
        font-family: 'Noto Sans JP', sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }

      code {
        font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',
          monospace;
      }

      @media print {
        .no_print {
          display: none;
        }
      }
    `}
  />
)
