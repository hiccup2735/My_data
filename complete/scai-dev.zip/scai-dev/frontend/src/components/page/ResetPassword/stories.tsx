import React from 'react'
import { ResetPassword } from '.'
import { BrowserRouter } from 'react-router-dom'
import { action } from '@storybook/addon-actions'

export default {
  component: ResetPassword,
  title: 'page/ResetPassword',
}

export const Default = () => (
  <BrowserRouter>
    <ResetPassword onResetPassword={action('onResetPassword')} />
  </BrowserRouter>
)
