import React from 'react'
import { ForgetPassword } from '.'
import { BrowserRouter } from 'react-router-dom'
import { action } from '@storybook/addon-actions'

export default {
  component: ForgetPassword,
  title: 'page/ForgetPassword',
}

export const Default = () => (
  <BrowserRouter>
    <ForgetPassword onRequest={action('onRequest')} />
  </BrowserRouter>
)
