import { useSnackbar } from 'notistack'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { OrganizerContext } from '../../../../contexts/OrganizerContext'
import { organizerRequests } from '../../../../utils/api'
import { organizerPaths } from '../../../../utils/paths'
import { FormValues, Login } from '../../Login'

export const OrganizerLogin = () => {
  const { enqueueSnackbar } = useSnackbar()
  const { setAuthenticated } = React.useContext(OrganizerContext)
  const history = useHistory()

  return (
    <Login
      admin
      onLogin={(values: FormValues) => {
        organizerRequests
          .loginOrganizer(values.email, values.password)
          .then((res) => {
            setAuthenticated(true)
            enqueueSnackbar('ログインに成功しました', {
              variant: 'success',
            })
            history.push(organizerPaths.root)
          })
          .catch((e) => {
            enqueueSnackbar('ログインに失敗しました', {
              variant: 'error',
            })
          })
      }}
    />
  )
}
