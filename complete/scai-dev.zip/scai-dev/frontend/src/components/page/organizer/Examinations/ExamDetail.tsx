import * as React from 'react'
import { RouteComponentProps, useHistory } from 'react-router-dom'
import {
  OrganizationExaminationDetail,
  OrganizationExaminationHistory,
  OrganizationExaminationStat,
} from '../../../../types/domain'
import { organizerRequests } from '../../../../utils/api'
import { organizerPaths } from '../../../../utils/paths'
import { ExamDetail } from '../../../module/organizer/ExamDetail'
import { Loading } from '../../../ui/Loading'

type Props = RouteComponentProps<{ id: string }>

export const OrgExamDetail = ({
  match: {
    params: { id },
  },
}: Props) => {
  const [loading, setLoading] = React.useState<boolean>(false)
  const [exam, setExam] = React.useState<
    OrganizationExaminationDetail | undefined
  >(undefined)
  const [sortByScore, setSortByScore] = React.useState<boolean>(false)
  const [examStat, setExamStat] = React.useState<
    OrganizationExaminationStat | undefined
  >(undefined)

  const [examHistories, setExamHistories] = React.useState<
    OrganizationExaminationHistory[]
  >([])

  React.useEffect(() => {
    setLoading(true)
    organizerRequests
      .getExam(id)
      .then((res) => {
        setExam(res.data)
      })
      .finally(() => {
        setLoading(false)
      })
  }, [setExam, setExamStat])

  React.useEffect(() => {
    if (exam) {
      organizerRequests.getExamStat(exam.id).then((res) => {
        setExamStat(res.data)
      })
      organizerRequests.getExamHistories(exam.id).then((res) => {
        setExamHistories(res.data.examinations)
      })
    }
  }, [exam, setExamStat])

  const history = useHistory()

  if (loading) {
    return <Loading />
  } else if (!exam) {
    return <div>not found</div>
  }
  return (
    <ExamDetail
      histories={examHistories}
      stat={examStat}
      sortByScore={sortByScore}
      onChangeSortByScore={(sort) => {
        setSortByScore(sort)
      }}
      goToList={() => history.push(organizerPaths.examinations)}
      exam={exam}
      users={(query) => {
        return new Promise((resolve) => {
          organizerRequests
            .getExamUsers(
              id,
              {
                q: query.search,
                page: query.page,
                page_size: query.pageSize,
              },
              sortByScore,
            )
            .then((res) => {
              resolve({
                page: res.data.page,
                totalCount: res.data.total,
                data: res.data.users,
              })
            })
        })
      }}
    />
  )
}
