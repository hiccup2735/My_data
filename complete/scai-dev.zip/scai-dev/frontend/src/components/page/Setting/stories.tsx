import React from 'react'
import { Setting } from '.'
import { action } from '@storybook/addon-actions'
import { BrowserRouter } from 'react-router-dom'
import { User } from '../../../types/domain'

export default {
  component: Setting,
  title: 'page/Setting',
}

const dummyUser: User = {
  is_verified: false,
  name: 'John Wick',
  email: 'user@example.com',
}

export const Default = () => (
  <BrowserRouter>
    <Setting
      onUpdateUser={action('onUpdateUser')}
      user={dummyUser}
      onRequestPasswordChange={action('onRequestPasswordChange')}
      onRequestVerify={action('onRequestVerify')}
    />
  </BrowserRouter>
)
