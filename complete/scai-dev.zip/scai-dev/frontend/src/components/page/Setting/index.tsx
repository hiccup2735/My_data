import { Box, Button, Paper, TextField, Typography } from '@material-ui/core'
import axios from 'axios'
import useAxios from 'axios-hooks'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { Controller, useForm } from 'react-hook-form'
import * as yup from 'yup'
import { User } from '../../../types/domain'
import { validation } from '../../../types/validation'
import { apiPath, requests } from '../../../utils/api'
import { colors } from '../../../utils/theme'
import { NotVerifiedAlert } from '../../ui/NotVerifiedAlert'
import { PageContainer } from '../../ui/PageContainer'
import { PageTitle } from '../../ui/PageTitle'

type FormValues = {
  name: string
  email: string
}

const validationSchema = yup.object().shape({
  name: validation.name,
  email: validation.email,
})

type Props = {
  onUpdateUser: (values: FormValues) => void
  onRequestPasswordChange: () => void
  onRequestVerify: () => void
  user: User
}

export const Setting = ({
  onUpdateUser,
  user,
  onRequestPasswordChange,
  onRequestVerify,
}: Props) => {
  const { handleSubmit, errors, control } = useForm<FormValues>({
    defaultValues: {
      name: user.name,
      email: user.email,
    },
    validationSchema,
    mode: 'onChange',
  })

  return (
    <>
      <NotVerifiedAlert user={user} onRequestVerify={onRequestVerify} />
      <PageContainer>
        <PageTitle title="プロフィール" />
        <Box
          component={Paper}
          style={{ padding: '20px 40px 30px 40px' }}
          marginBottom="20px"
        >
          <Box
            paddingBottom="30px"
            borderBottom={`1px solid ${colors.separator}`}
          >
            <form
              onSubmit={handleSubmit((values: FormValues) => {
                onUpdateUser(values)
              })}
            >
              <Box style={{ display: 'flex' }}>
                <Box style={{ width: 160, fontWeight: 600, fontSize: 16 }}>
                  ユーザー名
                </Box>
                <Box flexGrow={1}>
                  <Controller
                    name="name"
                    control={control}
                    as={
                      <TextField
                        style={{ fontSize: 16, width: '100%' }}
                        error={Boolean(errors.name)}
                        helperText={errors.name?.message || '　'}
                      />
                    }
                  />
                </Box>
              </Box>
              <Box style={{ display: 'flex' }}>
                <Box style={{ width: 160, fontWeight: 600, fontSize: 16 }}>
                  メールアドレス
                </Box>
                <Box flexGrow={1}>
                  <Controller
                    name="email"
                    control={control}
                    as={
                      <TextField
                        style={{ fontSize: 16, width: '100%' }}
                        error={Boolean(errors.email)}
                        helperText={errors.email?.message || '　'}
                      />
                    }
                  />
                </Box>
              </Box>

              <Box style={{ textAlign: 'center', paddingTop: 10 }}>
                <Button
                  color="primary"
                  type="submit"
                  variant="contained"
                  style={{
                    height: 48,
                    fontSize: 16,
                    fontWeight: 600,
                    paddingRight: '3em',
                    paddingLeft: '3em',
                  }}
                >
                  更新する
                </Button>
              </Box>
            </form>
          </Box>
          <Box paddingTop="30px">
            <Typography gutterBottom style={{ fontWeight: 600, fontSize: 16 }}>
              パスワードの変更
            </Typography>
            <Box style={{ textAlign: 'center', paddingTop: 20 }}>
              <Button
                color="primary"
                type="submit"
                variant="outlined"
                onClick={() => onRequestPasswordChange()}
                style={{
                  height: 48,
                  fontSize: 16,
                  fontWeight: 600,
                  paddingRight: '3em',
                  paddingLeft: '3em',
                }}
              >
                パスワード変更メールを送信する
              </Button>
            </Box>
          </Box>
        </Box>
      </PageContainer>
    </>
  )
}

export const SettingContainer = () => {
  const [{ data: user }] = useAxios<User>(apiPath.user, { useCache: false })
  const { enqueueSnackbar } = useSnackbar()

  if (!user) {
    return null
  }

  return (
    <Setting
      onRequestVerify={() => {
        requests
          .requestVerify()
          .then(() => {
            enqueueSnackbar(`確認メールを${user.email}宛に送信しました`, {
              variant: 'success',
            })
          })
          .catch(() => {
            enqueueSnackbar('送信できませんでした', {
              variant: 'error',
            })
          })
      }}
      onRequestPasswordChange={() => {
        requests
          .requestPasswordChange(user.email)
          .then(() => {
            enqueueSnackbar(
              `パスワードリセットのメールを${user.email}宛に送信しました`,
              {
                variant: 'success',
              },
            )
          })
          .catch(() => {
            enqueueSnackbar('送信できませんでした', {
              variant: 'error',
            })
          })
      }}
      user={user}
      onUpdateUser={(values) => {
        axios
          .put(apiPath.user, {
            ...values,
          })
          .then(() => {
            enqueueSnackbar('ユーザー情報を更新しました', {
              variant: 'success',
            })
          })
          .catch(() => {
            enqueueSnackbar('ユーザー情報の更新に失敗しました', {
              variant: 'error',
            })
          })
      }}
    />
  )
}
