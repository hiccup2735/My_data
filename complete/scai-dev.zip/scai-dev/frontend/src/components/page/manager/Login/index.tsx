import { useSnackbar } from 'notistack'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { ManagerContext } from '../../../../contexts/ManagerContext'
import { managerRequests } from '../../../../utils/api'
import { managerPaths } from '../../../../utils/paths'
import { FormValues, Login } from '../../Login'

export const ManagerLogin = () => {
  const { enqueueSnackbar } = useSnackbar()
  const { setAuthenticated, setGroup } = React.useContext(ManagerContext)
  const history = useHistory()

  return (
    <Login
      admin
      onLogin={(values: FormValues) => {
        managerRequests
          .loginManager(values.email, values.password)
          .then((res) => {
            setAuthenticated(true)
            setGroup(res.data.group)
            enqueueSnackbar('ログインに成功しました', {
              variant: 'success',
            })
            history.push(managerPaths.root)
          })
          .catch((e) => {
            enqueueSnackbar('ログインに失敗しました', {
              variant: 'error',
            })
          })
      }}
    />
  )
}
