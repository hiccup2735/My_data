import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  Container,
} from '@material-ui/core'
import axios from 'axios'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { components } from '../../../types/api'
import { apiPath } from '../../../utils/api'

type User = components['schemas']['User']

type Props = {
  onLogout: () => void
}

export const Logout = ({ onLogout }: Props) => {
  return (
    <Container>
      <Box>
        <Card>
          <CardContent>ログアウトします</CardContent>
          <CardActions>
            <Button type="submit" onClick={() => onLogout()}>
              ログアウト
            </Button>
          </CardActions>
        </Card>
      </Box>
    </Container>
  )
}

export const LogoutContainer = () => {
  const { enqueueSnackbar } = useSnackbar()
  return (
    <Logout
      onLogout={() => {
        axios
          .delete<null>(apiPath.auth, {})
          .then((res) => {
            enqueueSnackbar('ログアウトに成功しました', {
              variant: 'success',
            })
          })
          .catch((e) => {
            enqueueSnackbar('ログアウトに失敗しました', {
              variant: 'error',
            })
          })
      }}
    />
  )
}
