import {
  Box,
  Button,
  CardContent,
  Checkbox,
  Container,
  Grid,
  Paper,
  TextField,
  Typography,
} from '@material-ui/core'
import axios from 'axios'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { Controller, useForm } from 'react-hook-form'
import { useHistory } from 'react-router-dom'
import * as yup from 'yup'
import logo from '../../../assets/logo_tate.svg'
import { UserContext } from '../../../contexts/UserContext'
import { User } from '../../../types/domain'
import { apiPath } from '../../../utils/api'
import { inputProps } from '../../../utils/input'
import { paths } from '../../../utils/paths'
import { Copyright } from '../../ui/Copyright'
import { ErrorMessageBox } from '../../ui/ErrorMessageBox'
import { LoginOptions } from './LoginOptions'

export type FormValues = {
  email: string
  password: string
}

const validationSchema = yup.object().shape({
  email: yup
    .string()
    .email('正しい形式のメールアドレスを入力してください')
    .required('メールアドレスを入力してください'),
  password: yup.string().required('パスワードを入力してください'),
})

type Props = {
  onLogin: (values: FormValues) => void
  loading?: boolean
  admin?: boolean
}

export const Login = ({ onLogin, loading, admin }: Props) => {
  const [confirmed, setConfirmed] = React.useState<boolean>(admin || false)
  const { handleSubmit, errors, control, watch } = useForm<FormValues>({
    defaultValues: {
      email: '',
      password: '',
    },
    validationSchema,
    mode: 'onChange',
  })

  const c = watch('confirmation')

  return (
    <Container>
      <Grid container justify="center" style={{ paddingTop: 128 }}>
        <Grid item xs={6}>
          <Box style={{ paddingBottom: 128 }}>
            <form
              onSubmit={handleSubmit((values: FormValues) => {
                onLogin(values)
              })}
            >
              <Paper elevation={8} style={{ borderRadius: 10 }}>
                <CardContent>
                  <Box
                    style={{
                      textAlign: 'center',
                      paddingBottom: 24,
                      paddingTop: 48,
                    }}
                  >
                    <img width={166} height="auto" src={logo} alt="logo" />
                  </Box>
                  <Box style={{ textAlign: 'center', paddingBottom: 16 }}>
                    <Typography>ログイン</Typography>
                  </Box>
                  <Box
                    style={{
                      paddingBottom: 24,
                      paddingLeft: 64,
                      paddingRight: 64,
                    }}
                  >
                    <Box>
                      <Controller
                        name="email"
                        control={control}
                        as={
                          <TextField
                            autoComplete="email"
                            variant="outlined"
                            error={Boolean(errors.email)}
                            label="メールアドレス"
                            helperText={errors.email?.message || ' '}
                            {...inputProps}
                          />
                        }
                      />
                    </Box>
                    <Box>
                      <Controller
                        name="password"
                        control={control}
                        as={
                          <TextField
                            autoComplete="current-password"
                            variant="outlined"
                            error={Boolean(errors.password)}
                            label="パスワード"
                            type="password"
                            helperText={errors.password?.message || ' '}
                            {...inputProps}
                          />
                        }
                      />
                    </Box>
                    {!admin && (
                      <Box>
                        <Box>
                          <Checkbox
                            onChange={(e) => {
                              setConfirmed(e.currentTarget.checked)
                            }}
                            checked={confirmed}
                          />
                          <a
                            style={{
                              textDecoration: 'none',
                              color: 'rgb(102, 102, 102)',
                            }}
                            href="https://skillup-next.co.jp/lms-scai-terms-of-use/"
                            target="_blank"
                            rel="noreferrer"
                          >
                            利用規約
                          </a>
                          と
                          <a
                            style={{
                              textDecoration: 'none',
                              color: 'rgb(102, 102, 102)',
                            }}
                            href="https://skillup-next.co.jp/privacy/"
                            target="_blank"
                            rel="noreferrer"
                          >
                            プライバシーポリシー
                          </a>
                          に同意する
                        </Box>
                        <ErrorMessageBox
                          style={{
                            fontSize: 12,
                            color: '#f44336',
                            margin: '-14px 14px 16px 14px',
                          }}
                        >
                          {confirmed ? ' ' : 'ログインするには同意が必要です'}
                        </ErrorMessageBox>
                      </Box>
                    )}
                    <Box style={{ paddingBottom: 48 }}>
                      <Button
                        style={{
                          width: '100%',
                          height: 56,
                          borderRadius: 28,
                          fontSize: 16,
                        }}
                        disabled={loading || !confirmed}
                        variant="contained"
                        type="submit"
                        color="primary"
                      >
                        ログイン
                      </Button>
                    </Box>
                    <LoginOptions
                      login={false}
                      signup={!admin}
                      resetPassword={!admin}
                    />
                  </Box>
                </CardContent>
              </Paper>
            </form>
          </Box>
          <Copyright />
        </Grid>
      </Grid>
    </Container>
  )
}

export const LoginContainer = () => {
  const { enqueueSnackbar } = useSnackbar()
  const { setAuthenticated } = React.useContext(UserContext)
  const history = useHistory()

  return (
    <Login
      onLogin={(values: FormValues) => {
        axios
          .post<User>(apiPath.auth, {
            email: values.email,
            password: values.password,
          })
          .then((res) => {
            setAuthenticated(true)
            enqueueSnackbar('ログインに成功しました', {
              variant: 'success',
            })
            history.push(paths.root)
          })
          .catch((e) => {
            enqueueSnackbar('ログインに失敗しました', {
              variant: 'error',
            })
          })
      }}
    />
  )
}
