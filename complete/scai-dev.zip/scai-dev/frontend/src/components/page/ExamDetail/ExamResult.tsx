import styled from '@emotion/styled'
import { Box, Button, Grid, Paper, Switch, Typography } from '@material-ui/core'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import logo from '../../../assets/watermark30.png'
import { Examination } from '../../../types/domain'
import { paths } from '../../../utils/paths'
import { colors } from '../../../utils/theme'
import { PageContainer } from '../../ui/PageContainer'
import { CategoryChart } from './CategoryChart'
import { ExamAttrsMin } from './ExamAttrs'

const StyledPaper = styled(Paper)`
  margin-bottom: 24px;
  padding: 0;
  padding-top: 50px;
  padding-bottom: 40px;
`

type Props = {
  exam: Examination
}

export const ExamResult = ({ exam }: Props) => {
  const history = useHistory()
  return (
    <PageContainer>
      <StyledPaper elevation={4}>
        {exam.status !== 'scoring' && exam.questions_count > 0 && (
          <Box style={{ paddingLeft: 30, paddingRight: 30 }}>
            <ExamScores exam={exam} />
          </Box>
        )}
        <Box style={{ paddingTop: 40, textAlign: 'center' }}>
          <Button
            style={{
              fontSize: 16,
              height: 48,
              paddingRight: 40,
              paddingLeft: 40,
            }}
            variant="outlined"
            color="primary"
            onClick={() => {
              history.push(paths.root)
            }}
          >
            テスト一覧へ戻る
          </Button>
        </Box>
      </StyledPaper>
    </PageContainer>
  )
}

const ScoresPaper = styled(Paper)`
  padding: 24px;
  background-color: ${colors.resultBackground};
  -webkit-print-color-adjust: exact;

  @media print {
    background-image: url(${logo}) !important;
    background-repeat: repeat repeat;
    background-size: 33%;
  }

  .categories {
    background-color: white;
    @media print {
      background-color: rgba(255, 255, 255, 0.7);
    }
  }
`

export const ExamScores = ({ exam }: Props) => {
  const [pastExam, setPastExam] = React.useState<Examination>()

  const categoryFontSize = pastExam ? 16 : 20

  return (
    <ScoresPaper elevation={0}>
      <Grid container style={{ paddingBottom: 20 }}>
        <Grid item xs={3} style={{ 
          lineHeight: '80px',
          fontSize: '24px',
          fontWeight: 'bold',
          }}
        >
          テスト結果
        </Grid>
        <Grid
          item
          xs={6}
          style={{
            textAlign: 'center',
            height: '80px',
            fontWeight: 600,
          }}
        >
          <span style={{ fontSize: 74 }}>
            <span
              style={{
                fontSize: 24,
                verticalAlign: 'middle',
              }}
            >
              得点
            </span>
            {pastExam && (
              <>
                <span
                  style={{
                    color: colors.primary,
                  }}
                >
                  {pastExam.score}
                </span>
                <span
                  style={{
                    fontSize: 24,
                    verticalAlign: 'middle',
                  }}
                >
                  点
                </span>
                <span
                  style={{
                    fontSize: 24,
                    verticalAlign: 'middle',
                    paddingRight: 10,
                    paddingLeft: 10,
                  }}
                >
                  →
                </span>
              </>
            )}
            <span
              style={{
                color: colors.primary,
              }}
            >
              {exam.score}
            </span>
            <span
              style={{
                fontSize: 24,
                verticalAlign: 'middle',
              }}
            >
              点
            </span>
          </span>
        </Grid>
        <Grid item xs={3} />
      </Grid>
      <Paper elevation={0} className="categories" style={{ padding: 24 }}>
        <Grid container>
          <Grid item xs={6}>
            <Typography style={{ fontSize: 14 }}>カテゴリ別</Typography>
            <Box style={{ display: 'flex', justifyContent: 'center' }}>
              <Box style={{ color: colors.hint }}>
                <CategoryChart
                  scores={exam.scores}
                  pastScores={pastExam?.scores}
                />
              </Box>
            </Box>
          </Grid>
          <Grid
            item
            xs={6}
            style={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
            }}
          >
            <Box style={{ display: 'flex' }}>
              {pastExam && (
                <Box style={{ paddingRight: 10 }}>
                  <h4>前回</h4>
                  {pastExam.scores.map((s, i) => {
                    return (
                      <Box key={`c_${i}`}>
                        <Typography
                          style={{
                            fontSize: categoryFontSize,
                            lineHeight: 1.7,
                          }}
                        >
                          <strong>{s.category_name}</strong>：{s.score}％
                        </Typography>
                      </Box>
                    )
                  })}
                  <ExamAttrsMin exam={pastExam} />
                </Box>
              )}
              <Box>
                {pastExam && <h4>今回</h4>}
                {exam.scores.map((s, i) => {
                  return (
                    <Box key={`c_${i}`}>
                      <Typography
                        style={{ fontSize: categoryFontSize, lineHeight: 1.7 }}
                      >
                        <strong>{s.category_name}</strong>：{s.score}％
                      </Typography>
                    </Box>
                  )
                })}
                {pastExam && <ExamAttrsMin exam={exam} />}
              </Box>
            </Box>
            {exam.previous_data && (
              <Box style={{ textAlign: 'center', padding: 20 }}>
                <Switch
                  checked={Boolean(pastExam)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setPastExam(
                        (exam.previous_data as Examination) || undefined,
                      )
                    } else {
                      setPastExam(undefined)
                    }
                  }}
                />
                過去の結果と比較する
              </Box>
            )}
          </Grid>
        </Grid>
      </Paper>
    </ScoresPaper>
  )
}
