import { Button } from '@material-ui/core'
import * as React from 'react'
import { Controller, useForm } from 'react-hook-form'
import { CodeQuiz } from '../../../types/domain'
import { ExamDescription } from '../../ui/ExamDescription'
import { Select } from '../../ui/Select'

type Props = {
  codeQuiz: CodeQuiz
  onAnswerCodeQuiz: (
    questionId: number,
    codeQuizId: number,
    lang: string,
    code: string,
  ) => Promise<boolean>
}

type FormValues = {
  lang: string
  code: string
}

export const CodeQuizItem = ({ codeQuiz, onAnswerCodeQuiz }: Props) => {
  const {
    control,
    handleSubmit,
    formState: { dirty },
  } = useForm<FormValues>({
    defaultValues: {
      code: codeQuiz.answer?.code || '',
      lang: codeQuiz.answer?.lang || codeQuiz.available_langs[0]?.lang || '',
    },
  })

  const [answering, setAnswering] = React.useState<boolean>(false)

  return (
    <div>
      <form
        onSubmit={handleSubmit((values) => {
          setAnswering(true)
          onAnswerCodeQuiz(
            codeQuiz.question_id,
            codeQuiz.id,
            values.lang,
            values.code,
          ).finally(() => {
            setAnswering(false)
          })
        })}
      >
        <ExamDescription text={codeQuiz.description} />
        <div>
          <div>言語を選択</div>
          <div>
            <Controller
              control={control}
              name="lang"
              as={
                <Select
                  options={codeQuiz.available_langs.map((al) => ({
                    label: al.name,
                    value: al.lang,
                  }))}
                />
              }
            />
          </div>
        </div>
        <div>
          <Controller
            control={control}
            name="code"
            as={
              <textarea
                style={{ width: '100%', resize: 'vertical' }}
                rows={5}
              />
            }
          />
        </div>
        <Button
          color="primary"
          variant="contained"
          type="submit"
          disabled={answering || !dirty}
        >
          回答を送信する
        </Button>
      </form>
    </div>
  )
}
