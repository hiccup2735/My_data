import styled from '@emotion/styled'
import { Box, Button, Grid, Paper, Typography } from '@material-ui/core'
import * as React from 'react'
import { Examination } from '../../../types/domain'
import { colors } from '../../../utils/theme'
import { CodeQuizResultItem } from '../../module/CodeQuizResultItem'
import { PageContainer } from '../../ui/PageContainer'
import { PageTitle } from '../../ui/PageTitle'
import { ExamAttrs } from './ExamAttrs'
import { ExamHeader } from './ExamHeader'
import { ExamScores } from './ExamResult'

type Props = {
  onStart?: (id: number) => void
  onBack?: () => void
  exam: Examination
}

const StyledPaper = styled(Paper)`
  margin-bottom: 24px;
  padding: 0;
  -webkit-print-color-adjust: exact;
`

export const ExamInfo = ({ exam, onStart, onBack }: Props) => {
  return (
    <PageContainer>
      <PageTitle title="テスト詳細" />
      <StyledPaper elevation={4}>
        <ExamHeader exam={exam} />
        <Box
          className="watermark"
          style={{ paddingLeft: 40, paddingRight: 40, paddingBottom: 40 }}
        >
          <Box
            style={{ textAlign: 'right', paddingTop: 16, paddingBottom: 16 }}
          >
            <ExamAttrs exam={exam} />
          </Box>
          {exam.status === 'finished' && (
            <>
              {exam.questions_count > 0 && (
                <Box style={{ paddingBottom: 30 }}>
                  <ExamScores exam={exam} />
                </Box>
              )}
              {exam.code_quiz_results.length > 0 && (
                <Box
                  style={{
                    paddingBottom: 30,
                    display: 'flex',
                    flexDirection: 'column',
                    rowGap: '10px',
                  }}
                >
                  <div>コード問題の結果</div>
                  {exam.code_quiz_results.map((result) => {
                    return (
                      <CodeQuizResultItem
                        key={`cqr_${result.id}`}
                        result={result}
                      />
                    )
                  })}
                </Box>
              )}
            </>
          )}

          <Box>
            <Box style={{ display: 'flex' }}>
              <Box style={{ minWidth: 90 }}>
                <Typography style={{ fontSize: 12, color: colors.primary }}>
                  テスト詳細：
                </Typography>
              </Box>
              <Box style={{ flexGrow: 1 }}>
                <Typography style={{ fontSize: 12, color: colors.text }}>
                  {exam.description}
                </Typography>
              </Box>
            </Box>
          </Box>
          <Box style={{ paddingTop: 40 }} className="no_print">
            {exam.status === 'ready' && (
              <Box
                style={{
                  paddingBottom: 16,
                  color: colors.emphasis,
                  fontSize: 12,
                  textAlign: 'center',
                }}
              >
                一度試験を開始するとカウントダウンが開始されます。
                <br />
                中断した場合でもカウントダウンは止まりません。
              </Box>
            )}
            <Grid container>
              <Grid item md={3}></Grid>
              <Grid item md={2} style={{ paddingRight: 12 }}>
                <Button
                  variant="outlined"
                  color="primary"
                  style={{ height: 48, width: '100%' }}
                  onClick={() => onBack && onBack()}
                >
                  戻る
                </Button>
              </Grid>
              <Grid item md={4}>
                <Button
                  variant="contained"
                  color="primary"
                  style={{ height: 48, width: '100%' }}
                  onClick={() => onStart && onStart(exam.id)}
                  disabled={
                    exam.status === 'expired' ||
                    exam.status === 'finished' ||
                    exam.status === 'before' ||
                    exam.status === 'scoring'
                  }
                >
                  開始する
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </StyledPaper>
    </PageContainer>
  )
}
