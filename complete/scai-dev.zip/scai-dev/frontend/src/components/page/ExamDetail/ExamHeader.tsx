import { Box, Typography } from '@material-ui/core'
import * as React from 'react'
import { ExaminationSummary } from '../../../types/domain'
import { colors } from '../../../utils/theme'
import { formatDate } from '../../../utils/time'
import { ExamTag } from '../../ui/ExamTag'

type Props = {
  exam: ExaminationSummary
}

export const ExamHeader = ({ exam }: Props) => (
  <Box
    style={{
      backgroundColor: colors.itemHeader,
      padding: '16px 40px 16px 40px',
      height: 80,
      boxSizing: 'border-box',
      display: 'flex',
      position: 'relative',
    }}
  >
    <Box
      style={{
        minWidth: 90,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <ExamTag status={exam.status} />
    </Box>
    <Box
      style={{
        flexGrow: 1,
        paddingLeft: 24,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
      }}
    >
      <Typography style={{ fontSize: 16, fontWeight: 500, color: colors.text }}>
        {exam.name}
      </Typography>
    </Box>
    {exam.status === 'finished' && exam.started_at && (
      <Box
        style={{
          position: 'absolute',
          bottom: 4,
          left: 40,
          lineHeight: '2em',
          fontSize: '12px',
          color: colors.subText,
        }}
      >
        受験日時: {formatDate(exam.started_at)}
      </Box>
    )}
  </Box>
)
