import { useSnackbar } from 'notistack'
import * as React from 'react'
import { adminRequests } from '../../../../utils/api'
import { AdminList } from '../../../module/admin/AdminList'

export const AdminAdmins = () => {
  const { enqueueSnackbar } = useSnackbar()
  return (
    <AdminList
      data={(query) => {
        return new Promise((resolve) => {
          adminRequests
            .getAdmins({
              page: query.page,
              page_size: query.pageSize,
            })
            .then((res) => {
              resolve({
                page: res.data.page,
                totalCount: res.data.total,
                data: res.data.admins,
              })
            })
        })
      }}
      onAdd={(admin) => {
        return new Promise((resolve) =>
          adminRequests
            .createAdmin({
              name: admin.name,
              email: admin.email,
            })
            .then(() => {
              enqueueSnackbar('管理者を作成しました', { variant: 'success' })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar('管理者の作成に失敗しました', {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
      onEdit={(admin) => {
        return new Promise((resolve) =>
          adminRequests
            .updateAdmin(admin.id, {
              name: admin.name,
              email: admin.email,
            })
            .then(() => {
              enqueueSnackbar('管理者を更新しました', { variant: 'success' })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar('管理者の更新に失敗しました', {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
      onDelete={(adminId) => {
        return new Promise((resolve) =>
          adminRequests
            .deleteAdmin(adminId)
            .then(() => {
              enqueueSnackbar('管理者を削除しました', { variant: 'success' })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar('管理者の削除に失敗しました', {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
    />
  )
}
