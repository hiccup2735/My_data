import { useSnackbar } from 'notistack'
import * as React from 'react'
import { adminRequests } from '../../../../utils/api'
import { OperatorList } from '../../../module/admin/OperatorList'

const RESOURCE_NAME = 'オペレーター'

export const AdminOperators = () => {
  const { enqueueSnackbar } = useSnackbar()
  const pageSize = 20

  return (
    <OperatorList
      pageSize={pageSize}
      keyword=''
      data={(query) => {
        return new Promise((resolve) => {
          adminRequests
            .getOperators({
              q: query.search,
              page: query.page,
              page_size: query.pageSize,
            })
            .then((res) => {
              resolve({
                page: res.data.page,
                totalCount: res.data.total,
                data: res.data.operators,
              })
            })
        })
      }}
      onAdd={(newRecord) => {
        return new Promise((resolve) =>
          adminRequests
            .createOperator({
              name: newRecord.name,
              email: newRecord.email,
              password: newRecord.password,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を作成しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の作成に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
      onEdit={(record) => {
        return new Promise((resolve) =>
          adminRequests
            .updateOperator(record.id, {
              name: record.name,
              email: record.email,
              password: record.password,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を更新しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の更新に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            })
        )
      }}
      onDelete={(resourceId) => {
        return new Promise((resolve) =>
          adminRequests
            .deleteOperator(resourceId)
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を削除しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の削除に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            }),
        )
      }}
    />
  )
}
