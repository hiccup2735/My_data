import { useSnackbar } from 'notistack'
import * as React from 'react'
import { RouteComponentProps, useHistory } from 'react-router-dom'
import { AdminUser, License, Organization } from '../../../../types/domain'
import { adminRequests } from '../../../../utils/api'
import { adminPaths, ADMIN_ROOT, operatorPaths, MGR_ROOT, OPE_ROOT, managerPaths } from '../../../../utils/paths'
import { OrganizationLicenseList } from '../../../module/admin/OrganizationLicenseList'
import { AddLicenses } from './AddLicenses'

const RESOURCE_NAME = 'ライセンス'

type Props = RouteComponentProps<{ organizationId: string }>

type Mode = 'list' | 'bulk'

export const AdminOrganizationLicenses = ({ match }: Props) => {
  const { organizationId } = match.params
  const [org, setOrg] = React.useState<Organization | undefined>(undefined)
  const [mode, setMode] = React.useState<Mode>('list')
  React.useEffect(() => {
    adminRequests.getOrganization(organizationId).then((res) => {
      setOrg(res.data)
    })
  }, [setOrg])
  const history = useHistory()

  const [licenses, setLicenses] = React.useState<License[]>([])
  const [users, setUsers] = React.useState<AdminUser[]>([])

  const loadForBulk = () => {
    adminRequests
      .getOrganizationLicenses(organizationId, { page_size: 1000 })
      .then((res) => {
        setLicenses(res.data.licenses)
      })
    adminRequests
      .getOrganizationUsers(organizationId, { page_size: 1000 })
      .then((res) => {
        setUsers(res.data.users)
      })
  }
  const isAdmin = window.location.pathname.includes(ADMIN_ROOT) ? true : false
  const isManager = window.location.pathname.includes(MGR_ROOT) ? true : false
  const isOperator = window.location.pathname.includes(OPE_ROOT) ? true : false

  React.useEffect(() => {
    if (mode === 'bulk') {
      loadForBulk()
    }
  }, [mode])

  const { enqueueSnackbar } = useSnackbar()

  if (mode === 'bulk') {
    return (
      <AddLicenses
        onAttach={(licenseId, targetUsers) => {
          console.log('onAttach', licenseId, targetUsers)

          const promises = targetUsers.map(
            (u, i) =>
              new Promise<{ userId: number; success: boolean }>((resolve) => {
                window.setTimeout(() => {
                  adminRequests
                    .addUserLicense(u.id, licenseId)
                    .then(() => {
                      console.log('attached to ', u.id)
                      resolve({ userId: u.id, success: true })
                    })
                    .catch(() => {
                      resolve({ userId: u.id, success: false })
                    })
                }, i * 500)
              }),
          )

          return new Promise((resolve) => {
            Promise.all(promises)
              .then((res) => {
                enqueueSnackbar('一括付与を行いました', { variant: 'success' })
                loadForBulk()
                resolve(res)
              })
              .catch(() => {
                enqueueSnackbar('一括付与に失敗しました', { variant: 'error' })
              })
          })
        }}
        users={users}
        licenses={licenses}
        backToList={() => {
          setMode('list')
        }}
      />
    )
  }

  return (
    <OrganizationLicenseList
      onClickMultiple={() => {
        setMode('bulk')
      }}
      goToList={() => {
        if (isAdmin) history.push(adminPaths.organizations)
        if (isManager) history.push(managerPaths.organizations)
        if (isOperator) history.push(operatorPaths.organizations)
      }}
      organization={org}
      data={(query) => {
        return new Promise((resolve) => {
          adminRequests
            .getOrganizationLicenses(organizationId, {
              page: query.page,
              page_size: query.pageSize,
            })
            .then((res) => {
              resolve({
                page: res.data.page,
                totalCount: res.data.total,
                data: res.data.licenses,
              })
            })
        })
      }}
      onAdd={(newRecord) => {
        return new Promise((resolve) =>
          adminRequests
            .createOrganizationLicense(organizationId, {
              count: newRecord.count,
              start_date_time: newRecord.start_date_time,
              end_date_time: newRecord.end_date_time,
              examination_id: newRecord.examination_id,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を作成しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の作成に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            }),
        )
      }}
      onEdit={(record) => {
        return new Promise((resolve) =>
          adminRequests
            .updateOrganizationLicense(organizationId, record.id, {
              count: record.count,
              start_date_time: record.start_date_time,
              end_date_time: record.end_date_time,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を更新しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の更新に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            }),
        )
      }}
      onDelete={(resourceId) => {
        return new Promise((resolve) =>
          adminRequests
            .deleteOrganizationLicense(organizationId, resourceId)
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を削除しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の削除に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            }),
        )
      }}
    />
  )
}
