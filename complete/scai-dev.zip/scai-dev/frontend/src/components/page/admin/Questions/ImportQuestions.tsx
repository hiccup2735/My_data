import { Box } from '@material-ui/core'
import parse from 'csv-parse/lib/sync'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { useDropzone } from 'react-dropzone'
import { Metadata } from '../../../../types/domain'
import { adminRequests } from '../../../../utils/api'
import { ManagerContext } from '../../../../contexts/ManagerContext'

type ChoiceData = {
  name: string
  point: number
}

type QuizData = {
  description: string
  choices: ChoiceData[]
}

type QuestionData = {
  name: string
  image_uri?: string
  description: string
  tags: string[]
  quizzes: QuizData[]
  metadata: Metadata[]
  level: number
}

const parseCSV = (file: File) => {
  return new Promise<QuestionData[]>((resolve) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      if (e.target?.result) {
        const records = parse(e.target.result as string, {
          columns: true,
          skip_empty_lines: true,
        })
        const questions: QuestionData[] = []
        records.forEach((r: Record<string, string>) => {
          if (r.name) {
            questions.push({
              name: r.name,
              image_uri: r.image_uri,
              level: r.level ? parseInt(r.level, 10) : 0,
              description: r.description,
              tags: r.tags.split('/'),
              quizzes: [],
              metadata: r.metadata
                ? r.metadata.split('/').map((m: string) => {
                    const [key, value] = m.split(':')
                    return { key, value }
                  })
                : [],
            })
          }
          const questionIndex = questions.length - 1
          if (questionIndex >= 0) {
            if (r.quiz_description) {
              questions[questionIndex].quizzes.push({
                description: r.quiz_description,
                choices: [],
              })
            }
          }
          const quizIndex = questions[questionIndex].quizzes.length - 1
          if (quizIndex >= 0) {
            questions[questionIndex].quizzes[quizIndex].choices.push({
              name: r.choice_name,
              point: parseInt(r.choice_point, 10),
            })
          }
        })
        resolve(questions)
      }
    }
    reader.readAsText(file, 'UTF-8')
  })
}

type Props = {
  onUploaded: () => void
}

export const ImportQuestions = ({ onUploaded }: Props) => {
  const { enqueueSnackbar } = useSnackbar()
  const { group } = React.useContext(ManagerContext)
  const onDrop = React.useCallback((acceptedFiles: File[]) => {
    console.log('acceptedFiles', acceptedFiles)
    if (acceptedFiles.length === 0) {
      enqueueSnackbar('アップロードできるのはCSVのみです', {
        variant: 'warning',
      })
      return
    }
    parseCSV(acceptedFiles[0]).then((questions) => {
      console.log('parsed', questions)
      questions.forEach((q) => {
        adminRequests
          .createQuestion({
            name: q.name,
            description: q.description,
            image_uri: q.image_uri,
            metadata: q.metadata,
            tags: q.tags,
            level: q.level,
            group: group,
          })
          .then((res) => {
            const questionId = res.data.id
            setTimeout(() => {
              enqueueSnackbar(
                `問${questionId}「${res.data.name}」が作成されました`,
                { variant: 'success' },
              )
              onUploaded()
            }, 1000)
            q.quizzes.forEach((quiz, quizIndex) => {
              adminRequests
                .createQuiz(questionId, {
                  description: quiz.description,
                  sequence: quizIndex + 1,
                })
                .then((res2) => {
                  const quizId = res2.data.id
                  quiz.choices.forEach((choice, choiceIndex) => {
                    adminRequests.createChoice(quizId, {
                      name: choice.name,
                      point: choice.point,
                      sequence: choiceIndex + 1,
                    })
                  })
                })
            })
          })
      })
    })
  }, [])

  const { getInputProps, getRootProps, isDragActive } = useDropzone({
    onDrop,
    multiple: false,
    accept: '.csv',
  })

  return (
    <Box>
      <div
        {...getRootProps()}
        style={{
          border: '1px solid #ccc',
          padding: 16,
          marginBottom: 24,
          fontSize: 'small',
        }}
      >
        <input {...getInputProps()} />
        {isDragActive ? (
          <p>ここにファイルをドロップしてください...</p>
        ) : (
          <p>
            CSVをアップロードするにはファイルをドラッグ&amp;ドロップするかここをクリックしてファイルを選択してください
          </p>
        )}
      </div>
    </Box>
  )
}
