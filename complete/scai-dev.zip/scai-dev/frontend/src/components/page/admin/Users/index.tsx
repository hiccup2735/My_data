import { useSnackbar } from 'notistack'
import * as React from 'react'
import { adminRequests } from '../../../../utils/api'
import { UserList } from '../../../module/admin/UserList'
import { SessionKey } from '../../../../types/domain'

import { Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from '@material-ui/core'
import { async } from 'crypto-random-string'

const RESOURCE_NAME = 'ユーザー'

export const AdminUsers = () => {
  const { enqueueSnackbar } = useSnackbar()
  const [initialed, setInitialed] = React.useState<boolean>(false)
  const pageSize = Number(sessionStorage.getItem(SessionKey.UserPageSize)) || 20
  const keyword = sessionStorage.getItem(SessionKey.UserKeyword) || ''
  const [open, setOpen] = React.useState(false)
  const [params, setParams] = React.useState<{
    name?: string;
    email?: string;
    password?: string;
    isEmail?: boolean
  }>({});
  const [userId, setUserId] = React.useState<number | undefined>(undefined);
  const handleClose = () => setOpen(false);

  type UserType = {
    id: number;
    name: string;
    email: string;
    organization_name?: string;
    examinations_count?: number;
    is_invited?: boolean;
    init_password?: string;
  };

  const handleClickOpen = () => setOpen(true);

  const handleSubmitUpdate = (ismail: boolean) => {

    if (userId === undefined) {
      console.error('Invalid user ID');
      return;
    }
    adminRequests
    .updateUser(userId, {...params, isEmail: ismail})
    .then(() => {
      enqueueSnackbar(`${RESOURCE_NAME}を更新しました`, {
        variant: 'success',
      });
    })
    .catch(() => {
      enqueueSnackbar(`${RESOURCE_NAME}の更新に失敗しました`, {
        variant: 'error',
      });
    });

    handleClose()
  }


  return (
    <>
      <UserList
        keyword={keyword}
        pageSize={pageSize}
        data={(query) => {
          const page = !initialed ? Number(sessionStorage.getItem(SessionKey.UserPage)) || 0 : query.page
          return new Promise((resolve) => {
            adminRequests
              .getUsers({
                q: query.search,
                page: page,
                page_size: query.pageSize,
              })
              .then((res) => {
                resolve({
                  page: res.data.page,
                  totalCount: res.data.total,
                  data: res.data.users,
                })
                sessionStorage.setItem(SessionKey.UserKeyword, query.search)
                sessionStorage.setItem(SessionKey.UserPage, res.data.page.toString())
                sessionStorage.setItem(SessionKey.UserPageSize, query.pageSize.toString())
                setInitialed(true)
              })
          })
        }}
        onEdit={(record) => {
          return new Promise((resolve) => {
            const userData: {
              name?: string;
              email?: string;
              password?: string;
              isEmail?: boolean
            } = {
              name: record.name,
              email: record.email,
            };

            if (record.init_password) {
              userData.password = record.init_password;
            }

            setUserId(record.id);
            setParams(userData);
            handleClickOpen();
            resolve(true)
          })
        }
        }

        onDelete={(resourceId) => {
          return new Promise((resolve) =>
            adminRequests
              .deleteUser(resourceId)
              .then(() => {
                enqueueSnackbar(`${RESOURCE_NAME}を削除しました`, {
                  variant: 'success',
                })
                resolve(true)
              })
              .catch(() => {
                enqueueSnackbar(`${RESOURCE_NAME}の削除に失敗しました`, {
                  variant: 'error',
                })
                resolve(false)
              })
          )
        }}
      />
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          {"ユーザーにメールを送信しますか?"}
        </DialogTitle>
        <DialogContent>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => handleSubmitUpdate(true)}>はい</Button>
          <Button onClick={() => handleSubmitUpdate(false)}>いいえ</Button>
        </DialogActions>
      </Dialog>
    </>

  )
}
