import { useSnackbar } from 'notistack'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { adminRequests } from '../../../../utils/api'
import { adminPaths, ADMIN_ROOT, operatorPaths, managerPaths, MGR_ROOT, OPE_ROOT } from '../../../../utils/paths'
import { OrganizationList } from '../../../module/admin/OrganizationList'
import { SessionKey } from '../../../../types/domain'


const RESOURCE_NAME = '組織'

export const AdminOrganizations = () => {
  const { enqueueSnackbar } = useSnackbar()
  const history = useHistory()
  const [initialed, setInitialed] = React.useState<boolean>(false)
  const isAdmin = window.location.pathname.includes(ADMIN_ROOT) ? true : false
  const isManager = window.location.pathname.includes(MGR_ROOT) ? true : false
  const isOperator = window.location.pathname.includes(OPE_ROOT) ? true : false

  return (
    <OrganizationList
      onClickUsers={(organizationId) => {
        if (isAdmin) history.push(adminPaths.genOrganizationUsers(organizationId))
        if (isManager) history.push(managerPaths.genOrganizationUsers(organizationId))
        if (isOperator) history.push(operatorPaths.genOrganizationUsers(organizationId))
      }}
      onClickLicenses={(organizationId) => {
        if (isAdmin) history.push(adminPaths.genOrganizationLicenses(organizationId))
        if (isManager) history.push(managerPaths.genOrganizationLicenses(organizationId))
        if (isOperator) history.push(operatorPaths.genOrganizationLicenses(organizationId))
      }}
      onClickOrganizers={(organizationId) => {
        if (isAdmin) history.push(adminPaths.genOrganizationOrganizers(organizationId))
        if (isManager) history.push(managerPaths.genOrganizationOrganizers(organizationId))
        if (isOperator) history.push(operatorPaths.genOrganizationOrganizers(organizationId))
      }}
      data={(query) => {
        return new Promise((resolve) => {
          const page = !initialed ? Number(sessionStorage.getItem(SessionKey.OrganizationPage)) || 0 : query.page
          adminRequests
            .getOrganizations({
              page: page,
              q: query.search,
              page_size: query.pageSize,
            })
            .then((res) => {
              resolve({
                page: res.data.page,
                totalCount: res.data.total,
                data: res.data.organizations,
              })
              sessionStorage.setItem(SessionKey.OrganizationKeyword, query.search)
              sessionStorage.setItem(SessionKey.OrganizationPage, res.data.page.toString())
              sessionStorage.setItem(SessionKey.OrganizationPageSize, query.pageSize.toString())
              setInitialed(true)
            })
        })
      }}
      onAdd={(newRecord) => {
        return new Promise((resolve) =>
          adminRequests
            .createOrganization({
              name: newRecord.name,
              email: newRecord.email,
              address: newRecord.address,
              contact_person: newRecord.contact_person,
              category_id: newRecord.category_id,
              tel: newRecord.tel,
              comparable: newRecord.comparable,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を作成しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の作成に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            }),
        )
      }}
      onEdit={(record) => {
        return new Promise((resolve) =>
          adminRequests
            .updateOrganization(record.id, {
              name: record.name,
              email: record.email,
              address: record.address,
              contact_person: record.contact_person,
              category_id: record.category_id,
              tel: record.tel,
              comparable: record.comparable,
            })
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を更新しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の更新に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            }),
        )
      }}
      onDelete={(resourceId) => {
        return new Promise((resolve) =>
          adminRequests
            .deleteOrganization(resourceId)
            .then(() => {
              enqueueSnackbar(`${RESOURCE_NAME}を削除しました`, {
                variant: 'success',
              })
              resolve(true)
            })
            .catch(() => {
              enqueueSnackbar(`${RESOURCE_NAME}の削除に失敗しました`, {
                variant: 'error',
              })
              resolve(false)
            }),
        )
      }}
    />
  )
}
