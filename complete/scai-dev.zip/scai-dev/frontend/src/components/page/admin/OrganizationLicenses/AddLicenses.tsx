import { Box, Breadcrumbs, Button, Link } from '@material-ui/core'
import MaterialTable from 'material-table'
import * as React from 'react'
import { AdminUser, License } from '../../../../types/domain'
import { AdminSection } from '../../../ui/admin/Section'
import { Select } from '../../../ui/Select'

type AttachStatus = {
  userId: number
  success: boolean
}

type Props = {
  licenses: License[]
  users: AdminUser[]
  backToList: () => void
  onAttach: (licenceId: number, users: AdminUser[]) => Promise<AttachStatus[]>
}

export const AddLicenses = ({
  backToList,
  licenses,
  users,
  onAttach,
}: Props) => {
  const [license, setLicense] = React.useState<License | undefined>(undefined)
  const [attachStatuses, setAttachStatuses] = React.useState<AttachStatus[]>([])
  const [selectedUsers, setSelectedUsers] = React.useState<AdminUser[]>([])

  React.useEffect(() => {
    if (license) {
      setLicense(licenses.find((l) => l.id === license.id))
    }
  }, [licenses])

  const rest = license ? license.quantity - selectedUsers.length : 0

  return (
    <>
      <Box style={{ marginBottom: 24 }}>
        <Breadcrumbs>
          <Link
            style={{ cursor: 'pointer' }}
            onClick={() => backToList && backToList()}
          >
            ライセンス一覧に戻る
          </Link>
        </Breadcrumbs>
      </Box>

      <Box>
        <h3>ライセンス一括付与</h3>
        <AdminSection>
          <Select
            value={license?.id}
            options={licenses.map((l) => ({
              value: l.id,
              label: `${l.examination_name}(残数: ${l.quantity})`,
            }))}
            onChange={(id) => {
              setLicense(licenses.find((l) => l.id === id))
              setAttachStatuses([])
            }}
          />
        </AdminSection>
        {license && (
          <>
            <AdminSection>
              付与可能数: {rest}{' '}
              {rest < 0 && (
                <span style={{ color: 'red' }}>残数が足りません</span>
              )}
            </AdminSection>
            <AdminSection>
              <Button
                disabled={rest < 0}
                onClick={() => {
                  onAttach(license.id, selectedUsers).then((res) => {
                    setAttachStatuses(res)
                    setSelectedUsers([])
                  })
                }}
                variant="contained"
                color="primary"
              >
                付与を行う
              </Button>
            </AdminSection>
            <AdminSection>
              <MaterialTable<AdminUser>
                onSelectionChange={(rows) => {
                  console.log('selected', rows)
                  setSelectedUsers(rows)
                }}
                title="対象ユーザー選択"
                options={{
                  paging: false,
                  selection: true,
                }}
                data={users}
                columns={[
                  { field: 'id', title: 'ID' },
                  {
                    field: 'name',
                    title: '氏名',
                  },
                  {
                    field: 'has_license',
                    title: '付与ステータス',
                    render: (u) => {
                      let status: React.ReactNode = '-'
                      const attachStatus = attachStatuses.find(
                        (a) => a.userId === u.id
                      )
                      if (attachStatus) {
                        status = attachStatus.success ? (
                          <span style={{ color: 'green' }}>成功</span>
                        ) : (
                          <span style={{ color: 'red' }}>失敗</span>
                        )
                      }
                      return <div>{status}</div>
                    },
                  },
                ]}
              />
            </AdminSection>
          </>
        )}
      </Box>
    </>
  )
}
