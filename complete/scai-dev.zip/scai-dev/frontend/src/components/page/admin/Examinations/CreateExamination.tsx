import { useSnackbar } from 'notistack'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { adminRequests } from '../../../../utils/api'
import { adminPaths, managerPaths } from '../../../../utils/paths'
import { ExamForm } from '../../../module/admin/ExamDetail/ExamForm'
import { AdminContext } from '../../../../contexts/AdminContext'
import { ManagerContext } from '../../../../contexts/ManagerContext'

export const AdminCreateExamination = () => {
  const history = useHistory()
  const { enqueueSnackbar } = useSnackbar()
  const { authenticated } = React.useContext(AdminContext)
  const isAdmin = authenticated ? true : false
  const { group } = React.useContext(ManagerContext)
  return (
    <ExamForm
      onCancel={() => {
        history.push(isAdmin ? adminPaths.examinations : managerPaths.examinations)
      }}
      onSubmit={(values) => {
        console.log('onSubmit', values)
        adminRequests
          .createExam({
            name: values.name,
            description: values.description,
            limit_min: values.limitMin,
            scope: values.scope,
            code: values.code,
            group: isAdmin? values.group : group,
          })
          .then((res) => {
            console.log('res', res)
            enqueueSnackbar('試験を作成しました', { variant: 'success' })
            history.push(isAdmin ? adminPaths.examinations : managerPaths.examinations)
          })
          .catch((e) => {
            console.log('error', e)
            enqueueSnackbar('試験の作成に失敗しました', { variant: 'error' })
          })
      }}
    />
  )
}
