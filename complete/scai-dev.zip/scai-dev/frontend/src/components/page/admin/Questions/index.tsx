import { useSnackbar } from 'notistack'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { adminRequests } from '../../../../utils/api'
import { adminPaths, managerPaths } from '../../../../utils/paths'
import { QuestionList } from '../../../module/admin/QuestionList'
import { ImportQuestions } from './ImportQuestions'
import { SessionKey } from '../../../../types/domain'
import { ManagerContext } from '../../../../contexts/ManagerContext'
import { AdminContext } from '../../../../contexts/AdminContext'

export const AdminQuestions = () => {
  const history = useHistory()

  const { enqueueSnackbar } = useSnackbar()
  const [reloadCount, setReloadCount] = React.useState<number>(0)
  const [initialed, setInitialed] = React.useState<boolean>(false)
  const { group } = React.useContext(ManagerContext)
  const { authenticated } = React.useContext(AdminContext)
  const isAdmin = authenticated ? true : false

  return (
    <>
      <ImportQuestions onUploaded={() => setReloadCount(reloadCount + 1)} />
      <QuestionList
        reloadCount={reloadCount}
        onClick={(id) => {
          history.push(isAdmin ? adminPaths.genQuestion(id) : managerPaths.genQuestion(id))
        }}
        onCreate={() => {
          adminRequests
            .createQuestion({
              name: '名称未設定',
              description: 'なし',
              level: 0,
              group: group,
            })
            .then((res) => {
              console.log('created', res)
              enqueueSnackbar('問を作成しました', { variant: 'success' })
              history.push(isAdmin ? adminPaths.genQuestion(res.data.id) : managerPaths.genQuestion(res.data.id))
            })
            .catch((e) => {
              console.log(e)
              enqueueSnackbar('問の作成に失敗しました', { variant: 'error' })
            })
        }}
        onDelete={(questionId) => {
          console.log('onDelete', questionId)
          return new Promise<boolean>((resolve) => {
            adminRequests
              .deleteQuestion(questionId)
              .then(() => {
                resolve(true)
                enqueueSnackbar('問を削除しました', { variant: 'success' })
              })
              .catch(() => {
                resolve(false)
                enqueueSnackbar('問の削除に失敗しました', { variant: 'error' })
              })
          })
        }}
        onDuplicate={(questionId) => {
          console.log('onDuplicate', questionId)
          return new Promise<boolean>((resolve) => {
            adminRequests
              .duplicateQuestion(questionId)
              .then(() => {
                resolve(true)
                enqueueSnackbar('問を複製しました', { variant: 'success' })
                setReloadCount(reloadCount + 1)
              })
              .catch(() => {
                resolve(false)
                enqueueSnackbar('問の複製に失敗しました', { variant: 'error' })
              })
          })
        }}
        data={(query) => {
          return new Promise((resolve) => {
            const page = !initialed ? Number(sessionStorage.getItem(SessionKey.QuestionPage)) || 0 : query.page
            adminRequests
              .getQuestions({
                q: query.search,
                page: page,
                page_size: query.pageSize,
                group: group,
              })
              .then((res) => {
                resolve({
                  page: res.data.page,
                  data: res.data.questions,
                  totalCount: res.data.total,
                })
                sessionStorage.setItem(SessionKey.QuestionKeyword, query.search)
                sessionStorage.setItem(SessionKey.QuestionPage, res.data.page.toString())
                sessionStorage.setItem(SessionKey.QuestionPageSize, query.pageSize.toString())
                setInitialed(true)
              })
          })
        }}
      />
    </>
  )
}
