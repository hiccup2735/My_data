import * as React from 'react'
import { Grid } from '@material-ui/core'
import { requests } from '../../../utils/api'
import { useLocation } from 'react-router-dom'

type Status = 'verifying' | 'succeeded' | 'failed'

type Props = {
  status: Status
}

const messages: { [key in Status]: string } = {
  verifying: '検証しています...',
  succeeded: 'メールアドレスの確認ができました',
  failed: 'メールアドレスの検証に失敗しました',
}

export const VerifyEmail = ({ status }: Props) => (
  <Grid
    container
    justify="center"
    direction="column"
    style={{ height: '100vh' }}
  >
    <Grid item container justify="center">
      <Grid>{messages[status]}</Grid>
    </Grid>
  </Grid>
)

export const VerifyEmailContainer = () => {
  const location = useLocation()
  const params = new URLSearchParams(location.search)
  const token = params.get('verify_token')

  const [sts, setSts] = React.useState<Status>('verifying')

  React.useEffect(() => {
    if (token) {
      requests
        .verifyUser(token)
        .then(() => {
          setSts('succeeded')
        })
        .catch(() => {
          setSts('failed')
        })
    }
  }, [token])

  if (!token) {
    return <VerifyEmail status="failed" />
  }

  return <VerifyEmail status={sts} />
}
