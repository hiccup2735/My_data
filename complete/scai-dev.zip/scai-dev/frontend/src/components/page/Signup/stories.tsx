import React from 'react'
import { Signup } from '.'
import { action } from '@storybook/addon-actions'
import { BrowserRouter } from 'react-router-dom'

export default {
  component: Signup,
  title: 'page/Signup',
}

export const Default = () => (
  <BrowserRouter>
    <Signup onSignup={action('signup')} />
  </BrowserRouter>
)
