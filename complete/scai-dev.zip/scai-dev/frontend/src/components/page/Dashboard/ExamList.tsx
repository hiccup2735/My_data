import { Box, Paper } from '@material-ui/core'
import useAxios from 'axios-hooks'
import * as React from 'react'
import { useHistory } from 'react-router-dom'
import { Examination, ExaminationSummary } from '../../../types/domain'
import { apiPath, RecordSetProps } from '../../../utils/api'
import { paths } from '../../../utils/paths'
import { colors } from '../../../utils/theme'
import { ExamButton } from '../../ui/ExamButton'
import { ExamPublication } from '../../ui/ExamPublication'
import { Loading } from '../../ui/Loading'
import { PageContainer } from '../../ui/PageContainer'
import { PageTitle } from '../../ui/PageTitle'
import { ExamAttrs } from '../ExamDetail/ExamAttrs'
import { ExamHeader } from '../ExamDetail/ExamHeader'

type ExamListItemProps = {
  exam: ExaminationSummary
}
const ExamListItem = ({ exam }: ExamListItemProps) => {
  const history = useHistory()
  return (
    <Paper elevation={4} style={{ marginBottom: 24, padding: 0 }}>
      <ExamHeader exam={exam} />
      <Box style={{ padding: '16px 40px 16px 40px' }}>
        <Box style={{ display: 'flex' }}>
          <Box
            flexGrow="1"
            style={{
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            <Box
              style={{
                boxSizing: 'border-box',
                display: 'flex',
                paddingBottom: 12,
              }}
            >
              <Box
                style={{
                  minWidth: 90,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <ExamPublication />
              </Box>
              <Box
                style={{
                  flexGrow: 1,
                  paddingLeft: 24,
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'center',
                }}
              >
                <ExamAttrs exam={exam} showCount={false} />
              </Box>
            </Box>
            <Box
              style={{ fontSize: 12, color: colors.subText, paddingRight: 30 }}
            >
              テスト詳細: {exam.description}
            </Box>
          </Box>
          <Box style={{ minWidth: 176 }}>
            <Box
              style={{
                height: '100%',
                paddingLeft: 40,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                borderLeft: `1px solid ${colors.separator}`,
              }}
            >
              <ExamButton
                status={exam.status}
                onClick={() => {
                  history.push(paths.genExamination(exam.id.toString()))
                }}
              />
            </Box>
          </Box>
        </Box>
      </Box>
    </Paper>
  )
}

type Props = {
  exams: ExaminationSummary[]
  loading?: boolean
}

const AVAILABLE_EXAM_STATUS: Examination['status'][] = [
  'ready',
  'answering',
  'before',
]

const sortExam = (a: ExaminationSummary, b: ExaminationSummary) => {
  const dateA = a.available_at ? new Date(a.available_at) : null
  const timeA = dateA ? dateA.getTime() : 0

  const dateB = b.available_at ? new Date(b.available_at) : null
  const timeB = dateB ? dateB.getTime() : 0

  return timeA - timeB
}

export const ExamList = ({ exams, loading }: Props) => {
  if (!exams) {
    return null
  }

  const availableExams = exams.filter((exam) =>
    AVAILABLE_EXAM_STATUS.includes(exam.status),
  )

  const finishedExams = exams.filter(
    (exam) => !AVAILABLE_EXAM_STATUS.includes(exam.status),
  )

  return (
    <PageContainer>
      <Box>
        <PageTitle title="受験可能なテスト一覧" />
        <Box>
          {loading ? (
            <Loading />
          ) : availableExams.length > 0 ? (
            availableExams
              .sort(sortExam)
              .map((exam) => <ExamListItem key={exam.id} exam={exam} />)
          ) : (
            <Box
              style={{
                paddingBottom: 48,
                color: colors.hint,
                textAlign: 'center',
              }}
            >
              現在受験可能なテストはありません
            </Box>
          )}
        </Box>
      </Box>
      <Box>
        <PageTitle title="受験済・期限切れのテスト一覧" />
        <Box>
          {loading ? (
            <Loading />
          ) : finishedExams.length > 0 ? (
            finishedExams
              .sort(sortExam)
              .map((exam) => <ExamListItem key={exam.id} exam={exam} />)
          ) : (
            <Box
              style={{
                paddingBottom: 48,
                color: colors.hint,
                textAlign: 'center',
              }}
            >
              受験済・期限切れのテストはありません
            </Box>
          )}
        </Box>
      </Box>
    </PageContainer>
  )
}

export const ExamListContainer = () => {
  const [{ data, loading }] = useAxios<
    RecordSetProps & { examinations: ExaminationSummary[] }
  >(apiPath.examinations, { useCache: false })

  return <ExamList exams={data ? data.examinations : []} loading={loading} />
}
