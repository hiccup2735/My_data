import { useSnackbar } from 'notistack'
import * as React from 'react'
import { UserContext } from '../../../contexts/UserContext'
import { requests } from '../../../utils/api'
import { NotVerifiedAlert } from '../../ui/NotVerifiedAlert'
import { ExamListContainer } from './ExamList'

export const Dashboard = () => {
  const { user } = React.useContext(UserContext)
  const { enqueueSnackbar } = useSnackbar()
  return (
    <>
      <NotVerifiedAlert
        user={user}
        onRequestVerify={() => {
          requests
            .requestVerify()
            .then(() => {
              enqueueSnackbar(`確認メールを${user?.email}宛に送信しました`, {
                variant: 'success',
              })
            })
            .catch(() => {
              enqueueSnackbar('送信できませんでした', {
                variant: 'error',
              })
            })
        }}
      />
      <ExamListContainer />
    </>
  )
}
