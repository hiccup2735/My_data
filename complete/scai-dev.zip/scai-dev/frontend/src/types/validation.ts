import * as yup from 'yup'

const PASSWORD_ERROR =
  '数字・英字・記号（!#$%&*+-?@_）を各1文字以上含んでいる必要があります'

export const validation = {
  password: yup
    .string()
    .required('パスワードを入力してください')
    .matches(/[a-zA-Z]+/, PASSWORD_ERROR)
    .matches(/[0-9]+/, PASSWORD_ERROR)
    .matches(/[!#$%&*+\-?@_]+/, PASSWORD_ERROR)
    .min(8),
  passwordConfirmation: yup
    .string()
    .required('確認用パスワードを入力してください')
    .oneOf([yup.ref('password')], 'パスワードと確認用パスワードが一致しません'),
  email: yup
    .string()
    .email('正しいメールアドレスではありません')
    .required('メールアドレスを入力してください'),
  name: yup.string().required('名前を入力してください'),
  examinationName: yup.string().required('タイトルを入力してください'),
  examinationDescription: yup.string().required('説明を入力してください'),
  examinationLimitMin: yup.number().required('制限時間を入力してください'),
  group: yup.number().min(1, 'グループを選択してください'),
  image_uri: yup.string().url('正しいURLではありません'),
  id: yup.number().required('IDを指定してください'),
  optionalId: yup.number(),
  level: yup
    .number()
    .min(0, '0以上の数値を入力してください')
    .required('難易度を設定してください'),
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function isValidationError(item: any): item is yup.ValidationError {
  return item.name === 'ValidationError'
}

export const validate = (
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  schema: yup.Schema<any>,
  text: string,
): { isValid: boolean; helperText?: string } => {
  try {
    schema.validateSync(text)
    return { isValid: true }
  } catch (e) {
    if (isValidationError(e)) {
      return { isValid: false, helperText: e.errors.join('/') }
    }
    return { isValid: false, helperText: 'unknown' }
  }
}
