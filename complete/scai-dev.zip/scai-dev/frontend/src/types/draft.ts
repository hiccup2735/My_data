import { Examination, Question } from './domain'

export type ExaminationDraft = Pick<Examination, 'id' | 'description'> & {
  questions: QuestionDraft[]
}

export type QuizDraft = Pick<
  Question,
  'id' | 'is_answered' | 'category_name' | 'description'
> & {
  choices: ChoiceDraft[]
}

export type QuestionDraft = Pick<
  Question,
  'id' | 'description' | 'image_uri' | 'name'
> & {
  quizzes: QuizDraft[]
}

export type ChoiceDraft = {
  id: number
  name: string
}
