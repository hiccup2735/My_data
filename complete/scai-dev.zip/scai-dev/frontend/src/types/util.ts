export type TableData<TData> = {
  entities: TData[]
  page: number
  pageSize: number
  totalCount: number
}
