import axios from 'axios'
import useAxios from 'axios-hooks'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { createContext, ReactNode, useState } from 'react'
import { Operator } from '../types/domain'
import { apiPath } from '../utils/api'

type ContextValue = {
  authenticated: boolean
  setAuthenticated: (authenticated: boolean) => void
  operator?: Operator
  logout: (onLogout?: () => void) => void
}

export const OperatorContext = createContext<ContextValue>({
  authenticated: false,
  setAuthenticated: () => {
    return
  },
  operator: undefined,
  logout: () => {
    return
  },
})

type Props = {
  children: ReactNode
}

const AUTHENTICATED_KEY = 'operatorAuth'
const AUTHENTICATED_VALUE = '1'

export const OperatorProvider = ({ children }: Props) => {
  const { enqueueSnackbar } = useSnackbar()
  const [authenticated, setAuthenticated] = useState<boolean>(false)

  React.useEffect(() => {
    if (localStorage.getItem(AUTHENTICATED_KEY) === AUTHENTICATED_VALUE) {
      setAuthenticated(true)
    }
  }, [])

  const [{ data: operator, response, error }, getOperator] = useAxios<
    Operator
  >(apiPath.operator, {
    manual: true,
    useCache: false,
  })

  React.useEffect(() => {
    authenticated && getOperator()
  }, [authenticated, getOperator])

  React.useEffect(() => {
    if (error?.response?.status === 403 || error?.response?.status === 401) {
      setAuthenticated(false)
    }
  }, [response, error])

  return (
    <OperatorContext.Provider
      value={{
        authenticated,
        setAuthenticated: (auth: boolean) => {
          localStorage.setItem(AUTHENTICATED_KEY, AUTHENTICATED_VALUE)
          setAuthenticated(auth)
        },
        operator,
        logout: (onLogout) => {
          axios
            .delete<null>(apiPath.operatorAuth, {})
            .then((res) => {
              localStorage.setItem(AUTHENTICATED_KEY, '')
              setAuthenticated(false)
              enqueueSnackbar('ログアウトに成功しました', {
                variant: 'success',
              })
            })
            .catch((e) => {
              enqueueSnackbar('ログアウトに失敗しました', {
                variant: 'error',
              })
            })
            .finally(() => {
              onLogout && onLogout()
            })
        },
      }}
    >
      {children}
    </OperatorContext.Provider>
  )
}
