import axios from 'axios'
// import { User } from '../types/domain'
import useAxios from 'axios-hooks'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { createContext, ReactNode, useState } from 'react'
import { Admin } from '../types/domain'
import { apiPath } from '../utils/api'

type AdminContextValue = {
  authenticated: boolean
  setAuthenticated: (authenticated: boolean) => void
  admin?: Admin
  logout: (onLogout?: () => void) => void
}

export const AdminContext = createContext<AdminContextValue>({
  authenticated: false,
  setAuthenticated: () => {
    return
  },
  admin: undefined,
  logout: () => {
    return
  },
})

type Props = {
  children: ReactNode
}

const AUTHENTICATED_KEY = 'adminAuth'
const AUTHENTICATED_VALUE = '1'

export const AdminProvider = ({ children }: Props) => {
  const { enqueueSnackbar } = useSnackbar()
  const [authenticated, setAuthenticated] = useState<boolean>(false)

  React.useEffect(() => {
    if (localStorage.getItem(AUTHENTICATED_KEY) === AUTHENTICATED_VALUE) {
      setAuthenticated(true)
    }
  }, [])

  const [{ data: admin, response, error }, getAdmin] = useAxios<Admin>(
    apiPath.admin,
    {
      manual: true,
      useCache: false,
    },
  )

  React.useEffect(() => {
    authenticated && getAdmin()
  }, [authenticated, getAdmin])

  React.useEffect(() => {
    if (error?.response?.status === 403 || error?.response?.status === 401) {
      setAuthenticated(false)
    }
  }, [response, error])

  return (
    <AdminContext.Provider
      value={{
        authenticated,
        setAuthenticated: (auth: boolean) => {
          localStorage.setItem(AUTHENTICATED_KEY, AUTHENTICATED_VALUE)
          setAuthenticated(auth)
        },
        admin,
        logout: (onLogout) => {
          axios
            .delete<null>(apiPath.adminAuth, {})
            .then((res) => {
              localStorage.setItem(AUTHENTICATED_KEY, '')
              setAuthenticated(false)
              enqueueSnackbar('ログアウトに成功しました', {
                variant: 'success',
              })
            })
            .catch((e) => {
              enqueueSnackbar('ログアウトに失敗しました', {
                variant: 'error',
              })
            })
            .finally(() => {
              onLogout && onLogout()
            })
        },
      }}
    >
      {children}
    </AdminContext.Provider>
  )
}
