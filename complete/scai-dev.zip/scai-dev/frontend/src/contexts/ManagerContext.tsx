import axios from 'axios'
import useAxios from 'axios-hooks'
import { useSnackbar } from 'notistack'
import * as React from 'react'
import { createContext, ReactNode, useState } from 'react'
import { Manager } from '../types/domain'
import { apiPath } from '../utils/api'

type ContextValue = {
  authenticated: boolean
  setAuthenticated: (authenticated: boolean) => void
  manager?: Manager
  group: number
  setGroup: (group: number) => void
  logout: (onLogout?: () => void) => void
}

export const ManagerContext = createContext<ContextValue>({
  authenticated: false,
  setAuthenticated: () => {
    return
  },
  manager: undefined,
  group: 0,
  setGroup: () => {
    return
  },
  logout: () => {
    return
  },
})

type Props = {
  children: ReactNode
}

const AUTHENTICATED_KEY = 'managerAuth'
const AUTHENTICATED_VALUE = '1'
const GROUP_KEY = 'managerGroup'

export const ManagerProvider = ({ children }: Props) => {
  const { enqueueSnackbar } = useSnackbar()
  const [authenticated, setAuthenticated] = useState<boolean>(false)
  const [group, setGroup] = useState<number>(0)

  React.useEffect(() => {
    if (localStorage.getItem(AUTHENTICATED_KEY) === AUTHENTICATED_VALUE) {
      setAuthenticated(true)
      if (localStorage.getItem(GROUP_KEY) != null) setGroup(Number(localStorage.getItem(GROUP_KEY)))
    }
  }, [])

  const [{ data: manager, response, error }, getManager] = useAxios<
    Manager
  >(apiPath.manager, {
    manual: true,
    useCache: false,
  })

  React.useEffect(() => {
    authenticated && getManager()
  }, [authenticated, getManager])

  React.useEffect(() => {
    if (error?.response?.status === 403 || error?.response?.status === 401) {
      setAuthenticated(false)
    }
  }, [response, error])

  return (
    <ManagerContext.Provider
      value={{
        authenticated,
        setAuthenticated: (auth: boolean) => {
          localStorage.setItem(AUTHENTICATED_KEY, AUTHENTICATED_VALUE)
          setAuthenticated(auth)
        },
        manager,
        group,
        setGroup: (group: number) => {
          localStorage.setItem(GROUP_KEY, String(group))
          setGroup(group)
        },
        logout: (onLogout) => {
          axios
            .delete<null>(apiPath.managerAuth, {})
            .then((res) => {
              localStorage.setItem(AUTHENTICATED_KEY, '')
              localStorage.setItem(GROUP_KEY, '')
              setAuthenticated(false)
              enqueueSnackbar('ログアウトに成功しました', {
                variant: 'success',
              })
            })
            .catch((e) => {
              enqueueSnackbar('ログアウトに失敗しました', {
                variant: 'error',
              })
            })
            .finally(() => {
              onLogout && onLogout()
            })
        },
      }}
    >
      {children}
    </ManagerContext.Provider>
  )
}
