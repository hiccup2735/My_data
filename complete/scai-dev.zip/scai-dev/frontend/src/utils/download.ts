export const downloadTextFile = (
  content: string,
  fileName: string,
  contentType = 'text/plain',
) => {
  const blob = new Blob([content], { type: contentType })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  document.body.appendChild(a)
  a.download = fileName
  a.href = url
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}
