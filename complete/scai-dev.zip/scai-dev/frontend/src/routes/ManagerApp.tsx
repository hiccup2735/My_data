import { ThemeProvider } from '@material-ui/core'
import * as React from 'react'
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import { AdminExaminations } from '../components/page/admin/Examinations'
import { AdminCreateExamination } from '../components/page/admin/Examinations/CreateExamination'
import { AdminExamDetail } from '../components/page/admin/Examinations/ExamDetail'
import { AdminOrganizationCategories } from '../components/page/admin/OrganizationCategories'
import { AdminOrganizationLicenses } from '../components/page/admin/OrganizationLicenses'
import { AdminOrganizationOrganizers } from '../components/page/admin/OrganizationOrganizers'
import { AdminOrganizations } from '../components/page/admin/Organizations'
import { AdminOrganizationUsers } from '../components/page/admin/OrganizationUsers'
import { AdminQuestionCategories } from '../components/page/admin/QuestionCategories'
import { AdminQuestions } from '../components/page/admin/Questions'
import { AdminQuestionDetail } from '../components/page/admin/Questions/QuestionDetail'
import { AdminUsers } from '../components/page/admin/Users'
import { AdminUserDetail } from '../components/page/admin/Users/UserDetail'
import { AdminPageContainer } from '../components/ui/admin/PageContainer'
import { managerPaths, managerRegexp } from '../utils/paths'
import { adminTheme } from '../utils/theme'
import { ManagerContext, ManagerProvider } from '../contexts/ManagerContext'
import { ManagerHeader } from '../components/ui/manager/Header'
import { ManagerLogin } from '../components/page/manager/Login'

export const ManagerRoutes = () => {
  const { authenticated } = React.useContext(ManagerContext)

  React.useEffect(() => {
    document.title = 'SCAI サービス管理者ツール'
  }, [])

  if (!authenticated) {
    return (
      <Switch>
        <Route component={ManagerLogin} />
      </Switch>
    )
  }

  return (
    <>
      <ManagerHeader />
      <AdminPageContainer maxWidth="xl">
        <Switch>
          <Route path={managerPaths.user} component={AdminUserDetail} />
          <Route path={managerPaths.users} component={AdminUsers} />
          <Route
            path={managerPaths.organizationOrganizers}
            component={AdminOrganizationOrganizers}
          />

          <Route
            path={managerPaths.organizationUser}
            component={AdminUserDetail}
          />
          <Route
            path={managerPaths.organizationUsers}
            component={AdminOrganizationUsers}
          />
          <Route
            path={managerPaths.organizationLicenses}
            component={AdminOrganizationLicenses}
          />
          <Route
            path={managerPaths.organizationCategories}
            component={AdminOrganizationCategories}
          />
          <Route
            path={managerPaths.organizations}
            component={AdminOrganizations}
          />
          <Route
            path={managerPaths.questionCategories}
            component={AdminQuestionCategories}
          />
          <Route
            path={managerPaths.createExamination}
            component={AdminCreateExamination}
          />
          <Route path={managerPaths.examination} component={AdminExamDetail} />
          <Route path={managerPaths.examinations} component={AdminExaminations} />
          <Route path={managerPaths.question} component={AdminQuestionDetail} />
          <Route path={managerPaths.questions} component={AdminQuestions} />
          <Route path={managerPaths.root} component={AdminExaminations} />
        </Switch>
      </AdminPageContainer>
    </>
  )
}

export const ManagerApp = () => {
  if (!managerRegexp.test(window.location.pathname)) {
    return null
  }

  return (
    <ManagerProvider>
      <ThemeProvider theme={adminTheme}>
        <BrowserRouter>
          <ManagerRoutes />
        </BrowserRouter>
      </ThemeProvider>
    </ManagerProvider>
  )
}
