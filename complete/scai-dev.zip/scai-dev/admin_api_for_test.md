# テスト用API群サンプル

## サーバー設定

local環境

```
export SCAI_ADMIN_API_ENDPOINT=https://local.skill-check-ai.com/api/v1.0/admin
```

本番環境

```
export SCAI_ADMIN_API_ENDPOINT=https://skill-check-ai.com/api/v1.0/admin
```


## 管理者

作成

```
curl -d '
{"name": "ユーザー名1", "email": "example1@example.com", "password": "Passw0rd!"}
' $SCAI_ADMIN_API_ENDPOINT
```