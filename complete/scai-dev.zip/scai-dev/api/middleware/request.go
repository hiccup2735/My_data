package middleware

import (
	"app/session"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"net/http"
)

// SetContextRequestID ログ用にリクエストごとにIDを付与
func SetContextRequestID() gin.HandlerFunc {
	return func(c *gin.Context) {
		requestID, err := uuid.NewRandom()
		if err != nil {
			_ = c.AbortWithError(http.StatusInternalServerError, err)
			return
		}
		id := requestID.String()
		session.SetContextRequestID(c, id)
	}
}
