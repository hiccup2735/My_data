package s3

import (
	"fmt"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
	"mime/multipart"
	"os"
	"time"
)

var (
	bucket     = ""
	awsSession = session.Must(session.NewSessionWithOptions(session.Options{
		SharedConfigState: session.SharedConfigEnable,
	}))
)

// SetBucket バケットを設定
func SetBucket(bucketName string) {
	bucket = bucketName
}

// SetEndpoint エンドポイントを設定（minio使用時など）
func SetEndpoint(endpoint string) {
	awsSession = session.Must(session.NewSessionWithOptions(session.Options{
		Config: aws.Config{
			Endpoint:         aws.String(endpoint),
			S3ForcePathStyle: aws.Bool(true),
		},
		SharedConfigState: session.SharedConfigEnable,
	}))
}

// GetPresignedURI 署名付きURLの発行
func GetPresignedURI(key string) (string, error) {
	const expirationSec = 60
	svc := s3.New(awsSession)
	req, _ := svc.GetObjectRequest(&s3.GetObjectInput{
		Bucket: aws.String(bucket),
		Key:    aws.String(key),
	})
	return req.Presign(time.Second * expirationSec)
}

// UploadFile ファイルをS3に保存
func UploadFile(key string, filePath string, contentType string) (err error) {
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer func() {
		closeErr := file.Close()
		if closeErr != nil {
			err = fmt.Errorf("failed to close: %v (error: %v)", closeErr, err)
		}
	}()
	uploader := s3manager.NewUploader(awsSession)
	uploadInput := &s3manager.UploadInput{
		Bucket:      aws.String(bucket),
		Key:         aws.String(key),
		Body:        file,
		ContentType: aws.String(contentType),
	}
	if _, err := uploader.Upload(uploadInput); err != nil {
		return err
	}
	return nil
}

func UploadRawFile(fileHeader *multipart.FileHeader, key string, contentType string) (err error) {
	file, err := fileHeader.Open()
	if err != nil {
		return err
	}
	defer file.Close()

	uploader := s3manager.NewUploader(awsSession)
	uploadInput := &s3manager.UploadInput{
		Bucket:      aws.String(bucket),
		Key:         aws.String(key),
		Body:        file,
		ContentType: aws.String(contentType),
	}
	if _, err := uploader.Upload(uploadInput); err != nil {
		return err
	}
	return nil
}
