package util

import "testing"

func TestRoundToSecondDecimal(t *testing.T) {
	tests := []struct {
		arg    float64
		expect float64
	}{
		{arg: 10.345, expect: 10.35},
		{arg: 10.344, expect: 10.34},
		{arg: 10.34, expect: 10.34},
	}

	for _, tt := range tests {
		if r := RoundToSecondDecimal(tt.arg); r != tt.expect {
			t.Errorf("RoundToSecondDecimal() is expected: %v, actual %v", tt.expect, r)
		}
	}
}
