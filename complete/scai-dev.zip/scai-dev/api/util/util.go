package util

import "math"

// RoundToSecondDecimal 小数点第2で四捨五入
func RoundToSecondDecimal(v float64) float64 {
	return math.Round(v*100) / 100
}
