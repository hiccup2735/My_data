package session

import (
	"app/model"
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
)

const (
	contextRequestID       = "contextRequestID"
	contextUser            = "contextUser"
	contextUserExamination = "contextUserExamination"

	contextAdmin     = "contextAdmin"
	contextOrganizer = "contextOrganizer"
	contextOperator  = "contextOperator"
	contextManager   = "contextManager"
)

// SetContextRequestID ContextにRequestIDを保持
func SetContextRequestID(c *gin.Context, value string) {
	c.Set(contextRequestID, &value)
}

// GetContextRequestID ContextからRequestIDを取得
func GetContextRequestID(c context.Context) (string, error) {
	value, ok := c.Value(contextRequestID).(*string)
	if !ok {
		return "", fmt.Errorf("%s is not found in context", contextRequestID)
	}
	return *value, nil
}

// SetContextUser ContextにUserを保持
func SetContextUser(c *gin.Context, value *model.User) {
	c.Set(contextUser, value)
}

// GetContextUser ContextからUserを取得
func GetContextUser(c context.Context) (*model.User, error) {
	value, ok := c.Value(contextUser).(*model.User)
	if !ok {
		return nil, fmt.Errorf("%s is not found in context", contextUser)
	}
	return value, nil
}

// SetContextUserExamination ContextにUserExaminationを保持
func SetContextUserExamination(c *gin.Context, value *model.UserExamination) {
	c.Set(contextUserExamination, value)
}

// GetContextUserExamination ContextからUserExaminationを取得
func GetContextUserExamination(c context.Context) (*model.UserExamination, error) {
	value, ok := c.Value(contextUserExamination).(*model.UserExamination)
	if !ok {
		return nil, fmt.Errorf("%s is not found in context", contextUserExamination)
	}
	return value, nil
}

// SetContextAdmin ContextにAdminを保持
func SetContextAdmin(c *gin.Context, value *model.Admin) {
	c.Set(contextAdmin, value)
}

// GetContextAdmin ContextからAdminを取得
func GetContextAdmin(c *gin.Context) (*model.Admin, error) {
	value, ok := c.Value(contextAdmin).(*model.Admin)
	if !ok {
		return nil, fmt.Errorf("%s is not found in context", contextAdmin)
	}
	return value, nil
}

// SetContextOrganizer ContextにOrganizerを保持
func SetContextOrganizer(c *gin.Context, value *model.Organizer) {
	c.Set(contextOrganizer, value)
}

func GetContextOrganizer(c *gin.Context) (*model.Organizer, error) {
	value, ok := c.Value(contextOrganizer).(*model.Organizer)
	if !ok {
		return nil, fmt.Errorf("%s is not found in context", contextOrganizer)
	}
	return value, nil
}

func SetContextOperator(c *gin.Context, value *model.Operator) {
	c.Set(contextOperator, value)
}

func GetContextOperator(c *gin.Context) (*model.Operator, error) {
	value, ok := c.Value(contextOperator).(*model.Operator)
	if !ok {
		return nil, fmt.Errorf("%s is not found in context", contextOperator)
	}
	return value, nil
}

func SetContextManager(c *gin.Context, value *model.Manager) {
	c.Set(contextManager, value)
}

func GetContextManager(c *gin.Context) (*model.Manager, error) {
	value, ok := c.Value(contextManager).(*model.Manager)
	if !ok {
		return nil, fmt.Errorf("%s is not found in context", contextManager)
	}
	return value, nil
}
