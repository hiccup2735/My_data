package session

import (
	"github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
	"net/http"
)

// SessionTimeoutSec セッション保持期限
const SessionTimeoutSec int = 3 * 60 * 60

func set(c *gin.Context, key interface{}, val interface{}) error {
	session := sessions.Default(c)
	options := sessions.Options{
		Path:     "/",
		MaxAge:   SessionTimeoutSec,
		Secure:   true,
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	}
	session.Options(options)
	session.Set(key, val)
	return session.Save()
}

func get(c *gin.Context, key interface{}) interface{} {
	session := sessions.Default(c)
	return session.Get(key)
}

func delete(c *gin.Context, key interface{}) error {
	session := sessions.Default(c)
	session.Delete(key)
	return session.Save()
}

// Clear セッション全消去（setと同時に使うとsetが打ち消されるので注意）
func Clear(c *gin.Context) error {
	session := sessions.Default(c)
	session.Clear()
	return session.Save()
}
