package main

import (
	"app/controller"
	"app/controller/admin"
	"app/controller/code_runner"
	"app/controller/organizer"
	"app/controller/user"
	"app/controller/operator"
	"app/controller/manager"
	"app/env"
	"app/middleware"
	"app/model"
	"app/service"
	"app/util/s3"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/gin-gonic/gin"
)

func init() {
	if env.Config.Env == "prd" {
		gin.SetMode(gin.ReleaseMode)
	}
	if env.Config.AWSS3Endpoint != "" {
		s3.SetEndpoint(env.Config.AWSS3Endpoint)
	}
	s3.SetBucket(env.Config.AWSS3Bucket)
	if env.Config.Env == "local" {
		model.DropTables()
		model.Migrate()
		model.Seeds()
	}
}

func main() {
	router := gin.New()
	router.Use(gin.Recovery())
	router.Use(middleware.InitializeSession())
	router.Use(middleware.UpdateSessionExpires())
	router.Use(middleware.SetContextRequestID())
	router.Use(middleware.SetLogger())
	router.Use(middleware.ErrorHandler())

	router.GET("", controller.GetRoot)
	router.GET("api/", controller.GetRoot)

	awsConfig := &aws.Config{
		Region: aws.String("ap-northeast-1"),
	}

	scaiS3Service := service.NewS3Service(
		awsConfig,
		env.Config.AWSS3Bucket,
	)

	codeRunnerAwsConfig := &aws.Config{
		Region: aws.String("ap-northeast-1"),
		Credentials: credentials.NewStaticCredentials(
			env.Config.CodeRunnerAWSAccessKeyID,
			env.Config.CodeRunnerAWSSecretAccessKey,
			"",
		),
	}
	codeRunnerS3Service := service.NewS3Service(
		codeRunnerAwsConfig,
		env.Config.CodeRunnerAWSS3Bucket,
	)

	api := router.Group("api/v1.0")
	{
		{
			root := api.Group("admin")
			// TODO: 本番では招待制など、何らかの制限を入れる
			root.POST("", controller.AdminPostAdmin) // サインアップ
			root.POST("image/questions/upload", controller.AdminPostImageQuestionsUpload)

			{
				group := root.Group("auth")
				group.POST("", admin.SignIn)
				group.DELETE("", admin.SignOut)
			}

			// 以下は管理者ログイン状態でのみアクセス可能
			root.Use(middleware.RequireServiceManagerLogin())
			{
				root.GET("", controller.AdminGetAdmin)

				{
					ctrl := admin.NewExaminationController()
					group := root.Group("examinations")

					group.GET("", ctrl.Index)
					group.POST("", ctrl.Create)
					group.GET(":id", ctrl.Show)
					group.PATCH(":id", ctrl.Update)
					group.DELETE(":id", ctrl.Delete)
					group.POST(":id/copy", ctrl.Copy)

					group.GET(":id/questions", ctrl.IndexQuestion)
					group.PATCH(":id/questions/:question_id", ctrl.RelateQuestion)
					group.DELETE(":id/questions/:question_id", ctrl.RemoveQuestion)
					group.POST(":id/questions/:question_id/reorder", ctrl.ReorderQuestions)

					group.GET(":id/users", ctrl.IndexUser)

					group.PATCH(":id/organizations/:organization_id", ctrl.RelateOrganization)
					group.DELETE(":id/organizations/:organization_id", ctrl.RemoveOrganization)
				}
				{
					ctrl := admin.NewQuestionController()
					group := root.Group("questions")

					group.GET("", ctrl.Index)
					group.POST("", ctrl.Create)
					group.GET(":id", ctrl.Show)
					group.PATCH(":id", ctrl.Update)
					group.DELETE(":id", ctrl.Delete)
					group.POST(":id/copy", ctrl.Copy)

					quizController := admin.NewQuizController(
						model.NewQuestionRepository(),
						model.NewQuizRepository(),
					)

					group.GET(":id/quizzes", quizController.Index)
					group.POST(":id/quizzes", quizController.Create)
					group.PATCH(":id/quizzes/:quiz_id", quizController.Update)
					group.DELETE(":id/quizzes/:quiz_id", quizController.Delete)

					codeQuizController := admin.NewCodeQuizController(
						model.NewQuestionRepository(),
						model.NewCodeQuizRepository(),
						model.NewCodeQuizFileRepository(),
						scaiS3Service,
						codeRunnerS3Service,
					)
					group.POST(":id/code_quizzes", codeQuizController.Create)
					group.PATCH(":id/code_quizzes/:quiz_id", codeQuizController.Update)
					group.DELETE(":id/code_quizzes/:quiz_id", codeQuizController.Delete)
					group.PUT(":id/code_quizzes/:quiz_id/submit", codeQuizController.Submit)
				}
				{
					codeQuizFileController := admin.NewCodeQuizFileController(
						model.NewCodeQuizRepository(),
						model.NewCodeQuizFileRepository(),
						scaiS3Service,
					)
					group := root.Group("code_quizzes")
					group.PUT(":id/files/:type", codeQuizFileController.Upload)
					group.DELETE(":id/files/:file_id", codeQuizFileController.Delete)
				}
				{
					ctrl := admin.NewQuestionTagController()
					group := root.Group("question_tags")

					group.GET("", ctrl.Index)
				}
				{
					ctrl := admin.NewQuestionCategoryController(
						model.NewQuestionCategoryRepository(),
					)
					group := root.Group("question_categories")

					group.GET("", ctrl.Index)
					group.POST("", ctrl.Create)
					group.PATCH(":id", ctrl.Update)
					// TODO: deleteは削除した場合に関連づいているデータがどうなるか確認してから実装する
				}
				{
					ctrl := admin.NewChoiceController(
						model.NewQuizRepository(),
						model.NewChoiceRepository(),
					)
					group := root.Group("quizzes")

					group.GET(":quiz_id/choices", ctrl.Index)
					group.POST(":quiz_id/choices", ctrl.Create)
					group.PATCH(":quiz_id/choices/:choice_id", ctrl.Update)
					group.DELETE(":quiz_id/choices/:choice_id", ctrl.Delete)
				}
				{
					ctrl := admin.NewOrganizationController()
					group := root.Group("organizations")

					group.GET("", ctrl.Index)
					group.POST("", ctrl.Create)
					group.GET(":id", ctrl.Show)
					group.PATCH(":id", ctrl.Update)
					group.DELETE(":id", ctrl.Delete)

					group.GET(":id/users", ctrl.IndexUser)
					group.POST(":id/users", ctrl.CreateUser)
					group.PATCH(":id/users/:user_id", ctrl.UpdateUser)
					group.DELETE(":id/users/:user_id", ctrl.DeleteUser)

					group.GET(":id/licenses", ctrl.IndexLicense)
					group.POST(":id/licenses", ctrl.CreateLicense)
					group.PATCH(":id/licenses/:license_id", ctrl.UpdateLicense)
					group.DELETE(":id/licenses/:license_id", ctrl.DeleteLicense)

					group.GET(":id/organizers", ctrl.IndexOrganizer)
					group.POST(":id/organizers", ctrl.CreateOrganizer)
					group.PATCH(":id/organizers/:organizer_id", ctrl.UpdateOrganizer)
					// TODO: deleteを追加で実装する
				}
				{
					ctrl := admin.NewOrganizationCategoryController(
						model.NewOrganizationCategoryRepository(),
					)
					group := root.Group("organization_categories")
					group.GET("", ctrl.Index)
					group.POST("", ctrl.Create)
					group.PATCH(":id", ctrl.Update)
					// TODO: deleteは削除した場合に関連づいているデータがどうなるか確認してから実装する
				}
				{
					ctrl := admin.NewUserController()
					group := root.Group("users")

					group.GET("", ctrl.Index)
					group.POST("", ctrl.Create)
					group.GET(":id", ctrl.Show)
					group.PATCH(":id", ctrl.Update)
					group.DELETE(":id", ctrl.Delete)

					group.GET(":id/licenses", ctrl.IndexLicense)
					group.PATCH(":id/licenses/:license_id", ctrl.RelateLicense)
					group.DELETE(":id/licenses/:license_id", ctrl.RemoveLicense)
				}
				{
					group := root.Group("organizers")
					group.POST("", admin.CreateOrganizer)
				}
				{
					ctrl := admin.NewOperatorController()
					group := root.Group("operators")

					group.GET("", ctrl.Index)
					group.POST("", ctrl.Create)
					group.PATCH(":id", ctrl.Update)
					group.DELETE(":id", ctrl.Delete)
				}
				{
					ctrl := admin.NewManagerController()
					group := root.Group("managers")

					group.GET("", ctrl.Index)
					group.POST("", ctrl.Create)
					group.PATCH(":id", ctrl.Update)
					group.DELETE(":id", ctrl.Delete)
				}
			}
		}

		{
			root := api.Group("organizer")

			{
				ctrl := organizer.NewAuthController()
				group := root.Group("auth")

				group.POST("", ctrl.SignIn)
				group.DELETE("", ctrl.SignOut)
			}

			root.Use(middleware.RequireOrganizerLogin())
			{
				root.GET("", organizer.ShowMe)
				{
					group := root.Group("users")
					group.GET("", organizer.IndexUsers)
					group.GET(":id", organizer.ShowUser)

					group.PATCH(":id/licenses/:license_id", organizer.AppendUserLicense)
				}
				{
					ctrl := organizer.NewExaminationController()
					group := root.Group("examinations")

					group.GET("", ctrl.Index)
					group.GET(":id", ctrl.Show)
					group.GET(":id/users", ctrl.IndexUser)
					group.GET(":id/stat", ctrl.ShowStat)
					group.GET(":id/histories", ctrl.IndexHistory)
				}
				{
					group := root.Group("licenses")
					group.GET("", organizer.IndexLicenses)
				}
			}
		}

		{
			ctrl := user.NewAuthController()
			auth := api.Group("auth")

			auth.POST("", ctrl.SignIn)
			auth.DELETE("", ctrl.SignOut)
		}

		{
			group := api.Group("user")
			group.POST("", controller.PostUser)           // サインアップ
			group.POST("reset", controller.PostUserReset) // パスワード設定用URL送信
			group.PUT("reset", controller.PutUserReset)   // パスワード設定
		}

		{
			root := api.Group("operator")

			{
                group := root.Group("auth")
                group.POST("", operator.SignIn)
                group.DELETE("", operator.SignOut)
			}

			root.Use(middleware.RequireOperatorLogin())
			{
				root.GET("", operator.ShowMe)
			}
		}

		{
			root := api.Group("manager")

			{
                group := root.Group("auth")
                group.POST("", manager.SignIn)
                group.DELETE("", manager.SignOut)
			}

			root.Use(middleware.RequireManagerLogin())
			{
				root.GET("", manager.ShowMe)
			}
		}

		// code runnerとの連携API
		{
			ctrl := code_runner.NewCodeQuizResultController(
				model.NewCodeQuizAnswerRepository(),
				model.NewUserExaminationCodeQuizResultRepository(),
				model.NewUserExaminationRepository(),
			)

			group := api.Group("code_runner")
			group.PUT("code_quiz/results", ctrl.CreateOrUpdate)
		}

		// 以下はログイン状態でのみアクセス可能
		api.Use(middleware.RequireLogin())
		{
			group := api.Group("user")
			group.GET("", controller.GetUser)
			group.PUT("", controller.PutUser)
			group.POST("verify", controller.PostUserVerify) // メールアドレス確認用URL送信
			group.PUT("verify", controller.PutUserVerify)   // メールアドレス確認
		}
		// 以下はメールアドレス確認済み状態でのみアクセス可能
		api.Use(middleware.RequireVerify())
		{
			ctrl := user.NewExaminationController(
				model.NewUserExaminationRepository(),
				model.NewCodeQuizAnswerRepository(),
				codeRunnerS3Service,
			)
			group := api.Group("examinations")

			// 以下にアクセスする場合は試験の状態を最新化する
			group.Use(middleware.UpdateFinishedAt())
			group.GET("", ctrl.Index) // 試験一覧

			// 以下はExaminationIDが自分のものである場合のみアクセス可能
			group.Use(middleware.RequireUserExamination())
			group.GET(":id", ctrl.Show)                                             // 試験詳細
			group.POST(":id", ctrl.Start)                                           // 試験開始
			group.PATCH(":id/questions/:questionID", ctrl.AnswerChoiceQuiz)         // 選択式設問回答
			group.PATCH(":id/questions/:questionID/code_quiz", ctrl.AnswerCodeQuiz) // コード設問回答
			group.PUT(":id", ctrl.Finish)                                           // 試験終了
		}
	}

	if err := router.Run(":" + env.Config.Port); err != nil {
		panic(err)
	}
}
