package service

import (
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
	"github.com/pkg/errors"
	"io"
	"net/url"
	"os"
)

type S3Service struct {
	awsSession *session.Session
	bucket     *string
}

func NewS3Service(
	awsConfig *aws.Config,
	bucket string,
) *S3Service {
	awsSession := session.Must(session.NewSessionWithOptions(session.Options{
		Config:            *awsConfig,
		SharedConfigState: session.SharedConfigEnable,
	}))
	return &S3Service{
		awsSession,
		aws.String(bucket),
	}
}

func (m *S3Service) newUploader() *s3manager.Uploader {
	return s3manager.NewUploader(m.awsSession)
}

func (m *S3Service) Upload(key string, body io.Reader) (*s3manager.UploadOutput, error) {
	uploader := m.newUploader()
	res, err := uploader.Upload(&s3manager.UploadInput{
		Bucket: m.bucket,
		Key:    aws.String(key),
		Body:   body,
	})
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return res, nil
}

func (m *S3Service) newDownloader() *s3manager.Downloader {
	return s3manager.NewDownloader(m.awsSession)
}

func (m *S3Service) Download(rawURL string, file *os.File) error {
	u, err := url.Parse(rawURL)
	if err != nil {
		return errors.WithStack(err)
	}

	downloader := m.newDownloader()
	_, err = downloader.Download(file, &s3.GetObjectInput{
		Bucket: m.bucket,
		Key:    aws.String(u.Path),
	})
	if err != nil {
		return errors.WithStack(err)
	}
	return nil
}

func (m *S3Service) Delete(rawURL string) error {
	u, err := url.Parse(rawURL)
	if err != nil {
		return errors.WithStack(err)
	}

	svc := s3.New(m.awsSession)
	_, err = svc.DeleteObject(&s3.DeleteObjectInput{
		Bucket: m.bucket,
		Key:    aws.String(u.Path),
	})
	if err != nil {
		return errors.WithStack(err)
	}

	return svc.WaitUntilObjectNotExists(&s3.HeadObjectInput{
		Bucket: m.bucket,
		Key:    aws.String(u.Path),
	})
}
