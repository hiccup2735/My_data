package service

import (
	"app/model"
	"encoding/json"
	"fmt"
	"github.com/pkg/errors"
	"os"
	"strconv"
)

type CodeRunnerFileName string

const (
	CodeRunnerFileNameMetadata CodeRunnerFileName = "metadata.json"
	CodeRunnerFileNameOutput   CodeRunnerFileName = "output.zip"
	CodeRunnerFileNameInput    CodeRunnerFileName = "input.zip"
	CodeRunnerFileNameNgList   CodeRunnerFileName = "ng.list"
	CodeRunnerFileNameOkList   CodeRunnerFileName = "ok.list"
	CodeRunnerFileNameSetup    CodeRunnerFileName = "setup.sh"
)

func (n CodeRunnerFileName) ToString() string {
	return string(n)
}

type CodeRunnerService struct {
	s3Service  *S3Service
	workingDir string
	quiz       model.CodeQuiz
}

func NewCodeRunnerService(
	s3Service *S3Service,
	workingDir string,
	quiz model.CodeQuiz,
) *CodeRunnerService {
	return &CodeRunnerService{
		s3Service,
		workingDir,
		quiz,
	}
}

const AppName = "scai"

type metadata struct {
	ID          string `json:"id"` // Note: code runnerに数値でもstringで送らないとエラーとなる
	App         string `json:"app"`
	Type        string `json:"type"`
	MemoryLimit int    `json:"memory_limit"`
	TimeLimit   int    `json:"time_limit"`
	Criteria    int    `json:"criteria"`
	Compare     string `json:"compare"`
}

func (s *CodeRunnerService) UploadMetadata() error {
	metadata := metadata{
		ID:          strconv.Itoa(s.quiz.ID.ToInt()),
		App:         AppName,
		Type:        s.quiz.Type.ToString(),
		MemoryLimit: s.quiz.MemoryLimit,
		TimeLimit:   s.quiz.TimeLimit,
		Criteria:    s.quiz.Criteria,
		Compare:     s.quiz.Compare,
	}

	bytes, err := json.Marshal(metadata)
	if err != nil {
		return errors.WithStack(err)
	}

	filepath := s.workingDir + "/" + CodeRunnerFileNameMetadata.ToString()
	err = os.WriteFile(filepath, bytes, 0644)
	if err != nil {
		return errors.WithStack(err)
	}

	file, err := os.Open(filepath)
	defer file.Close()
	if err != nil {
		return errors.WithStack(err)
	}

	return s.uploadToS3(CodeRunnerFileNameMetadata.ToString(), file)
}

func (s *CodeRunnerService) UploadInput(file *os.File) error {
	return s.uploadToS3(CodeRunnerFileNameInput.ToString(), file)
}

func (s *CodeRunnerService) UploadOutput(file *os.File) error {
	return s.uploadToS3(CodeRunnerFileNameOutput.ToString(), file)
}

func (s *CodeRunnerService) UploadNgList(file *os.File) error {
	return s.uploadToS3(CodeRunnerFileNameNgList.ToString(), file)
}

func (s *CodeRunnerService) UploadOkList(file *os.File) error {
	return s.uploadToS3(CodeRunnerFileNameOkList.ToString(), file)
}

func (s *CodeRunnerService) UploadSetup(file *os.File) error {
	return s.uploadToS3(CodeRunnerFileNameSetup.ToString(), file)
}

func (s *CodeRunnerService) uploadToS3(filename string, file *os.File) error {
	prefix := fmt.Sprintf("problem/%s/%d/", AppName, s.quiz.ID)
	_, err := s.s3Service.Upload(prefix+filename, file)
	if err != nil {
		return errors.WithStack(err)
	}

	return nil
}

func (s *CodeRunnerService) DeleteInput() error {
	return s.deleteFromS3(CodeRunnerFileNameInput.ToString())
}

func (s *CodeRunnerService) DeleteOutput() error {
	return s.deleteFromS3(CodeRunnerFileNameOutput.ToString())
}

func (s *CodeRunnerService) DeleteNgList() error {
	return s.deleteFromS3(CodeRunnerFileNameNgList.ToString())
}

func (s *CodeRunnerService) DeleteOkList() error {
	return s.deleteFromS3(CodeRunnerFileNameOkList.ToString())
}

func (s *CodeRunnerService) DeleteSetup() error {
	return s.deleteFromS3(CodeRunnerFileNameSetup.ToString())
}

func (s *CodeRunnerService) deleteFromS3(filename string) error {
	prefix := fmt.Sprintf("problem/%s/%d/", AppName, s.quiz.ID)
	err := s.s3Service.Delete(prefix + filename)
	if err != nil {
		return errors.WithStack(err)
	}

	return nil
}

func GenerateProgramFileName(ext string) string {
	return fmt.Sprintf("Main.%s", ext)
}
