package service

import (
	"app/env"
	"app/model"
	"archive/zip"
	"encoding/json"
	"fmt"
	"github.com/google/uuid"
	"github.com/pkg/errors"
	"os"
	"strconv"
	"time"
)

type CodeRunnerAnswerFileName string

const (
	CodeRunnerAnswerFileNameHook    CodeRunnerAnswerFileName = "hook.json"
	CodeRunnerAnswerFileNameProgram CodeRunnerAnswerFileName = "program.zip"
)

func (n CodeRunnerAnswerFileName) ToString() string {
	return string(n)
}

type CodeRunnerAnswerService struct {
	s3Service      *S3Service
	workingDir     string
	answer         model.CodeQuizAnswer
	submissionID   uuid.UUID
	submissionTime time.Time
}

func NewCodeRunnerAnswerService(
	s3Service *S3Service,
	workingDir string,
	answer model.CodeQuizAnswer,
) *CodeRunnerAnswerService {
	submissionID := uuid.New()
	// TODO: jstにするかを確認する
	submissionTime := time.Now()

	return &CodeRunnerAnswerService{
		s3Service,
		workingDir,
		answer,
		submissionID,
		submissionTime,
	}
}

func (s *CodeRunnerAnswerService) GetSubmissionID() uuid.UUID {
	return s.submissionID
}

func (s *CodeRunnerAnswerService) GetSubmissionTime() time.Time {
	return s.submissionTime
}

type hookJson struct {
	ID         string `json:"id"`
	App        string `json:"app"`
	Problem    string `json:"problem"`
	Lang       string `json:"lang"`
	ResultDir  string `json:"result_dir"`
	ResultPath string `json:"result_path"`
}

func (s *CodeRunnerAnswerService) CreateHookFile() (filepath string, err error) {
	hookJson := hookJson{
		ID:        s.submissionID.String(),
		App:       AppName,
		Problem:   strconv.Itoa(s.answer.CodeQuizID.ToInt()),
		Lang:      s.answer.Lang.ToString(),
		ResultDir: env.Config.AWSS3Bucket,
		ResultPath: fmt.Sprintf(
			"code_runner/code_quiz/%d/%s/result.json",
			s.answer.CodeQuizID.ToInt(),
			s.submissionID.String(),
		),
	}

	bytes, err := json.Marshal(hookJson)
	if err != nil {
		return "", errors.WithStack(err)
	}

	filepath = s.workingDir + "/" + CodeRunnerAnswerFileNameHook.ToString()
	err = os.WriteFile(filepath, bytes, 0644)
	if err != nil {
		return "", errors.WithStack(err)
	}

	return filepath, nil
}

func (s *CodeRunnerAnswerService) UploadHookFile(filepath string) error {
	file, err := os.Open(filepath)
	defer file.Close()
	if err != nil {
		return errors.WithStack(err)
	}

	return s.uploadFileToS3(CodeRunnerAnswerFileNameHook.ToString(), file)
}

func (s *CodeRunnerAnswerService) getMainProgramFileName() string {
	ext := ""
	switch s.answer.Lang {
	case model.CodeQuizAnswerLangCpp:
		ext = "cpp"
	case model.CodeQuizAnswerLangJava:
		ext = "java"
	case model.CodeQuizAnswerLangPython:
		ext = "py"
	case model.CodeQuizAnswerLangR:
		ext = "r"
	case model.CodeQuizAnswerLangGo:
		ext = "go"
	}

	return fmt.Sprintf("Main.%s", ext)
}

func (s *CodeRunnerAnswerService) CreateProgramFile() (filepath string, err error) {
	filepath = s.workingDir + "/" + CodeRunnerAnswerFileNameProgram.ToString()
	file, err := os.Create(filepath)
	defer file.Close()
	if err != nil {
		return "", errors.WithStack(err)
	}

	zipWriter := zip.NewWriter(file)
	defer zipWriter.Close()

	w, err := zipWriter.Create(s.getMainProgramFileName())
	if err != nil {
		return "", errors.WithStack(err)
	}

	_, err = w.Write([]byte(s.answer.Code))
	if err != nil {
		return "", errors.WithStack(err)
	}

	return filepath, nil
}

func (s *CodeRunnerAnswerService) UploadProgramFile(filepath string) error {
	file, err := os.Open(filepath)
	defer file.Close()
	if err != nil {
		return errors.WithStack(err)
	}

	return s.uploadFileToS3(CodeRunnerAnswerFileNameProgram.ToString(), file)
}

func (s *CodeRunnerAnswerService) getS3Prefix() string {
	return fmt.Sprintf(
		"submission/%s/%s/%s/",
		AppName,
		// Note: このlayoutの指定で、yyyymmdd形式でフォーマットされた文字列が出力される
		s.submissionTime.Format("20060102"),
		s.submissionID.String(),
	)
}

func (s *CodeRunnerAnswerService) uploadFileToS3(filename string, file *os.File) error {
	_, err := s.s3Service.Upload(s.getS3Prefix()+filename, file)
	if err != nil {
		return errors.WithStack(err)
	}

	return nil
}
