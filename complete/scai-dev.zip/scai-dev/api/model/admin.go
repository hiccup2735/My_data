package model

import (
	"github.com/jinzhu/gorm"
	"golang.org/x/crypto/bcrypt"
)

func AdminFindByID(id int) (*Admin, error) {
	admin := &Admin{}
	if err := db.Find(&admin).Error; err != nil {
		return nil, err
	}
	return admin, nil
}

func AdminCreate(admin *Admin) error {
	return db.Create(admin).Error
}

func UserExaminationCreateAll(UserExaminations []*UserExamination) error {
	return db.Transaction(func(tx *gorm.DB) error {
		for _, UserExamination := range UserExaminations {
			if err := tx.Create(UserExamination).Error; err != nil {
				return err
			}
		}
		return nil
	})
}

func AdminSignIn(email string, password string) (*Admin, error) {
	admin := &Admin{Email: email}
	if err := db.Where(admin).First(admin).Error; err != nil {
		return nil, err
	}
	if err := bcrypt.CompareHashAndPassword([]byte(admin.Password), []byte(password)); err != nil {
		return nil, err
	}
	return admin, nil
}
