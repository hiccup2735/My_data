package model

// QuestionCategory
// Note: テーブルはcategoriesで作成してしまった
type QuestionCategory struct {
	Model
	Name      string      `json:"name"      gorm:"not null;unique_index:is_not_deleted" validate:"min=1,max=255"`
	Questions []*Question `json:"-"         gorm:""                                     validate:""`
	Group     int         `json:"group"     gorm:"not null;default:0"                   validate:"min=0,max=255"`
}

func (QuestionCategory) TableName() string {
	return "categories"
}

type QuestionCategoryID int

// FindCategoryByID find category by id
func FindCategoryByID(id int) (*QuestionCategory, error) {
	category := &QuestionCategory{}
	if err := db.First(&category, id).Error; err != nil {
		return nil, err
	}

	return category, nil
}
