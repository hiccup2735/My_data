package model

// QuestionTag question tag
type QuestionTag struct {
	NewModel
	Name       string `json:"name"        gorm:"not null"`
	QuestionID int    `json:"question_id" gorm:""`
}

// Delete delete question tag
func (tag *QuestionTag) Delete() error {
	return db.Delete(&tag).Error
}

func (tag *QuestionTag) Copy() (newTag *QuestionTag, err error) {
	if err = copyModel(tag, &newTag); err != nil {
		return nil, err
	}

	// TODO: question.goのCopyと同一の対応を検討
	newTag.ID = 0

	return newTag, nil
}

type QuestionTagRepository struct{}

// GetDistinctNames get distinct names
func (r *QuestionTagRepository) GetDistinctNames() (tags []*QuestionTag, err error) {
	if err = db.Raw("SELECT DISTINCT(name) FROM question_tags").Scan(&tags).Error; err != nil {
		return nil, err
	}

	return tags, nil
}
