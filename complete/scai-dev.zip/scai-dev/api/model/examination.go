package model

import (
	"github.com/jinzhu/gorm"
	"math"
)

// Examination examinations
type Examination struct {
	NewModel
	Name                     string                     `json:"name"          gorm:"not null" validate:"min=1,max=255"`
	Description              string                     `json:"description"   gorm:"type:varchar(10000);not null"                            validate:"min=1,max=10000"`
	LimitMin                 int                        `json:"limit_min"     gorm:"not null"                                                validate:"min=1,max=4294967295"`
	Scope                    string                     `json:"scope"         gorm:"type:enum('global','private');default:'global';not null" validate:""`
	Code                     string                     `json:"code"          gorm:"index:idx_code;not null"                                 validate:""`
	Questions                []*Question                `json:"questions"     gorm:"many2many:examination_questions"                         validate:""`
	ExaminationQuestions     []*ExaminationQuestion     `json:"-"             gorm:""                                                        validate:"min=0"`
	UserExaminations         []*UserExamination         `json:"-"             gorm:""                                                        validate:""`
	Organizations            []*Organization            `json:"organizations" gorm:"many2many:examination_organizations"                     validate:""`
	ExaminationOrganizations []*ExaminationOrganization `json:"-"             gorm:""                                                        validate:""`
	Group                    int                        `json:"group"         gorm:"not null;default:0"                                      validate:"min=0,max=255"`	
}

type CopiedExamination struct {
	OriginID int
	*Examination
	CopiedQuestions []*CopiedQuestion
}

// ExaminationPreload preload relation
type ExaminationPreload struct {
	Questions                bool
	QuestionsQuizzes         bool
	QuestionsQuizzesChoices  bool
	UserExaminations         bool
	ExaminationOrganizations bool
}

type ExaminationID int

func appendExaminationSearchQuery(db *gorm.DB, searchWord string) *gorm.DB {
	return db.Where("name LIKE ?", "%"+searchWord+"%").
		Or("description LIKE ?", "%"+searchWord+"%")
}

func appendExaminationGroupQuery(db *gorm.DB, group int) *gorm.DB {
	return db.Where("`group` = ?", group)
}

// FindExaminationByID find examination by id
func FindExaminationByID(id int, preload ExaminationPreload) (*Examination, error) {
	examination := &Examination{}
	tx := db

	if preload.Questions {
		tx = tx.
			// TODO: Preloadが多すぎるのなんとかできないか検討する
			Preload("Questions").
			Preload("ExaminationQuestions", func(db *gorm.DB) *gorm.DB {
				return db.Order("sequence")
			}).
			Preload("ExaminationQuestions.Category").
			Preload("ExaminationQuestions.Question").
			Preload("ExaminationQuestions.Question.Quizzes").
			Preload("ExaminationQuestions.Question.Quizzes.Choices")
	}

	if preload.QuestionsQuizzes {
		tx = tx.Preload("Questions.Quizzes", func(db *gorm.DB) *gorm.DB {
			return db.Order("sequence")
		})
	}

	if preload.QuestionsQuizzesChoices {
		tx = tx.Preload("Questions.Quizzes.Choices", func(db *gorm.DB) *gorm.DB {
			return db.Order("choices.sequence")
		})
	}

	if preload.UserExaminations {
		tx = tx.
			Preload("UserExaminations.User.Organization").
			Preload("UserExaminations.License")
	}

	if preload.ExaminationOrganizations {
		tx = tx.
			Preload("ExaminationOrganizations")
	}

	if err := tx.First(examination, id).Error; err != nil {
		return nil, err
	}

	return examination, nil
}

// CountExamination count examination
func CountExamination(searchWord string) (count int, err error) {
	var examinations []*Examination

	tx := db
	if searchWord != "" {
		tx = appendExaminationSearchQuery(tx, searchWord)
	}

	if err := tx.Find(&examinations).Count(&count).Error; err != nil {
		return 0, err
	}

	return count, nil
}

// FilterByExamination filter examination
// TODO: question, license, user数でソートできるようにする
func FilterByExamination(searchWord string, page int, pageSize int, group int) (examinations []*Examination, err error) {
	tx := db
	if searchWord != "" {
		tx = appendExaminationSearchQuery(tx, searchWord)
	}
	if group != 0 {
		tx = appendExaminationGroupQuery(tx, group)
	}

	tx = appendPagerQuery(tx, page, pageSize)
	if err := tx.Preload("Questions").Find(&examinations).Error; err != nil {
		return nil, err
	}

	return examinations, nil
}

// CreateExamination create examination
func CreateExamination(examination *Examination, assocAuto bool) error {
	return db.
		Set("gorm:association_autocreate", assocAuto).
		Create(examination).Error
}

// Update update examination
func (m *Examination) Update(data *Examination) error {
	return db.
		Set("gorm:save_associations", false).
		First(m).
		Updates(data).Error
}

// Delete delete examination
func (m *Examination) Delete() error {
	return db.Delete(&m).Error
}

func (exam *Examination) AppendExaminationQuestion(examQues *ExaminationQuestion) error {
	return db.
		Set("gorm:association_autoupdate", false).
		Model(&exam).
		Association("ExaminationQuestions").
		Append(examQues).Error
}

// DeleteQuestion delete associated question
func (m *Examination) DeleteQuestion(question *Question) error {
	return db.Model(&m).Association("Questions").Delete(question).Error
}

func (exam *Examination) AppendOrganization(eo *ExaminationOrganization) error {
	return db.
		Set("gorm:association_autoupdate", false).
		Model(&exam).
		Association("ExaminationOrganizations").
		Append(eo).Error
}

func (exam *Examination) DeleteOrganization(o *Organization) error {
	return db.Model(&exam).Association("Organizations").Delete(o).Error
}

func (exam *Examination) Copy() (*CopiedExamination, error) {
	var newExamination *Examination
	err := copyModel(exam, &newExamination)
	if err != nil {
		return nil, err
	}

	newExamination.ID = 0
	copiedQuestions := make([]*CopiedQuestion, 0)
	if exam.Questions != nil {
		newQuestions := make([]*Question, 0)
		for _, question := range exam.Questions {
			newQuestion, err := question.Copy()
			if err != nil {
				return nil, err
			}
			newQuestions = append(newQuestions, newQuestion)
			copiedQuestions = append(copiedQuestions, &CopiedQuestion{
				OriginID: question.ID,
				Question: newQuestion,
			})
		}
		newExamination.Questions = newQuestions
	}

	return &CopiedExamination{
		OriginID:        exam.ID,
		Examination:     newExamination,
		CopiedQuestions: copiedQuestions,
	}, nil
}

type ExaminationCategoryPoint struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Point int    `json:"point"`
}

// GetCategoryPoints
func (exam *Examination) GetCategoryPoints() (ps []ExaminationCategoryPoint) {
	m := make(map[int]ExaminationCategoryPoint)
	for _, examQues := range exam.ExaminationQuestions {
		p := examQues.Question.GetPoint()
		if v, ok := m[examQues.CategoryID]; ok {
			v.Point += p
			m[examQues.CategoryID] = v
		} else {
			v := ExaminationCategoryPoint{
				ID:    examQues.Category.ID,
				Name:  examQues.Category.Name,
				Point: examQues.Question.GetPoint(),
			}
			m[examQues.CategoryID] = v
		}
	}

	for _, v := range m {
		ps = append(ps, v)
	}

	return ps
}

func (exam *Examination) IsGlobalScope() bool {
	return exam.Scope == "global"
}

type StatScore struct {
	Avg int
	Max int
	Min int
}

// GetStatTotalScore
func (m *Examination) GetStatTotalScore() (*StatScore, error) {
	r := &StatScore{}
	if err := db.Raw(
		"SELECT FLOOR(AVG(score)) AS avg, MAX(score) AS max, MIN(score) AS min"+
			" FROM user_examinations"+
			" INNER JOIN user_examination_scores"+
			" ON user_examinations.id = user_examination_scores.user_examination_id"+
			" WHERE user_examinations.examination_id = ?", m.ID).
		Scan(r).Error; err != nil {
		return nil, err
	}

	return r, nil
}

type ExaminationResult struct {
	TotalCount    int
	CompleteCount int
}

func (r *ExaminationResult) GetAttendanceRate() int {
	div := 1
	if r.TotalCount > 0 {
		div = r.TotalCount
	}

	return (int)(math.Round(float64(r.CompleteCount) / float64(div) * 100))
}

func (m *Examination) GetResultCount() (*ExaminationResult, error) {
	r := &ExaminationResult{}
	if err := db.Raw(
		"SELECT COUNT(*) AS total_count,"+
			" COUNT(IF(finished_at IS NOT NULL, 1, NULL)) AS complete_count"+
			" FROM user_examinations"+
			" WHERE examination_id = ?", m.ID).Scan(r).Error; err != nil {
		return nil, err
	}

	return r, nil
}

func GetExaminationsByCode(code string, excludeIds ...int) (exams []*Examination, err error) {
	if code == "" {
		return exams, nil
	}

	tx := db
	if len(excludeIds) > 0 {
		tx = tx.Not(excludeIds)
	}

	if err = tx.Where(&Examination{Code: code}).
		Find(&exams).Error; err != nil {
		return nil, err
	}

	return exams, nil
}

// GetStatTotalScore
func GetStatLicenseTotalScore(examID int, licenseID int) (*StatScore, error) {
	r := &StatScore{}
	if err := db.Raw(
		"SELECT FLOOR(AVG(score)) AS avg, MAX(score) AS max, MIN(score) AS min"+
			" FROM user_examinations"+
			" INNER JOIN user_examination_scores"+
			" ON user_examinations.id = user_examination_scores.user_examination_id"+
			" WHERE user_examinations.examination_id = ? AND user_examinations.license_id = ?", examID, licenseID).
		Scan(r).Error; err != nil {
		return nil, err
	}

	return r, nil
}

func (m *Examination) GetLevel() float64 {
	level := 0
	for _, q := range m.Questions {
		level += q.Level
	}

	div := 1
	cnt := len(m.Questions)
	if cnt > 0 {
		div = cnt
	}

	return math.Round(float64(level)/float64(div)*100) / 100
}
