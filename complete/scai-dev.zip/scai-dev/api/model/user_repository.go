package model

import (
	"github.com/jinzhu/gorm"
)

type UserRepository struct {
	db *gorm.DB
}

func (r *UserRepository) Preload(preload UserPreload2) *UserRepository {
	if r.db == nil {
		r.db = db
	}

	if preload.Examinations {
		r.db = r.db.Preload("Examinations")
	}
	return r
}

type UserFilterCondition2 struct {
	OrganizationID OrganizationID
	SearchTerm     string
}

func (r *UserRepository) filterCondition(condition UserFilterCondition2) *UserRepository {
	if r.db == nil {
		r.db = db
	}

	if condition.OrganizationID != 0 {
		r.db = r.db.Where("organization_id = ?", condition.OrganizationID)
	}
	if condition.SearchTerm != "" {
		r.db = r.db.Where("(name LIKE ? OR email LIKE ?)",
			"%"+condition.SearchTerm+"%", "%"+condition.SearchTerm+"%")
	}
	return r
}

func (r *UserRepository) FilterByCondition(condition UserFilterCondition2) ([]*User, error) {
	defer func() {
		r.db = nil
	}()
	if r.db == nil {
		r.db = db
	}

	var users []*User
	err := r.filterCondition(condition).db.Find(&users).Error
	if err != nil {
		return nil, err
	}
	return users, nil
}

func (r *UserRepository) CountByCondition(condition UserFilterCondition2) (uint, error) {
	defer func() {
		r.db = nil
	}()
	if r.db == nil {
		r.db = db
	}

	var count uint
	err := r.filterCondition(condition).db.Table("users").Count(&count).Error
	if err != nil {
		return 0, err
	}
	return count, nil
}

type UserPreload2 struct {
	Examinations bool
}

func (r *UserRepository) Limit(n int) *UserRepository {
	if r.db == nil {
		r.db = db
	}
	r.db = r.db.Limit(n)
	return r
}

func (r *UserRepository) Offset(n int) *UserRepository {
	if r.db == nil {
		r.db = db
	}
	r.db = r.db.Offset(n)
	return r
}
