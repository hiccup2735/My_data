package model

import (
	"app/env"
	"app/mail"
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/crypto/bcrypt"
	"regexp"
	"time"
)

// User users
type User struct {
	Model
	Name                 string             `json:"name"                    gorm:"not null"                             validate:"min=1,max=255"`
	Email                string             `json:"email"                   gorm:"not null;unique_index:is_not_deleted" validate:"min=1,max=255,email"`
	Password             string             `json:"password"                gorm:"not null"                             validate:"min=1,max=255"`
	VerifyToken          *string            `json:"verify_token"            gorm:"unique_index:verify_token"            validate:"omitempty,min=1,max=255"`
	VerifyTokenExpiredAt *time.Time         `json:"verify_token_expired_at" gorm:""                                     validate:""`
	ResetToken           *string            `json:"reset_token"             gorm:"unique_index:reset_token"             validate:"omitempty,min=1,max=255"`
	ResetTokenExpiredAt  *time.Time         `json:"reset_token_expired_at"  gorm:""                                     validate:""`
	Examinations         []*Examination     `json:"examinations"            gorm:"many2many:user_examinations"          validate:""`
	UserExaminations     []*UserExamination `json:"user_examinations"       gorm:""                                     validate:""`
	OrganizationID       int                `json:"organization_id"         gorm:""                                     validate:""`
	Organization         *Organization      `json:"-"                       gorm:""                                     validate:""`
	LastLoginAt          *time.Time         `json:"last_login_at"           gorm:""                                     validate:""`
}

// UserPreload preloadするリレーション
type UserPreload struct {
	Organization     bool
	Examinations     bool
	UserExaminations bool
}

// UserFilterCondition filter condition
type UserFilterCondition struct {
	OrganizationID int
}

func appendUserSearchQuery(db *gorm.DB, searchWord string) *gorm.DB {
	return db.Where("(name LIKE ? OR email LIKE ?)", "%"+searchWord+"%", "%"+searchWord+"%")
}

func appendUserPreloads(db *gorm.DB, preload UserPreload) *gorm.DB {
	tx := db
	if preload.Organization {
		tx = tx.Preload("Organization")
	}

	if preload.Examinations {
		tx = tx.Preload("Examinations")
	}

	if preload.UserExaminations {
		tx = tx.Preload("UserExaminations.License.Examination")
	}

	return tx
}

func (c *UserFilterCondition) convConditionMap() map[string]interface{} {
	conditions := make(map[string]interface{})
	if c.OrganizationID > 0 {
		conditions["organization_id"] = c.OrganizationID
	}

	return conditions
}

// UserFindByID idからユーザーを検索
func UserFindByID(id int, preload UserPreload) (*User, error) {
	user := &User{}

	tx := db
	tx = appendUserPreloads(tx, preload)

	if err := tx.First(user, id).Error; err != nil {
		return nil, err
	}
	return user, nil
}

// FilterByUser filter user
func FilterByUser(searchWord string, page int, pageSize int, condition UserFilterCondition, preload UserPreload) (users []*User, err error) {
	tx := db
	if searchWord != "" {
		tx = appendUserSearchQuery(tx, searchWord)
	}

	tx = appendPagerQuery(tx, page, pageSize)
	tx = appendUserPreloads(tx, preload)

	if err := tx.Where(condition.convConditionMap()).Find(&users).Error; err != nil {
		return nil, err
	}

	return users, nil
}

// CountUser count user
func CountUser(searchWord string, condition UserFilterCondition) (count int, err error) {
	var users []*User

	tx := db
	if searchWord != "" {
		tx = appendUserSearchQuery(tx, searchWord)
	}

	if err := tx.Where(condition.convConditionMap()).Find(&users).Count(&count).Error; err != nil {
		return 0, err
	}

	return count, nil
}

func UserCreateAll(users []*User) error {
	return db.Transaction(func(tx *gorm.DB) error {
		for _, user := range users {
			if !ValidatePassword(user.Password) {
				return fmt.Errorf("invalid password")
			}
			hash, err := bcrypt.GenerateFromPassword([]byte(user.Password), 10)
			if err != nil {
				return err
			}
			user.Password = string(hash)
			if err := tx.Create(user).Error; err != nil {
				return err
			}
		}
		return nil
	})
}

// UserSignUp サインアップ
func UserSignUp(name string, email string, password string) (*User, error) {
	if !ValidatePassword(password) {
		return nil, fmt.Errorf("invalid password")
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(password), 10)
	if err != nil {
		return nil, err
	}
	verifyToken, err := randomString(255)
	if err != nil {
		return nil, err
	}
	verifyTokenExpiredAt := time.Now().Add(time.Hour)
	user := &User{
		Name:                 name,
		Email:                email,
		Password:             string(hash),
		VerifyToken:          &verifyToken,
		VerifyTokenExpiredAt: &verifyTokenExpiredAt,
		OrganizationID:       IndependentOrganizationID,
	}
	if err := db.Create(user).Error; err != nil {
		return nil, err
	}
	if err := user.SendVerifyToken(); err != nil {
		return nil, err
	}
	return user, nil
}

// UserSignIn サインイン
func UserSignIn(email string, password string) (*User, error) {
	user := &User{Email: email}
	if err := db.Where(user).First(user).Error; err != nil {
		return nil, err
	}
	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)); err != nil {
		return nil, err
	}
	return user, nil
}

// UserSendResetToken パスワード設定用メール送信
func UserSendResetToken(email string) error {
	user := &User{Email: email}
	if err := db.Where(user).First(user).Error; err != nil {
		return err
	}
	resetToken, err := randomString(255)
	if err != nil {
		return err
	}
	resetTokenExpiredAt := time.Now().Add(time.Hour)
	if err := db.Model(user).Updates(map[string]interface{}{"ResetToken": resetToken, "ResetTokenExpiredAt": &resetTokenExpiredAt}).Error; err != nil {
		return err
	}
	return mail.Send(user.Email, "パスワード再設定のご案内", fmt.Sprintf(
		`
スキルチェックAIをご利用いただきありがとうございます。

パスワードの再設定を行うために、以下のリンクをクリックしてください。
＊有効期限は1時間となっています。
https://%s/reset?reset_token=%s

有効期限を過ぎてしまった場合は、お手数ですが
以下のURLより再度パスワード変更手続きをお願いいたします。
https://%s/setting

----------------------------------------------------------------
スキルチェックAI運営事務局　お問い合わせ
https://share.hsforms.com/1xQEU6nkGTcuzDQW8zX4mAw2mtef

スキルチェックAI
https://%s
----------------------------------------------------------------
＊このメールに心当たりがない場合は破棄していただくようお願いいたします。
＊このメールアドレスへの返信はできません。
		`,
		env.Config.Domain,
		*user.ResetToken,
		env.Config.Domain,
		env.Config.Domain,
	))
}

// UserReset パスワード設定
func UserReset(resetToken string, password string) (*User, error) {
	user := &User{ResetToken: &resetToken}
	if err := db.Where(user).First(user).Error; err != nil {
		return nil, err
	}
	if user.ResetTokenExpiredAt.Before(time.Now()) {
		return nil, fmt.Errorf("token expired")
	}
	if !ValidatePassword(password) {
		return nil, fmt.Errorf("invalid password")
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(password), 10)
	if err != nil {
		return nil, err
	}
	if err := db.Model(user).Updates(map[string]interface{}{"Password": string(hash), "ResetToken": nil, "ResetTokenExpiredAt": nil}).Error; err != nil {
		return nil, err
	}
	return user, nil
}

// SendVerifyToken メールアドレス確認用メール送信
func (user *User) SendVerifyToken() error {
	if user.IsVerified() {
		return nil
	}
	verifyToken, err := randomString(255)
	if err != nil {
		return err
	}
	verifyTokenExpiredAt := time.Now().Add(time.Hour)
	if err := db.Model(user).Updates(map[string]interface{}{"VerifyToken": verifyToken, "VerifyTokenExpiredAt": &verifyTokenExpiredAt}).Error; err != nil {
		return err
	}
	return mail.Send(user.Email, "メールアドレスのご確認をお願いします", fmt.Sprintf(
		`
スキルチェックAIをご利用いただきありがとうございます。

%s
があなたのメールアドレスであることを認証したのち、
スキルチェックAIのテスト受験が可能になります。

以下のURLをクリックして認証をお願いします
＊有効期限は1時間となっています。
https://%s/verify?verify_token=%s

有効期限を過ぎてしまった場合は、お手数ですが
以下のURLより再度認証メール送信をお願いいたします。
https://%s/setting

----------------------------------------------------------------
スキルチェックAI運営事務局　お問い合わせ
https://share.hsforms.com/1xQEU6nkGTcuzDQW8zX4mAw2mtef

スキルチェックAI
https://%s
----------------------------------------------------------------
＊このメールに心当たりがない場合は破棄していただくようお願いいたします。
＊このメールアドレスへの返信はできません。
		`,
		user.Email,
		env.Config.Domain,
		*user.VerifyToken,
		env.Config.Domain,
		env.Config.Domain,
	))
}

// Update プロフィール更新
func (user *User) Update(name string, email string) error {
	// FIXME: 更新時にvalidationが走ってしまいエラーとなるためnilにして対応している
	user.UserExaminations = nil
	isSameEmail := user.Email == email
	if err := db.Model(user).Updates(map[string]interface{}{"Name": name, "Email": email}).Error; err != nil {
		return err
	}
	if !isSameEmail {
		if err := user.SendVerifyToken(); err != nil {
			return err
		}
	}
	return nil
}

// UpdateLastLoginAt update last login at
func (user *User) UpdateLastLoginAt(time time.Time) error {
	return db.Model(user).Update(&User{LastLoginAt: &time}).Error
}

// Verify メールアドレス確認
func (user *User) Verify(verifyToken string) error {
	if user.IsVerified() {
		return nil
	}
	if *user.VerifyToken != verifyToken {
		return fmt.Errorf("token invalid")
	}
	if user.VerifyTokenExpiredAt.Before(time.Now()) {
		return fmt.Errorf("token expired")
	}
	if err := db.Model(user).Updates(map[string]interface{}{"VerifyToken": nil, "VerifyTokenExpiredAt": nil}).Error; err != nil {
		return err
	}
	return nil
}

// IsVerified メールアドレス確認済みかどうか
func (user *User) IsVerified() bool {
	return user.VerifyToken == nil && user.VerifyTokenExpiredAt == nil
}

// FinishExpiredUserExaminations 回答制限時間を過ぎた開始済み試験を強制的に終了扱いにする
func (user *User) FinishExpiredUserExaminations() error {
	var userExaminations []*UserExamination

	repo := NewUserExaminationRepository()

	if err := db.Joins("JOIN licenses ON licenses.id = user_examinations.license_id").
		Where(&UserExamination{UserID: user.ID}).
		Where("user_examinations.started_at IS NOT NULL").   // 試験開始している
		Where("user_examinations.submitted_at IS NOT NULL"). // 提出時刻が入っていない(提出時刻があり、finished_atが無い = code_runnerからの結果待ち)
		Where("user_examinations.finished_at IS NULL").      // 終了時刻が入っていない
		Where("licenses.end_date_time < ?", time.Now()).     // 回答制限時間を過ぎている
		Find(&userExaminations).
		Error; err != nil {
		return err
	}
	for _, userExamination := range userExaminations {
		if err := userExamination.Finish(); err != nil {
			return err
		}
		err := repo.Update(userExamination)
		if err != nil {
			return err
		}
	}
	return nil
}

// AdminUpdate 管理者による更新
func (user *User) AdminUpdate(data *User) error {
	if data.Password != "" {
		if !ValidatePassword(data.Password) {
			return fmt.Errorf("invalid password")
		}
		hash, err := bcrypt.GenerateFromPassword([]byte(data.Password), 10)
		if err != nil {
			return err
		}
		data.Password = string(hash)
	}
	return db.
		Set("gorm:save_associations", false).
		First(user).Updates(data).Error
}

func (user *User) Delete() error {
	return db.Delete(&user).Error
}

func (user *User) DeleteUserExaminationByLicenseID(licenseID int) error {
	return db.Model(&user).Where("user_id = ?", user.ID).
		Where("license_id = ?", licenseID).
		Delete(&UserExamination{}).
		Error
}

// SendCreatedMail ユーザー作成後のメール送信
func (user *User) SendCreatedMail(password string) error {
	return mail.Send(user.Email, "【SkillCheckAI】アカウント登録完了", fmt.Sprintf(
		`
SkillCheckAIのアカウント登録が完了しました。

■ご登録内容
・ご契約企業: %s
・メールアドレス: %s
・初期パスワード: %s
・ログインURL: https://%s

ログイン後、初期パスワードの変更をおすすめしております。
下記からご変更いただけます。
https://%s/setting

「受験可能なテスト一覧」に表示されたテストは、受験期間内にすべて回答いただくようお願いします。
----------------------------------------------------------------------------
■ご登録の覚えがない方
本メールにお心当たりの無い場合は、管理者がメールアドレスを誤って登録した可能性があります。
企業管理者までお問い合わせ下さい。
%s

ログイン出来ない場合や、その他ご質問は、下記フォームよりご連絡ください。
https://www.skillupai.com/question/
このメールは、送信専用アドレスよりお送りしています。メールの返信は受け付けておりません。あらかじめご了承ください。
----------------------------------------------------------------------------
＜運営会社＞
株式会社スキルアップNeXt
https://skillup-next.co.jp/
`,
		user.Organization.Name,
		user.Email,
		password,
		env.Config.Domain,
		env.Config.Domain,
		user.Organization.Email,
	))
}

// SendCreatedMail ユーザー更新後のメール送信
func (user *User) SendUpdatedMail(password string) error {
	return mail.Send(user.Email, "【SkillCheckAI】アカウント更新のお知らせ", fmt.Sprintf(
		`
SkillCheckAIのアカウントが更新されました。

■ご登録内容
・ご契約企業: %s
・メールアドレス: %s
・初期パスワード: %s
・ログインURL: https://%s

ログイン後、初期パスワードの変更をおすすめしております。
下記からご変更いただけます。
https://%s/setting

「受験可能なテスト一覧」に表示されたテストは、受験期間内にすべて回答いただくようお願いします。
----------------------------------------------------------------------------
■ご登録の覚えがない方
本メールにお心当たりの無い場合は、管理者がメールアドレスを誤って登録した可能性があります。
企業管理者までお問い合わせ下さい。
%s

ログイン出来ない場合や、その他ご質問は、下記フォームよりご連絡ください。
https://www.skillupai.com/question/
このメールは、送信専用アドレスよりお送りしています。メールの返信は受け付けておりません。あらかじめご了承ください。
----------------------------------------------------------------------------
＜運営会社＞
株式会社スキルアップNeXt
https://skillup-next.co.jp/
`,
		user.Organization.Name,
		user.Email,
		password,
		env.Config.Domain,
		env.Config.Domain,
		user.Organization.Email,
	))
}

func (u *User) GetExaminations() (exams []*UserExamination, err error) {
	if err = db.Preload("License").Preload("Examination").
		Where(&UserExamination{UserID: u.ID}).
		Joins("JOIN examinations ON examinations.id = user_examinations.examination_id").
		Where("examinations.deleted_at is null").
		Find(&exams).Error; err != nil {

		return nil, err
	}

	return exams, nil
}

func randomString(length int) (string, error) {
	b := make([]byte, length)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	str := base64.RawURLEncoding.EncodeToString(b)
	return str[:length], nil
}

func ValidatePassword(password string) bool {
	passwordBytes := []byte(password)
	regs := []string{
		"^([0-9A-Za-z!-/:-@[-`{-~]){8,64}$",
		"[0-9]",
		"[A-Za-z]",
		"[!-/:-@[-`{-~]",
	}
	for _, reg := range regs {
		if !regexp.MustCompile(reg).Match(passwordBytes) {
			return false
		}
	}
	return true
}
