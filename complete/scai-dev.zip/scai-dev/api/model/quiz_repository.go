package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
)

type QuizRepository struct {
	db *gorm.DB
}

type QuizPreload struct {
	Choices bool
}

func NewQuizRepository() *QuizRepository {
	return &QuizRepository{db: db}
}

func (r *QuizRepository) FindByID(id QuizID) (*Quiz, error) {
	entity := &Quiz{}
	err := r.db.First(entity, int(id)).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *QuizRepository) Insert(entity *Quiz) error {
	err := r.db.Create(&entity).Error
	return errors.WithStack(err)
}

func (r *QuizRepository) Update(entity Quiz) error {
	err := r.db.Model(&Quiz{}).
		Where("id = ?", entity.ID).
		Updates(map[string]interface{}{
			"QuestionID":  entity.QuestionID,
			"Sequence":    entity.Sequence,
			"Description": entity.Description,
		}).Error
	return errors.WithStack(err)
}

func (r *QuizRepository) DeleteByID(id QuizID) error {
	err := r.db.Delete(&Quiz{}, int(id)).Error
	return errors.WithStack(err)
}

func (r *QuizRepository) FilterByQuestionID(questionID QuestionID, preload QuizPreload) ([]Quiz, error) {
	var entities []Quiz
	tx := r.db
	if preload.Choices {
		tx = tx.Preload("Choices", func(db *gorm.DB) *gorm.DB {
			return db.Order("id")
		})
	}

	err := tx.Order("id").
		Where(&Quiz{QuestionID: int(questionID)}).
		Find(&entities).Error
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return entities, nil
}
