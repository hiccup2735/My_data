// TODO: modelからcontrollerに移動する
package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
	"time"
)

type UserExaminationResponse struct {
	ID              int                       `json:"id"`
	Name            string                    `json:"name"`
	Description     string                    `json:"description"`
	LimitMin        int                       `json:"limit_min"`
	AvailableAt     *time.Time                `json:"available_at"`
	StartLimitAt    *time.Time                `json:"start_limit_at"`
	StartedAt       *time.Time                `json:"started_at"`
	AnswerLimitAt   *time.Time                `json:"answer_limit_at"`
	SubmittedAt     *time.Time                `json:"submitted_at"`
	FinishedAt      *time.Time                `json:"finished_at"`
	Status          string                    `json:"status"`
	QuestionsCount  int                       `json:"questions_count"`
	Questions       []*QuestionResponse       `json:"questions"`
	Score           int                       `json:"score"`
	Scores          []*ScoreResponse          `json:"scores"`
	CodeQuizResults []*CodeQuizResultResponse `json:"code_quiz_results"`
	Now             *time.Time                `json:"now"`
}

func createUserExaminationResponse(examination *UserExamination) (*UserExaminationResponse, error) {
	now := time.Now()
	status, err := examination.Status()
	if err != nil {
		return nil, err
	}
	var (
		questionsCount          = 0
		questionResponses       = make([]*QuestionResponse, 0)
		scoreResponses          = make([]*ScoreResponse, 0)
		totalScore              = &UserExaminationScore{}
		codeQuizResultResponses = make([]*CodeQuizResultResponse, 0)
	)
	questionsCount = len(examination.Examination.Questions)
	if examination.IsAnswering() {
		questionResponses = make([]*QuestionResponse, len(examination.Examination.Questions))
		for i, question := range examination.Examination.Questions {
			questionResponses[i] = createQuestionResponse(question)
		}
	}
	if examination.IsFinished() {
		// TODO: response整形でデータを取得するのをやめる
		tmpTotalScore, err := FindUserExaminationScoreByUserExaminationID(examination.ID)
		totalScore = &UserExaminationScore{}
		if err == nil && tmpTotalScore != nil {
			totalScore = tmpTotalScore
		}
		if err != nil {
			if !errors.Is(err, gorm.ErrRecordNotFound) {
				return nil, err
			}
		}

		catScores, err := GetUserExaminationCategoryScoreByUserExaminationID(examination.ID)
		if err != nil {
			return nil, err
		}
		scoreResponses = make([]*ScoreResponse, len(catScores))
		for i, s := range catScores {
			scoreResponses[i] = &ScoreResponse{
				CategoryName: s.Category.Name,
				Score:        s.Score,
			}
		}

		codeQuizResults, err := NewUserExaminationCodeQuizResultRepository().
			WithPreload().
			FilterByUserExaminationID(UserExaminationID(examination.ID))
		if err != nil {
			return nil, err
		}
		codeQuizResultResponses = make([]*CodeQuizResultResponse, len(codeQuizResults))
		for i, r := range codeQuizResults {
			codeQuizResultResponses[i] = &CodeQuizResultResponse{
				ID: r.ID,
				CodeQuiz: CodeQuizForResult{
					ID:          r.CodeQuizID,
					Description: r.CodeQuiz.Description,
				},
				Question: QuestionForResult{
					ID:          r.CodeQuiz.QuestionID,
					Name:        r.CodeQuiz.Question.Name,
					Description: r.CodeQuiz.Question.Description,
				},
				Result:     r.Result,
				Score:      r.Score,
				Statistics: r.Statistics,
			}
		}
	}

	return &UserExaminationResponse{
		ID:              examination.ID,
		Name:            examination.Examination.Name,
		Description:     examination.Examination.Description,
		LimitMin:        examination.Examination.LimitMin,
		AvailableAt:     examination.License.StartDateTime,
		StartLimitAt:    examination.License.EndDateTime,
		StartedAt:       examination.StartedAt,
		AnswerLimitAt:   examination.AnswerLimitAt,
		SubmittedAt:     examination.SubmittedAt,
		FinishedAt:      examination.FinishedAt,
		Status:          status.ToString(),
		QuestionsCount:  questionsCount,
		Questions:       questionResponses,
		Score:           totalScore.Score,
		Scores:          scoreResponses,
		CodeQuizResults: codeQuizResultResponses,
		Now:             &now,
	}, nil
}

type QuestionResponse struct {
	ID          int                 `json:"id"`
	Name        string              `json:"name"`
	Description string              `json:"description"`
	ImageURI    string              `json:"image_uri,omitempty"`
	Quizzes     []*QuizResponse     `json:"quizzes"`
	CodeQuizzes []*CodeQuizResponse `json:"code_quizzes"`
	IsAnswered  bool                `json:"is_answered"`
}

func createQuestionResponse(question *Question) *QuestionResponse {
	quizResponses := make([]*QuizResponse, len(question.Quizzes))
	for i, quiz := range question.Quizzes {
		quizResponses[i] = createQuizResponse(quiz)
	}

	codeQuizResponses := make([]*CodeQuizResponse, len(question.CodeQuizzes))
	for i, quiz := range question.CodeQuizzes {
		codeQuizResponses[i] = createCodeQuizResponse(quiz)
	}

	return &QuestionResponse{
		ID:          question.ID,
		Name:        question.Name,
		Description: question.Description,
		ImageURI:    question.ImageURI,
		Quizzes:     quizResponses,
		CodeQuizzes: codeQuizResponses,
		IsAnswered:  len(question.Answers) > 0,
	}
}

type QuizResponse struct {
	ID          int               `json:"id"`
	QuestionID  int               `json:"question_id"`
	Sequence    int               `json:"sequence"`
	Description string            `json:"description"`
	Choices     []*ChoiceResponse `json:"choices"`
}

func createQuizResponse(quiz *Quiz) *QuizResponse {
	choiceResponses := make([]*ChoiceResponse, len(quiz.Choices))
	for i, choice := range quiz.Choices {
		choiceResponses[i] = createChoiceResponse(choice)
	}

	return &QuizResponse{
		ID:          quiz.ID,
		QuestionID:  quiz.QuestionID,
		Sequence:    quiz.Sequence,
		Description: quiz.Description,
		Choices:     choiceResponses,
	}
}

type ChoiceResponse struct {
	ID         int    `json:"id"`
	Name       string `json:"name"`
	IsSelected bool   `json:"is_selected"`
}

func createChoiceResponse(choice *Choice) *ChoiceResponse {
	return &ChoiceResponse{
		ID:         choice.ID,
		Name:       choice.Name,
		IsSelected: len(choice.Answers) > 0,
	}
}

type CodeQuizResponse struct {
	ID             int                            `json:"id"`
	QuestionID     int                            `json:"question_id"`
	Sequence       int                            `json:"sequence"`
	Description    string                         `json:"description"`
	MemoryLimit    int                            `json:"memory_limit"`
	TimeLimit      int                            `json:"time_limit"`
	Criteria       int                            `json:"criteria"`
	Compare        string                         `json:"compare"`
	AvailableLangs []CodeQuizAnswerAvailableLangs `json:"available_langs"`
	Answer         *CodeQuizAnswerResponse        `json:"answer"`
}

type CodeQuizAnswerAvailableLangs struct {
	Lang CodeQuizAnswerLang `json:"lang"`
	Name string             `json:"name"`
}

type CodeQuizAnswerResponse struct {
	Lang string `json:"lang"`
	Code string `json:"code"`
}

func createCodeQuizResponse(quiz *CodeQuiz) *CodeQuizResponse {
	var answer *CodeQuizAnswerResponse
	if quiz.Answer != nil {
		answer = &CodeQuizAnswerResponse{
			Lang: quiz.Answer.Lang.ToString(),
			Code: quiz.Answer.Code,
		}
	}

	return &CodeQuizResponse{
		ID:          quiz.ID.ToInt(),
		QuestionID:  quiz.QuestionID.ToInt(),
		Sequence:    quiz.Sequence,
		Description: quiz.Description,
		MemoryLimit: quiz.MemoryLimit,
		TimeLimit:   quiz.TimeLimit,
		Criteria:    quiz.Criteria,
		Compare:     quiz.Compare,
		// TODO: 定義箇所を変える
		AvailableLangs: []CodeQuizAnswerAvailableLangs{
			{Lang: CodeQuizAnswerLangCpp, Name: "C++"},
			{Lang: CodeQuizAnswerLangJava, Name: "Java"},
			{Lang: CodeQuizAnswerLangPython, Name: "Python"},
			{Lang: CodeQuizAnswerLangR, Name: "R"},
			{Lang: CodeQuizAnswerLangGo, Name: "Go"},
		},
		Answer: answer,
	}
}
