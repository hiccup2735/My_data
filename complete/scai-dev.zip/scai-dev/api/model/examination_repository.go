package model

import (
	"errors"
	"github.com/jinzhu/gorm"
)

type ExaminationRepository struct {
	db *gorm.DB
}

func (r *ExaminationRepository) First() (*Examination, error) {
	defer func() {
		r.db = nil
	}()
	if r.db == nil {
		r.db = db
	}

	entity := &Examination{}
	err := r.db.First(&entity).Error
	if err != nil {
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, err
		}
		return nil, nil
	}
	return entity, nil
}

func (r *ExaminationRepository) ConditionID(id ExaminationID) *ExaminationRepository {
	if r.db == nil {
		r.db = db
	}
	r.db = r.db.Where("id = ?", id)
	return r
}
