package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
)

type QuestionRepository struct {
	db *gorm.DB
}

func NewQuestionRepository() *QuestionRepository {
	return &QuestionRepository{db: db}
}

func (r *QuestionRepository) FindByID(id QuestionID) (*Question, error) {
	entity := &Question{}
	err := r.db.First(entity, int(id)).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}
