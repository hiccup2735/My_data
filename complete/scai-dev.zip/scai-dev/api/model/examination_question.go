package model

// ExaminationQuestion examination_questions
type ExaminationQuestion struct {
	Model
	ExaminationID int               `json:"examination_id" gorm:"not null;unique_index:is_not_deleted" validate:"required_without=Examination,omitempty,min=1,max=4294967295"`
	QuestionID    int               `json:"question_id"    gorm:"not null;unique_index:is_not_deleted" validate:"required_without=Question,omitempty,min=1,max=4294967295"`
	Sequence      int               `json:"sequence"       gorm:"not null;default:1"                   validate:"min=0,max=4294967295"`
	CategoryID    int               `json:"category_id"    gorm:"not null"                             validate:"required,min=1,max=4294967295"`
	Examination   *Examination      `json:"examination"    gorm:""                                     validate:"required_without=ExaminationID"`
	Question      *Question         `json:"question"       gorm:""                                     validate:"required_without=QuestionID"`
	Category      *QuestionCategory `json:"category"       gorm:""                                     validate:""`
}

// GetExaminationQuestionMaxSequence
func GetExaminationQuestionMaxSequence(examID int) int {
	var seq int
	r := db.Table("examination_questions").
		Where("examination_id = ?", examID).
		Select("max(sequence)").Row()
	r.Scan(&seq)

	return seq
}

func (m *ExaminationQuestion) Update() error {
	return db.
		Set("gorm:save_associations", false).
		Model(&m).
		Updates(m).Error
}
