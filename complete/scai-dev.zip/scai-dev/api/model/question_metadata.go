package model

// QuestionMetadata question metadata
type QuestionMetadata struct {
	NewModel
	Key        string `json:"key"         gorm:"not null"`
	Value      string `json:"value"       gorm:"not null"`
	QuestionID int    `json:"question_id" gorm:"not null"`
	Group      int    `json:"group"       gorm:"not null"`
}

// Delete delete question metadata
func (m *QuestionMetadata) Delete() error {
	return db.Delete(&m).Error
}

// Copy copy new struct from receiver
func (m *QuestionMetadata) Copy() (new *QuestionMetadata, err error) {
	if err = copyModel(m, &new); err != nil {
		return nil, err
	}

	// TODO: question.goのCopyと同一の対応を検討
	m.ID = 0
	return m, nil
}
