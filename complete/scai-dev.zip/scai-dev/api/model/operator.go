package model

import (
	"golang.org/x/crypto/bcrypt"
	"github.com/jinzhu/gorm"
)

// Operator オペレーター
type Operator struct {
	Model
	Name           string        `json:"name"            gorm:"not null"                             validate:"min=1,max=255"`
	Email          string        `json:"email"           gorm:"not null;unique_index:is_not_deleted" validate:"min=1,max=255,email"`
	Password       string        `json:"-"               gorm:"not null"                             validate:"min=1,max=255"`
}

func OperatorSignIn(email string, password string) (*Operator, error) {
	operator := &Operator{Email: email}
	if err := db.Where(operator).First(operator).Error; err != nil {
		return nil, err
	}
	if err := bcrypt.CompareHashAndPassword([]byte(operator.Password), []byte(password)); err != nil {
		return nil, err
	}
	return operator, nil
}

func FindOperatorByID(id int) (*Operator, error) {
	operator := &Operator{}
	if err := db.First(&operator, id).Error; err != nil {
		return nil, err
	}
	return operator, nil
}

func appendOperatorSearchQuery(db *gorm.DB, searchWord string) *gorm.DB {
	return db.Where("(name LIKE ? OR email LIKE ?)", "%"+searchWord+"%", "%"+searchWord+"%")
}

func FindOperators(searchWord string, page int, pageSize int) (operators []*Operator, err error) {
	tx := db
	if searchWord != "" {
		tx = appendOperatorSearchQuery(tx, searchWord)
	}

	tx = appendPagerQuery(tx, page, pageSize)

	if err := tx.Find(&operators).Error; err != nil {
		return nil, err
	}

	return operators, nil
}

func CountOperator(searchWord string) (count int, err error) {
	var operators []*Operator

	tx := db
	if searchWord != "" {
		tx = appendOperatorSearchQuery(tx, searchWord)
	}

	if err := tx.Find(&operators).Count(&count).Error; err != nil {
		return 0, err
	}

	return count, nil
}

func CreateOperator(operators []*Operator) error {
	return db.Transaction(func(tx *gorm.DB) error {
		for _, operator := range operators {
			hash, err := bcrypt.GenerateFromPassword([]byte(operator.Password), 10)
			if err != nil {
				return err
			}
			operator.Password = string(hash)
			if err := tx.Create(operator).Error; err != nil {
				return err
			}
		}
		return nil
	})
}

func (m *Operator) UpdateOperator(data *Operator) error {
	return db.First(m).Updates(data).Error
}

func (m *Operator) DeleteOperator() error {
	return db.Delete(&m).Error
}