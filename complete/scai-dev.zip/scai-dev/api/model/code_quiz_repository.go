package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
)

type CodeQuizRepository struct {
	db *gorm.DB
}

func NewCodeQuizRepository() *CodeQuizRepository {
	return &CodeQuizRepository{db: db}
}

func (r *CodeQuizRepository) FindByID(id CodeQuizID) (*CodeQuiz, error) {
	entity := &CodeQuiz{}
	err := r.db.First(entity, int(id)).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *CodeQuizRepository) Insert(entity *CodeQuiz) error {
	err := r.db.Create(&entity).Error
	return errors.WithStack(err)
}

func (r *CodeQuizRepository) Update(entity *CodeQuiz) error {
	err := r.db.Set("gorm:save_associations", false).
		Model(&CodeQuiz{}).
		Where("id = ?", entity.ID).
		Updates(map[string]interface{}{
			"QuestionID":  entity.QuestionID,
			"Sequence":    entity.Sequence,
			"IsSubmitted": entity.IsSubmitted,
			"Type":        entity.Type,
			"Description": entity.Description,
			"MemoryLimit": entity.MemoryLimit,
			"TimeLimit":   entity.TimeLimit,
			"Criteria":    entity.Criteria,
			"Compare":     entity.Compare,
		}).Error
	return errors.WithStack(err)
}

func (r *CodeQuizRepository) WithPreload() *CodeQuizRepository {
	r.db = r.db.Preload("CodeQuizFiles")
	return r
}

func (r *CodeQuizRepository) DeleteByID(id CodeQuizID) error {
	err := r.db.Delete(&CodeQuiz{}, id.ToInt()).Error
	return errors.WithStack(err)
}

func (r *CodeQuizRepository) FilterByQuestionID(questionID QuestionID) ([]CodeQuiz, error) {
	var entities []CodeQuiz
	tx := r.db

	err := tx.Order("id").
		Where(&CodeQuiz{QuestionID: questionID}).
		Find(&entities).Error
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return entities, nil
}
