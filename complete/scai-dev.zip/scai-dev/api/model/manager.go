package model

import (
	"golang.org/x/crypto/bcrypt"
	"github.com/jinzhu/gorm"
)

// Manager サービス管理者
type Manager struct {
	Model
	Name           string        `json:"name"            gorm:"not null"                             validate:"min=1,max=255"`
	Email          string        `json:"email"           gorm:"not null;unique_index:is_not_deleted" validate:"min=1,max=255,email"`
	Group          int           `json:"group"           gorm:"not null"                             validate:"min=1,max=4294967295"`
	Password       string        `json:"-"               gorm:"not null"                             validate:"min=1,max=255"`
}

func ManagerSignIn(email string, password string) (*Manager, error) {
	manager := &Manager{Email: email}
	if err := db.Where(manager).First(manager).Error; err != nil {
		return nil, err
	}
	if err := bcrypt.CompareHashAndPassword([]byte(manager.Password), []byte(password)); err != nil {
		return nil, err
	}
	return manager, nil
}

func FindManagerByID(id int) (*Manager, error) {
	manager := &Manager{}
	if err := db.First(&manager, id).Error; err != nil {
		return nil, err
	}
	return manager, nil
}

func appendManagerSearchQuery(db *gorm.DB, searchWord string) *gorm.DB {
	return db.Where("(name LIKE ? OR email LIKE ?)", "%"+searchWord+"%", "%"+searchWord+"%")
}

func CountManager(searchWord string) (count int, err error) {
	var managers []*Manager

	tx := db
	if searchWord != "" {
		tx = appendManagerSearchQuery(tx, searchWord)
	}

	if err := tx.Find(&managers).Count(&count).Error; err != nil {
		return 0, err
	}

	return count, nil
}

func FindManagers(searchWord string, page int, pageSize int) (managers []*Manager, err error) {
	tx := db
	if searchWord != "" {
		tx = appendManagerSearchQuery(tx, searchWord)
	}

	tx = appendPagerQuery(tx, page, pageSize)

	if err := tx.Find(&managers).Error; err != nil {
		return nil, err
	}

	return managers, nil
}

func CreateManager(managers []*Manager) error {
	return db.Transaction(func(tx *gorm.DB) error {
		for _, manager := range managers {
			hash, err := bcrypt.GenerateFromPassword([]byte(manager.Password), 10)
			if err != nil {
				return err
			}
			manager.Password = string(hash)
			if err := tx.Create(manager).Error; err != nil {
				return err
			}
		}
		return nil
	})
}

func (m *Manager) UpdateManager(data *Manager) error {
	return db.First(m).Updates(data).Error
}

func (m *Manager) DeleteManager() error {
	return db.Delete(&m).Error
}