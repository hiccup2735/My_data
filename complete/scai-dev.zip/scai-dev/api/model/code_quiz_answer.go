package model

type CodeQuizAnswerID int

func (i CodeQuizAnswerID) ToInt() int {
	return int(i)
}

type CodeQuizAnswerLang string

// TODO: CodeQuizAnswerからCodeQuizで持つように変える
//       name, extensionとstructに変える
const (
	CodeQuizAnswerLangCpp    CodeQuizAnswerLang = "cpp"
	CodeQuizAnswerLangJava   CodeQuizAnswerLang = "java"
	CodeQuizAnswerLangPython CodeQuizAnswerLang = "python"
	CodeQuizAnswerLangR      CodeQuizAnswerLang = "r"
	CodeQuizAnswerLangGo     CodeQuizAnswerLang = "go"
)

func (l CodeQuizAnswerLang) ToString() string {
	return string(l)
}

func (l CodeQuizAnswerLang) IsValid() bool {
	switch l {
	case CodeQuizAnswerLangCpp, CodeQuizAnswerLangJava, CodeQuizAnswerLangPython, CodeQuizAnswerLangR, CodeQuizAnswerLangGo:
		return true
	}
	return false
}

// CodeQuizAnswer コード提出形式の設問(CodeQuiz)の回答
type CodeQuizAnswer struct {
	ID                CodeQuizAnswerID   `json:"id,omitempty"        gorm:"primary_key"                          validate:""`
	UserExaminationID int                `json:"user_examination_id" gorm:"not null;unique_index:is_not_deleted" validate:"required_without=UserExamination,omitempty,min=1,max=4294967295"`
	QuestionID        QuestionID         `json:"question_id"         gorm:"not null;unique_index:is_not_deleted" validate:"required_without=Question,omitempty,min=1,max=4294967295"`
	CodeQuizID        CodeQuizID         `json:"code_quiz_id"        gorm:"not null;unique_index:is_not_deleted" validate:"required_without=CodeQuiz,omitempty,min=1,max=4294967295"`
	Lang              CodeQuizAnswerLang `json:"lang"                gorm:"not null"                             validate:"min=0,max=10000"`
	Code              string             `json:"code"                gorm:"not null;type:text"                   validate:""`
	SubmissionID      *string            `json:"submission_id"       gorm:""                                     validate:"min=1,max=4294967295"`
	Timestamps
	UserExamination *UserExamination `json:"user_examination" gorm:"" validate:"required_without=UserExaminationID"`
	Question        *Question        `json:"question"         gorm:"" validate:"required_without=QuestionID"`
	CodeQuiz        *CodeQuiz        `json:"code_quiz"        gorm:"" validate:"required_without=CodeQuizID"`
}
