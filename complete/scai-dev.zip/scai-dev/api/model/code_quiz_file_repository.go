package model

import (
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
)

type CodeQuizFileRepository struct {
	db *gorm.DB
}

func NewCodeQuizFileRepository() *CodeQuizFileRepository {
	return &CodeQuizFileRepository{db: db}
}

func (r *CodeQuizFileRepository) FindByID(id CodeQuizFileID) (*CodeQuizFile, error) {
	entity := &CodeQuizFile{}
	err := r.db.First(entity, int(id)).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *CodeQuizFileRepository) Insert(entity *CodeQuizFile) error {
	err := r.db.Create(&entity).Error
	return errors.WithStack(err)
}

func (r *CodeQuizFileRepository) Update(entity CodeQuizFile) error {
	err := r.db.Model(&CodeQuizFile{}).
		Where("id = ?", entity.ID).
		Updates(map[string]interface{}{
			"CodeQuizID": entity.CodeQuizID,
			"Type":       entity.Type,
			"URL":        entity.URL,
		}).Error
	return errors.WithStack(err)
}

func (r *CodeQuizFileRepository) DeleteByID(id CodeQuizFileID) error {
	err := r.db.Delete(&CodeQuizFile{}, int(id)).Error
	return errors.WithStack(err)
}

func (r *CodeQuizFileRepository) FindByQuizIDWithFileType(quizID CodeQuizID, fileType CodeQuizFileType) (*CodeQuizFile, error) {
	entity := &CodeQuizFile{}
	err := r.db.Where(&CodeQuizFile{CodeQuizID: quizID}).
		Where(&CodeQuizFile{Type: fileType}).
		First(entity).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errors.WithStack(err)
	}
	return entity, nil
}

func (r *CodeQuizFileRepository) FilterByQuizID(quizID CodeQuizID) ([]CodeQuizFile, error) {
	var entities []CodeQuizFile
	tx := r.db

	err := tx.Order("id").
		Where(&CodeQuizFile{CodeQuizID: quizID}).
		Find(&entities).Order("id").Error
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return entities, nil
}

func (r *CodeQuizFileRepository) DeleteByQuizID(quizID CodeQuizID) error {
	err := r.db.Where("code_quiz_id = ?", quizID.ToInt()).
		Delete(&CodeQuizFile{}).Error
	return errors.WithStack(err)
}
