package model

import (
	"encoding/json"
	"github.com/jinzhu/gorm"
	"time"
)

type Timestamps struct {
	CreatedAt *time.Time `json:"-" gorm:"type:timestamp;not null;default:CURRENT_TIMESTAMP"                             validate:""`
	UpdatedAt *time.Time `json:"-" gorm:"type:timestamp;not null;default:CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" validate:""`
	DeletedAt *time.Time `json:"-" gorm:""                                                                              validate:""`
}

// Model 各テーブル共通のカラム
type Model struct {
	ID           int        `json:"id,omitempty" gorm:"primary_key"                                                                   validate:""`
	CreatedAt    *time.Time `json:"-"            gorm:"type:timestamp;not null;default:CURRENT_TIMESTAMP"                             validate:""`
	UpdatedAt    *time.Time `json:"-"            gorm:"type:timestamp;not null;default:CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" validate:""`
	DeletedAt    *time.Time `json:"-"            gorm:""                                                                              validate:""`
	IsNotDeleted *bool      `json:"-"            gorm:"default:true;unique_index:is_not_deleted"                                      validate:""`
}

// TODO: modelと統合する
type NewModel struct {
	ID           int        `json:"id,omitempty" gorm:"primary_key"                                                                   validate:""`
	CreatedAt    *time.Time `json:"-"            gorm:"type:timestamp;not null;default:CURRENT_TIMESTAMP"                             validate:""`
	UpdatedAt    *time.Time `json:"-"            gorm:"type:timestamp;not null;default:CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" validate:""`
	DeletedAt    *time.Time `json:"-"            gorm:""                                                                              validate:""`
	IsNotDeleted *bool      `json:"-"            gorm:"default:true;index:is_not_deleted"                                             validate:""`
}

// Admin admins
type Admin struct {
	Model
	Name     string `json:"name"         gorm:"not null"                             validate:"min=1,max=255"`
	Email    string `json:"email"        gorm:"not null;unique_index:is_not_deleted" validate:"min=1,max=255,email"`
	Password string `json:"password"     gorm:"not null"                             validate:"min=1,max=255"`
}

func appendPagerQuery(db *gorm.DB, page int, pageSize int) *gorm.DB {
	return db.Limit(pageSize).Offset(page * pageSize)
}

// copyModel create new struct from source struct
func copyModel(s interface{}, d interface{}) (err error) {
	bs, err := json.Marshal(s)
	if err != nil {
		return err
	}
	if err = json.Unmarshal(bs, &d); err != nil {
		return err
	}
	return nil
}
