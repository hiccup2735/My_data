package user

import (
	"app/controller"
	"app/model"
	"app/service"
	"app/session"
	"errors"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"net/http"
	"os"
	"strconv"
)

type examinationController struct {
	userExaminationRepository *model.UserExaminationRepository
	codeQuizAnswerRepository  *model.CodeQuizAnswerRepository
	codeRunnerS3Service       *service.S3Service
}

func NewExaminationController(
	userExaminationRepository *model.UserExaminationRepository,
	codeQuizAnswerRepository *model.CodeQuizAnswerRepository,
	codeRunnerS3Service *service.S3Service,
) *examinationController {
	return &examinationController{
		userExaminationRepository,
		codeQuizAnswerRepository,
		codeRunnerS3Service,
	}
}

func (*examinationController) Index(ctx *gin.Context) {
	user, err := session.GetContextUser(ctx)
	if err != nil {
		_ = ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	exams, err := user.GetExaminations()
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	filtered := make([]*model.UserExamination, 0)
	for _, e := range exams {
		if e.Visible(user) {
			filtered = append(filtered, e)
			continue
		}
	}

	ress := make([]*userExaminationSummaryResponse, len(filtered))
	for i, e := range filtered {
		r, err := toUserExaminationSummaryResponse(e)
		if err != nil {
			_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
			return
		}
		ress[i] = r
	}

	ctx.JSON(http.StatusOK, gin.H{
		"examinations": ress,
	})
}

func (*examinationController) Show(ctx *gin.Context) {
	// 認可済みのデータが取得される
	userExamination, err := session.GetContextUserExamination(ctx)
	if err != nil {
		_ = ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	response, err := userExamination.GetResponse()
	if err != nil {
		_ = ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	prev, err := userExamination.GetPreviousResult()
	if err != nil {
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			_ = ctx.AbortWithError(http.StatusInternalServerError, err)
			return
		}
	}

	var prevResponse *model.UserExaminationResponse
	if prev != nil {
		prevResponse, err = prev.GetResponse()
		if err != nil {
			_ = ctx.AbortWithError(http.StatusInternalServerError, err)
			return
		}
	}

	ctx.JSON(http.StatusOK, gin.H{
		"id":                response.ID,
		"name":              response.Name,
		"description":       response.Description,
		"limit_min":         response.LimitMin,
		"available_at":      response.AvailableAt,
		"start_limit_at":    response.StartLimitAt,
		"started_at":        response.StartedAt,
		"answer_limit_at":   response.AnswerLimitAt,
		"submitted_at":      response.SubmittedAt,
		"finished_at":       response.FinishedAt,
		"status":            response.Status,
		"questions_count":   response.QuestionsCount,
		"questions":         response.Questions,
		"score":             response.Score,
		"scores":            response.Scores,
		"code_quiz_results": response.CodeQuizResults,
		"now":               response.Now,
		"previous_data":     prevResponse,
	})
}

func (*examinationController) Start(ctx *gin.Context) {
	userExamination, err := session.GetContextUserExamination(ctx)
	if err != nil {
		_ = ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	if err := userExamination.Start(); err != nil {
		_ = ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	response, err := userExamination.GetResponse()
	if err != nil {
		_ = ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	ctx.JSON(http.StatusOK, response)
}

func (*examinationController) AnswerChoiceQuiz(ctx *gin.Context) {
	// Note: examinationIDの整合性チェックはミドルウェアで実施している
	questionID, err := strconv.Atoi(ctx.Param("questionID"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid question_id")
		return
	}

	type params struct {
		QuizID   int `json:"quiz_id" binding:"required"`
		ChoiceID int `json:"choice_id" binding:"required"`
	}
	var p params
	if err := ctx.ShouldBind(&p); err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	userExamination, err := session.GetContextUserExamination(ctx)
	if err != nil {
		controller.SetNotFoundError(ctx, "Not found examination")
		return
	}
	if !userExamination.IsAnswering() {
		controller.SetBadRequestError(ctx, "Examination status is not answering")
		return
	}

	_, err = userExamination.FindQuestionByID(questionID)
	if err != nil {
		_ = ctx.AbortWithError(http.StatusBadRequest, err)
		return
	}
	if err := userExamination.Answer(questionID, p.QuizID, p.ChoiceID); err != nil {
		_ = ctx.AbortWithError(http.StatusBadRequest, err)
		return
	}
	response, err := userExamination.GetResponse()
	if err != nil {
		_ = ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	ctx.JSON(http.StatusOK, response)
}

func (c *examinationController) AnswerCodeQuiz(ctx *gin.Context) {
	// Note: examinationIDの整合性チェックはミドルウェアで実施している
	questionID, err := strconv.Atoi(ctx.Param("questionID"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid question_id")
		return
	}

	type params struct {
		CodeQuizID int    `json:"code_quiz_id" binding:"required"`
		Lang       string `json:"lang"         binding:"required"`
		Code       string `json:"code"         binding:""`
	}
	var p params
	err = ctx.ShouldBind(&p)
	if err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}
	lang := model.CodeQuizAnswerLang(p.Lang)
	if !lang.IsValid() {
		controller.SetBadRequestError(ctx, "Invalid lang")
		return
	}

	userExamination, err := session.GetContextUserExamination(ctx)
	if err != nil {
		controller.SetNotFoundError(ctx, "Not found examination")
		return
	}
	if !userExamination.IsAnswering() {
		controller.SetBadRequestError(ctx, "Examination status is not answering")
		return
	}

	userExam, err := c.userExaminationRepository.FindByCodeQuizUniqueID(
		model.UserExaminationID(userExamination.ID),
		model.QuestionID(questionID),
		model.CodeQuizID(p.CodeQuizID),
	)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if userExam == nil {
		controller.SetBadRequestError(ctx, "Not related user examination and code quiz")
		return
	}

	answer, err := c.codeQuizAnswerRepository.FindByUniqueID(
		userExamination.ID,
		model.QuestionID(questionID),
		model.CodeQuizID(p.CodeQuizID),
	)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	if answer == nil {
		answer = &model.CodeQuizAnswer{
			UserExaminationID: userExamination.ID,
			QuestionID:        model.QuestionID(questionID),
			CodeQuizID:        model.CodeQuizID(p.CodeQuizID),
			Lang:              lang,
			Code:              p.Code,
		}
		err = c.codeQuizAnswerRepository.Insert(answer)
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}
	} else {
		answer.Lang = lang
		answer.Code = p.Code
		err = c.codeQuizAnswerRepository.Update(answer)
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}
	}

	response, err := userExamination.GetResponse()
	if err != nil {
		_ = ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	ctx.JSON(http.StatusOK, response)
}

func (c *examinationController) Finish(ctx *gin.Context) {
	userExamination, err := session.GetContextUserExamination(ctx)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	if userExamination.IsFinished() {
		controller.SetBadRequestError(ctx, "User examination status is finished")
		return
	}

	codeQuizAnswers, err := c.codeQuizAnswerRepository.FilterByUserExaminationID(
		model.UserExaminationID(userExamination.ID),
	)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	if len(codeQuizAnswers) > 0 {
		if userExamination.IsSubmitted() {
			controller.SetBadRequestError(ctx, "User examination status is submitted has code quiz examination")
			return
		}

		tempDir, err := os.MkdirTemp("/tmp", "code_quiz_answer_submit")
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}
		defer os.RemoveAll(tempDir)

		for _, answer := range codeQuizAnswers {
			codeRunnerService := service.NewCodeRunnerAnswerService(
				c.codeRunnerS3Service, tempDir, answer,
			)

			zipFilePath, err := codeRunnerService.CreateProgramFile()
			if err != nil {
				controller.SetInternalServerError(ctx, err)
				return
			}

			err = codeRunnerService.UploadProgramFile(zipFilePath)
			if err != nil {
				controller.SetInternalServerError(ctx, err)
				return
			}

			hookFilepath, err := codeRunnerService.CreateHookFile()
			if err != nil {
				controller.SetInternalServerError(ctx, err)
				return
			}

			err = codeRunnerService.UploadHookFile(hookFilepath)
			if err != nil {
				controller.SetInternalServerError(ctx, err)
				return
			}

			submissionID := codeRunnerService.GetSubmissionID().String()
			answer.SubmissionID = &submissionID
			err = c.codeQuizAnswerRepository.Update(&answer)
			if err != nil {
				controller.SetInternalServerError(ctx, err)
				return
			}
		}

		err = userExamination.Submit()
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}

		err = c.userExaminationRepository.Update(userExamination)
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}

	} else {
		err = userExamination.Finish()
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}

		// TODO: transaction貼る
		err = c.userExaminationRepository.Update(userExamination)
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}

		err = userExamination.CreateTotalScore()
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}

		err = userExamination.CreateCategoryScores()
		if err != nil {
			controller.SetInternalServerError(ctx, err)
			return
		}
	}

	response, err := userExamination.GetResponse()
	if err != nil {
		_ = ctx.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	ctx.JSON(http.StatusOK, response)
}
