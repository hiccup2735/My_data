package operator

import (
	"app/controller"
	"app/session"
	"github.com/gin-gonic/gin"
	"net/http"
)

// ShowMe ログイン中のoperatorを取得
func ShowMe(c *gin.Context) {
	operator, err := session.GetContextOperator(c)
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusInternalServerError, err.Error())
		return
	}

	c.JSON(http.StatusOK, operator)
}
