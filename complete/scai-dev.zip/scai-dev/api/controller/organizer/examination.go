package organizer

import (
	"app/controller"
	"app/model"
	"app/session"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"net/http"
	"strconv"
	"time"
)

type examinationController struct{}

func NewExaminationController() *examinationController {
	return &examinationController{}
}

func (*examinationController) Index(ctx *gin.Context) {
	// TODO: 検索を有効にする
	// searchWord := ctx.Query("q")
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "25"))

	organizer, err := session.GetContextOrganizer(ctx)
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, err)
		return
	}

	// FIXME: 絞り込みに対応する
	organization, err := model.FindOrganizationByID(organizer.OrganizationID,
		model.OrganizationPreload{
			LicensesExamination:      true,
			LicensesUserExaminations: true,
		})
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	var responses []response
	for _, license := range organization.Licenses {
		var takenCount int
		for _, exam := range license.UserExaminations {
			if exam.IsFinished() {
				takenCount++
			}
		}

		stat, err := model.GetStatLicenseTotalScore(license.ExaminationID, license.ID)
		if err != nil {
			ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
			return
		}

		responses = append(responses, response{
			ID:                license.Examination.ID,
			Name:              license.Examination.Name,
			Description:       license.Examination.Description,
			StartDateTime:     license.StartDateTime,
			EndDateTime:       license.EndDateTime,
			LicenseUsersCount: len(license.UserExaminations),
			TakenUsersCount:   takenCount,
			AverageScore:      stat.Avg,
			BestScore:         stat.Max,
			WorstScore:        stat.Min,
		})
	}

	// FIXME: 件数を取得

	ctx.JSON(http.StatusOK, gin.H{
		"page":         page,
		"page_size":    pageSize,
		"total":        len(responses),
		"examinations": responses,
	})
}

func (*examinationController) Show(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	organizer, err := session.GetContextOrganizer(ctx)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnauthorized, err.Error())
		return
	}

	exam, err := model.FindExaminationByID(id, model.ExaminationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	var hasLicense bool
	var license model.License
	var takenCount int
	organization, err := model.FindOrganizationByID(organizer.OrganizationID,
		model.OrganizationPreload{
			LicensesExamination:      true,
			LicensesUserExaminations: true,
		})
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	for _, lic := range organization.Licenses {
		if exam.ID == lic.ExaminationID {
			hasLicense = true
			license = *lic

			for _, exam := range license.UserExaminations {
				if exam.IsFinished() {
					takenCount++
				}
			}

			break
		}
	}

	if !hasLicense {
		_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
		return
	}

	type response struct {
		ID                int        `json:"id"`
		Name              string     `json:"name"`
		Description       string     `json:"description"`
		StartDateTime     *time.Time `json:"start_date_time"`
		EndDateTime       *time.Time `json:"end_date_time"`
		LicenseUsersCount int        `json:"license_users_count"`
		TakenUsersCount   int        `json:"taken_users_count"`
		AverageScore      int        `json:"average_score"`
		// FIXME: score定義
		Scores []int `json:"category_average_scores"`
	}

	ctx.JSON(http.StatusOK, response{
		ID:                exam.ID,
		Name:              exam.Name,
		Description:       exam.Description,
		StartDateTime:     license.StartDateTime,
		EndDateTime:       license.EndDateTime,
		LicenseUsersCount: len(license.UserExaminations),
		TakenUsersCount:   takenCount,
		// FIXME: 動的化
		AverageScore: 0,
		Scores:       make([]int, 0),
	})
}

func (*examinationController) IndexUser(ctx *gin.Context) {
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "25"))
	sortDir := ctx.Query("direction")

	examID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	organizer, err := session.GetContextOrganizer(ctx)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnauthorized, err.Error())
		return
	}

	exam, err := model.FindExaminationByID(examID, model.ExaminationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	organization, err := model.FindOrganizationByID(organizer.OrganizationID, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	licenses, err := model.LicenseFilterBy(model.LicenseFilterConditions{
		OrganizationID: organization.ID,
		ExaminationID:  exam.ID,
	})
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	if len(licenses) == 0 {
		_ = controller.SetErrorContext(ctx, fmt.Errorf("Has no license"), http.StatusNotFound, "Not found")
		return
	}

	type score struct {
		CategoryName string `json:"category_name"`
		Score        int    `json:"score"`
	}
	type response struct {
		ID        int        `json:"id"`
		Name      string     `json:"name"`
		Status    string     `json:"status"`
		StartedAt *time.Time `json:"started_at"`
		Score     int        `json:"score"`
		Scores    []score    `json:"scores"`
	}

	var responses []response

	licenseIDs := make([]int, len(licenses))
	for i, lic := range licenses {
		licenseIDs[i] = lic.ID
	}

	userExams, err := model.GetUserExaminationsWithScoreByLicenseIDs(licenseIDs, sortDir)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	for _, v := range userExams {
		userExam, err := model.FindUserExaminationByID(v.ID)
		if err != nil {
			_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
			return
		}

		if userExam.User == nil {
			continue
		}

		status, err := userExam.Status()
		if err != nil {
			_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
			return
		}

		totalScore := 0
		scores := make([]score, 0)
		if userExam.IsFinished() {
			total, err := model.FindUserExaminationScoreByUserExaminationID(userExam.ID)
			if err != nil {
				_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, "Invalid user examination total score")
				return
			}
			totalScore = 0
			if total != nil {
				totalScore = total.Score
			}

			catScores, err := model.GetUserExaminationCategoryScoreByUserExaminationID(userExam.ID)
			if err != nil {
				_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, "Invalid user examination category scores")
				return
			}

			scores = make([]score, len(catScores))
			for i, s := range catScores {
				scores[i] = score{
					Score:        s.Score,
					CategoryName: s.Category.Name,
				}
			}
		}

		responses = append(responses, response{
			ID:        userExam.User.ID,
			Name:      userExam.User.Name,
			Status:    status.ToString(),
			StartedAt: userExam.StartedAt,
			Score:     totalScore,
			Scores:    scores,
		})
	}

	ctx.JSON(http.StatusOK, gin.H{
		"page":      page,
		"page_size": pageSize,
		// FIXME 件数取得
		"total": len(responses),
		"users": responses,
	})
}

// ShowStat 試験の他組織の統計データを取得する
func (*examinationController) ShowStat(ctx *gin.Context) {
	examID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	organizer, err := session.GetContextOrganizer(ctx)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnauthorized, err.Error())
		return
	}

	exam, err := model.FindExaminationByID(examID, model.ExaminationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	organization, err := model.FindOrganizationByID(organizer.OrganizationID, model.OrganizationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	licenses, err := model.LicenseFilterBy(model.LicenseFilterConditions{
		OrganizationID: organization.ID,
		ExaminationID:  exam.ID,
	})
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	if len(licenses) == 0 {
		_ = controller.SetErrorContext(ctx, fmt.Errorf("Has no license"), http.StatusNotFound, "Not found")
		return
	}

	statData, err := model.GetExaminationStatDataByExaminationID(examID, organization.ID)
	if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	catStatData, err := model.GetExaminationCategoryStatDataByExaminationID(examID, organization.ID)
	if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	type categoryResponse struct {
		Name         string  `json:"name"`
		AverageScore float64 `json:"average_score"`
	}

	ress := make([]categoryResponse, len(catStatData))
	for i, d := range catStatData {
		ress[i] = categoryResponse{
			Name:         d.CategoryName,
			AverageScore: d.AverageScore,
		}
	}

	ctx.JSON(http.StatusOK, gin.H{
		"average_score": statData.AverageScore,
		"categories":    ress,
	})
}

func (*examinationController) IndexHistory(ctx *gin.Context) {
	examID, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", ctx.Param("id")))
		return
	}

	organizer, err := session.GetContextOrganizer(ctx)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnauthorized, err.Error())
		return
	}

	exam, err := model.FindExaminationByID(examID, model.ExaminationPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(ctx, err, http.StatusNotFound, "Not found")
			return
		}

		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	licenses, err := model.LicenseFilterBy(model.LicenseFilterConditions{
		OrganizationID: organizer.OrganizationID,
		ExaminationID:  examID,
	})
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}
	if len(licenses) == 0 {
		_ = controller.SetErrorContext(ctx, fmt.Errorf("Has no license"), http.StatusNotFound, "Not found")
		return
	}

	exams, err := model.GetExaminationsByCode(exam.Code, exam.ID)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	var ress []response
	allLicenses, err := model.LicenseFilterBy(model.LicenseFilterConditions{
		OrganizationID: organizer.OrganizationID,
	})
	for _, em := range exams {
		for _, lic := range allLicenses {
			if em.ID != lic.ExaminationID {
				continue
			}

			cnt := 0
			for _, uem := range lic.UserExaminations {
				if uem.IsFinished() {
					cnt++
				}
			}

			stat, err := model.GetStatLicenseTotalScore(lic.ExaminationID, lic.ID)
			if err != nil {
				ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
				return
			}

			ress = append(ress, response{
				ID:                em.ID,
				Name:              em.Name,
				Description:       em.Description,
				StartDateTime:     lic.StartDateTime,
				EndDateTime:       lic.EndDateTime,
				LicenseUsersCount: len(lic.UserExaminations),
				TakenUsersCount:   cnt,
				AverageScore:      stat.Avg,
				BestScore:         stat.Max,
				WorstScore:        stat.Min,
			})
		}
	}

	ctx.JSON(http.StatusOK, gin.H{
		"examinations": ress,
	})
}

type ExamLicense struct {
	ID            int
	Name          string
	Description   string
	StartDateTime *time.Time
	EndDateTime   *time.Time
}

type response struct {
	ID                int        `json:"id"`
	Name              string     `json:"name"`
	Description       string     `json:"description"`
	StartDateTime     *time.Time `json:"start_date_time"`
	EndDateTime       *time.Time `json:"end_date_time"`
	LicenseUsersCount int        `json:"license_users_count"`
	TakenUsersCount   int        `json:"taken_users_count"`
	AverageScore      int        `json:"average_score"`
	BestScore         int        `json:"best_score"`
	WorstScore        int        `json:"worst_score"`
}
