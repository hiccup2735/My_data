package organizer

import (
	"app/controller"
	"app/model"
	"app/session"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"net/http"
	"strconv"
	"time"
)

// IndexUsers index users
func IndexUsers(c *gin.Context) {
	organizer, err := session.GetContextOrganizer(c)
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusUnauthorized, err.Error())
		return
	}

	searchWord := c.Query("q")
	page, _ := strconv.Atoi(c.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("page_size", "25"))

	condition := model.UserFilterCondition{
		OrganizationID: organizer.Organization.ID,
	}
	users, err := model.FilterByUser(searchWord, page, pageSize, condition, model.UserPreload{
		Organization: true,
		Examinations: true,
	})
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusInternalServerError, err.Error())
		return
	}

	// TODO: 絞り込みに対応する
	total, err := model.CountUser(searchWord, condition)
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusInternalServerError, err.Error())
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"page":      page,
		"page_size": pageSize,
		"total":     total,
		"users":     toUserResponses(users),
	})
}

// ShowUser show user
func ShowUser(c *gin.Context) {
	organizer, err := session.GetContextOrganizer(c)
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusUnauthorized, err.Error())
		return
	}

	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", c.Param("id")))
		return
	}

	user, err := organizer.FindUserByID(id)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(c, err, http.StatusNotFound, "Not found user")
			return
		}

		_ = controller.SetErrorContext(c, err, http.StatusInternalServerError, err.Error())
		return
	}

	// TODO: scoresを空配列にする
	response := toUserDetailResponse(user)
	c.JSON(http.StatusOK, response)
}

// AppendUserLicense action: GET /organizer/users/:id/licenses/:license_id
func AppendUserLicense(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter id : %v", c.Param("id")))
		return
	}

	licenseID, err := strconv.Atoi(c.Param("license_id"))
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusBadRequest,
			fmt.Sprintf("Invalid parameter organizer_id : %v", c.Param("license_id")))
		return
	}

	organizer, err := session.GetContextOrganizer(c)
	if err != nil {
		_ = controller.SetErrorContext(c, err, http.StatusUnauthorized, err.Error())
		return
	}

	user, err := model.UserFindByID(id, model.UserPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(c, err, http.StatusNotFound, "Not found user")
			return
		}

		_ = controller.SetErrorContext(c, err, http.StatusInternalServerError, err.Error())
		return
	}

	if organizer.OrganizationID != user.OrganizationID {
		_ = controller.SetErrorContext(c, errors.New("not manage organization user"), http.StatusNotFound, "Not found user")
		return
	}

	license, err := model.LicenseFindByID(licenseID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			_ = controller.SetErrorContext(c, err, http.StatusNotFound, "Not found license")
			return
		}

		_ = controller.SetErrorContext(c, err, http.StatusInternalServerError, err.Error())
		return
	}

	if organizer.OrganizationID != license.OrganizationID {
		_ = controller.SetErrorContext(c, errors.New("not manage organization license"), http.StatusNotFound, "Not found license")
		return
	}

	// TODO available_at, start_limit_atをパラメーターで受け取る?
	exam := &model.UserExamination{
		UserID:        user.ID,
		ExaminationID: license.ExaminationID,
		LicenseID:     license.ID,
		AvailableAt:   license.StartDateTime,
		StartLimitAt:  license.EndDateTime,
	}

	var exams []*model.UserExamination
	exams = append(exams, exam)
	if err := model.UserExaminationCreateAll(exams); err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	type response struct {
		ID              int        `json:"id"`
		StartDateTime   *time.Time `json:"start_date_time"`
		EndDateTime     *time.Time `json:"end_date_time"`
		ExaminationID   int        `json:"examination_id"`
		ExaminationName string     `json:"examination_name"`
	}

	c.JSON(http.StatusOK, response{
		ID:              license.ID,
		StartDateTime:   license.StartDateTime,
		EndDateTime:     license.EndDateTime,
		ExaminationID:   license.ExaminationID,
		ExaminationName: license.Examination.Name,
	})
}
