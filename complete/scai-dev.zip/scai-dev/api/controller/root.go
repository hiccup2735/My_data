package controller

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

// GetRoot /
func GetRoot(c *gin.Context) {
	c.JSON(http.StatusOK, "OK")
}
