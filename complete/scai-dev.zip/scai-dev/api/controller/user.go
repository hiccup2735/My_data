package controller

import (
	"app/model"
	"app/session"
	"github.com/gin-gonic/gin"
	"net/http"
)

// PostUser POST /user サインアップ
func PostUser(c *gin.Context) {
	type params struct {
		Name                 string `json:"name"                  binding:"required,min=1,max=255"`
		Email                string `json:"email"                 binding:"required,min=1,max=255,email"`
		Password             string `json:"password"              binding:"required,min=8,max=255,printascii,excludes= "`
		PasswordConfirmation string `json:"password_confirmation" binding:"required,min=1,max=255,eqfield=Password"`
	}
	var p params
	if err := c.ShouldBind(&p); err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	user, err := model.UserSignUp(p.Name, p.Email, p.Password)
	if err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	if err := session.SetUserID(c, user.ID); err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	response := user.ToResponse() // 今後関連テーブルを増やした場合はuser.GetResponse()を使うこと
	c.JSON(http.StatusOK, response)
}

// GetUser GET /user プロフィール
func GetUser(c *gin.Context) {
	user, err := session.GetContextUser(c)
	if err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	response := user.ToResponse() // 今後関連テーブルを増やした場合はuser.GetResponse()を使うこと
	c.JSON(http.StatusOK, response)
}

// PutUser PUT /user プロフィール更新
func PutUser(c *gin.Context) {
	type params struct {
		Name  string `json:"name"  binding:"required,min=1,max=255"`
		Email string `json:"email" binding:"required,min=1,max=255,email"`
	}
	var p params
	if err := c.ShouldBind(&p); err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	user, err := session.GetContextUser(c)
	if err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	if err := user.Update(p.Name, p.Email); err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	response := user.ToResponse() // 今後関連テーブルを増やした場合はuser.GetResponse()を使うこと
	c.JSON(http.StatusOK, response)
}

// PostUserReset POST /user/reset パスワード再設定コード送信
func PostUserReset(c *gin.Context) {
	type params struct {
		Email string `json:"email" binding:"required,min=1,max=255,email"`
	}
	var p params
	if err := c.ShouldBind(&p); err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	if err := model.UserSendResetToken(p.Email); err != nil {
		c.Status(http.StatusOK) // エラーがあっても無視（登録済みのEmailを推測させない）
		return
	}
	c.Status(http.StatusOK)
}

// PutUserReset PUT /user/reset パスワード設定
func PutUserReset(c *gin.Context) {
	type params struct {
		ResetToken           string `json:"reset_token"           binding:"required,min=1,max=255"`
		Password             string `json:"password"              binding:"required,min=8,max=255,printascii,excludes= "`
		PasswordConfirmation string `json:"password_confirmation" binding:"required,min=1,max=255,eqfield=Password"`
	}
	var p params
	if err := c.ShouldBind(&p); err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	user, err := model.UserReset(p.ResetToken, p.Password)
	if err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	if err := session.SetUserID(c, user.ID); err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	response := user.ToResponse() // 今後関連テーブルを増やした場合はuser.GetResponse()を使うこと
	c.JSON(http.StatusOK, response)
}

// PostUserVerify POST /user/verify メールアドレス確認コード送信
func PostUserVerify(c *gin.Context) {
	user, err := session.GetContextUser(c)
	if err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	if err := user.SendVerifyToken(); err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	c.Status(http.StatusOK)
}

// PutUserVerify PUT /user/verify メールアドレス確認
func PutUserVerify(c *gin.Context) {
	type params struct {
		VerifyToken string `json:"verify_token" binding:"required,min=1,max=255"`
	}
	var p params
	if err := c.ShouldBind(&p); err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	user, err := session.GetContextUser(c)
	if err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	if err := user.Verify(p.VerifyToken); err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	response := user.ToResponse() // 今後関連テーブルを増やした場合はuser.GetResponse()を使うこと
	c.JSON(http.StatusOK, response)
}
