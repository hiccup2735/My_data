package admin

import (
	"app/model"
)

type ExaminationResponse struct {
	ID             int     `json:"id"`
	Name           string  `json:"name"`
	Description    string  `json:"description"`
	LimitMin       int     `json:"limit_min"`
	Scope          string  `json:"scope"`
	Code           string  `json:"code"`
	Level          float64 `json:"level"`
	AverageScore   int     `json:"average_score"`
	BestScore      int     `json:"best_score"`
	WorstScore     int     `json:"worst_score"`
	AttendanceRate int     `json:"attendance_rate"`
	Group          int     `json:"group"`
}

type ExaminationIndexResponse struct {
	ExaminationResponse
	QuestionsCount int `json:"questions_count"`
}

type ExaminationDetailResponse struct {
	ExaminationResponse
	Questions       []*examinationQuestionResponse `json:"questions"`
	OrganizationIDs []int                          `json:"organization_ids"`
	Categories      []categoryScore                `json:"categories"`
}

type examinationQuestionResponse struct {
	ID         int    `json:"id"`
	Name       string `json:"name"`
	CategoryID int    `json:"category_id"`
	Sequence   int    `json:"sequence"`
}

type categoryScore struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Score int    `json:"score"`
}

func toExaminationResponse(exam *model.Examination) ExaminationResponse {
	// TODO: responseの整形のみを行い、データの取得はここの上で行う
	stat, _ := exam.GetStatTotalScore()
	result, _ := exam.GetResultCount()

	return ExaminationResponse{
		ID:             exam.ID,
		Name:           exam.Name,
		Description:    exam.Description,
		LimitMin:       exam.LimitMin,
		Scope:          exam.Scope,
		Code:           exam.Code,
		Level:          exam.GetLevel(),
		AverageScore:   stat.Avg,
		BestScore:      stat.Max,
		WorstScore:     stat.Min,
		AttendanceRate: result.GetAttendanceRate(),
		Group:          exam.Group,
	}
}

type ExaminationPresenter struct{}

func (*ExaminationPresenter) ToIndexResponse(exams []*model.Examination) []ExaminationIndexResponse {
	ress := make([]ExaminationIndexResponse, len(exams))
	for i, e := range exams {

		ress[i] = ExaminationIndexResponse{
			ExaminationResponse: toExaminationResponse(e),
			QuestionsCount:      len(e.Questions),
		}
	}

	return ress
}

func (*ExaminationPresenter) ToDetailResponse(exam *model.Examination) ExaminationDetailResponse {
	questions := make([]*examinationQuestionResponse, len(exam.ExaminationQuestions))
	for i, q := range exam.ExaminationQuestions {
		questions[i] = &examinationQuestionResponse{
			ID:         q.Question.ID,
			Name:       q.Question.Name,
			CategoryID: q.CategoryID,
			Sequence:   q.Sequence,
		}
	}

	orgIDs := make([]int, len(exam.ExaminationOrganizations))
	for i, o := range exam.ExaminationOrganizations {
		orgIDs[i] = o.OrganizationID
	}

	return ExaminationDetailResponse{
		ExaminationResponse: toExaminationResponse(exam),
		Questions:           questions,
		OrganizationIDs:     orgIDs,
		Categories:          toCategoryScores(exam.GetCategoryPoints()),
	}
}

func toCategoryScores(ps []model.ExaminationCategoryPoint) []categoryScore {
	ss := make([]categoryScore, 0)
	for _, p := range ps {
		ss = append(ss, categoryScore{
			ID:    p.ID,
			Name:  p.Name,
			Score: p.Point,
		})
	}

	return ss
}
