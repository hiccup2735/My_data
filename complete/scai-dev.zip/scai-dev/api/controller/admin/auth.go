package admin

import (
	"app/model"
	"app/session"
	"github.com/gin-gonic/gin"
	"net/http"
)

// SignIn POST /admin/auth
func SignIn(c *gin.Context) {
	type params struct {
		Email    string `json:"email"    binding:"required,email"`
		Password string `json:"password" binding:"required"`
	}
	var p params
	if err := c.ShouldBind(&p); err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	admin, err := model.AdminSignIn(p.Email, p.Password)
	if err != nil {
		_ = c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	if err := session.SetAdminID(c, admin.ID); err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, admin.ToResponse())
}

// SignOut DELETE /admin/auth
func SignOut(c *gin.Context) {
	if err := session.Clear(c); err != nil {
		_ = c.AbortWithError(http.StatusInternalServerError, err)
		return
	}
	c.Status(http.StatusOK)
}
