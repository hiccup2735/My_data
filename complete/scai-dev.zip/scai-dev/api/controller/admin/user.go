package admin

import (
	"app/controller"
	"app/model"
	"errors"
	"fmt"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

type userController struct{}

func NewUserController() *userController {
	return &userController{}
}

func (*userController) Index(ctx *gin.Context) {
	searchWord := ctx.Query("q")
	page, _ := strconv.Atoi(ctx.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(ctx.DefaultQuery("page_size", "25"))

	// TODO: 企業名のフィルタリング対応
	condition := model.UserFilterCondition{}
	users, err := model.FilterByUser(searchWord, page, pageSize, condition, model.UserPreload{
		Organization: true,
		Examinations: true,
	})
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	total, err := model.CountUser(searchWord, condition)
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	presenter := UserPresenter{}
	ress := presenter.ToIndexResponse(users)

	ctx.JSON(http.StatusOK, gin.H{
		"page":      page,
		"page_size": pageSize,
		"total":     total,
		"users":     ress,
	})
}

func (*userController) Create(ctx *gin.Context) {
	type params struct {
		Name     string `json:"name"     binding:"required,min=1,max=255"`
		Email    string `json:"email"    binding:"required,min=1,max=255,email"`
		Password string `json:"password" binding:"required,min=8,max=255,printascii,excludes= "`
	}
	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	// TODO: passwordバリデート
	// UserCreateAllでバリデートをしているが、フロントにバリデートエラーと返すようにする

	user := &model.User{
		Name:     p.Name,
		Email:    p.Email,
		Password: p.Password,
	}
	var users []*model.User
	users = append(users, user)
	if err := model.UserCreateAll(users); err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	response := toUserDetailResponse(user)
	ctx.JSON(http.StatusOK, response)
}

func (*userController) Show(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	user, err := model.UserFindByID(id, model.UserPreload{
		Organization:     true,
		Examinations:     true,
		UserExaminations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	response := toUserDetailResponse(user)
	ctx.JSON(http.StatusOK, response)
}

func (*userController) Update(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	user, err := model.UserFindByID(id, model.UserPreload{
		Organization: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	type params struct {
		Name           string `json:"name"            binding:"required,min=1,max=255"`
		Email          string `json:"email"           binding:"required,min=1,max=255,email"`
		Password       string `json:"password"        binding:"min=0,max=255,printascii,excludes= "`
		OrganizationID int    `json:"organization_id" binding:"min=-1,max=4294967295"`
		IsEmail        bool   `json:"isEmail"  binding:""`
	}

	var p params
	if err := ctx.ShouldBindJSON(&p); err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusUnprocessableEntity, err.Error())
		return
	}

	data := &model.User{}
	data.Name = p.Name
	data.Email = p.Email
	// DB更新時のvalidationエラーになり、500となるので、事前に最低限のチェックを行う
	if p.Password != "" {
		if 1 <= len(p.Password) && len(p.Password) <= 7 {
			_ = controller.SetErrorContext(ctx, fmt.Errorf("Invalid password"), http.StatusBadRequest, "Bad request")
			return
		}

		data.Password = p.Password
	}
	if p.OrganizationID != 0 {
		data.OrganizationID = p.OrganizationID
	}

	if err := user.AdminUpdate(data); err != nil {
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	// password更新時のみ、ユーザーにメールを送信する
	if p.Password != "" && p.IsEmail != false {
		plainPassword := p.Password
		if err := user.SendUpdatedMail(plainPassword); err != nil {
			ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
			return
		}
	}

	updatedUser, err := model.UserFindByID(id, model.UserPreload{
		Organization: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	response := toUserDetailResponse(updatedUser)
	ctx.JSON(http.StatusOK, response)
}

func (*userController) Delete(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	user, err := model.UserFindByID(id, model.UserPreload{})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	if err := user.Delete(); err != nil {
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	ctx.JSON(http.StatusOK, gin.H{})
}

func (*userController) IndexLicense(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	// TODO: preloadが適切か確認する
	user, err := model.UserFindByID(id, model.UserPreload{
		Organization:     true,
		Examinations:     true,
		UserExaminations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"licenses": toUserLicenseResponses(user.UserExaminations),
	})
}

func (*userController) RelateLicense(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	licenseID, err := strconv.Atoi(ctx.Param("license_id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	// TODO: preloadが適切か確認する
	user, err := model.UserFindByID(id, model.UserPreload{
		Organization:     true,
		Examinations:     true,
		UserExaminations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	license, err := model.LicenseFindByID(licenseID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	if user.OrganizationID != license.OrganizationID {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	// TODO available_at, start_limit_atをパラメーターで受け取る?
	exam := &model.UserExamination{
		UserID:        user.ID,
		ExaminationID: license.ExaminationID,
		LicenseID:     license.ID,
		AvailableAt:   license.StartDateTime,
		StartLimitAt:  license.EndDateTime,
	}

	var exams []*model.UserExamination
	exams = append(exams, exam)
	if err := model.UserExaminationCreateAll(exams); err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		// FIXME 追加した物を結果に含める
		"licenses": toUserLicenseResponses(user.UserExaminations),
	})
}

func (*userController) RemoveLicense(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	licenseID, err := strconv.Atoi(ctx.Param("license_id"))
	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, err)
		return
	}

	// TODO: preloadが適切か確認する
	user, err := model.UserFindByID(id, model.UserPreload{
		Organization:     true,
		Examinations:     true,
		UserExaminations: true,
	})
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	_, err = model.LicenseFindByID(licenseID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctx.AbortWithStatusJSON(http.StatusNotFound, err)
			return
		}

		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	// TODO user経由で削除する
	if err := user.DeleteUserExaminationByLicenseID(licenseID); err != nil {
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, err)
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		// FIXME 削除した物を結果から除く
		"licenses": toUserLicenseResponses(user.UserExaminations),
	})
}
