package admin

import (
	"app/controller"
	"app/model"
	"github.com/gin-gonic/gin"
	"net/http"
)

type questionTagController struct{}

func NewQuestionTagController() *questionTagController {
	return &questionTagController{}
}

func (*questionTagController) Index(ctx *gin.Context) {
	repo := model.QuestionTagRepository{}

	tags, err := repo.GetDistinctNames()
	if err != nil {
		_ = controller.SetErrorContext(ctx, err, http.StatusInternalServerError, err.Error())
		return
	}

	type response struct {
		Name string `json:"name"`
	}

	ress := make([]response, len(tags))
	for i, t := range tags {
		ress[i] = response{
			Name: t.Name,
		}
	}

	ctx.JSON(http.StatusOK, ress)
}
