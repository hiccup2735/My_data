package admin

import (
	"app/controller"
	"app/model"
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
)

type questionCategoryController struct {
	questionCategoryRepository *model.QuestionCategoryRepository
}

func NewQuestionCategoryController(
	questionCategoryRepository *model.QuestionCategoryRepository,
) *questionCategoryController {
	return &questionCategoryController{
		questionCategoryRepository: questionCategoryRepository,
	}
}

func (c *questionCategoryController) Index(ctx *gin.Context) {
	group, _ := strconv.Atoi(ctx.DefaultQuery("group", "0"))
	categories, err := c.questionCategoryRepository.FindByGroup(group)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, categories)
}

func (c *questionCategoryController) Create(ctx *gin.Context) {
	category := &model.QuestionCategory{}
	err := ctx.ShouldBindJSON(&category)
	if err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	err = c.questionCategoryRepository.Insert(*category)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, category)
}

func (c *questionCategoryController) Update(ctx *gin.Context) {
	id, err := strconv.Atoi(ctx.Param("id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid id")
		return
	}
	categoryID := model.QuestionCategoryID(id)

	var data *model.QuestionCategory
	if err := ctx.ShouldBindJSON(&data); err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	category, err := c.questionCategoryRepository.FindByID(categoryID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if category == nil {
		controller.SetNotFoundError(ctx, "Not found question category")
		return
	}

	category.Name = data.Name
	category.Group = data.Group
	err = c.questionCategoryRepository.Update(*category)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, category)
}
