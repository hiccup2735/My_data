package admin

import (
	"app/controller"
	"app/model"
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
)

type choiceController struct {
	quizRepository   *model.QuizRepository
	choiceRepository *model.ChoiceRepository
}

func NewChoiceController(
	quizRepository *model.QuizRepository,
	choiceRepository *model.ChoiceRepository,
) *choiceController {
	return &choiceController{
		quizRepository,
		choiceRepository,
	}
}

func (c *choiceController) Index(ctx *gin.Context) {
	rQuizID, err := strconv.Atoi(ctx.Param("quiz_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid quiz_id")
	}
	quizID := model.QuizID(rQuizID)

	quiz, err := c.quizRepository.FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}

	choices, err := c.choiceRepository.FilterByQuizID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"choices": choices,
	})
}

func (c *choiceController) Create(ctx *gin.Context) {
	rQuizID, err := strconv.Atoi(ctx.Param("quiz_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid quiz_id")
		return
	}
	quizID := model.QuizID(rQuizID)

	quiz, err := c.quizRepository.FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}

	var choice *model.Choice
	err = ctx.ShouldBindJSON(&choice)
	if err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}

	choice.QuizID = int(quizID)
	err = c.choiceRepository.Insert(choice)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, choice)
}

func (c *choiceController) Update(ctx *gin.Context) {
	rQuizID, err := strconv.Atoi(ctx.Param("quiz_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid quiz_id")
		return
	}
	quizID := model.QuizID(rQuizID)

	rChoiceID, err := strconv.Atoi(ctx.Param("choice_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid choice_id")
		return
	}
	choiceID := model.ChoiceID(rChoiceID)

	quiz, err := c.quizRepository.FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}

	choice, err := c.choiceRepository.FindByID(choiceID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if choice == nil {
		controller.SetNotFoundError(ctx, "Not found choice")
		return
	}
	if choice.QuizID != quiz.ID {
		controller.SetBadRequestError(ctx, "Not related quiz and choice")
		return
	}

	err = ctx.ShouldBindJSON(&choice)
	if err != nil {
		controller.SetBadRequestError(ctx, err.Error())
		return
	}
	err = c.choiceRepository.Update(*choice)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, choice)
}

func (c *choiceController) Delete(ctx *gin.Context) {
	rQuizID, err := strconv.Atoi(ctx.Param("quiz_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid quiz_id")
		return
	}
	quizID := model.QuizID(rQuizID)

	rChoiceID, err := strconv.Atoi(ctx.Param("choice_id"))
	if err != nil {
		controller.SetBadRequestError(ctx, "Invalid choice_id")
		return
	}
	choiceID := model.ChoiceID(rChoiceID)

	quiz, err := c.quizRepository.FindByID(quizID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if quiz == nil {
		controller.SetNotFoundError(ctx, "Not found quiz")
		return
	}

	choice, err := c.choiceRepository.FindByID(choiceID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}
	if choice == nil {
		controller.SetNotFoundError(ctx, "Not found choice")
		return
	}
	if choice.QuizID != quiz.ID {
		controller.SetBadRequestError(ctx, "Not related quiz and choice")
		return
	}

	err = c.choiceRepository.DeleteByID(choiceID)
	if err != nil {
		controller.SetInternalServerError(ctx, err)
		return
	}

	ctx.JSON(http.StatusOK, gin.H{})
}
