# scai

### 環境構築

1. 端末の`/etc/hosts`に`127.0.0.1 local.skill-check-ai.com`を追記
1. `docker-compose up`

## 開発用リンク集

- frontend（現状ではfrontend/public配下のものが表示される）
    - https://local.skill-check-ai.com/
- api（仕様は下記のswaggerで確認）
    - https://local.skill-check-ai.com/api/
- swagger（openapi.yamlの内容を貼り付けて確認）
    - https://local.skill-check-ai.com/swagger/
- mailhog（サーバーから送信されたメールが溜まる）
    - http://local.skill-check-ai.com:8025/

## とりあえず

- 起動時に最低限のユーザーや試験などが登録される（再起動のたびに初期化される）
- swaggerでサインインするとcookieセッションがつくられる（最終アクセスから3時間有効）
- swaggerやcurlなどでいろんな操作をしてみる
- SameSite=Laxなので同一ドメインから叩く必要あり（場合によってはnginx.confの修正が必要）

## MySQL接続

```
docker-compose run --rm db mysql --default-character-set=utf8mb4 -u root -h db -P 3306 -ppassword scai
```

## ローカル用SSL証明書更新（期限が切れない限り実行しない）

```
docker-compose run --rm nginx certbot certonly --manual --domain local.skill-check-ai.com --domain *.local.skill-check-ai.com --email tomoaki.nagata@gmail.com --agree-tos --manual-public-ip-logging-ok --no-eff-email --preferred-challenges dns
```
