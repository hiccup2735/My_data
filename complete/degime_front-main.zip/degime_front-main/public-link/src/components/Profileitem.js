import React from 'react'

export default function Profileitem({index, type, }) {
  return (
    <div>Profileitem</div>
  )
}
