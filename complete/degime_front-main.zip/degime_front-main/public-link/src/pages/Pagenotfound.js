import React from 'react'

export default function Pagenotfound() {
  return (
    <div className='text-2xl text-center pt-10'><span className='text-red-800'>404</span> Page not found</div>
  )
}
