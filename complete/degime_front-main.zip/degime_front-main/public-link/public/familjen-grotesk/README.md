# Familjen Grotesk

Familjen Grotesk is a typeface family suitable for both text and headlines.

The Latin component was designed by Anders Wikström, Jonas Bäckman, Matilda Gysing, Kristian Möller (Familjen STHLM AB (https://familjen.se)). 

Familjen Grotesk project is led by Kristian Möller, a type designer based in Stockholm. 
To contribute, see [github.com/Familjen-Sthlm/Familjen-Grotesk](https://github.com/Familjen-Sthlm/Familjen-Grotesk)
