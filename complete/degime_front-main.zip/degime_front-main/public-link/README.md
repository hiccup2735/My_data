# Degime
This is Web site for B2B, B2C. 
