// optional
$('#blogCarousel').carousel({
    interval: 100000
});