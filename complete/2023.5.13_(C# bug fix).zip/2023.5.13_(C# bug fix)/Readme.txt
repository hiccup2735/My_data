Only rebuild NCPDP library
