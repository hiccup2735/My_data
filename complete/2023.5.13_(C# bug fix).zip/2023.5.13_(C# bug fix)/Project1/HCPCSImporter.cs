using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Linq;
using CDMI.Util;
using CDMI.Util.Database;
using CDMI.Util.Import;
using NCPDP.Schema;
using NCPDP.Processor;
using NCPDP.WebSite;

namespace NCPDP.Persist
{
    public class HCPCSImporter : DataImporter
    {
        private class Record
        {
            public string NDC { get; set; }
            public string HCPCS { get; set; }
            public string ShortDescription { get; set; }
            public decimal BillUnits { get; set; }
            public decimal BillUnitsPackage { get; set; }
            public string HCPCSdosage { get; set; }


            internal bool Validate()
            {
                if (string.IsNullOrEmpty(this.HCPCS) || 
                    string.IsNullOrEmpty(this.NDC) ||
                    string.IsNullOrEmpty(this.ShortDescription) ||
                    string.IsNullOrEmpty(this.HCPCSdosage) ||
                    this.BillUnits <= 0.0M ||
                    this.BillUnitsPackage <= 0.0M)
                {
                    return false;
                }

                this.NDC = this.NDC.Replace("-", string.Empty);
                return true;
            }

            public ProductHCPCS Link => new ProductHCPCS()
            {
                NDC = this.NDC,
                HCPCS = this.HCPCS,
                BillUnits = this.BillUnits,
                BillUnitsPackage = this.BillUnitsPackage,
                HCPCSdosage = this.HCPCSdosage
            };
        }

        private class ProductData
        {
            public Product Header { get; private set; }
            public List<ProductHCPCS> Saved { get; private set; }
            public List<Record> Imported { get; private set; }

            public ProductData(Product ndc)
            {
                this.Header = ndc;
                this.Saved = new List<ProductHCPCS>();
                this.Imported = new List<Record>();
            }
        }

        public HCPCSImporter(Operation operation, DataEntryConfiguration configuration)
            : base(operation, configuration)
        {
        }

        public HCPCSImporter(string path, DataEntryConfiguration configuration)
            : base(path, configuration)
        {
        }

        protected override void DoImport(IUserSession session)
        {
            var hcpcsTable = session.GetTable<HCPCS>();
            var hcpcsLinkTable = session.GetTable<ProductHCPCS>();

            // load list of existing NDCs, HCPCSs and links
            this.logger.Write(StatusCode.Info, "Loading product information");

            var ndcItems = session.GetTable<Product>().ToDictionary(i => i.NDC, i => new ProductData(i));
            var hcpcsItems = hcpcsTable.ToDictionary(i => i.Code, i => i);

            foreach (var item in hcpcsLinkTable)
            {
                ndcItems[item.NDC].Saved.Add(item);
            }

            this.logger.Write(StatusCode.Info, "Loading crosswalk records");

            var dataTable = this.ReadTable();
            var columns = new List<string>();
            int rowIndex = 0;

            this.logger.Write(StatusCode.Info, "Processing crosswalk records");

            foreach (DataRow row in dataTable.Rows)
            {
                rowIndex++;

                int dataCount = GetDataCellCount(row);
                if (dataCount < 5)
                {
                    continue;
                }
                else if (columns.Count == 0)
                {
                    // column titles
                    columns.Add("HCPCS");

                    for (int c = 1; c < dataTable.Columns.Count; c++)
                    {
                        var name = row[c];
                        columns.Add(name as string);
                    }

                    continue;
                }

                var item = this.configuration.Build<Record>(row, columns);
                if (!item.Validate())
                {
                    throw new UserException("Invalid data on row : " + rowIndex);
                }

                // save imported record for later update
                if (!ndcItems.TryGetValue(item.NDC, out var product))
                {
                    product = new ProductData(new Product()
                    {
                        NDC = item.NDC
                    });

                    ndcItems.Add(product.Header.NDC, product);
                }

                product.Imported.Add(item);

                // save HCPCS header
                if (!hcpcsItems.TryGetValue(item.HCPCS, out var header))
                {
                    header = new HCPCS()
                    {
                        Code = item.HCPCS,
                        ShortDescription = item.ShortDescription
                    };

                    hcpcsItems.Add(header.Code, header);
                    hcpcsTable.InsertOnSubmit(header);

                    string message = string.Format("Added new HCPCS : {0} - {1}", header.Code, header.ShortDescription);
                    this.logger.Write(StatusCode.Info, message);
                }
                else
                {
                    // could be changed
                    header.ShortDescription = item.ShortDescription;
                }
            }

            // save new HCPCS headers
            session.SubmitChanges();

            // save imported records
            foreach (var row in ndcItems)
            {
                var item = row.Value;

                if (item.Imported.Count == 0)
                {
                    // no data to save
                    continue;
                }
                else if (string.IsNullOrEmpty(item.Header.NDC_Format))
                {
                    this.logger.Write(StatusCode.Info, "NDC not found : " + item.Header.NDC);
                    continue;
                }

                var removeList = new List<ProductHCPCS>(item.Saved);

                foreach(var import in item.Imported)
                {
                    var existing = (from i in item.Saved
                                    where i.HCPCS.Equals(import.HCPCS)
                                    select i).SingleOrDefault();

                    if (existing == null)
                    {
                        // Insert new
                        string message = string.Format("Added new code : {0} - {1}", import.NDC, import.HCPCS);
                        this.logger.Write(StatusCode.Info, message);

                        hcpcsLinkTable.InsertOnSubmit(import.Link);
                    }
                    else
                    {
                        // Update existing
                        existing.BillUnits = import.BillUnits;
                        existing.BillUnitsPackage = import.BillUnitsPackage;
                        existing.HCPCSdosage = import.HCPCSdosage;

                        removeList.Remove(existing);
                    }
                }

                // MRS-744: do not remove missing HCPCS-NDC link
            }

            // log will submit all database changes
            this.logger.Write(StatusCode.End, "Import completed");
        }


        private static int GetDataCellCount(DataRow row)
        {
            int dataCount = 0;
            int columnCount = row.Table.Columns.Count;

            for (int c = 0; c < columnCount; c++)
            {
                var value = row[c];
                if (!DatabaseFileConnection.IsEmptyCell(value))
                {
                    dataCount++;
                }
            }

            return dataCount;
        }
    }
}
