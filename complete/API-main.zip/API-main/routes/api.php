<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/

//Route::get('/testmail', 'RadioController@sendMail');
Route::get('/radio', 'RadioController@getRadio');

Route::post('/login', 'AuthController@login');
Route::post('/user-check', 'AuthController@user_check'); 
Route::post('/login-with-social', 'AuthController@loginWithSocialAccount');
Route::post('/register', 'UserController@register');
Route::get('/user/verify/{code}', 'UserController@verifyUser')->name('user_verify');
Route::get('/user/perm', 'UserController@userPerm');

Route::post('/forgot-password', 'ApiAuth\PasswordResetController@create');
Route::get('/reset-password/{token}', 'ApiAuth\PasswordResetController@find');
Route::post('/reset-password', 'ApiAuth\PasswordResetController@reset');

Route::group(['middleware' => 'jwt.verify'], function () {
    Route::post('/logout', 'AuthController@logout');
    Route::get('/is-user-logged-in', 'AuthController@isUserLoggedIn');

	// User
	Route::get('/users', 'UserController@getUsers');
	Route::put('/users/{id}', 'UserController@update');
	Route::get('/user/{id}', 'UserController@getUserById');
	Route::post('/user/change-password', 'ApiAuth\ChangePasswordController@index');

	//user roles
	Route::get('/user-role-permissions', 'UserController@getUserRolePermissions');
	Route::post('/user-role-permissions', 'UserController@saveUserRolePermissions');

	// Video
	Route::get('/videos', 'VideoController@index');
	Route::post('/video', 'VideoController@store');
	Route::get('/video/{id}', 'VideoController@find');

	//blog
	Route::post('/blog', 'BlogController@store');
	Route::put('/blog/{id}', 'BlogController@update');


	//audio
	Route::get('/audios', 'AudioController@index');


	//comments
	Route::group(['prefix' => 'comments'], function() {
		Route::get('/', 'CommentsController@index');
		Route::get('/list', 'CommentsController@getCommentList');
		Route::post('/', 'CommentsController@create');
		Route::post('/update', 'CommentsController@update');
		Route::put('/{comment}/{status}', 'CommentsController@changeStatus')->where('status', '(approve|reject)');
	});

	// tags
	Route::group(['prefix' => 'tags'], function() {
		Route::get('/', 'TagsController@index');
		Route::post('/', 'TagsController@store');
		Route::put('/{tag}', 'TagsController@update');
		Route::delete('/{tag}', 'TagsController@delete');
	});

	// categories
	Route::group(['prefix' => 'categories'], function() {
		Route::post('/', 'CategoriesController@store');
		Route::put('/{category}', 'CategoriesController@update');
		Route::delete('/{category}', 'CategoriesController@delete');
	});

	// media
	Route::group(['prefix' => 'media'], function() {
		Route::get('/protected', 'MediaController@index');
		Route::get('/podcast', 'MediaController@podcast');
                Route::get('/archive-latest', 'MediaController@archive_latest');
                Route::get('/get-archive-all', 'MediaController@get_archive_all');
		Route::get('/archive', 'ArchiveController@archive');
		Route::post('/', 'MediaController@store');
		Route::post('/single-file-upload', 'MediaFileUploadController@uploadSingleFile');
		Route::put('/{media}', 'MediaController@toggleStatus');
		Route::delete('/{media}', 'MediaController@delete');
	});
        
	//Author routes
	Route::group(['prefix' => 'translation-authors'], function() {
		Route::get('/', 'AuthorController@getTranslationAuthors');
		Route::post('/{id}/status/{status}', 'AuthorController@updateStatus');
		Route::put('/{id}/mark-default', 'AuthorController@markDefault');
	});

	Route::get('/singers', 'AudioController@getSingers');
	
	Route::group(['prefix' => 'media/tracking'], function() {
		Route::get('/recently-played', 'MediaTrackingsController@getRecentlyAccessedMedia');
		Route::post('/', 'MediaTrackingsController@store');
	});
});

// media
Route::group(['prefix' => 'scripture'], function() {

	Route::get('/advance-search', 'ScripturesController@advancedSearch');
	Route::get('/media-advance-search', 'ScripturesController@mediaAdvancedSearch');
	Route::get('/media-advance-search-web', 'ScripturesController@mediaAdvancedSearchWeb');
});
//Shabad routes
Route::get('/shabad/{id}/{shabadId?}', 'ShabadController@getShabad');
Route::get('/shabad-pages/{id}', 'ShabadController@getShabadPages');

// Author routes withour middelware
Route::group(['prefix' => 'translation-authors'], function() {
	Route::get('/', 'AuthorController@getTranslationAuthors');
});

//Blog Routes
Route::get('/blogs', 'BlogController@index');
Route::get('/shabad-blogs', 'BlogController@getBlogbyShabadID');
Route::get('/blog/{id}', 'BlogController@show');
Route::post('/blogs-search', 'BlogController@searchblog');
Route::post('/blogs-approval', 'BlogController@approveBlog');
Route::get('/blog-delete/{id}', 'BlogController@delete');
// Dictionary
Route::get('/get-dictionary-words', 'DictionaryController@getDictionaryWords');
Route::get('/get-dictionary-word-detail', 'DictionaryController@getSingleWordDetail');
Route::get('/tbl-authors', 'TblAuthorsController@index');
Route::get('/tbl-melodies', 'TblMelodiesController@index');
//delete Audios
Route::post('/video-delete', 'VideoController@deleteVideo');
//delete video
Route::post('/audio-delete', 'AudioController@deleteAudio');
Route::post('/audio-reject', 'AudioController@rejectAudio');
	
// media
Route::group(['prefix' => 'media'], function() {
	Route::get('/', 'MediaController@index');
        Route::post('/subs', 'MediaController@subs');
	Route::get('/featured', 'MediaController@getFeaturedItems');
		Route::get('/podcast', 'MediaController@podcast');
		Route::get('/archive', 'ArchiveController@archive');
		Route::get('/podcast-index', 'MediaController@podcast_index');
		Route::get('/archive-index', 'ArchiveController@archive_index');
        Route::get('/category-media/{id}', 'MediaController@category_media');
        Route::get('/podcast-subcategory-media/{id}', 'MediaController@subcategory_media');
        Route::get('/resource-subcategory-media/{id}', 'MediaController@resource_subcategory_media');
        Route::get('/resource-subcategory-media-new/{id}', 'MediaController@resource_subcategory_media_new');
        Route::get('/resource-category-media-new/{id}', 'MediaController@resource_category_media_new');
        
        Route::get('/resource-subcategory-podmedia-new/{id}', 'MediaController@resource_subcategory_podmedia_new');
        Route::get('/resource-category-podmedia-new/{id}', 'MediaController@resource_category_podmedia_new');
        
		Route::post('/play', 'MediaController@media_play');
		Route::get('/totalCount', 'MediaController@mediaCount');
		Route::get('/latest-archive', 'MediaController@latest_archive');
		Route::get('/latest-archive-second', 'ArchiveController@latest_archive_second');
		
		Route::get('/all-archive', 'MediaController@all_archive');
		Route::get('/all-archive-second', 'ArchiveController@all_archive_second');
		
		Route::get('/podcast-list', 'MediaController@podcast_list');
		Route::get('/archive-list', 'ArchiveController@archive_list');
                Route::get('/get-archive-all', 'MediaController@get_archive_all');
        Route::post('/play', 'MediaController@media_play');
        Route::get('/audit-list', 'MediaController@audit_list');
        Route::post('/featured-artist-gurbani/{id}', 'MediaController@featured_artist_gurbani');
        Route::get('/featured-artist-gurbani/{id}', 'MediaController@featured_artist_gurbani');
        Route::get('/recently-played', 'MediaController@recently_played');
        Route::post('/recently-played', 'MediaController@recently_played');
        Route::get('/popular-tracks', 'MediaController@popular_tracks');
        
});

Route::group(['prefix' => 'media-authors'], function() {
	Route::get('/all-list', 'MediaAuthorsController@all');
	Route::get('/featured', 'MediaAuthorsController@getFeaturedItems');
        
        Route::post('/add', 'MediaAuthorsController@add_media_author');
        Route::get('/list', 'MediaAuthorsController@media_author_list');
        Route::get('/alphabet-list', 'MediaAuthorsController@media_author_alphabet_list');
        Route::post('/update/{id}', 'MediaAuthorsController@update_media_author');
        Route::post('/update-status/{id}', 'MediaAuthorsController@update_status');
        Route::get('/delete/{id}', 'MediaAuthorsController@delete_media_author');
});

// categories
Route::group(['prefix' => 'categories'], function() {
	Route::get('/', 'CategoriesController@index');
	Route::get('/sub-categories/{id}', 'CategoriesController@sub_cats');
	Route::get('/featured', 'CategoriesController@getFeaturedItems');
        
	Route::post('/add-podcast-category', 'CategoriesController@add_podcast_category');
	Route::get('/add-podcast-category', 'CategoriesController@add_podcast_category');
	Route::post('/update-podcast-category/{id}', 'CategoriesController@update_podcast_category');
	Route::get('/podcast-list', 'CategoriesController@podcast_catetgory_list');
	Route::get('/update-podcast-status/{id}', 'CategoriesController@update_podcast_status');
	Route::post('/update-podcast-status/{id}', 'CategoriesController@update_podcast_status');
	Route::post('/delete-podcast/{id}', 'CategoriesController@delete_podcast_category');
	Route::get('/delete-podcast/{id}', 'CategoriesController@delete_podcast_category');
        
        Route::post('/add-podcast-subcategory', 'CategoriesController@add_podcast_subcategory');
	Route::get('/add-podcast-subcategory', 'CategoriesController@add_podcast_subcategory');
	Route::post('/update-podcast-subcategory/{id}', 'CategoriesController@update_podcast_subcategory');
	Route::get('/podcast-subcategory-list', 'CategoriesController@podcast_subcatetgory_list');
	Route::get('/update-podcast-subcat-status/{id}', 'CategoriesController@update_podcast_substatus');
	Route::post('/update-podcast-subcat-status/{id}', 'CategoriesController@update_podcast_substatus');
	Route::post('/delete-podcast-subcategory/{id}', 'CategoriesController@delete_podcast_subcategory');
	Route::get('/delete-podcast-subcategory/{id}', 'CategoriesController@delete_podcast_subcategory');  
        
        //Resources Categories APIs START
        Route::post('/add-resources-category', 'CategoriesController@add_resources_category');
	Route::get('/add-resources-category', 'CategoriesController@add_resources_category');
	Route::post('/update-resources-category/{id}', 'CategoriesController@update_resources_category');
	Route::get('/resources-list', 'CategoriesController@resources_catetgory_list');
	Route::get('/update-resources-status/{id}', 'CategoriesController@update_resources_status');
	Route::post('/update-resources-status/{id}', 'CategoriesController@update_resources_status');
	Route::post('/delete-resources/{id}', 'CategoriesController@delete_resources_category');
	Route::get('/delete-resources/{id}', 'CategoriesController@delete_resources_category');
        //Resources Categories APIs END
        
        //Resources Sub Categories APIs START
        Route::post('/add-resources-subcategory', 'CategoriesController@add_resources_subcategory');
	Route::get('/add-resources-subcategory', 'CategoriesController@add_resources_subcategory');
	Route::post('/update-resources-subcategory/{id}', 'CategoriesController@update_resources_subcategory');
	Route::get('/resources-subcategory-list', 'CategoriesController@resources_subcatetgory_list');
	Route::get('/update-resources-subcat-status/{id}', 'CategoriesController@update_resources_substatus');
	Route::post('/update-resources-subcat-status/{id}', 'CategoriesController@update_resources_substatus');
	Route::post('/delete-resources-subcategory/{id}', 'CategoriesController@delete_resources_subcategory');
	Route::get('/delete-resources-subcategory/{id}', 'CategoriesController@delete_resources_subcategory');  
        //Resources Sub Categories APIs END
});

Route::group(['prefix' => 'media'], function() {
	Route::get('/featured-list', 'MediaController@getFeaturedCategories');
        Route::get('/archive-latest', 'MediaController@archive_latest');
        /*Route::post('/today-podcast', 'MediaController@add_today');
        Route::get('/today-podcast', 'MediaController@add_today'); */

        Route::any('/today-podcast', 'MediaController@updatePodcastStatus'); 
		Route::any('/today-archive', 'ArchiveController@updateArchiveStatus'); 
		Route::get('/get-unapproved-media', 'MediaController@getUnapprovedMedia');
		Route::get('/download', 'MediaController@download_config')->name('download_config'); 
		Route::post('/add', 'MediaController@add');
		Route::post('/update-approval-status', 'MediaController@updateApprovalStatus'); 
		Route::get('/search-media-title', 'MediaController@searchMediaByTitle');
		Route::post('/podcast-add', 'MediaController@podcast_add'); 
		Route::post('/archive-add', 'ArchiveController@archive_add'); 
        Route::get('/list', 'MediaController@media_list');  
		Route::get('/podcast-list', 'MediaController@podcast_media_list'); 
		Route::get('/media-list-noduration', 'MediaController@media_list_noduration'); 
		Route::post('/media-duration-update', 'MediaController@media_duration_update'); 
		Route::get('/media-list-noduration', 'MediaController@media_list_noduration'); 
		Route::get('/archive-list', 'ArchiveController@archive_media_list'); 
		Route::get('/shabad-data/{id}', 'MediaController@shabad_data'); 
		Route::get('/shabad-data-archive/{id}', 'ArchiveController@shabad_data_archive'); 
        Route::get('/update-media-status/{id}', 'MediaController@update_status_media'); 
        Route::post('/update-media-status/{id}', 'MediaController@update_status_media'); 
        Route::get('/update-podcast-media-status/{id}', 'MediaController@update_podcast_status_media'); 
		Route::post('/update-podcast-media-status/{id}', 'MediaController@update_podcast_status_media'); 
		
		Route::get('/update-archive-media-status/{id}', 'ArchiveController@update_archive_status_media'); 
        Route::post('/update-archive-media-status/{id}', 'ArchiveController@update_archive_status_media'); 

        Route::post('/update-media/{id}', 'MediaController@update_media'); 
		Route::post('/update-podcast-media/{id}', 'MediaController@update_podcast_media'); 
		Route::post('/update-archive-media/{id}', 'ArchiveController@update_archive_media'); 
        Route::get('/delete-media/{id}', 'MediaController@delete_media'); 
		Route::get('/delete-podcast-media/{id}', 'MediaController@delete_podcast_media'); 
		Route::get('/delete-archive-media/{id}', 'ArchiveController@delete_archive_media'); 
		
});

Route::group(['prefix' => 'featured-api'], function() {
	Route::get('/listing', 'FeaturedResourcesapiController@listing');
	Route::get('/podcast-listing', 'FeaturedResourcesapiController@podcast_listing');
	
	Route::post('/save-featured-media', 'FeaturedResourcesapiController@save_featured_media');
	Route::post('/save-prior-media', 'FeaturedResourcesapiController@save_prior_media');
	Route::post('/save-prior-podmedia', 'FeaturedResourcesapiController@save_prior_podmedia');
	Route::post('/save-featured-category', 'FeaturedResourcesapiController@save_featured_category');
	Route::post('/save-featured-author', 'FeaturedResourcesapiController@save_featured_author');
        
        Route::post('/save-podcast-media', 'FeaturedResourcesapiController@save_podcast_media');
	Route::post('/save-podcast-category', 'FeaturedResourcesapiController@save_podcast_category');
	Route::post('/save-podcast-author', 'FeaturedResourcesapiController@save_podcast_author');
});

Route::group(['prefix' => 'resource-tag'], function(){
    Route::post('/add', 'TagsController@add');
    Route::get('/list', 'TagsController@tags_list');
    Route::post('/edit-tag/{id}', 'TagsController@edit_tag');
    Route::post('/update-tag-status/{id}', 'TagsController@update_tag_status');
    Route::get('/delete-tag/{id}', 'TagsController@delete_tag');
});

Route::group(['prefix' => 'shabad-data'], function(){
    Route::get('/list', 'ShabadController@shabad_list');
    Route::get('/get-shabad-media/{id}', 'ShabadController@get_shabad_media');
    Route::post('/add-translation/{id}', 'ShabadController@add_translation');
    Route::post('/export-shabads', 'ShabadController@export_shabad');
});

Route::group(['prefix' => 'commentary'], function(){
    Route::post('/add/{id}', 'ShabadController@add_commentary');
    Route::get('/list/{id}', 'ShabadController@commentaries');
    Route::get('/shabad-comment-list/{id}', 'ShabadController@shabad_comments');
    Route::post('/add-comment/{id}', 'ShabadController@add_comment');
    Route::post('/add-reply/{id}', 'ShabadController@add_reply');
    Route::post('/comment-delete/{id}', 'ShabadController@shabad_comment_delete');
    Route::post('/comment-status/{id}', 'ShabadController@comment_status');
    
    Route::post('/reply-delete/{id}', 'ShabadController@shabad_reply_delete');
    Route::post('/reply-status/{id}', 'ShabadController@reply_status');
    
    Route::post('/update-comment/{id}', 'ShabadController@update_comment');
	Route::post('/update-reply/{id}', 'ShabadController@update_reply');
	Route::get('/get-unapproved-comments', 'ShabadController@getUnapprovedComments');
});

// Android Application Programming Interface
Route::group(['prefix' => 'android'], function() {
	Route::post('/login', 'AndroidController@login');
	Route::post('/user-check', 'AndroidController@user_check'); 
	Route::post('/login-with-social', 'AndroidController@loginWithSocialAccount');
	//Route::post('/register', 'AndroidController@register')
	Route::post('/play', 'AndroidController@media_play');


});

Route::group(['middleware' => 'jwt.verify', 'prefix' => 'android'], function () {
	
	Route::post('/user-download', 'AndroidController@user_downloads');
	
	Route::get('/user-download-list', 'AndroidController@user_downloads_list');
	Route::get('/podcast-fav-list', 'AndroidController@podcast_fav_list');
	Route::get('/user-downloaded', 'AndroidController@user_downloads');
	
	

	
	
	Route::post('/sub-cat-fav', 'AndroidController@sub_cat_fav');
	Route::get('/sub-cat-fav-list', 'AndroidController@sub_cat_fav_list');

	Route::post('/upload-profile-image', 'AndroidController@upload_profile_image');
});

Route::group(['prefix' => 'android'], function () {
	Route::get('/favorite_artist_fetch', 'AndroidController@favorite_artists_fetch');
	Route::get('/filters-search', 'AndroidController@media_search_2');
	Route::get('/all-singers', 'AndroidController@all_authors');
	Route::get('/all-melodies', 'AndroidController@all_melodies');
	Route::get('/featured-media', 'AndroidController@featuredMedia');
	Route::get('/featured-categories', 'AndroidController@featuredCategories');
	Route::post('/media-search-delete', 'AndroidController@media_search_delete');
	Route::post('/media-search-insert', 'AndroidController@media_search_insert');
	Route::get('/search-history', 'AndroidController@media_search_history');
	Route::get('/home', 'AndroidController@home');
	Route::post('/fav', 'AndroidController@media_fav');
	Route::post('/create-playlist', 'AndroidController@create_playlist');
	Route::post('/action-track-playlist', 'AndroidController@append_playlist_tracks');
	Route::get('/home-skip', 'AndroidController@home_skip');
	Route::get('/recently-played', 'AndroidController@recently_played');
	Route::get('/media-authors', 'AndroidController@media_authors');
	Route::get('/podcast-category/{id}', 'AndroidController@resource_category_podmedia_new');
	Route::get('/sub-categories/{id}', 'AndroidController@sub_cats');
	Route::get('/sub-categories-new/{id}', 'AndroidController@resource_category_media_new');
	Route::get('/resource-subcategory-media/{id}', 'AndroidController@resource_subcategory_media_new');
	Route::get('/featured-artist-gurbani/{id}', 'AndroidController@featured_artist_gurbani');
	Route::get('/featured-artist-gurbani-five/{id}', 'AndroidController@featured_artist_gurbani_five');
	Route::get('/get-similar-by-artist/{id}', 'AndroidController@get_similar_by_artist');
	Route::get('/shabad/{id}/{shabadId?}', 'AndroidController@getShabad');
	Route::get('/user-playlist', 'AndroidController@user_playlist');
	Route::get('/user-playlist-tracks', 'AndroidController@user_playlist_tracks');
	Route::get('/delete-playlist-track', 'AndroidController@delete_playlist_track');
	Route::get('/delete-playlist', 'AndroidController@delete_playlist');
	Route::get('/artist-fav-list', 'AndroidController@artist_fav_list');
	Route::post('/artist-fav', 'AndroidController@artist_fav');
	Route::get('/fav-list', 'AndroidController@media_fav_list');
	Route::get('/user-download-list', 'AndroidController@user_downloads_list');
	Route::post('/user-download', 'AndroidController@user_downloads');
	Route::post('/user-share', 'AndroidController@user_share');
	Route::get('/podcast-fav-list', 'AndroidController@podcast_fav_list');
	Route::post('/podcast-fav', 'AndroidController@podcast_fav');
	Route::get('/media-search', 'AndroidController@media_search_for_artist_and_song');
	Route::get('/search', 'AndroidController@media_search_3');
	Route::get('/drop-down', 'AndroidController@search_drop_down');
	Route::get('/all-podcasts', 'AndroidController@all_podcasts');
	Route::get('/android-radio', 'AndroidController@getRadioAndroid');
	Route::post('/radio-play', 'AndroidController@radio_play');
	Route::post('/sub-cat-fav', 'AndroidController@sub_cat_fav');
	Route::get('/home-podcast-index', 'AndroidController@home_podcast_index');
	Route::post('/delete-user', 'AndroidController@delete_user');
});