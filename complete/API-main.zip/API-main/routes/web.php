<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

Route::group(['prefix' => 'media'], function() {
	Route::post('/upload', 'MediaFileUploadController@fileChunkUpload');
});

Route::namespace('Admin')
	->prefix('admin')
	->name('admin.')
	->group(function() {

	Route::get('/', 'Auth\LoginController@showLoginForm')->name('login');
	Route::get('/login', 'Auth\LoginController@showLoginForm')->name('login.index');
	Route::post('/login', 'Auth\LoginController@login')->name('post.login');

	Route::group(['middleware' => 'admin.auth'], function() {

		Route::get('/logout', 'Auth\LoginController@logout')->name('logout');
		Route::get('dashboard', 'DashboardController@index')->name('dashboard');

		Route::group(['prefix' => 'media/categories'], function() {
			Route::get('/{category?}', 'MediaCategoriesController@index')->name('media.categories.index');
			Route::post('/', 'MediaCategoriesController@store')->name('media.categories.store');
			Route::post('/{category}', 'MediaCategoriesController@update')->name('media.categories.update');
			Route::delete('/{category}', 'MediaCategoriesController@delete')->name('media.categories.delete');
			Route::get('/toggle-status/{category}', 'MediaCategoriesController@toggleStatus')->name('media.categories.toggle-status');
		});
                
                Route::group(['prefix' => 'media/subcategories'], function() {
			Route::get('/{category?}', 'MediaSubcategoriesController@index')->name('media.subcategories.index');
			Route::post('/', 'MediaSubcategoriesController@store')->name('media.subcategories.store');
			Route::post('/{subcategory}', 'MediaSubcategoriesController@update')->name('media.subcategories.update');
			Route::delete('/{subcategory}', 'MediaSubcategoriesController@delete')->name('media.subcategories.delete');
			Route::get('/toggle-status/{subcategory}', 'MediaSubcategoriesController@toggleStatus')->name('media.subcategories.toggle-status');
		});

		Route::group(['prefix' => 'tags'], function() {
			Route::get('/{tag?}', 'TagsController@index')->name('tags.index');
			Route::post('/', 'TagsController@store')->name('tags.store');
			Route::post('/{tag}', 'TagsController@update')->name('tags.update');
			Route::delete('/{tag}', 'TagsController@delete')->name('tags.delete');
			Route::get('/toggle-status/{tag}', 'TagsController@toggleStatus')->name('tags.toggle-status');
		});

		Route::group(['prefix' => 'media/authors'], function() {
			Route::get('/{mediaAuthor?}', 'MediaAuthorsController@index')->name('media.authors.index');
			Route::post('/', 'MediaAuthorsController@store')->name('media.authors.store');
			Route::post('/{mediaAuthor}', 'MediaAuthorsController@update')->name('media.authors.update');
			Route::delete('/{mediaAuthor}', 'MediaAuthorsController@delete')->name('media.authors.delete');
			Route::get('/toggle-status/{mediaAuthor}', 'MediaAuthorsController@toggleStatus')->name('media.authors.toggle-status');
		});

		Route::group(['prefix' => 'media'], function() {
			Route::get('/', 'MediaController@index')->name('media.index');
			Route::get('/create', 'MediaController@create')->name('media.create');
			Route::post('/', 'MediaController@store')->name('media.store');
			Route::get('/edit/{media}', 'MediaController@edit')->name('media.edit');
			Route::put('/{media}', 'MediaController@update')->name('media.update');
			Route::delete('/{media}', 'MediaController@delete')->name('media.delete');
			Route::get('/toggle-status/{media}', 'MediaController@toggleStatus')->name('media.toggle-status');
		});

		Route::group(['prefix' => 'shabads'], function() {
			Route::get('/list', 'ShabadsController@getList')->name('shabad.list');
		});

		Route::group(['prefix' => 'featured-resources'], function() {
			Route::get('/', 'FeaturedResourcesController@index')->name('featured.resources.index');
			Route::get('/media-list', 'FeaturedResourcesController@getMediaList')->name('featured.resources.media.list');
			Route::post('/media-list', 'FeaturedResourcesController@storeFeaturedMedia')->name('store.featured.resources.media.list');

			Route::get('/artists-list', 'FeaturedResourcesController@getAuthorsList')->name('featured.resources.authors.list');
			Route::post('/artists-list', 'FeaturedResourcesController@storeFeaturedAuthor')->name('store.featured.resources.authors.list');


			Route::get('/categories-list', 'FeaturedResourcesController@getCategoriesList')->name('featured.resources.categories.list');
			Route::post('/categories-list', 'FeaturedResourcesController@storeFeaturedCategories')->name('store.featured.resources.categories.list');
		});
                
                Route::group(['prefix' => 'podcast-list'], function() {
			Route::get('/', 'FeaturedResourcesController@podcast_list');
			Route::post('/', 'FeaturedResourcesController@podcast_list');
                        Route::get('today/{id}/{title}/', 'FeaturedResourcesController@add_today');
                        Route::post('today{id}/{title}/', 'FeaturedResourcesController@add_today');
                        Route::post('remove-today', 'FeaturedResourcesController@remove_today');
                        Route::get('remove-today', 'FeaturedResourcesController@remove_today');
		});
	});
});