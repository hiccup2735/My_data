<?php

use App\Models\Media;

return [
	'current_mysql_version' => '', // dynamically set in middleware
	'images' => [
		'path' => 'images',
		'placeholder_name' => 'placeholder.jpg',
	],
	'uploads' => [
		'path' => 'uploads',

		'media' => [
			'file_upload_chunk_size_in_bytes' => 1000000,
			'path' => 'uploads'.DIRECTORY_SEPARATOR.'media',
			'main_dir' => 'media',
			'thumb_dir' => 'thumbnail',
			'medium_dir' => 'medium',
			'large_dir' => 'large',
		],
		'media_sizes' => [
			'thumbnail' => [
                'width' => 400,
                'height' => 400,
            ],
            'medium' => [
                'width' => 600,
                'height' => 450,
            ],
            'large' => [
                'width' => 800,
                'height' => 800,
            ],
		]
	],
	'media' => [
		'ref_type' => [
			Media::POST_REF_TYPE => 'Post',
			Media::RESOURCE_REF_TYPE => 'Resource',
		],
		'type' => [
                        Media::AUDIO_TYPE => 'Audio',
			Media::IMAGE_TYPE => 'Podbean',
//			Media::VIDEO_TYPE => 'Video',
			Media::YOUTUBE_TYPE => 'YouTube',
//			Media::VIMEO_TYPE => 'Vimeo',
			
		],
	]
];