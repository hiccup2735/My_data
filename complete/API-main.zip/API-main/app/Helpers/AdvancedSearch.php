<?php

namespace App\Helpers;

class AdvancedSearch
{
	protected $option;
	protected $field;
	protected $keyword;
	protected $query;

	
	public function __construct($option, $field, $keyword)
	{
		$this->option = $option;
		$this->field = $field;
		$this->keyword = $keyword;
	}

	public function buildQuery()
	{

		$keyword = $this->keyword;
		$field = $this->field;
		$characters = array();
		for($index = 0; $index < mb_strlen($keyword); $index++){
			$characters[] = mb_substr($keyword, $index, 1);
		}

		$returnValue = "";
		switch($this->option){
			case 1: // Exact Match
				$returnValue = $this->exactMatch($field, $keyword);
				break;
			case 2: // Exact Match + Begins With
				$returnValue = $field." REGEXP '^".$keyword."'";
				break;
			case 3: // First Letter + Begins With
				$returnValue = $this->matchFirstLetterBeginWith($field, $characters);
				break;
			case 4: // First Letter
				$returnValue = $this->matchFirstLetter($field, $characters);
				break;
			case 5: // Match All Words Anywhere
				$returnValue = $this->matchAllWordsAnywhere($field, $keyword);
				break;
			case 6: // Match Any Word
				$returnValue = $this->matchAnyWord($field, $keyword);
				break;
			case 7: // Match all words partially
				$returnValue = $this->matchAllWordsPartially($field, $keyword);
				break;
			case 8: // Match any word partially
				$returnValue = $this->matchAnyWordsPartially($field, $keyword);
				break;
			case 9: // Match any word partially
				$returnValue = $this->matchAnyWord($field, $keyword);
				break;
		}

		// print_r($returnValue);die;

		$this->query = $returnValue;

		return $this;
	}

	public function getQuery()
	{
		return $this->query;
	}

	/**
	 * create regex query for exact match keyword
	 * 
	 * @param  $field: string of database table field name.
	 * @param  $keyword: string of keywords.
	 * @return sql query with regex
	 */
	private function exactMatch($field, $keyword)
	{
	/*
		$returnValue = $field." REGEXP '\\\b$keyword\\\b'";
		if($this->getMysqlVersion() == 5) {
			$returnValue = $field." REGEXP '[[:<:]]".$keyword."[[:>:]]'";
		}
	*/
		$returnValue = "MATCH ($field) against ('\"$keyword\"' in boolean mode)";
		return $returnValue;
	}

	/**
	 * create regex query for first letter + begins with
	 * 
	 * @param  $field: string of database table field name.
	 * @param  $keyword: string of keywords.
	 * @return sql query with regex
	 */
	private function matchFirstLetterBeginWith($field, $characters)
	{
		$returnValue = $field." REGEXP '^".implode("\\\S* ", $characters).".*'";
		if($this->getMysqlVersion() == 5) {
			$returnValue = $field." REGEXP '^[[:<:]]".implode("[^[:space:]]* ", $characters).".*'";
		}
		return $returnValue;
	}

	/**
	 * create query to match first character and find result.
	 * 
	 * @param  $field: string of database table field name.
	 * @param  $firstCharacters: array of first characters.
	 * @return sql query with regex
	 */
	private function matchFirstLetter($field, $firstCharacters = [])
	{
		$returnValue = $field." REGEXP '\\\b".implode("[^[:space:]]* ", $firstCharacters).".*'";
		if($this->getMysqlVersion() == 5) {
			$returnValue = $field." REGEXP '[[:<:]]".implode("[^[:space:]]* ", $firstCharacters).".*'";
		}
		return $returnValue;
	}

	/**
	 * create query to match all words in any here in string.
	 * 
	 * @param  $field: string of database table field name.
	 * @param  $firstCharacters: string of keyword.
	 * @return sql query with regex
	 */
	private function matchAllWordsAnywhere($field, $keyword)
	{
		$splitKeywords = explode(" ", $keyword);
		$splitKeywordsConditions = array();
		foreach($splitKeywords as $splittedKeyword){

			if($this->getMysqlVersion() == 5) {
				$splitKeywordsConditions[] = $field." REGEXP '[[:<:]]".$splittedKeyword."[[:>:]]' ";
			} else {
				$splitKeywordsConditions[] = $field." REGEXP '\\\b".$splittedKeyword."\\\b' ";
			}
		}

		return implode(" \nAND ", $splitKeywordsConditions);
	}

	/**
	 * create query to match any word in any where string.
	 * 
	 * @param  $field: string of database table field name.
	 * @param  $firstCharacters: string of keyword.
	 * @return sql query with regex
	 */
	private function matchAnyWord($field, $keyword)
	{
		$splitKeywords = explode(" ", $keyword);
		$anyWordCondition = "";
		foreach($splitKeywords as $splittedKeyword){
			$anyWordCondition .= "|".$splittedKeyword;
		}

		if($this->getMysqlVersion() == 5) { 
			return $field." REGEXP '[[:<:]](" . mb_substr($anyWordCondition, 1) . ")[[:>:]]'";
		}

		return $field." REGEXP '\\\b(" . mb_substr($anyWordCondition, 1) . ")\\\b'";
	}

	/**
	 * create query to match all words partially.
	 * 
	 * @param  $field: string of database table field name.
	 * @param  $firstCharacters: string of keyword.
	 * @return sql query with regex
	 */
	private function matchAllWordsPartially($field, $keyword)
	{
		$splitKeywords = explode(" ", $keyword);
		$splitKeywordsConditions = array();
		foreach($splitKeywords as $splittedKeyword){
			$splitKeywordsConditions[] = $field." LIKE '%".$splittedKeyword."%' ";
		}
		return implode(" \nAND ", $splitKeywordsConditions);
	}

	/**
	 * create query to match any word partially.
	 * 
	 * @param  $field: string of database table field name.
	 * @param  $firstCharacters: string of keyword.
	 * @return sql query with regex
	 */
	private function matchAnyWordsPartially($field, $keyword)
	{
		$splitKeywords = explode(" ", $keyword);
		$splitKeywordsConditions = array();
		foreach($splitKeywords as $splittedKeyword){
			$splitKeywordsConditions[] = $field." LIKE '%".$splittedKeyword."%' ";
		}
		return implode(" \nOR ", $splitKeywordsConditions);
	}

	private function getMysqlVersion() 
	{
		return config('global.current_mysql_version');
	}
}