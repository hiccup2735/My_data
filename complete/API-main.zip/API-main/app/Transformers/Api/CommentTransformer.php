<?php

namespace App\Transformers\Api;

use App\Models\Comment;
use App\Presenters\TransformerAbstract;

class CommentTransformer extends TransformerAbstract
{
    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $availableIncludes = [];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $defaultIncludes = [];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Comment $resource)
    {
        $status = false;
        if($resource->getCommentApprove() > 0) {
            $status = $resource->getCommentApprove();
        }
        $fields = [
            'id'                => $resource->getKey(),
            'comment_id'        => $resource->getKey(),
            'comment_author_id' => $resource->getCommentAuthorId(),
            'comment_text'      => $resource->getCommentText(),
            'comment_date'      => $resource->getCommentDate(),
            'comment_post_id'   => $resource->getCommentPostId(),
            'comment_approve'   => $status,
            'comment_formated_date'	=> date('F j, Y', $resource->getCommentDate())
        ];

        return $this->applySparseFieldsets($fields);
    }
}
