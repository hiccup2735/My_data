<?php

namespace App\Transformers\Api;

use App\Models\TblAuthor;
use App\Presenters\TransformerAbstract;

class TblAuthorTransformer extends TransformerAbstract
{
    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $availableIncludes = [];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $defaultIncludes = [];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(TblAuthor $resource)
    {
        $fields = [
            'id'                => $resource->getKey(),
            'author'            => $resource->getAuthor(),
            'author_gurmukhi'   => $resource->getAuthorGurmukhi(),
            'description'       => $resource->getAuthorDescription()
        ];

        return $this->applySparseFieldsets($fields);
    }
}
