<?php

namespace App\Transformers\Api;

use App\Models\Tag;
use App\Presenters\TransformerAbstract;

class TagTransformer extends TransformerAbstract
{
    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $availableIncludes = [];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $defaultIncludes = [];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Tag $resource)
    {
        $fields = [
            'id'                => $resource->getKey(),
            'slug'              => $resource->getSlug(),
            'name'              => $resource->getName(),
            'description'       => $resource->getDescription(),
            'status'            => $resource->getStatus()
        ];

        return $this->applySparseFieldsets($fields);
    }
}
