<?php

namespace App\Transformers\Api;

use App\Models\Category;
use App\Presenters\TransformerAbstract;

class CategoryTransformer extends TransformerAbstract
{
    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $availableIncludes = [];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $defaultIncludes = [];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Category $resource)
    {
        $fields = [
            'id'                        => $resource->getKey(),
            'slug'                      => $resource->getSlug(),
            'name'                      => $resource->getName(),
            'description'               => $resource->getDescription(),
            'status'                    => $resource->getStatus(),
            'featured'                  => (bool)$resource->getFeatured(),
            'featured_display_order'    => $resource->getFeaturedDisplayOrder(),
        ];

        return $this->applySparseFieldsets($fields);
    }
}
