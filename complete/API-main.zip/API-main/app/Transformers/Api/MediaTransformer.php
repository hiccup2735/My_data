<?php

namespace App\Transformers\Api;

use App\Models\Media;
use App\Presenters\TransformerAbstract;
use App\Transformers\Api\UserTransformer;

class MediaTransformer extends TransformerAbstract
{
    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $availableIncludes = ['categories', 'tags', 'created_by_user'];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $defaultIncludes = [];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(Media $resource)
    {

        $fields = [
            'id'                        => $resource->getKey(),
            'author_id'                 => $resource->getAuthorId(),
            'shabad_id'                 => $resource->getShabadId(),
            'shabad_page'               => $resource->page_number,
            'ref_type'                  => $resource->getRefType(),
            'title'                     => $resource->getTitle(),
            'description'               => $resource->getDescription(),
            'attachment_name'           => $resource->getAttachmentName(),
            'attachment_url'            => $resource->getAttachmentUrl(),
            'external_url'              => $resource->getAttachmentName(),
            'attachment_mime_type'      => $resource->getAttachmentMimeType(),
            'thumbnail'                 => $resource->getThumbnail(),
            'type'                      => $resource->getType(),
            'status'                    => $resource->getStatus(),
            'featured'                  => (bool) $resource->getFeatured(),
            'featured_display_order'    => $resource->getFeaturedDisplayOrder(),
            'created_by'                => $resource->getCreatedBy(),
            'updated_by'                => $resource->getUpdatedBy(),
            'created_at'                => $resource->getCreatedAt(),
            'updated_at'                => $resource->getUpdatedAt(),
        ];

        return $this->applySparseFieldsets($fields);
    }

    /**
     * Include Categories
     *
     * @return League\Fractal\ItemResource
     */
    public function includeCategories(Media $resource)
    {
        $items = $resource->categories;
        if($items->isEmpty()) {
            return null;
        }
        return $this->collection($items, new CategoryTransformer, 'categories');
    }

    /**
     * Include tags
     *
     * @return League\Fractal\ItemResource
     */
    public function includeTags(Media $resource)
    {
        $items = $resource->tags;
        if($items->isEmpty()) {
            return null;
        }
        return $this->collection($items, new TagTransformer, 'tags');
    }

    public function includeCreatedByUser(Media $resource)
    {
        $item = $resource->created_by_user;
        return $this->item($item, new UserTransformer, 'users');
    }
}
