<?php

namespace App\Transformers\Api;

use App\Models\MediaAuthor;
use App\Presenters\TransformerAbstract;

class MediaAuthorTransformer extends TransformerAbstract
{
    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $availableIncludes = [];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected $defaultIncludes = [];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform(MediaAuthor $resource)
    {
        $fields = [
            'id'                        => $resource->getKey(),
            'slug'                      => $resource->getSlug(),
            'name'                      => $resource->getName(),
            'status'                    => $resource->getStatus(),
            'featured'                  => (bool) $resource->getFeatured(),
            'featured_display_order'    => $resource->getFeaturedDisplayOrder(),
        ];

        return $this->applySparseFieldsets($fields);
    }
}
