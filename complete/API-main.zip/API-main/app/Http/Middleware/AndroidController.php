<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Mail;
use Symfony\Component\HttpFoundation\Response as ResponseCode;
use App\User;
use App\Repositories\UserRepository;
use App\Repositories\ScriptureRepository;
use App\Repositories\ShabadRepository;
use App\Repositories\ScriptureAdvanceSearchRepository;
use App\Transformers\Api\AdvancedScriptureTransformer;
use App\Repositories\MediaAuthorsRepository;
use App\Transformers\Api\MediaAuthorTransformer;
use App\Repositories\TblMelodiesRepository;
use App\Transformers\Api\TblMelodyTransformer;
use App\Models\Scripture;
use App\Mail\WelcomeMail;
use App\Http\Requests\Api\RegisterUserRequest;
use DB;
use Exception, Response;
use JWTAuth, Validator;


class AndroidController extends ApiController
{
    use AuthenticatesUsers;

    private $repository;

    function __construct(UserRepository $repository, ScriptureRepository $scriptureRepo, ShabadRepository $shabadrepository, ScriptureAdvanceSearchRepository $advanceSearchRepository, MediaAuthorsRepository $author_repository, TblMelodiesRepository $melody_repository)
    {
        $this->repository              = $repository;
        $this->shabadrepository        = $shabadrepository;
        $this->scriptureRepo           = $scriptureRepo;
        $this->advanceSearchRepository = $advanceSearchRepository;
        $this->author_repository = $author_repository;
        $this->melody_repository = $melody_repository;
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email'    => 'required|string|email|max:255',
            'password' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'  => 'error',
                'token'   => '',
                'user'    => '',
                'message' => $validator->errors()
            ], 422);
        }

        $credentials              = $this->credentials($request);
        $jwt_token                = null;
        $credentials['is_active'] = true;

        try {
            if (!$jwt_token = JWTAuth::attempt($credentials)) {
                return response()->json([
                    'status'  => 'error',
                    'token'   => '',
                    'user'    => '',
                    'message' => 'Invalid Email or Password'
                ], 403);
            }
        } catch (JWTException $e) {
            return response()->json([
                'status'  => 'error',
                'token'   => '',
                'user'    => '',
                'message' => 'could_not_create_token'
            ], 500);
        }

        $user  = $this->guard()->user();
        $roles = $this->repository->setUserRoles($user);

        $user['roles'] = $roles;

        return response()->json([
            'status'  => 'success',
            'token'   => $jwt_token,
            'user'    => $user,
            'message' => 'Logged In Succesfully'
        ]);
    }

    public function loginWithSocialAccount(Request $request)
    {
        $email = $request->input('email');
        $user  = User::where('email', $email)->first();

        if ($user) {
            $jwt_token = JWTAuth::fromUser($user);
        } else {
            $user                  = new User;
            $user->name            = $request->input('name');
            $user->email           = $email;
            $user->role_id         = 2;
            $user->google_id       = $request->input('social_account_id');
            $user->photo_url       = $request->input('photo_url');
            $user->provider        = $request->input('provider');
            $user->is_active       = 1;
            $user->save();

            $jwt_token = JWTAuth::fromUser($user);
        }

        $roles         = $this->repository->setUserRoles($user);
        $user['roles'] = $roles;

        return response()->json([
            'status'  => 'success',
            'token'   => $jwt_token,
            'user'    => $user,
            'message' => 'Logged In Succesfully'

        ]);
    }

    public function logout(Request $request)
    {
        try {
            JWTAuth::invalidate($request->token);

            return response()->json([
                'status'  => 'success',
                'message' => 'User logged out successfully'
            ]);
        } catch (JWTException $exception) {
            return response()->json([
                'status'  => 'error',
                'message' => 'Sorry, the user cannot be logged out'
            ], 500);
        }
    }

    public function isUserLoggedIn()
    {
        if (!$user = JWTAuth::parseToken()->authenticate()) {
            return response()->json([
                'status'  => 'error',
                'message' => 'User not found'
            ], 401);
        }

        return response()->json([
            'status'  => 'success',
            'message' => 'User successfully found'
        ]);
    }

    public function user_check(Request $request)
    {
        $email      = $request->email;
        $user_count = DB::table('users')
            ->where('email', $email)
            ->where('google_id', null)
            ->count();

        if ($user_count == '1') {
            return response()->json([
                'data' => [
                    'status' => 'success',
                    'result' => true
                ]
            ]);
        } else {
            return response()->json([
                'data' => [
                    'status' => 'error',
                    'result' => false
                ]
            ]);
        }
    }

    public function register(Request $request, User $user)
    {
        $validator = Validator::make($request->all(), [
            'email'    => 'required|email|unique:users',
            'password' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status'  => 'errpr',
                'message' => $validator->errors()
            ], 422);
        }

        try {
            $user->setName($request->input('name'))
                ->setEmail($request->input('email'))
                ->setPassword($request->input('password'))
                ->setState($request->input('state'))
                ->setCity($request->input('city'))
                ->setRole(2)
                ->setCountry($request->input('country'))
                ->setVerificationCode(str_random(20));

            $user = $this->repository->createUser($user);

            Mail::to($user['email'])->send(new WelcomeMail($user));

            return response()->json([
                'status' => 'success',
                'message' => 'User successfully registerd.'
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage()
            ], 404);
        }
    }

    public function home(Request $request)
    {
        # featured_categories
        # featured_podcast_categories
        # popular_tracks
        # recently_played
        # featured_podcasts
        # today_podcast
        # featured_authors
        # featured_tracks

        $data                                = array();
        $data['featured_categories']         = [];
        $data['featured_podcast_categories'] = [];
        $data['popular_tracks']              = [];
        $data['recently_played']             = [];
        $data['featured_podcasts']           = [];
        $data['today_podcast']               = [];
        $data['featured_authors']            = [];
        $data['featured_tracks']             = [];

        if ($request->user_id == '' || $request->user_id == null) {
            $fav_media_array = array();
        } else {
            $fav_media_array = $this->fetch_fav_media_ids($request->user_id);
            if (!is_array($fav_media_array)) {
                $fav_media_array = $fav_media_array->toArray();
            }
        }

        $items = DB::table('categories')->where('featured', '1')->orderBy('featured_display_order', 'asc')->paginate(10);

        if (count($items) > 0) {
            foreach ($items as $item) {
                $sub_cat_counts = DB::table('subcategories')->where('category_id', $item->id)->where('status', '1')->count();
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/category/') . '/' . $item->image;
                }
                $data['featured_categories'][] = array(
                    'id'                 => $item->id,
                    'name'               => $item->name,
                    'slug'               => $item->slug,
                    'sub_category_count' => $sub_cat_counts,
                    'attachment_name'    => $category_image
                );
            }
        } else {
            $data['featured_categories'] = [];
        }

        /*===================================================
        =            Featured Podcast Categories            =
        ===================================================*/

        $all_cats = DB::table('podcast_categories')->where('status', '1')->where('featured', '1')->get();

        if (count($all_cats) > 0) {
            foreach ($all_cats as $all_cat) {
                if ($all_cat->image == null || $all_cat->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/podcast_category/') . '/' . $all_cat->image;
                }
                $sub_pod_count = DB::table('podcast_subcategories')->where('category_id', $all_cat->id)->where('status', '1')->count();
                if ($sub_pod_count > 0) {
                    $sub_pod_data1 = DB::table('podcast_subcategories')->where('category_id', $all_cat->id)->where('status', '1')->get();
                    foreach ($sub_pod_data1 as $item) {
                        if ($item->image == null || $item->image == '') {
                            $category_image = '';
                        } else {
                            $category_image = url('uploads/podcast_category/') . '/' . $item->image;
                        }
                        $sub_pod_data[] = array(
                            'id' => $item->id,
                            'name' => $item->name,
                            'status' => $item->status,
                            'attachment_name' => $category_image,
                            'category_id' => $item->category_id,
                        );
                    }
                } else {
                    $sub_pod_data = [];
                }
                $data['featured_podcast_categories'][] = array(
                    'id'                     => $all_cat->id,
                    'title'                  => $all_cat->name,
                    'description'            => $all_cat->description,
                    'category_image'         => $category_image,
                    'featured'               => $all_cat->featured,
                    'featured_display_order' => $all_cat->featured_display_order,
                    'podcast_subcats'        => $sub_pod_data
                );
            }
        } else {
            $data['featured_podcast_categories'] = [];
        }

        /*=====  End of Featured Podcast Categories  ======*/

        /*======================================
        =            Popular Tracks            =
        ======================================*/

        $media_distinct_count_check = DB::table('media_play')
            ->select(['media_id as media_id'])
            ->groupBy('media_id')
            ->havingRaw('COUNT(media_id) > ?', [1])
            ->pluck('media_id');
        $all_medias = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->where('media_approve', '=', '1')->where('play_count', '>', 1)->whereIn('media.id', $media_distinct_count_check)->orderBy('updated_at', 'asc')->get();
        /*$all_medias = DB::table('media')->where('media_approve','=','1')->where('play_count','>',1)->whereIn('id', $media_distinct_count_check)->paginate(60);*/

        if (count($all_medias) > 0) {
            foreach ($all_medias as $k => $all_media) {
                if ($all_media->attachment_name == null || $all_media->attachment_name == '') {
                    $media_url = '';
                } else {
                    if ($all_media->type == 'AUDIO') {
                        $media_url = url('uploads/media/') . '/' . $all_media->attachment_name;
                    } else {
                        $media_url = $all_media->attachment_name;
                    }
                }
                $media_distinct_count = DB::table('media_play')->where('media_id', $all_media->id)->count();
                @$pageID = DB::table('tblscripture')->select('Page')->where('ShabadID', $all_media->shabad_id)->min('Page');

                //   echo "<pre>";
                //     print_r($pageID);die;
                //                $result [] = array(
                //                    'media_id' => $all_media->id,
                //                    'media_title' => $all_media->title,
                //                    'media_url' => $media_url,
                //                    'media_start_date' => $all_media->play_start_date,
                //                    'media_start_time' => $all_media->play_start_time,
                //                    'media_last_date' => $all_media->play_last_date,
                //                    'media_last_time' => $all_media->play_last_time,
                //                    'media_distinct_count' => $media_distinct_count,
                //                );
                $all_medias[$k]->page_id = $pageID;
                $all_medias[$k]->media_url = $media_url;
                $all_medias[$k]->media_distinct_count = $media_distinct_count;
            }

            $all_medias->setCollection(
                collect(
                    collect($all_medias->items())->sortByDesc('media_distinct_count')
                )->values()
            );
        }

        if ($all_medias) {
            foreach ($all_medias as $item) {
                $result12 = substr($item->attachment_name, 0, 5);
                if ($result12 == 'https') {
                    $attachment_file = $item->attachment_name;
                } else {
                    $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                }
                if ($item->image != null) {
                    $thumb = url('uploads/author/') . '/' . $item->image;
                } else {
                    $thumb = '';
                }
                /*echo "<pre>";
print_r ($fav_media_array->toArray());
echo "</pre>";die();*/
                $data['popular_tracks'][] = array(
                    'id'              => $item->id,
                    'shabad_id'       => $item->shabad_id,
                    'title'           => $item->title,
                    'author'           => $item->name,
                    'type'            => $item->type,
                    'duration'        => $item->duration,
                    'attachment_name' => $attachment_file,
                    'play_count'      => $item->media_distinct_count,
                    'image'           => $thumb,
                    'favourite'       => (in_array($item->id, $fav_media_array)) ? 1 : 0
                );
            }
        }

        /*$media_distinct_count_check = DB::table('media_play')
                                        ->select(['media_id as media_id'])
                                        ->groupBy('media_id')
                                        ->havingRaw('COUNT(media_id) > ?', [1])
                                        ->pluck('media_id');

        $all_medias = DB::table('media')->select('media.*','media_authors.image')->leftjoin('media_authors','media.author_id','=','media_authors.id')->where('media_approve','=','1')->where('play_count','>',1)->whereIn('media.id', $media_distinct_count_check)->orderBy('updated_at', 'asc')->get();

        if ($all_medias) {
            foreach ($all_medias as $item) {
                $result12 = substr($item->attachment_name, 0, 5);
                if ($result12 == 'https') {
                    $attachment_file = $item->attachment_name;
                } else {
                    $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                }
                if($item->image!=null){
                    $thumb = url('uploads/author/').'/'.$item->image;
                }else{
                    $thumb='';
                }
                $data['popular_tracks'][] = array(
                    'id' => $item->id,
                    'title' => $item->title,
                    'type' => $item->type,
                    'duration' => $item->duration,
                    'attachment_name' => $attachment_file,
                    'play_count'=>$item->play_count,
                    'image'=>$thumb
                );
            }
        }*/

        /*=====  End of Popular Tracks  ======*/

        /*=======================================
        =            Recently Played            =
        =======================================*/

        if ($request->user_id == '' || $request->user_id == null) {
            $recent_media_count = DB::table('media_play')->where('machine_id', $request->machine_id)->count();
            if ($recent_media_count > 0) {
                $recent_media = DB::table('media_play')->where('machine_id', $request->machine_id)->orderBy('updated_at', 'DESC')->get()->unique('media_id');
                foreach ($recent_media as $recent_medias) {
                    $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name', 'media_authors.id as author_id', 'user_media.id as user_media_id')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')->where('media.id', $recent_medias->media_id)->get();
                    foreach ($items as $item) {
                        $result12 = substr($item->attachment_name, 0, 5);
                        if ($result12 == 'https') {
                            $attachment_file = $item->attachment_name;
                        } else {
                            $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        }
                        if ($item->image != null) {
                            $thumb = url('uploads/author/') . '/' . $item->image;
                        } else {
                            $thumb = '';
                        }
                        $data['recently_played'][] = array(
                            'id'              => $item->id,
                            'shabad_id'       => $item->shabad_id,
                            'title'           => $item->title,
                            'author'           => $item->name,
                            'type'            => $item->type,
                            'duration'        => $item->duration,
                            'attachment_name' => $attachment_file,
                            'image'           => $thumb,
                            'user_media_id'   => $item->user_media_id,
                            'favourite'       => (in_array($item->id, $fav_media_array)) ? 1 : 0,
                            'author_id'       => $item->author_id,
                        );
                    }
                }
            }
        } else {
            $recent_media_count = DB::table('media_play')->where('user_id', $request->user_id)->count();
            if ($recent_media_count > 0) {
                $recent_media = DB::table('media_play')->where('user_id', $request->user_id)->orderBy('updated_at', 'DESC')->get()->unique('media_id');
                foreach ($recent_media as $recent_medias) {
                    $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name', 'user_media.id as user_media_id')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')->where('media.id', $recent_medias->media_id)->get();
                    foreach ($items as $item) {
                        $result12 = substr($item->attachment_name, 0, 5);
                        if ($result12 == 'https') {
                            $attachment_file = $item->attachment_name;
                        } else {
                            $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        }
                        if ($item->image != null) {
                            $thumb = url('uploads/author/') . '/' . $item->image;
                        } else {
                            $thumb = '';
                        }
                        $data['recently_played'][] = array(
                            'id'              => $item->id,
                            'shabad_id'       => $item->shabad_id,
                            'title'           => $item->title,
                            'author'           => $item->name,
                            'type'            => $item->type,
                            'duration'        => $item->duration,
                            'attachment_name' => $attachment_file,
                            'image'           => $thumb,
                            'user_media_id'   => $item->user_media_id,
                            'favourite'       => (in_array($item->id, $fav_media_array)) ? 1 : 0
                        );
                    }
                }
            }
        }

        /*=====  End of Recently Played  ======*/

        /*=========================================
        =            Featured Podcasts            =
        =========================================*/

        $all_media = DB::table('podcast_media')->select('podcast_media.*', 'podcast_media_authors.name')->leftjoin('podcast_media_authors', 'podcast_media.author_id', '=', 'podcast_media_authors.id')->where('podcast_media.status', '1')->where('podcast_media.featured', 1)->get();
        //medias
        if (count($all_media) > 0) {
            foreach ($all_media as $all_medias) {
                $result12 = substr($all_medias->attachment_name, 0, 5);
                if ($result12 == 'https') {
                    $attachment_file = $all_medias->attachment_name;
                } else {
                    $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $all_medias->attachment_name;
                }

                if ($all_medias->thumbnail == null || $all_medias->thumbnail == '') {
                    $thu_image = '';
                } else {
                    $thu_image = url('uploads/thumbnail/') . '/' . $all_medias->thumbnail;
                }
                $data['featured_podcasts'][] = array(
                    'id'                     => $all_medias->id,
                    'title'                  => $all_medias->title,
                    'author'                  => $all_medias->name,
                    'featured'               => $all_medias->featured,
                    'duration'               => $all_medias->duration,
                    'featured_display_order' => $all_medias->featured_display_order,
                    'media'                  => $attachment_file,
                    'thumbnail'              => $thu_image,
                );
            }
        }

        /*=====  End of Featured Podcasts  ======*/

        /*=====================================
        =            Today Podcast            =
        =====================================*/

        $final_feeds_count = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->count();
        if ($final_feeds_count > 0) {
            $final_feeds = DB::table('podcast_media')->select('podcast_media.*', 'podcast_media_authors.name')->leftjoin('podcast_media_authors', 'podcast_media.author_id', '=', 'podcast_media_authors.id')->where('podcast_media.today_approval', '1')->orderBy('id', 'desc')->first();
            $shabad_id = $final_feeds->shabad_id;
            $status = $this->getCommentrybyshabadID($shabad_id);

            $result12 = substr($final_feeds->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $attachment_file = $final_feeds->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
            }
            //             //s3 starts here
            //             $exists = Storage::disk('s3archive')->exists($final_feeds->attachment_name);
            //
            //             if($exists){
            //              $attachment_file = Storage::disk('s3archive')->url($final_feeds->attachment_name);
            //             }else{
            //                 $attachment_file = $final_feeds->attachment_name;
            //             }
            //s3 ends here
            $data['today_podcast'] = array(
                'id' => $final_feeds->id,
                'title' => $final_feeds->title,
                'author' => $final_feeds->name,
                'description' => $final_feeds->description,
                'media_data' => $attachment_file,
                'updated_at' => $final_feeds->updated_at,
                'duration' => $final_feeds->duration,
                'time' => $final_feeds->duration,
                'commentry_desc' => $status,
                'commentry_status' => true,
                'image' => 'https://dev.khojgurbani.org/assets/image/slider_1.jpg'
            );
        } else {
            $final_feeds = DB::table('podcast_media')->select('podcast_media.*', 'podcast_media_authors.name')->leftjoin('podcast_media_authors', 'podcast_media.author_id', '=', 'podcast_media_authors.id')->orderBy('id', 'desc')->first();

            $shabad_id = $final_feeds->shabad_id;
            $status = $this->getCommentrybyshabadID($shabad_id);

            $result12 = substr($final_feeds->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $attachment_file = $final_feeds->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
            }
            //s3 starts here
            $exists = Storage::disk('s3archive')->exists($final_feeds->attachment_name);

            if ($exists) {
                $attachment_file = Storage::disk('s3archive')->url($final_feeds->attachment_name);
            } else {
                $attachment_file = $final_feeds->attachment_name;
            }
            //s3 ends here
            $data['today_podcast'][] = array(
                'id' => $final_feeds->id,
                'title' => $final_feeds->title,
                'author' => $final_feeds->name,
                'description' => $final_feeds->description,
                'media_data' => $attachment_file,
                'updated_at' => $final_feeds->updated_at,
                'time' => $final_feeds->duration,
                'duration' => $final_feeds->duration,
                'commentry_status' => $status,
                'image' => 'https://dev.khojgurbani.org/assets/image/slider_1.jpg'
            );
        }

        /*=====  End of Today Podcast  ======*/

        /*========================================
        =            Featured Authors            =
        ========================================*/

        $items = DB::table('media_authors')->where('featured', '1')->where('status', '1')->orderBy('featured_display_order', 'asc')->get();

        if (count($items) > 0) {
            foreach ($items as $item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/author/') . '/' . $item->image;
                }

                $data['featured_authors'][] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'status' => $item->status,
                    'attachment_name' => $category_image
                );
            }
        }

        /*=====  End of Featured Authors  ======*/

        /*=======================================
        =            Featured Tracks            =
        =======================================*/

        $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name', 'user_media.id as user_media_id')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')->where('media.featured', '1')->orderBy('featured_display_order', 'asc')->paginate(10);
        if (count($items) > 0) {
            foreach ($items as $item) {
                $result12 = substr($item->attachment_name, 0, 5);
                if ($result12 == 'https') {
                    $attachment_file = $item->attachment_name;
                } else {
                    $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                }
                if ($item->image != null) {
                    $thumb = url('uploads/author/') . '/' . $item->image;
                } else {
                    $thumb = '';
                }
                $data['featured_tracks'][] = array(
                    'id'              => $item->id,
                    'shabad_id'       => $item->shabad_id,
                    'title'           => $item->title,
                    'author_name'     => $item->name,
                    'type'            => $item->type,
                    'duration'        => $item->duration,
                    'attachment_name' => $attachment_file,
                    'image'           => $thumb,
                    'favourite'       => (in_array($item->id, $fav_media_array)) ? 1 : 0,
                    'user_media_id' => $item->user_media_id
                );
            }
        }

        /*=====  End of Featured Tracks  ======*/


        return response()->json([
            'status' => '200',
            'message' => 'Data found',
            'result' => $data
        ], 200);
    }

    public function home_skip(Request $request)
    {
        # featured_categories
        # featured_podcast_categories
        # popular_tracks
        # recently_played
        # featured_podcasts
        # today_podcast
        # featured_authors
        # featured_tracks

        $data = array();
        $data['featured_categories'] = [];
        $data['featured_podcast_categories'] = [];
        $data['popular_tracks'] = [];
        $data['recently_played'] = [];
        $data['featured_podcasts'] = [];
        $data['today_podcast'] = [];
        $data['featured_authors'] = [];
        $data['featured_tracks'] = [];

        $items = DB::table('categories')->where('featured', '1')->orderBy('featured_display_order', 'asc')->paginate(10);

        if (count($items) > 0) {
            foreach ($items as $item) {
                $sub_cat_counts = DB::table('subcategories')->where('category_id', $item->id)->where('status', '1')->count();
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/category/') . '/' . $item->image;
                }
                $data['featured_categories'][] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'slug' => $item->slug,
                    'sub_category_count' => $sub_cat_counts,
                    'attachment_name' => $category_image,
                );
            }
        } else {
            $data['featured_categories'] = [];
        }

        /*===================================================
        =            Featured Podcast Categories            =
        ===================================================*/

        $all_cats = DB::table('podcast_categories')->where('status', '1')->where('featured', '1')->get();

        if (count($all_cats) > 0) {
            foreach ($all_cats as $all_cat) {
                if ($all_cat->image == null || $all_cat->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/podcast_category/') . '/' . $all_cat->image;
                }
                $sub_pod_count = DB::table('podcast_subcategories')->where('category_id', $all_cat->id)->where('status', '1')->count();
                if ($sub_pod_count > 0) {
                    $sub_pod_data1 = DB::table('podcast_subcategories')->where('category_id', $all_cat->id)->where('status', '1')->get();
                    foreach ($sub_pod_data1 as $item) {
                        if ($item->image == null || $item->image == '') {
                            $category_image = '';
                        } else {
                            $category_image = url('uploads/podcast_category/') . '/' . $item->image;
                        }
                        $sub_pod_data[] = array(
                            'id'              => $item->id,
                            'name'            => $item->name,
                            'status'          => $item->status,
                            'attachment_name' => $category_image,
                            'category_id'     => $item->category_id,
                        );
                    }
                } else {
                    $sub_pod_data = [];
                }
                $data['featured_podcast_categories'][] = array(
                    'id'                     => $all_cat->id,
                    'title'                  => $all_cat->name,
                    'description'            => $all_cat->description,
                    'category_image'         => $category_image,
                    'featured'               => $all_cat->featured,
                    'featured_display_order' => $all_cat->featured_display_order,
                    'podcast_subcats'        => $sub_pod_data
                );
            }
        } else {
            $data['featured_podcast_categories'] = [];
        }

        /*=====  End of Featured Podcast Categories  ======*/

        /*======================================
        =            Popular Tracks            =
        ======================================*/

        $media_distinct_count_check = DB::table('media_play')
            ->select(['media_id as media_id'])
            ->groupBy('media_id')
            ->havingRaw('COUNT(media_id) > ?', [1])
            ->pluck('media_id');
        $all_medias = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->where('media_approve', '=', '1')->where('play_count', '>', 1)->whereIn('media.id', $media_distinct_count_check)->orderBy('updated_at', 'asc')->paginate(60);
        /*$all_medias = DB::table('media')->where('media_approve','=','1')->where('play_count','>',1)->whereIn('id', $media_distinct_count_check)->paginate(60);*/

        if (count($all_medias) > 0) {
            foreach ($all_medias as $k => $all_media) {
                if ($all_media->attachment_name == null || $all_media->attachment_name == '') {
                    $media_url = '';
                } else {
                    if ($all_media->type == 'AUDIO') {
                        $media_url = url('uploads/media/') . '/' . $all_media->attachment_name;
                    } else {
                        $media_url = $all_media->attachment_name;
                    }
                }
                $media_distinct_count = DB::table('media_play')->where('media_id', $all_media->id)->count();
                @$pageID = DB::table('tblscripture')->select('Page')->where('ShabadID', $all_media->shabad_id)->min('Page');

                //   echo "<pre>";
                //     print_r($pageID);die;
                //                $result [] = array(
                //                    'media_id' => $all_media->id,
                //                    'media_title' => $all_media->title,
                //                    'media_url' => $media_url,
                //                    'media_start_date' => $all_media->play_start_date,
                //                    'media_start_time' => $all_media->play_start_time,
                //                    'media_last_date' => $all_media->play_last_date,
                //                    'media_last_time' => $all_media->play_last_time,
                //                    'media_distinct_count' => $media_distinct_count,
                //                );
                $all_medias[$k]->page_id              = $pageID;
                $all_medias[$k]->media_url            = $media_url;
                $all_medias[$k]->media_distinct_count = $media_distinct_count;
            }

            $all_medias->setCollection(
                collect(
                    collect($all_medias->items())->sortByDesc('media_distinct_count')
                )->values()
            );
        }

        if ($all_medias) {
            foreach ($all_medias as $item) {
                $result12 = substr($item->attachment_name, 0, 5);
                if ($result12 == 'https') {
                    $attachment_file = $item->attachment_name;
                } else {
                    $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                }
                if ($item->image != null) {
                    $thumb = url('uploads/author/') . '/' . $item->image;
                } else {
                    $thumb = '';
                }
                $data['popular_tracks'][] = array(
                    'id'              => $item->id,
                    'shabad_id'       => $item->shabad_id,
                    'title'           => $item->title,
                    'author'           => $item->name,
                    'type'            => $item->type,
                    'duration'        => $item->duration,
                    'attachment_name' => $attachment_file,
                    'play_count'      => $item->media_distinct_count,
                    'image'           => $thumb,
                    'favourite'       => 0
                );
            }
        }

        /*$media_distinct_count_check = DB::table('media_play')
                                        ->select(['media_id as media_id'])
                                        ->groupBy('media_id')
                                        ->havingRaw('COUNT(media_id) > ?', [1])
                                        ->pluck('media_id');

        $all_medias = DB::table('media')->select('media.*','media_authors.image')->leftjoin('media_authors','media.author_id','=','media_authors.id')->where('media_approve','=','1')->where('play_count','>',1)->whereIn('media.id', $media_distinct_count_check)->orderBy('updated_at', 'asc')->get();

        if ($all_medias) {
            foreach ($all_medias as $item) {
                $result12 = substr($item->attachment_name, 0, 5);
                if ($result12 == 'https') {
                    $attachment_file = $item->attachment_name;
                } else {
                    $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                }
                if($item->image!=null){
                    $thumb = url('uploads/author/').'/'.$item->image;
                }else{
                    $thumb='';
                }
                $data['popular_tracks'][] = array(
                    'id' => $item->id,
                    'title' => $item->title,
                    'type' => $item->type,
                    'duration' => $item->duration,
                    'attachment_name' => $attachment_file,
                    'play_count'=>$item->play_count,
                    'image'=>$thumb
                );
            }
        }*/

        /*=====  End of Popular Tracks  ======*/

        /*=======================================
        =            Recently Played            =
        =======================================*/

        if ($request->user_id == '' || $request->user_id == null) {
            $recent_media_count = DB::table('media_play')->where('machine_id', $request->machine_id)->count();
            if ($recent_media_count > 0) {
                $recent_media = DB::table('media_play')->where('machine_id', $request->machine_id)->orderBy('updated_at', 'DESC')->get()->unique('media_id');
                foreach ($recent_media as $recent_medias) {
                    $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->where('media.id', $recent_medias->media_id)->get();
                    foreach ($items as $item) {
                        $result12 = substr($item->attachment_name, 0, 5);
                        if ($result12 == 'https') {
                            $attachment_file = $item->attachment_name;
                        } else {
                            $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        }
                        if ($item->image != null) {
                            $thumb = url('uploads/author/') . '/' . $item->image;
                        } else {
                            $thumb = '';
                        }
                        $data['recently_played'][] = array(
                            'id'              => $item->id,
                            'shabad_id'       => $item->shabad_id,
                            'title'           => $item->title,
                            'author'          => $item->name,
                            'type'            => $item->type,
                            'duration'        => $item->duration,
                            'attachment_name' => $attachment_file,
                            'image'           => $thumb,
                            'favourite'       => 0
                        );
                    }
                }
            }
        } else {
            $recent_media_count = DB::table('media_play')->where('user_id', $request->user_id)->count();
            if ($recent_media_count > 0) {
                $recent_media = DB::table('media_play')->where('user_id', $request->user_id)->orderBy('updated_at', 'DESC')->get()->unique('media_id');
                foreach ($recent_media as $recent_medias) {
                    $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->where('media.id', $recent_medias->media_id)->get();
                    foreach ($items as $item) {
                        $result12 = substr($item->attachment_name, 0, 5);
                        if ($result12 == 'https') {
                            $attachment_file = $item->attachment_name;
                        } else {
                            $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        }
                        if ($item->image != null) {
                            $thumb = url('uploads/author/') . '/' . $item->image;
                        } else {
                            $thumb = '';
                        }
                        $data['recently_played'][] = array(
                            'id'              => $item->id,
                            'shabad_id'       => $item->shabad_id,
                            'title'           => $item->title,
                            'author'          => $item->name,
                            'type'            => $item->type,
                            'duration'        => $item->duration,
                            'attachment_name' => $attachment_file,
                            'image'           => $thumb,
                            'favourite'       => 0
                        );
                    }
                }
            }
        }

        /*=====  End of Recently Played  ======*/

        /*=========================================
        =            Featured Podcasts            =
        =========================================*/

        $all_media = DB::table('podcast_media')->select('podcast_media.*', 'podcast_media_authors.name')->leftjoin('podcast_media_authors', 'podcast_media.author_id', '=', 'podcast_media_authors.id')->where('podcast_media.status', '1')->where('podcast_media.featured', 1)->get();
        //medias
        if (count($all_media) > 0) {
            foreach ($all_media as $all_medias) {
                $result12 = substr($all_medias->attachment_name, 0, 5);
                if ($result12 == 'https') {
                    $attachment_file = $all_medias->attachment_name;
                } else {
                    $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $all_medias->attachment_name;
                }

                if ($all_medias->thumbnail == null || $all_medias->thumbnail == '') {
                    $thu_image = '';
                } else {
                    $thu_image = url('uploads/thumbnail/') . '/' . $all_medias->thumbnail;
                }
                $data['featured_podcasts'][] = array(
                    'id'                     => $all_medias->id,
                    'title'                  => $all_medias->title,
                    'author'                 => $all_medias->name,
                    'duration'               => $all_medias->duration,
                    'featured'               => $all_medias->featured,
                    'featured_display_order' => $all_medias->featured_display_order,
                    'media'                  => $attachment_file,
                    'thumbnail'              => $thu_image,
                );
            }
        }

        /*=====  End of Featured Podcasts  ======*/

        /*=====================================
        =            Today Podcast            =
        =====================================*/

        $final_feeds_count = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->count();
        if ($final_feeds_count > 0) {
            $final_feeds = DB::table('podcast_media')->select('podcast_media.*', 'podcast_media_authors.name')->leftjoin('podcast_media_authors', 'podcast_media.author_id', '=', 'podcast_media_authors.id')->where('podcast_media.today_approval', '1')->orderBy('id', 'desc')->first();

            $shabad_id = $final_feeds->shabad_id;
            $status = $this->getCommentrybyshabadID($shabad_id);

            $result12 = substr($final_feeds->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $attachment_file = $final_feeds->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
            }
            //             //s3 starts here
            //             $exists = Storage::disk('s3archive')->exists($final_feeds->attachment_name);
            //
            //             if($exists){
            //              $attachment_file = Storage::disk('s3archive')->url($final_feeds->attachment_name);
            //             }else{
            //                 $attachment_file = $final_feeds->attachment_name;
            //             }
            //s3 ends here
            $data['today_podcast'] = array(
                'id'               => $final_feeds->id,
                'title'            => $final_feeds->title,
                'author'           => $final_feeds->name,
                'description'      => $final_feeds->description,
                'media_data'       => $attachment_file,
                'updated_at'       => $final_feeds->updated_at,
                'duration'         => $final_feeds->duration,
                'time'             => $final_feeds->duration,
                'commentry_desc'   => $status,
                'commentry_status' => true,
                'image'            => 'https://dev.khojgurbani.org/assets/image/slider_1.jpg'
            );
        } else {
            $final_feeds = DB::table('podcast_media')->select('podcast_media.*', 'podcast_media_authors.name')->leftjoin('podcast_media_authors', 'podcast_media.author_id', '=', 'podcast_media_authors.id')->orderBy('id', 'desc')->first();
            $shabad_id = $final_feeds->shabad_id;
            $status = $this->getCommentrybyshabadID($shabad_id);

            $result12 = substr($final_feeds->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $attachment_file = $final_feeds->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
            }
            //s3 starts here
            $exists = Storage::disk('s3archive')->exists($final_feeds->attachment_name);

            if ($exists) {
                $attachment_file = Storage::disk('s3archive')->url($final_feeds->attachment_name);
            } else {
                $attachment_file = $final_feeds->attachment_name;
            }
            //s3 ends here
            $data['today_podcast'][] = array(
                'id'               => $final_feeds->id,
                'title'            => $final_feeds->title,
                'author'           => $final_feeds->name,
                'description'      => $final_feeds->description,
                'media_data'       => $attachment_file,
                'updated_at'       => $final_feeds->updated_at,
                'time'             => $final_feeds->duration,
                'duration'         => $final_feeds->duration,
                'commentry_status' => $status,
                'image'            => 'https://dev.khojgurbani.org/assets/image/slider_1.jpg'
            );
        }

        /*=====  End of Today Podcast  ======*/

        /*========================================
        =            Featured Authors            =
        ========================================*/

        $items = DB::table('media_authors')->where('featured', '1')->where('status', '1')->orderBy('featured_display_order', 'asc')->get();

        if (count($items) > 0) {
            foreach ($items as $item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/author/') . '/' . $item->image;
                }

                $data['featured_authors'][] = array(
                    'id'              => $item->id,
                    'name'            => $item->name,
                    'status'          => $item->status,
                    'attachment_name' => $category_image
                );
            }
        }

        /*=====  End of Featured Authors  ======*/

        /*=======================================
        =            Featured Tracks            =
        =======================================*/

        $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name', 'media_authors.id as author_id', 'user_media.id as user_media_id', 'playlist_media.media_id as playlist_media_id')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->leftjoin('playlist_media', 'media.id', '=', 'playlist_media.media_id')->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')->where('media.featured', '1')->orderBy('featured_display_order', 'asc')->paginate(10);
        if (count($items) > 0) {
            foreach ($items as $item) {
                $result12 = substr($item->attachment_name, 0, 5);
                if ($result12 == 'https') {
                    $attachment_file = $item->attachment_name;
                } else {
                    $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                }
                if ($item->image != null) {
                    $thumb = url('uploads/author/') . '/' . $item->image;
                } else {
                    $thumb = '';
                }
                $data['featured_tracks'][] = array(
                    'id' => $item->id,
                    'shabad_id'       => $item->shabad_id,
                    'title' => $item->title,
                    'author_name' => $item->name,
                    'type' => $item->type,
                    'duration' => $item->duration,
                    'attachment_name' => $attachment_file,
                    'image' => $thumb,
                    'favourite'       => 0,
                    'user_media_id' => $item->user_media_id,
                    'playlist_media_id' => $item->playlist_media_id,
                    'author_id' => $item->author_id
                );
            }
        }

        /*=====  End of Featured Tracks  ======*/


        return response()->json([
            'status' => '200',
            'message' => 'Data found',
            'result' => $data
        ], 200);
    }

    public function recently_played(Request $request)
    {
        if ($request->user_id == '' || $request->user_id == null) {
            $fav_media_array = array();
        } else {
            $fav_media_array = $this->fetch_fav_media_ids($request->user_id);

            if (!is_array($fav_media_array)) {
                $fav_media_array = $fav_media_array->toArray();
            }
        }
        $data = array();
        if ($request->user_id == '' || $request->user_id == null) {
            $recent_media_count = DB::table('media_play')->where('machine_id', $request->machine_id)->count();
            if ($recent_media_count > 0) {
                $recent_media = DB::table('media_play')->where('machine_id', $request->machine_id)->orderBy('updated_at', 'DESC')->get()->unique('media_id');
                foreach ($recent_media as $recent_medias) {
                    $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->where('media.id', $recent_medias->media_id)->get();
                    foreach ($items as $item) {
                        $result12 = substr($item->attachment_name, 0, 5);
                        if ($result12 == 'https') {
                            $attachment_file = $item->attachment_name;
                        } else {
                            $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        }
                        if ($item->image != null) {
                            $thumb = url('uploads/author/') . '/' . $item->image;
                        } else {
                            $thumb = '';
                        }
                        $data[] = array(
                            'id'              => $item->id,
                            'shabad_id'       => $item->shabad_id,
                            'title'           => $item->title,
                            'author'          => $item->name,
                            'type'            => $item->type,
                            'duration'        => $item->duration,
                            'attachment_name' => $attachment_file,
                            'img'             => $thumb,
                            'favourite'       => (in_array($item->id, $fav_media_array)) ? 1 : 0
                        );
                    }
                }
            }
        } else {
            $recent_media_count = DB::table('media_play')->where('user_id', $request->user_id)->count();
            if ($recent_media_count > 0) {
                $recent_media = DB::table('media_play')->where('user_id', $request->user_id)->orderBy('updated_at', 'DESC')->get()->unique('media_id');
                foreach ($recent_media as $recent_medias) {
                    $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->where('media.id', $recent_medias->media_id)->get();
                    foreach ($items as $item) {
                        $result12 = substr($item->attachment_name, 0, 5);
                        if ($result12 == 'https') {
                            $attachment_file = $item->attachment_name;
                        } else {
                            $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        }
                        if ($item->image != null) {
                            $thumb = url('uploads/author/') . '/' . $item->image;
                        } else {
                            $thumb = '';
                        }
                        $data[] = array(
                            'id'              => $item->id,
                            'shabad_id'       => $item->shabad_id,
                            'title'           => $item->title,
                            'author'           => $item->name,
                            'type'            => $item->type,
                            'duration'        => $item->duration,
                            'attachment_name' => $attachment_file,
                            'img'             => $thumb,
                            'favourite'       => (in_array($item->id, $fav_media_array)) ? 1 : 0
                        );
                    }
                }
            }
        }
        return response()->json([
            'status' => '200',
            'message' => 'Data found',
            'recently_played' => $data
        ], 200);
    }

    public function getCommentrybyshabadID($shabad_id = null)
    {
        @$commentry =  DB::table('commentaries')->where('shabad_id', $shabad_id)->orderBy('id', 'desc')->first()->commentary;
        if (isset($commentry)) {
            return $commentry;
        } else {
            return false;
        }
    }

    /*==================================
    =            Media Play            =
    ==================================*/

    public function media_play(Request $request)
    {
        $media_id   = $request->media_id;
        $user_id    = $request->user_id;
        $machine_id = $request->machine_id;
        $view_date  = $request->view_date;

        if ($media_id == '' || $machine_id == '' || $view_date == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        $media_user_null = DB::table('media_play')->where('machine_id', $machine_id)->where('media_id', $media_id)->whereNull('user_id')->get();
        $media_get_data = DB::table('media')->where('id', $media_id)->first();

        if (!$media_get_data) {
            return response()->json([
                'status' => '404',
                'message' => 'Media not found'
            ], 404);
        }


        if ($media_get_data->play_start_date == '' || $media_get_data->play_start_time == '') {
            $play_start_date = date("Y-m-d");
            $play_start_time = date("h:i:sa");
            DB::table('media')->where('id', $media_id)->update(['play_start_date' => $play_start_date, 'play_start_time' => $play_start_time]);
        }

        $play_last_date = date("Y-m-d");
        $play_last_time = date("h:i:sa");

        DB::table('media')->where('id', $media_id)->update(['play_last_date' => $play_last_date, 'play_last_time' => $play_last_time]);

        if ($media_get_data->play_count == 0) {
            $media_play_count = '1';
        } else {
            $media_play_count = $media_get_data->play_count + '1';
        }

        DB::table('media')->where('id', $media_id)->update(['play_count' => $media_play_count]);

        if ($user_id != '') {
            if (count($media_user_null) > 0) {
                DB::table('media_play')->where('id', $media_user_null[0]->id)->update([
                    'user_id' => $request->user_id
                ]);
                return response()->json([
                    'status'   => '200',
                    'message'  => 'Media ID generated',
                    'media_id' => $media_id
                ], 200);
            }
        }

        if ($user_id != '') {
            $media_machine_null = DB::table('media_play')->where('machine_id', $machine_id)->where('media_id', $media_id)->where('user_id', $user_id)->get();
        } else {
            $media_machine_null = DB::table('media_play')->where('machine_id', $machine_id)->where('media_id', $media_id)->get();
        }

        if (count($media_machine_null) > 0) {
            DB::table('media_play')->where('machine_id', $machine_id)->where('media_id', $media_id)->update([
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            return response()->json([
                'status' => '200',
                'message' => 'Media ID generated',
                'media_id' => $media_id
            ], 200);
        } else {
            DB::table('media_play')->insert([
                'media_id'   => $media_id,
                'user_id'    => $user_id,
                'machine_id' => $machine_id,
                'view_date'  => $view_date,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            return response()->json([
                'status'   => '200',
                'message'  => 'Media ID generated',
                'media_id' => $media_id
            ], 200);
        }
    }

    /*=====  End of Media Play  ======*/

    /*==================================
    =            Media Fav.            =
    ==================================*/

    public function media_fav(Request $request)
    {
        $media_id   = $request->media_id;
        $user_id    = $request->user_id;
        $machine_id = $request->machine_id;

        if ($media_id == '' || $machine_id == '') {
            return response()->json([
                'status' => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        // $media_check = DB::table('media')->where('id', $media_id)->first();

        // if (!$media_check) {
        //     return response()->json([
        //         'status' => '404',
        //         'message' => 'Media not found'
        //     ], 404);
        // }
        // if ($user_id != '') {
        //     $user_check = DB::table('users')->where('id', $user_id)->first();

        //     if (!$user_check) {
        //         return response()->json([
        //             'status' => '404',
        //             'message' => 'User not found'
        //         ], 404);
        //     }
        // }

        // $machine_check = DB::table('media_play')->where('machine_id', $machine_id)->first();
        // if (!$machine_check) {
        //     return response()->json([
        //         'status' => '404',
        //         'message' => 'Machine not found'
        //     ], 404);
        // }

        $media_fav_check = DB::table('user_media')
            ->where('media_id', $media_id)
            ->where(function ($query) use ($user_id, $machine_id) {
                $query->where('user_id', $user_id)
                    ->orWhere('machine_id', $machine_id);
            })
            ->first();

        if (!$media_fav_check) {
            DB::table('user_media')->insert([
                'media_id' => $media_id,
                'user_id' => $user_id,
                'machine_id' => $machine_id
            ]);
            return response()->json([
                'status'   => '200',
                'message'  => 'Song marked as favourite',
                'media_id' => $media_id,
                'user_id'  => $user_id,
                'machine_id' => $machine_id,
                'favourite' => 1
            ], 200);
        } else {
            DB::table('user_media')
                ->where('media_id', $media_id)
                ->where(function ($query) use ($user_id, $machine_id) {
                    $query->where('user_id', $user_id)
                        ->orWhere('machine_id', $machine_id);
                })
                ->delete();

            return response()->json([
                'status'   => '200',
                'message'  => 'Song removed from favourites',
                'media_id' => $media_id,
                'user_id'  => $user_id,
                'machine_id' => $machine_id,
                'favourite' => 0
            ], 200);
        }
    }


    // public function media_fav_check(Request $request)
    // {
    //     $user_id    = $request->user_id;
    //     $machine_id = $request->machine_id;

    //     $media_fav_check = DB::table('user_media')
    //         ->where('machine_id', $machine_id)
    //         ->orWhere('user_id', $user_id)
    //         ->get();


    //     return response()->json([
    //         'status'   => '200',
    //         'message'  => 'all songs',
    //         'favorite_id' => $media_fav_check,
    //     ], 200);
    // }

    public function media_fav_list(Request $request)
    {
        $data    = array();
        if ($request->user_id) $user_id = $request->user_id;
        if ($request->machine_id) $machine_id = $request->machine_id;

        if ($user_id == '' && $machine_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        // $machine_check = DB::table('media_play')->where('machine_id', $machine_id)->first();

        // if (!$machine_check) {
        //     return response()->json([
        //         'status'  => '404',
        //         'message' => 'Machine not found'
        //     ], 404);
        // }

        $fav_media_count = DB::table('user_media')->where('user_id', $request->user_id)->orWhere('machine_id', $request->machine_id)->count();

        if ($fav_media_count > 0) {
            $fav_media = DB::table('user_media')->where('user_id', $request->user_id)->orWhere('machine_id', $request->machine_id)->get();
            foreach ($fav_media as $fav_medias) {
                $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name', 'media_authors.id as author_id', 'user_media.id as user_media_id')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')->where('media.id', $fav_medias->media_id)->get();
                foreach ($items as $item) {
                    $result12 = substr($item->attachment_name, 0, 5);
                    if ($result12 == 'https') {
                        $attachment_file = $item->attachment_name;
                    } else {
                        $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                    }

                    if ($item->image != null) {
                        $thumb = url('uploads/author/') . '/' . $item->image;
                    } else {
                        $thumb = '';
                    }

                    $data[] = array(
                        'id'              => $item->id,
                        'shabad_id'       => $item->shabad_id,
                        'title'           => $item->title,
                        'author'           => $item->name,
                        'type'            => $item->type,
                        'duration'        => $item->duration,
                        'attachment_name' => $attachment_file,
                        'image'           => $thumb,
                        'user_media_id'   => $item->user_media_id,
                        'author_id'       => $item->author_id
                    );
                }
            }
        }

        return response()->json([
            'status'   => '200',
            'message'  => 'Data found',
            'fav_list' => $data
        ], 200);
    }

    public function fetch_fav_media_ids($user_id = NULL)
    {
        $fav_medias = array();

        if ($user_id != NULL) {
            $user_check = DB::table('users')->where('id', $user_id)->first();

            if ($user_check) {
                $fav_medias = DB::table('media_play')->select('media_id')->where('user_id', $user_id)->pluck('media_id');
            }
        }

        return $fav_medias;
    }

    /*=====  End of Media Fav.  ======*/

    /*=====================================
    =            Media Authors            =
    =====================================*/

    public function media_authors(Request $request)
    {
        $data  = array();

        if ($request->page == 'All') {
            $items = DB::table('media_authors')->where('status', '1')->orderBy('name', 'asc')->get();
            $items = $items->map(function ($message, $key) {
                $message->image = url('uploads/author/') . '/' . $message->image;
                return $message;
            });

            $data['data'] = $items;
            return response()->json([
                'status'  => '200',
                'message' => 'Data found',
                'result'  => $data
            ], 200);
        } else {
            $items = DB::table('media_authors')->where('status', '1')->orderBy('name', 'asc')->paginate();
            $items->getCollection()->transform(function ($product) {
                $product->image = url('uploads/author/') . '/' . $product->image;
                return $product;
            });

            return response()->json([
                'status'  => '200',
                'message' => 'Data found',
                'result'  => $items
            ], 200);
        }


        /*if (count($items) > 0) {
            foreach ($items as $item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/author/') . '/' . $item->image;
                }

                $data[] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'status' => $item->status,
                    'attachment_name' => $category_image
                );
            }
        }*/
    }

    /*=====  End of Media Authors  ======*/

    /*===============================================
    =            Podcast Category Detail            =
    ===============================================*/

    public function resource_category_podmedia_new(Request $request, $id)
    {
        $data = array();
        $cat_medias = DB::table('podcast_media_categories')->where('category_id', $id)->orderBy('media_id')->get();

        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('podcast_media')->where('id', $cat_media->media_id)->where('status', '1')->first();
            }

            $itemd_data = array_filter($items);

            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {
                    if ($item->attachment_name == null || $item->attachment_name == '') {
                        $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $result_str = substr($item->attachment_name, 0, 8);
                            if ($result_str == 'https://') {
                                $media_url = $item->attachment_name;
                            } else {
                                $media_url = url('uploads/podcast_media/') . '/' . $item->attachment_name;
                            }
                        } else {
                            $media_url = $item->attachment_name;
                        }
                    }

                    $data[] = array(
                        'id'                     => $item->id,
                        'title'                  => $item->title,
                        'description'            => $item->description,
                        'type'                   => $item->type,
                        'status'                 => $item->status,
                        'duration'               => $item->duration,
                        'featured'               => $item->featured,
                        'featured_display_order' => $item->featured_display_order,
                        'priority_status'        => $item->priority_status,
                        'priority_order_status'  => $item->priority_order_status,
                        'attachment_name'        => $media_url,
                        'thumbnail'              => url('uploads/thumbnail/') . '/' . $item->thumbnail
                    );
                }
            } else {
                $data = [];
            }
        }

        return response()->json([
            'status'  => '200',
            'message' => 'Data found',
            'result'  => $data
        ], 200);
    }

    /*=====  End of Podcast Category Detail  ======*/

    /*======================================
    =            Media Category            =
    ======================================*/

    public function sub_cats(Request $request, $id)
    {
        $items = DB::table('subcategories')->where('category_id', $id)->where('status', '1')->where('featured', '0')->paginate(10);

        if (count($items) > 0) {
            foreach ($items as $item) {
                if ($item->image == null || $item->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/subcategory/') . '/' . $item->image;
                }
                $data[] = array(
                    'id'              => $item->id,
                    'name'            => $item->name,
                    'slug'            => $item->slug,
                    'attachment_name' => $category_image,
                );
            }
        } else {
            $data = [];
        }

        return response()->json([
            'status'  => '200',
            'message' => 'Data found',
            'result'  => $data
        ], 200);
    }

    public function resource_category_media_new(Request $request, $id)
    {
        //        die('hi');
        $cat_medias = DB::table('media_categories')->where('category_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('media')->select('media.*', 'user_media.id as user_media_id', 'playlist_media.media_id as playlist_media_id')->leftjoin('playlist_media', 'media.id', '=', 'playlist_media.media_id')->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')->where('media.id', $cat_media->media_id)->where('media.status', '1')->first();
            }
            $itemd_data = array_filter($items);

            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {

                    $media_author = DB::table('media_authors')
                        ->where('id', $item->author_id)
                        ->first();

                    if ($item->attachment_name == null || $item->attachment_name == '') {
                        $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $result_str = substr($item->attachment_name, 0, 8);
                            if ($result_str == 'https://') {
                                $media_url = $item->attachment_name;
                            } else {
                                $media_url = url('uploads/media/') . '/' . $item->attachment_name;
                            }
                        } else {
                            $media_url = $item->attachment_name;
                        }

                        if ($media_author->image == '') {
                            $author_image = '';
                        } else {
                            $author_image = url('uploads/author/' . $media_author->image);
                        }
                    }

                    $data[] = array(
                        'id'                       => $item->id,
                        'shabad_id'                => $item->shabad_id,
                        'title'                    => $item->title,
                        'type'                     => $item->type,
                        'status'                   => $item->status,
                        'duration'                 => $item->duration,
                        'featured'                 => $item->featured,
                        'featured_display_order'   => $item->featured_display_order,
                        'priority_status'          => $item->priority_status,
                        'priority_order_status'    => $item->priority_order_status,
                        'attachment_name'          => $media_url,
                        'author_image'             => $author_image,
                        'author_name'              => $media_author->name,
                        'author_name_without_bhai' => str_replace('Bhai ', '', $media_author->name),
                        'user_media_id'            => $item->user_media_id,
                        'playlist_media_id'        => $item->playlist_media_id,
                        'author_id'                => $media_author->id
                    );
                }

                $c      = collect($data);
                $sorted = $c->sortBy('author_name');
                $data   = $sorted->values()->toArray();
            } else {
                $data = [];
            }
        } else {
            $data = [];
        }
        return response()->json([
            'status'  => '200',
            'message' => 'Data found',
            'result'  => $data
        ], 200);
    }

    /*=====  End of Media Category  ======*/

    /*===========================================
    =            Media Artist Detail            =
    ===========================================*/

    public function resource_subcategory_media_new(Request $request, $id)
    {
        if ($request->user_id == '' || $request->user_id == null) {
            $sub_cat_fav_array = array();
        } else {
            $sub_cat_fav_array = $this->fetch_fav_sub_cat_ids($request->user_id)->toArray();
        }

        $cat_medias = DB::table('media_subcategories')->where('subcategory_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('media')->select('media.*', 'user_media.id as user_media_id', 'playlist_media.media_id as playlist_media_id')->leftjoin('playlist_media', 'media.id', '=', 'playlist_media.media_id')->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')->where('media.id', $cat_media->media_id)->where('media.status', '1')->first();
            }
            $itemd_data = array_filter($items);

            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {

                    $media_author = DB::table('media_authors')
                        ->where('id', $item->author_id)
                        ->first();

                    if ($item->attachment_name == null || $item->attachment_name == '') {
                        $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $result_str = substr($item->attachment_name, 0, 8);
                            if ($result_str == 'https://') {
                                $media_url = $item->attachment_name;
                            } else {
                                $media_url = url('uploads/media/') . '/' . $item->attachment_name;
                            }
                        } else {
                            $media_url = $item->attachment_name;
                        }

                        if ($media_author->image == '') {
                            $author_image = '';
                        } else {
                            $author_image = url('uploads/author/' . $media_author->image);
                        }
                    }

                    $data[] = array(
                        'id'                     => $item->id,
                        'shabad_id'              => $item->shabad_id,
                        'title'                  => $item->title,
                        'author'                 => $media_author->name,
                        'type'                   => $item->type,
                        'status'                 => $item->status,
                        'duration'               => $item->duration,
                        'featured'               => $item->featured,
                        'featured_display_order' => $item->featured_display_order,
                        'priority_status'        => $item->priority_status,
                        'priority_order_status'  => $item->priority_order_status,
                        'attachment_name'        => $media_url,
                        'author_image'           => $author_image,
                        'user_media_id'          => $item->user_media_id,
                        'playlist_media_id'      => $item->playlist_media_id,
                        'author_id'              => $media_author->id
                    );
                }

                $c      = collect($data);
                $sorted = $c->sortBy('priority_order_status');
                $data = $sorted->values()->toArray();
            } else {
                $data = [];
            }
        } else {
            $data = [];
        }

        return response()->json([
            'status'  => '200',
            'favourite'  => (in_array($id, $sub_cat_fav_array)) ? 1 : 0,
            'message' => 'Data found',
            'result'  => $data
        ], 200);
    }

    public function featured_artist_gurbani(Request $request, $id)
    {
        if ($request->user_id == '' || $request->user_id == null) {
            $fav_media_array = array();
            $artist_fav_media_array = array();
        } else {
            $fav_media_array = $this->fetch_fav_media_ids($request->user_id);
            if (!is_array($fav_media_array)) {
                $fav_media_array = $fav_media_array->toArray();
            }
            $artist_fav_media_array = $this->fetch_fav_artist_ids($request->user_id)->toArray();
        }

        $items = DB::table('media')
            ->select('media.*', 'user_media.id as user_media_id', 'playlist_media.media_id as playlist_media_id')
            ->leftjoin('playlist_media', 'media.id', '=', 'playlist_media.media_id')
            ->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')
            ->where('author_id', $id)
            ->orderBy('title')
            ->get();

        if (count($items) > 0) {
            foreach ($items as $item) {
                $media_author = DB::table('media_authors')
                    ->where('id', $id)
                    ->first();

                $result12 = substr($item->attachment_name, 0, 5);

                if ($result12 == 'https') {
                    $attachment_file = $item->attachment_name;
                } else {
                    $attachment_file =  url('uploads/media/') . $item->attachment_name;
                }

                if ($media_author->image == '') {
                    $author_image = '';
                } else {
                    $author_image = url('uploads/author/' . $media_author->image);
                }

                if (isset($item->shabad_id) && !empty($item->shabad_id)) {
                    $PageID = DB::table('tblscripture')
                        ->select('Page')
                        ->where('ShabadID', $item->shabad_id)
                        ->min('Page');

                    //                    $shabadetail = DB::table('tblscripture')
                    //                                                ->whereIn('tblscripture.id', $translation_ids)
                    //                                                ->where('ShabadID',$item->shabad_id)
                    //                                                ->first();

                    $shabadetail = DB::table('tblscripture')
                        ->where('ShabadID', $item->shabad_id)
                        ->whereExists(function ($query) {
                            $query->select("translation.ScriptureID")
                                ->from('translation')
                                ->whereRaw('translation.ScriptureID = tblscripture.id')
                                ->whereRaw('SahibSinghPunjabi is not null')
                                ->orderBy('ScriptureID');
                        })
                        ->first();

                    foreach ($shabadetail as $key => $value) {
                        $shabadetail->Page = $PageID;
                    }
                } else {
                    $shabadetail = (object) array();
                }

                $data[] = array(
                    'id'                 => $item->id,
                    'shabad_id'          => $item->shabad_id,
                    'title'              => $item->title,
                    'author'              => $media_author->name,
                    'duration'           => $item->duration,
                    'author_name'        => $media_author->name,
                    'author_description' => $media_author->description,
                    'attachment_name'    => $attachment_file,
                    'author_image'       => $author_image,
                    'shabad_detail'      => $shabadetail,
                    'favourite'          => (in_array($item->id, $fav_media_array)) ? 1 : 0,
                    'user_media_id'      => $item->user_media_id,
                    'playlist_media_id'  => $item->playlist_media_id
                );
            }
        } else {
            $data = [];
        }

        return response()->json([
            'status'  => '200',
            'favourite'  => (in_array($id, $artist_fav_media_array)) ? 1 : 0,
            'message' => 'Data found',
            'result'  => $data
        ], 200);
    }

    /*=====  End of Media Artist Detail  ======*/

    /*==============================
    =            Shabad            =
    ==============================*/

    /**
     * Get shabads data with scriptures
     */
    public function getShabad($shabadId, $pageId = null)
    {
        try {
            if ($pageId == null) {
                $pageId = $this->fetch_page($shabadId);

                if ($pageId == $shabadId) {
                    $shabadId = null;
                }
            }

            $pages = $this
                ->scriptureRepo
                ->getScripturePagesForShabad($pageId);

            if (!$shabadId) {
                $shabadId = $pages->first();
            }

            $shabad = $this
                ->shabadrepository
                ->getShabad($shabadId);

            if (!in_array($shabad->id, $pages->toArray())) {
                throw new Exception("Shabad $shabadId is not found in page $pageId", 400);
            }
            return response()->json([
                'status'  => '200',
                'message' => 'Data found',
                'result'  => $shabad,
                'pages'   => $pages
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status'  => '500',
                'message' => $e->getMessage(),
                'result'  => $e->getCode(),
                'pages'  => ''
            ], 500);
        }
    }


    public function fetch_page($shabadid = NULL)
    {
        if ($shabadid != NULL) {
            $page_check = DB::table('tblscripture')->where('ShabadID', $shabadid)->first();

            if ($page_check) {
                $page = DB::table('tblscripture')->select('Page')->where('ShabadID', $shabadid)->pluck('Page');
                return $page;
            }
        }

        return $shabadid;
    }
    /*=====  End of Shabad  ======*/

    /*===================================
    =            Artist Fav.            =
    ===================================*/

    public function artist_fav(Request $request)
    {
        $artist_id = $request->artist_id;
        $user_id   = $request->user_id;
        $machine_id = $request->machine_id;

        if ($artist_id == '' || $machine_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        $artist_check = DB::table('media_authors')->where('id', $artist_id)->first();

        if (!$artist_check) {
            return response()->json([
                'status'  => '404',
                'message' => 'Artist not found'
            ], 404);
        }

        // if ($user_id != '') {
        //     $user_check = DB::table('users')->where('id', $user_id)->first();

        //     if (!$user_check) {
        //         return response()->json([
        //             'status'  => '404',
        //             'message' => 'User not found'
        //         ], 404);
        //     }
        // }

        $machine_check = DB::table('media_play')->where('machine_id', $machine_id)->first();
        if (!$machine_check) {
            return response()->json([
                'status' => '404',
                'message' => 'Machine not found'
            ], 404);
        }

        $artist_fav_check = DB::table('user_singer')
            ->where('singer_id', $artist_id)
            ->where(function ($query) use ($user_id, $machine_id) {
                $query->where('user_id', $user_id)
                    ->orWhere('machine_id', $machine_id);
            })
            ->first();

        if (!$artist_fav_check) {
            DB::table('user_singer')->insert([
                'singer_id' => $artist_id,
                'user_id'   => $user_id,
                'machine_id'   => $machine_id
            ]);
            return response()->json([
                'status'    => '200',
                'message'   => 'Artist marked as favourite',
                'singer_id' => $artist_id,
                'user_id'   => $user_id,
                'machine_id' => $machine_id,
                'favourite' => 1
            ], 200);
        } else {
            DB::table('user_singer')
                ->where('singer_id', $artist_id)
                ->where(function ($query) use ($user_id, $machine_id) {
                    $query->where('user_id', $user_id)
                        ->orWhere('machine_id', $machine_id);
                })
                ->delete();

            return response()->json([
                'status'    => '200',
                'message'   => 'Artist removed from favourites',
                'singer_id' => $artist_id,
                'user_id'   => $user_id,
                'machine_id' => $machine_id,
                'favourite' => 0
            ], 200);
        }
    }

    public function artist_fav_list(Request $request)
    {
        $data    = array();
        if ($request->user_id) $user_id = $request->user_id;
        if ($request->machine_id) $machine_id = $request->machine_id;

        if ($user_id == '' && $machine_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        // $machine_check = DB::table('media_play')->where('machine_id', $machine_id)->first();

        // if (!$machine_check) {
        //     return response()->json([
        //         'status'  => '404',
        //         'message' => 'Machine not found'
        //     ], 404);
        // }

        $fav_artist_count = DB::table('user_singer')->where('machine_id', $request->machine_id)->orWhere('user_id', $request->user_id)->count();

        if ($fav_artist_count > 0) {
            $fav_artists = DB::table('user_singer')->where('user_id', $request->user_id)->orWhere('machine_id', $request->machine_id)->get();
            foreach ($fav_artists as $fav_artist) {
                $items = DB::table('media_authors')
                    ->where('id', $fav_artist->singer_id)
                    ->get();
                foreach ($items as $item) {
                    if ($item->image != null) {
                        $thumb = url('uploads/author/') . '/' . $item->image;
                    } else {
                        $thumb = '';
                    }
                    $data[] = array(
                        'id'          => $item->id,
                        'slug'        => $item->slug,
                        'name'        => $item->name,
                        'description' => $item->description,
                        'image'       => $thumb,
                        'status'      => $item->status,
                        'featured'    => $item->featured,
                        'featured_display_order' => $item->featured_display_order,
                    );
                }
            }
            return response()->json([
                'status'   => '200',
                'message'  => 'Data found',
                'artist_fav_list' => $data
            ], 200);
        }
    }

    public function user_downloads(Request $request)
    {
        $media_id = $request->media_id;
        $podcast_id = $request->podcast_id;
        $user_id   = $request->user_id;
        $machine_id = $request->machine_id;

        // if ($artist_id == '' || $machine_id == '') {
        //     return response()->json([
        //         'status'  => '422',
        //         'message' => 'Insufficient parameters passed'
        //     ], 422);
        // }


        // if ($user_id != '') {
        //     $user_check = DB::table('users')->where('id', $user_id)->first();

        //     if (!$user_check) {
        //         return response()->json([
        //             'status'  => '404',
        //             'message' => 'User not found'
        //         ], 404);
        //     }
        // }

        $machine_check = DB::table('media_play')->where('machine_id', $machine_id)->first();
        if (!$machine_check) {
            return response()->json([
                'status' => '404',
                'message' => 'Machine not found'
            ], 404);
        }

        DB::table('user_download')->insert([
            'media_id' => $media_id,
            'podcast_id' => $podcast_id,
            'user_id'   => $user_id,
            'machine_id'   => $machine_id
        ]);
        return response()->json([
            'status'    => '200',
            'message'   => 'Downloaded',
            'media_id' => $media_id,
            'podcast_id' => $podcast_id,
            'user_id'   => $user_id,
            'machine_id' => $machine_id,
        ], 200);
    }

    // Library Downloads
    public function user_downloads_list(Request $request)
    {
        $data    = array();
        if ($request->user_id) $user_id = $request->user_id;
        if ($request->machine_id) $machine_id = $request->machine_id;

        if ($user_id == '' || $machine_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        $downloads_count = DB::table('user_download')->where('user_id', $request->user_id)->orWhere('machine_id', $request->machine_id)->count();

        if ($downloads_count > 0) {
            $media_down = DB::table('user_download')->where('user_id', $request->user_id)->orWhere('machine_id', $request->machine_id)->get();
            foreach ($media_down as $down) {
                $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name', 'media_authors.id as author_id', 'user_media.id as user_media_id')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')->where('media.id', $down->media_id)->get();
                foreach ($items as $item) {
                    $result12 = substr($item->attachment_name, 0, 5);

                    if ($result12 == 'https') {
                        $attachment_file = $item->attachment_name;
                    } else {
                        $attachment_file = url('uploads/media/') . '/' . $item->attachment_name;
                    }

                    if ($item->image != null) {
                        $thumb = url('uploads/author/') . '/' . $item->image;
                    } else {
                        $thumb = '';
                    }

                    $data[] = array(
                        'id'              => $item->id,
                        'shabad_id'       => $item->shabad_id,
                        'title'           => $item->title,
                        'author'           => $item->name,
                        'type'            => $item->type,
                        'duration'        => $item->duration,
                        'attachment_name' => $attachment_file,
                        'image'           => $thumb,
                        'is_media'        => 1,
                        'user_media_id'   => $item->user_media_id,
                        'author_id'       => $item->author_id
                    );
                }
                $items = DB::table('podcast_media')->where('id', $down->podcast_id)->get();
                // if($down->podcast_id != null)
                // return $items;
                foreach ($items as $item) {

                    $result12 = substr($item->attachment_name, 0, 5);

                    if ($result12 == 'https') {
                        $attachment_file = $item->attachment_name;
                    } else {
                        $attachment_file = url('uploads/podcast_media/') . '/' . $item->attachment_name;
                    }

                    if ($item->thumbnail != null) {
                        $thumb = url('uploads/thumbnail/') . '/' . $item->thumbnail;
                    } else {
                        $thumb = '';
                    }

                    $data[] = array(
                        'id'              => $item->id,
                        'shabad_id'       => $item->shabad_id,
                        'title'           => $item->title,
                        'author'           => '',
                        'type'            => '',
                        'duration'        => $item->duration,
                        'attachment_name' => $attachment_file,
                        'image'           => $thumb,
                        'is_media'        => 0
                    );
                }
            }
        }

        return response()->json([
            'status'   => '200',
            'message'  => 'Data found',
            'media_downloaded' => $data
        ], 200);
    }


    public function fetch_fav_artist_ids($user_id = NULL)
    {
        $fav_artists = array();

        if ($user_id != NULL) {
            $user_check = DB::table('users')->where('id', $user_id)->first();

            if ($user_check) {
                $fav_artists = DB::table('artist_fav')->select('artist_id')->where('user_id', $user_id)->pluck('artist_id');
            }
        }

        return $fav_artists;
    }


    /*=====  End of Artist Fav.  ======*/

    /*====================================
    =            Media Search            =
    ====================================*/

    public function media_search(Request $request)
    {
        if ($_GET['content'] != 'audio') {
            $items = $this->advanceSearchRepository->advancedSearch($request);
            foreach ($items as $key => $value) {
                $PageID            = DB::table('tblscripture')->select('Page')->where('ShabadID', $value->ShabadID)->min('Page');
                $items[$key]->Page = $PageID;
            }

            return response()->json([
                'status'   => '200',
                'message'  => 'Data found',
                'result'   => $this->paginate($items, new AdvancedScriptureTransformer, 'scriptures')
            ], 200);
        } else {
            $items = $this->advanceSearchRepository->advancedSearch($request);
            foreach ($items as $key => $value) {
                $PageID            = DB::table('tblscripture')->select('Page')->where('ShabadID', $value->ShabadID)->min('Page');
                $items[$key]->Page = $PageID;
            }
            $get_shabd_medias = array();
            foreach ($items as $k => $item) {
                $shabad_count = DB::table('media')->where('shabad_id', $item['shabadID'])->count();
                if ($shabad_count == 0) {
                    $items[$k]['data_m'] = array();
                } else {
                    $sbad_id = $item['ShabadID'];
                    @$authorid = $_GET['audio_author_id'];
                    if (isset($authorid)) {
                        $sql = "select * from media where shabad_id=$sbad_id AND tag_id='2' AND author_id=$authorid";
                    } else {
                        $sql = "select * from media where shabad_id=$sbad_id AND tag_id='2'";
                    }
                    $get_shabd_medias = DB::select($sql);
                    foreach ($get_shabd_medias as $yy => $shabad_gets) {
                        $result12   = substr($shabad_gets->attachment_name, 0, 5);
                        $autho_data = DB::table('media_authors')->where('id', $shabad_gets->author_id)->first();
                        if (isset($autho_data) && !empty($autho_data)) {
                            $author_data_name = $autho_data->name;
                        } else {
                            $author_data_name = '';
                        }
                        if ($result12 == 'https') {
                            $attachment_file = $shabad_gets->attachment_name;
                        } else {
                            $attachment_file = url('uploads/media/') . $shabad_gets->attachment_name;
                        }
                        $get_shabd_medias[$yy]->att_n     = $attachment_file;
                        $get_shabd_medias[$yy]->auth_name = $author_data_name;
                    }
                }
                $c                   = collect($get_shabd_medias);
                $sorted              = $c->sortBy('auth_name');
                $items[$k]['data_m'] = $sorted->values()->toArray();
            }
        }
        if ($request->res == "media") {
            return response()->json([
                'status'   => '200',
                'message'  => 'Data found',
                'result'   => $items
            ], 200);
        } else {
            return response()->json([
                'status'   => '200',
                'message'  => 'Data found',
                'result'   => $this->paginate($items, new AdvancedScriptureTransformer, 'scriptures')
            ], 200);
        }

        $data          = DB::table('media')->where('tag_id', '=', 2)->where('title', 'LIKE', '%' . $_GET['search_keyword'] . '%')->paginate(25);
        $tbl_scripture = DB::table('tblscripture')->where('ScriptureRomanEnglish', 'LIKE', '%' . $_GET['search_keyword'] . '%')->paginate(25);

        foreach ($tbl_scripture as $k => $tbl_scriptures) {
            $shabad_count = DB::table('media')->where('shabad_id', $tbl_scriptures->id)->where('type', '!=', 'YOUTUBE')->count();
            if ($shabad_count == '0') {
                unset($tbl_scripture[$k]);
            }
        }
        $shabad_count = array();
        $shabad_get   = array();
        foreach ($tbl_scripture as $kk => $tbl_scripturess) {
            $shabad_get = DB::table('media')->where('shabad_id', $tbl_scripturess->id)->get();
            foreach ($shabad_get as $yy => $shabad_gets) {
                $result12   = substr($shabad_gets->attachment_name, 0, 5);
                $autho_data = DB::table('media_authors')->where('id', $shabad_gets->author_id)->first();
                if (isset($autho_data) && !empty($autho_data)) {
                    $author_data_name = $autho_data->name;
                } else {
                    $author_data_name = '';
                }
                if ($result12 == 'https') {
                    $attachment_file = $shabad_gets->attachment_name;
                } else {
                    $attachment_file = url('uploads/media/') . $shabad_gets->attachment_name;
                }
                $shabad_get[$yy]->att_n     = $attachment_file;
                $shabad_get[$yy]->auth_name = $author_data_name;
            }
            $tbl_scripture[$kk]->data_m = $shabad_get;
        }
        $items = $tbl_scripture;
        return response()->json([
            'status'   => '200',
            'message'  => 'Data found',
            'result'   => $items
        ], 200);
    }

    public function media_search_2(Request $request)
    {
        $dump_array = array();

        if (strlen($request->search_keyword) != mb_strlen($request->search_keyword, 'utf-8')) {
            $request->request->add([
                'language' => 'gurmukhi'
            ]);
        } else {
            $request->request->add([
                'language' => 'english'
            ]);
        }
        if ($request->user_id == '' || $request->user_id == null) {
            $fav_media_array = array();
        } else {
            $fav_media_array = $this->fetch_fav_media_ids($request->user_id);
            if (!is_array($fav_media_array)) {
                $fav_media_array = $fav_media_array->toArray();
            }
        }

        if ($request->search_option == '') {
            $request->request->add([
                'search_option' => 3
            ]);
        }

        if ($request->res == '') {
            $request->request->add([
                'res'           => 'media',
            ]);
        }

        if ($request->language == '') {
            $request->request->add([
                'language'      => 'english',
            ]);
        }

        if ($request->content == '') {
            $request->request->add([
                'content'       => 'audio'
            ]);
        }


        /*if ($request->user_id != '' && $request->user_id != null) {
            $media_search_check = DB::table('media_search_history')
                                    ->where('keyword', $request->search_keyword)
                                    ->where('user_id', $request->user_id)
                                    ->first();

            if ($media_search_check) {
                DB::table('media_search_history')
                    ->where('keyword', $request->search_keyword)
                    ->where('user_id', $request->user_id)
                    ->delete();
            }

            DB::table('media_search_history')->insert([
                'keyword' => $request->search_keyword,
                'user_id' => $request->user_id
            ]);
        }*/

        $items = $this->advanceSearchRepository->advancedSearch($request);

        foreach ($items as $key => $value) {
            $PageID            = DB::table('tblscripture')->select('Page')->where('ShabadID', $value->ShabadID)->min('Page');
            $items[$key]->Page = $PageID;
        }

        $get_shabd_medias = array();

        foreach ($items as $k => $item) {
            $shabad_count = DB::table('media')->where('shabad_id', $item['shabadID'])->count();

            if ($shabad_count == 0) {
                $items[$k]['data_m'] = array();
            } else {
                $sbad_id   = $item['ShabadID'];
                @$authorid = $_GET['audio_author_id'];

                if (isset($authorid)) {
                    /*$sql = "select * from media where shabad_id = $sbad_id AND tag_id = '2' AND author_id = $authorid";*/
                    $sql = "select * from media where shabad_id = $sbad_id AND tag_id = '2'";
                } else {
                    $sql = "select * from media where shabad_id = $sbad_id AND tag_id = '2'";
                }

                $get_shabd_medias = DB::select($sql);

                foreach ($get_shabd_medias as $yy => $shabad_gets) {
                    $result12   = substr($shabad_gets->attachment_name, 0, 5);
                    $autho_data = DB::table('media_authors')->where('id', $shabad_gets->author_id)->first();

                    if (isset($autho_data) && !empty($autho_data)) {
                        $author_data_name = $autho_data->name;
                    } else {
                        $author_data_name = '';
                    }

                    if ($result12 == 'https') {
                        $attachment_file = $shabad_gets->attachment_name;
                    } else {
                        $attachment_file = url('uploads/media/') . $shabad_gets->attachment_name;
                    }

                    $get_shabd_medias[$yy]->att_n     = $attachment_file;
                    $get_shabd_medias[$yy]->auth_name = $author_data_name;
                }
            }

            $c                   = collect($get_shabd_medias);
            $sorted              = $c->sortBy('auth_name');
            $items[$k]['data_m'] = $sorted->values()->toArray();
            $dump_array[] = $get_shabd_medias;
        }

        if (is_array($dump_array) && !empty($dump_array)) {
            $merged = call_user_func_array('array_merge', $dump_array);

            foreach ($merged as $merged_item) {
                $merged_item->favourite = (in_array($merged_item->id, $fav_media_array)) ? 1 : 0;
                $itemxs = DB::table('media')->select('media.*', 'media_authors.image')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->where('media.id', $merged_item->id)->first();

                if ($itemxs->image != null) {
                    $thumb = url('uploads/author/') . '/' . $itemxs->image;
                } else {
                    $thumb = '';
                }

                $merged_item->att_n = $thumb;
            }

            /*$c      = collect($merged);
	        $sorted = $c->sortBy('title');
	        $merged = $sorted->values()->toArray();*/
        } else {
            $merged = array();
        }

        $search_history = array();
        $user_id        = $request->user_id;

        if ($user_id != '') {
            $user_check = DB::table('users')->where('id', $user_id)->first();

            if ($user_check) {
                $count = DB::table('user_search')->where('user_id', $request->user_id)->count();

                if ($count > 0) {
                    $search_history = DB::table('user_search')->where('user_id', $request->user_id)->orderBy('id', 'Desc')->take(6)->get()->pluck('keyword');
                }
            }
        }

        return response()->json([
            'status'         => '200',
            'message'        => 'Data found',
            /*'result'         => $items,*/
            'result'         => $merged,
            'search_history' => $search_history
        ], 200);
    }

    public function media_search_3(Request $request)
    {
        $payload = array();

        if ($request->user_id != '' && $request->user_id != null) {
            $media_search_check = DB::table('user_search')
                ->where('keyword', $request->search_keyword)
                ->where('user_id', $request->user_id)
                ->first();

            if ($media_search_check) {
                DB::table('user_search')
                    ->where('keyword', $request->search_keyword)
                    ->where('user_id', $request->user_id)
                    ->delete();
            }

            DB::table('user_search')->insert([
                'keyword' => $request->search_keyword,
                'user_id' => $request->user_id
            ]);
        }

        if ($request->user_id == '' || $request->user_id == null) {
            $fav_media_array = array();
        } else {
            $fav_media_array = $this->fetch_fav_media_ids($request->user_id);
            if (!is_array($fav_media_array)) {
                $fav_media_array = $fav_media_array->toArray();
            }
        }

        $song_search = DB::table('media')
            ->join('media_authors', 'media.author_id', '=', 'media_authors.id')
            ->where('media.title', 'like', '%' . $request->search_keyword . '%')
            /*->orWhere('media_authors.name', 'like', '%'.$request->search_keyword.'%')*/
            ->select('media.*', 'media_authors.name AS auth_name', DB::raw('CONCAT("https://api2.khojgurbani.org/uploads/author/", media_authors.image) AS att_n'))
            ->orderBy('media.title')
            ->take(200)
            ->get();

        $search_history = array();
        $user_id        = $request->user_id;

        if ($user_id != '') {
            $user_check = DB::table('users')->where('id', $user_id)->first();

            if ($user_check) {
                $count = DB::table('user_search')->where('user_id', $request->user_id)->count();

                if ($count > 0) {
                    $search_history = DB::table('user_search')->where('user_id', $request->user_id)->orderBy('id', 'Desc')->take(6)->get()->pluck('keyword');
                }
            }
        }

        foreach ($song_search as $song_item) {
            $song_item->favourite = (in_array($song_item->id, $fav_media_array)) ? 1 : 0;
        }

        return response()->json([
            'status'         => '200',
            'message'        => 'Data found',
            'result'         => $song_search,
            'search_history' => $search_history
        ], 200);
    }

    public function media_search_history(Request $request)
    {
        $data    = array();
        $user_id = $request->user_id;
        $machine_id = $request->machine_id;

        // if ($user_id == '') {
        //     return response()->json([
        //         'status'  => '200',
        //         'message' => 'Insufficient parameters passed'
        //     ], 200);
        // }

        // $user_check = DB::table('users')->where('id', $user_id)->first();

        // if (!$user_check) {
        //     return response()->json([
        //         'status'  => '404',
        //         'message' => 'User not found'
        //     ], 404);
        // }

        $count = DB::table('user_search')->where('user_id', $user_id)->orWhere('machine_id', $machine_id)->count();

        if ($count > 0) {
            $data = DB::table('user_search')->where('user_id', $user_id)->orWhere('machine_id', $machine_id)->orderBy('id', 'Desc')->get();
        }

        return response()->json([
            'status'  => '200',
            'message' => 'Data found',
            'result'  => $data
        ], 200);
    }

    public function media_search_delete(Request $request)
    {

        $keyword = $request->keyword;
        $user_id = $request->user_id;
        $machine_id = $request->machine_id;


        $media_search_check = DB::table('media_search_history')
            ->where('keyword', $keyword)
            ->where(function ($query) use ($user_id, $machine_id) {
                $query->where('user_id', $user_id)
                    ->orWhere('machine_id', $machine_id);
            })
            ->first();

        if ($media_search_check) {
            DB::table('media_search_history')
                ->where('keyword', $request->keyword)
                ->where('user_id', $request->user_id)
                ->orWhere('machine_id', $request->machine_id)
                ->delete();
        }

        return response()->json([
            'status'    => '200',
            'message'   => 'Keyword deleted'
        ], 200);
    }

    public function media_search_for_artist_and_song(Request $request)
    {


        $items = DB::table('media')
            ->select('media.*', 'media_authors.image', 'media_authors.name', 'media_authors.id as author_id', 'playlist_media.media_id as playlist_media_media_id', 'user_media.id as user_media_id')
            ->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')
            ->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')
            ->leftjoin('playlist_media', 'media.id', '=', 'playlist_media.media_id')
            ->get();

        foreach ($items as $item) {
            $result12 = substr($item->attachment_name, 0, 5);

            if ($result12 == 'https') {
                $attachment_file = $item->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
            }

            if ($item->image != null) {
                $thumb = url('uploads/author/') . '/' . $item->image;
            } else {
                $thumb = '';
            }

            $songs[] = array(
                'id'              => $item->id,
                'author_id'         => $item->author_id,
                'shabad_id'       => $item->shabad_id,
                'title'           => $item->title,
                'author'           => $item->name,
                'type'            => $item->type,
                'duration'        => $item->duration,
                'attachment_name' => $attachment_file,
                'image'           => $thumb,
                'is_media'         => 1,
                'user_media_id'    => $item->user_media_id,
                'playlist_media_media_id' => $item->playlist_media_media_id
            );
        }
        $items = DB::table('media_authors')
            ->select('media_authors.*')
            ->orderBy('media_authors.name')
            ->get();


        foreach ($items as $item) {

            if ($item->image != null) {
                $thumb = url('uploads/author/') . '/' . $item->image;
            } else {
                $thumb = '';
            }

            $artists[] = array(
                'id'              => $item->id,
                'slug'         => $item->slug,
                'name'       => $item->name,
                'description'           => $item->description,
                'image'           => $thumb,
                'status'            => $item->status,
                'featured'        => $item->featured,
                'featured_display_order' => $item->featured_display_order,
                'created_at'         => $item->created_at,
                'updated_at'    => $item->updated_at
            );
        }
        return response()->json([
            'status'   => '200',
            'message'  => 'Data found',
            'songs' => $songs,
            'artists' => $artists
        ], 200);
    }


    /*=====  End of Media Search  ======*/

    /*=======================================
    =            Advanced Search            =
    =======================================*/

    public function advanced_media_search(Request $request)
    {
        $search_keyword = $request->search_keyword;
        $search_option  = $request->search_option;
        $language       = $request->language;
        $content        = $request->content;

        if ($search_keyword == '' || $search_option == '' || $language == '' || $content == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        if ($request->user_id != '' && $request->user_id != null) {
            $media_search_check = DB::table('media_search_history')
                ->where('keyword', $request->search_keyword)
                ->where('user_id', $request->user_id)
                ->first();

            if ($media_search_check) {
                DB::table('media_search_history')
                    ->where('keyword', $request->search_keyword)
                    ->where('user_id', $request->user_id)
                    ->delete();
            }

            DB::table('media_search_history')->insert([
                'keyword' => $request->search_keyword,
                'user_id' => $request->user_id
            ]);
        }

        $items = $this->advanceSearchRepository->advancedSearch($request);

        foreach ($items as $key => $value) {
            $PageID            = DB::table('tblscripture')->select('Page')->where('ShabadID', $value->ShabadID)->min('Page');
            $items[$key]->Page = $PageID;
        }

        $get_shabd_medias = array();

        foreach ($items as $k => $item) {
            $shabad_count = DB::table('media')->where('shabad_id', $item['shabadID'])->count();

            if ($shabad_count == 0) {
                $items[$k]['data_m'] = array();
            } else {
                $sbad_id   = $item['ShabadID'];
                @$authorid = $_GET['audio_author_id'];

                if (isset($authorid)) {
                    $sql = "select * from media where shabad_id=$sbad_id AND tag_id='2' AND author_id=$authorid";
                } else {
                    $sql = "select * from media where shabad_id=$sbad_id AND tag_id='2'";
                }

                $get_shabd_medias = DB::select($sql);

                foreach ($get_shabd_medias as $yy => $shabad_gets) {
                    $result12   = substr($shabad_gets->attachment_name, 0, 5);
                    $autho_data = DB::table('media_authors')->where('id', $shabad_gets->author_id)->first();

                    if (isset($autho_data) && !empty($autho_data)) {
                        $author_data_name = $autho_data->name;
                    } else {
                        $author_data_name = '';
                    }

                    if ($result12 == 'https') {
                        $attachment_file = $shabad_gets->attachment_name;
                    } else {
                        $attachment_file = url('uploads/media/') . $shabad_gets->attachment_name;
                    }

                    $get_shabd_medias[$yy]->att_n     = $attachment_file;
                    $get_shabd_medias[$yy]->auth_name = $author_data_name;
                }
            }

            $c                   = collect($get_shabd_medias);
            $sorted              = $c->sortBy('auth_name');
            $items[$k]['data_m'] = $sorted->values()->toArray();
        }

        return response()->json([
            'status'   => '200',
            'message'  => 'Data found',
            'result'   => $this->paginate($items, new AdvancedScriptureTransformer, 'scriptures')
        ], 200);
    }

    /*=====  End of Advanced Search  ======*/


    /*=======================================
    =            Create Playlist            =
    =======================================*/

    public function create_playlist(Request $request)
    {
        $user_id = $request->user_id;
        $playlist_name   = $request->playlist_name;
        $machine_id = $request->machine_id;

        if ($machine_id == '' || $playlist_name == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        $title_check_user_null = DB::table('user_playlist')->where('playlist_name', $playlist_name)->where('machine_id', $machine_id)->whereNull('user_id')->first();

        if ($title_check_user_null) {
            return response()->json([
                'status'  => '200',
                'message' => 'Title already exists'
            ], 200);
        }

        $title_check_machine_id = DB::table('user_playlist')->where('playlist_name', $playlist_name)->where('user_id', $user_id)->whereNull('machine_id')->first();

        if ($title_check_machine_id) {
            return response()->json([
                'status'  => '200',
                'message' => 'Title already exists'
            ], 200);
        }



        $playlist_id = DB::table('user_playlist')->insertGetId([
            'playlist_name'   => $request->playlist_name,
            'user_id' =>  $request->user_id,
            'machine_id' => $request->machine_id
        ]);


        $media_playlist = DB::table('user_playlist')->where('playlist_id', $playlist_id)->first();

        return response()->json([
            'status'   => '200',
            'message'  => 'Playlist created',
            'playlist' => $media_playlist
        ], 200);
    }

    /*=====  End of Create Playlist  ======*/

    /*=====================================
    =            List Playlist            =
    =====================================*/

    public function user_playlist(Request $request)
    {
        if ($request->user_id) $user_id = $request->user_id;
        if ($request->machine_id) $machine_id = $request->machine_id;

        if ($user_id == '' && $machine_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }


        $media_playlists = DB::table('user_playlist')->where('user_id', $user_id)->orWhere('machine_id', $machine_id)->get();
        foreach ($media_playlists as $med) {
            $med->cnt_playlist_media = DB::table('playlist_media')->where('playlist_id', $med->playlist_id)->count();
        }


        return response()->json([
            'status'   => '200',
            'message'  => 'Playlist created',
            'playlist' => $media_playlists
        ], 200);
    }

    /*=====  End of List Playlist  ======*/

    /*=======================================
    =            Delete Playlist            =
    =======================================*/

    public function delete_playlist(Request $request)
    {
        if ($request->user_id) $user_id     = $request->user_id;
        if ($request->playlist_id) $playlist_id = $request->playlist_id;
        if ($request->machine_id) $machine_id = $request->machine_id;

        if ($user_id == '' || $playlist_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }
        if ($machine_id == '' || $playlist_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        $user_check = DB::table('users')->where('id', $user_id)->first();

        if (!$user_check) {
            return response()->json([
                'status'  => '404',
                'message' => 'User not found'
            ], 404);
        }

        $playlist_check = DB::table('user_playlist')->where('playlist_id', $playlist_id)->first();

        if (!$playlist_check) {
            return response()->json([
                'status'  => '404',
                'message' => 'Playlist not found'
            ], 404);
        }

        DB::table('user_playlist')
            ->where('playlist_id', $playlist_id)
            ->delete();

        return response()->json([
            'status'    => '200',
            'message'   => 'Playlist deleted'
        ], 200);
    }

    public function delete_playlist_track(Request $request)
    {
        $playlist_id     = $request->playlist_id;
        $media_id    = $request->media_id;
        $podcast_id  = $request->podcast_id;


        DB::table('playlist_media')
            ->where('playlist_id', $playlist_id)
            ->where('media_id', $media_id)
            ->orWhere('podcast_id', $podcast_id)
            ->delete();

        return response()->json([
            'status'    => '200',
            'message'   => 'Track deleted'
        ], 200);
    }
    /*=====  End of Delete Playlist  ======*/


    /*=======================================
    =            Playlist Tracks            =
    =======================================*/

    public function append_playlist_tracks(Request $request)
    {
        $media_id    = $request->media_id;
        $playlist_id = $request->playlist_id;
        $podcast_id = $request->podcast_id;




        DB::table('playlist_media')->insert([
            'playlist_id' => $playlist_id,
            'media_id'    => $media_id,
            'podcast_id'  => $podcast_id
        ]);
        return response()->json([
            'status'      => '200',
            'message'     => 'Song added to playlist',
            'playlist_id' => $playlist_id,
            'media_id'    => $media_id,
            'podcast_id'  => $podcast_id
        ], 200);
    }

    public function user_playlist_tracks(Request $request)
    {
        $data        = array();
        $user_id     = $request->user_id;
        $machine_id = $request->machine_id;
        $playlist_id = $request->playlist_id;

        if ($user_id == '' || $playlist_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        // $user_check = DB::table('users')->where('id', $user_id)->first();

        // if (!$user_check) {
        //     return response()->json([
        //         'status'  => '404',
        //         'message' => 'User not found'
        //     ], 404);
        // }

        $playlist_check = DB::table('user_playlist')->where('playlist_id', $playlist_id)->first();

        if (!$playlist_check) {
            return response()->json([
                'status'  => '404',
                'message' => 'Playlist not found'
            ], 404);
        }

        if ($request->user_id == '' || $request->user_id == null) {
            $fav_media_array = array();
        } else {
            $fav_media_array = $this->fetch_fav_media_ids($request->user_id);
            if (!is_array($fav_media_array)) {
                $fav_media_array = $fav_media_array->toArray();
            }
        }

        $media_playlist = DB::table('playlist_media')->where('playlist_id', $playlist_id)->get();
        // return $media_playlist;

        foreach ($media_playlist as $med) {
            $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name', 'media_authors.id as author_id', 'playlist_media.media_id as playlist_media_media_id', 'user_media.id as user_media_id')->leftjoin('user_media', 'media.id', '=', 'user_media.media_id')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->leftjoin('playlist_media', 'media.id', '=', 'playlist_media.media_id')->where('media.id', $med->media_id)->get();

            foreach ($items as $item) {
                $result12 = substr($item->attachment_name, 0, 5);

                if ($result12 == 'https') {
                    $attachment_file = $item->attachment_name;
                } else {
                    $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                }

                if ($item->image != null) {
                    $thumb = url('uploads/author/') . '/' . $item->image;
                } else {
                    $thumb = '';
                }

                $data[] = array(
                    'id'              => $item->id,
                    'shabad_id'       => $item->shabad_id,
                    'favourite'       => (in_array($item->id, $fav_media_array)) ? 1 : 0,
                    'title'           => $item->title,
                    'author'           => $item->name,
                    'type'            => $item->type,
                    'duration'        => $item->duration,
                    'attachment_name' => $attachment_file,
                    'image'           => $thumb,
                    'is_media'         => 1,
                    'user_media_id'    => $item->user_media_id,
                    'playlist_media_media_id' => $item->playlist_media_media_id,
                    'author_id'         => $item->author_id
                );
            }
            $items = DB::table('podcast_media')->select('podcast_media.*', 'playlist_media.podcast_id as playlist_media_podcast_id', 'user_podcast.id as user_podcast_id')->leftjoin('user_podcast', 'podcast_media.id', '=', 'user_podcast.podcast_id')->leftjoin('playlist_media', 'podcast_media.id', '=', 'playlist_media.podcast_id')->where('podcast_media.id', $med->podcast_id)->get();
            // if($down->podcast_id != null)
            // return $items;
            foreach ($items as $item) {

                $result12 = substr($item->attachment_name, 0, 5);

                if ($result12 == 'https') {
                    $attachment_file = $item->attachment_name;
                } else {
                    $attachment_file = url('uploads/podcast_media/') . '/' . $item->attachment_name;
                }

                if ($item->thumbnail != null) {
                    $thumb = url('uploads/thumbnail/') . '/' . $item->thumbnail;
                } else {
                    $thumb = '';
                }

                $data[] = array(
                    'id'              => $item->id,
                    'shabad_id'       => $item->shabad_id,
                    'favourite'       => (in_array($item->id, $fav_media_array)) ? 1 : 0,
                    'title'           => $item->title,
                    'author'           => '',
                    'type'            => '',
                    'duration'        => $item->duration,
                    'attachment_name' => $attachment_file,
                    'image'           => $thumb,
                    'is_media'        => 0,
                    'user_podcast_id'    => $item->user_podcast_id,
                    'playlist_media_podcast_id' => $item->playlist_media_podcast_id
                );
            }
        }
        return response()->json([
            'status'   => '200',
            'message'  => 'Playlist songs found',
            'fav_list' => $data
        ], 200);
    }

    /*=====  End of Playlist Tracks  ======*/


    /*=========================================
    =            Sub-category Fav.            =
    =========================================*/

    public function sub_cat_fav(Request $request)
    {
        $subcategory_id = $request->subcategory_id;
        $user_id        = $request->user_id;

        if ($subcategory_id == '' || $user_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        $sub_cat_check = DB::table('subcategories')->where('id', $subcategory_id)->first();

        if (!$sub_cat_check) {
            return response()->json([
                'status'  => '404',
                'message' => 'Sub-category not found'
            ], 404);
        }

        $user_check = DB::table('users')->where('id', $user_id)->first();

        if (!$user_check) {
            return response()->json([
                'status'  => '404',
                'message' => 'User not found'
            ], 404);
        }

        $sub_cat_fav_check = DB::table('subcategory_fav')
            ->where('subcategory_id', $subcategory_id)
            ->where('user_id', $user_id)
            ->first();

        if (!$sub_cat_fav_check) {
            DB::table('subcategory_fav')->insert([
                'subcategory_id' => $subcategory_id,
                'user_id'        => $user_id
            ]);
            return response()->json([
                'status'         => '200',
                'message'        => 'Sub-category marked as favourite',
                'subcategory_id' => $subcategory_id,
                'user_id'        => $user_id,
                'favourite'      => 1
            ], 200);
        } else {
            DB::table('subcategory_fav')
                ->where('subcategory_id', $subcategory_id)
                ->where('user_id', $user_id)
                ->delete();

            return response()->json([
                'status'         => '200',
                'message'        => 'Sub-category removed from favourites',
                'subcategory_id' => $subcategory_id,
                'user_id'        => $user_id,
                'favourite'      => 0
            ], 200);
        }
    }

    public function sub_cat_fav_list(Request $request)
    {
        $data    = array();
        $user_id = $request->user_id;

        if ($user_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        $user_check = DB::table('users')
            ->where('id', $user_id)
            ->first();

        if (!$user_check) {
            return response()->json([
                'status'  => '404',
                'message' => 'User not found'
            ], 404);
        }

        $fav_sub_cat_count = DB::table('subcategory_fav')
            ->where('user_id', $request->user_id)
            ->count();

        if ($fav_sub_cat_count > 0) {
            $fav_sub_cat = DB::table('subcategory_fav')
                ->where('user_id', $request->user_id)
                ->get()
                ->pluck('subcategory_id');

            $items = DB::table('subcategories')
                ->whereIn('subcategories.id', $fav_sub_cat)
                ->get();

            if (count($items) > 0) {
                foreach ($items as $item) {
                    if ($item->image == null || $item->image == '') {
                        $category_image = '';
                    } else {
                        $category_image = url('uploads/subcategory/') . '/' . $item->image;
                    }

                    $data[] = array(
                        'id'              => $item->id,
                        'name'            => $item->name,
                        'slug'            => $item->slug,
                        'attachment_name' => $category_image,
                    );
                }
            }
        }

        return response()->json([
            'status'   => '200',
            'message'  => 'Data found',
            'fav_list' => $data
        ], 200);
    }

    public function fetch_fav_sub_cat_ids($user_id = NULL)
    {
        $fav_sub_cat_ids = array();

        if ($user_id != NULL) {
            $user_check = DB::table('users')->where('id', $user_id)->first();

            if ($user_check) {
                $fav_sub_cat_ids = DB::table('subcategory_fav')
                    ->select('subcategory_id')
                    ->where('user_id', $user_id)
                    ->pluck('subcategory_id');
            }
        }

        return $fav_sub_cat_ids;
    }

    /*=====  End of Sub-category Fav.  ======*/

    public function all_authors(Request $request)
    {
        $items = $this->author_repository->get($request);

        $sorted = $items->sortBy('name');
        return response()->json([
            'status'   => '200',
            'message'  => 'Data found',
            'data' => $items
        ], 200);

        return $this->get($sorted, new MediaAuthorTransformer, 'media-authors');
    }

    public function all_melodies(Request $request)
    {
        $items = $this->melody_repository->get($request);

        return response()->json([
            'status'  => '200',
            'message' => 'Data found',
            'data'    => $items
        ], 200);

        if ($request->filled('paginate')) {

            return $this->paginate($items, new TblMelodyTransformer, 'tbl_melodies');
        }
        return $this->get($items, new TblMelodyTransformer, 'tbl_melodies');
    }

    /*=================================
    =            Drop Down            =
    =================================*/

    public function search_drop_down(Request $request)
    {
        $authors    = $this->author_repository->get($request);

        $sorted_authors     = $authors->sortBy('name');

        $melodies   = $this->melody_repository->get($request);

        return response()->json([
            'status'   => '200',
            'message'  => 'Data found',
            'data'     => array(
                'melodies'       => $melodies,
                'authors'        => $authors,
                'search_options' => array(
                    array(
                        'id'    => 1,
                        'value' => 'With the exact phrase'
                    ),
                    array(
                        'id'    => 2,
                        'value' => 'Begins with'
                    ),
                    array(
                        'id'    => 3,
                        'value' => 'First letter (search in the begin)'
                    ),
                    array(
                        'id'    => 4,
                        'value' => 'First letter (search anywhere)'
                    ),
                    array(
                        'id'    => 5,
                        'value' => 'Match all words'
                    ),
                    array(
                        'id'    => 6,
                        'value' => 'Match any words'
                    ),
                    array(
                        'id'    => 7,
                        'value' => 'Match all words (partial)'
                    ),
                    array(
                        'id'    => 8,
                        'value' => 'Match any words (partial)'
                    )
                )
            )
        ], 200);
    }

    /*=====  End of Drop Down  ======*/

    /*=========================================
    =            All Podcast Media            =
    =========================================*/


    public function podcast_fav(Request $request)
    {
        $podcast_id = $request->podcast_id;
        $machine_id = $request->machine_id;
        $user_id = $request->user_id;


        if ($podcast_id == '' || $machine_id == '') {
            return response()->json([
                'status' => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }

        $podcast_check = DB::table('podcast_media')->where('id', $podcast_id)->first();

        if (!$podcast_check) {
            return response()->json([
                'status' => '404',
                'message' => 'Podcast not found'
            ], 404);
        }
        // if ($user_id != '') {
        //     $user_check = DB::table('users')->where('id', $user_id)->first();

        //     if (!$user_check) {
        //         return response()->json([
        //             'status' => '404',
        //             'message' => 'User not found'
        //         ], 404);
        //     }
        // }

        // $machine_check = DB::table('media_play')->where('machine_id', $machine_id)->first();
        // if (!$machine_check) {
        //     return response()->json([
        //         'status' => '404',
        //         'message' => 'Machine not found'
        //     ], 404);
        // }

        $podcast_fav_check = DB::table('user_podcast')
            ->where('podcast_id', $podcast_id)
            ->where(function ($query) use ($user_id, $machine_id) {
                $query->where('user_id', $user_id)
                    ->orWhere('machine_id', $machine_id);
            })
            ->first();

        if (!$podcast_fav_check) {
            DB::table('user_podcast')->insert([
                'podcast_id' => $podcast_id,
                'user_id' => $user_id,
                'machine_id' => $machine_id
            ]);
            return response()->json([
                'status'   => '200',
                'message'  => 'Podcast marked as favourite',
                'podcast_id' => $podcast_id,
                'user_id'  => $user_id,
                'machine_id' => $machine_id,
                'favourite' => 1
            ], 200);
        } else {
            DB::table('user_podcast')
                ->where('podcast_id', $podcast_id)
                ->where(function ($query) use ($user_id, $machine_id) {
                    $query->where('user_id', $user_id)
                        ->orWhere('machine_id', $machine_id);
                })
                ->delete();

            return response()->json([
                'status'   => '200',
                'message'  => 'Podcast removed from favourites',
                'podcast_id' => $podcast_id,
                'user_id'  => $user_id,
                'machine_id' => $machine_id,
                'favourite' => 0
            ], 200);
        }
    }


    public function podcast_fav_list(Request $request)
    {
        $data    = array();
        if ($request->user_id) $user_id = $request->user_id;
        if ($request->machine_id) $machine_id = $request->machine_id;

        if ($user_id == '' && $machine_id == '') {
            return response()->json([
                'status'  => '422',
                'message' => 'Insufficient parameters passed'
            ], 422);
        }
        // $machine_check = DB::table('media_play')->where('machine_id', $machine_id)->first();

        // if (!$machine_check) {
        //     return response()->json([
        //         'status'  => '404',
        //         'message' => 'Machine not found'
        //     ], 404);
        // }

        $fav_media_count = DB::table('user_podcast')->where('user_id', $request->user_id)->orWhere('machine_id', $request->machine_id)->count();

        if ($fav_media_count > 0) {
            $fav_media = DB::table('user_podcast')->where('user_id', $request->user_id)->orWhere('machine_id', $request->machine_id)->get();
            foreach ($fav_media as $fav_medias) {
                $items = DB::table('podcast_media')->select('podcast_media.*', 'user_podcast.id as user_podcast_id')->leftjoin('user_podcast', 'podcast_media.id', '=', 'user_podcast.podcast_id')->where('podcast_media.id', $fav_medias->podcast_id)->get();
                foreach ($items as $item) {
                    $result12 = substr($item->attachment_name, 0, 5);
                    if ($result12 == 'https') {
                        $attachment_file = $item->attachment_name;
                    } else {
                        $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $item->attachment_name;
                    }

                    if ($item->thumbnail != null) {
                        $thumb = url('uploads/thumbnail/') . '/' . $item->thumbnail;
                    } else {
                        $thumb = '';
                    }

                    $data[] = array(
                        'id'              => $item->id,
                        'shabad_id'       => $item->shabad_id,
                        'title'           => $item->title,
                        'description'     => $item->description,
                        'type'            => $item->type,
                        'duration'        => $item->duration,
                        'attachment_name' => $attachment_file,
                        'image'           => $thumb,
                        'user_podcast_id' => $item->user_podcast_id
                    );
                }
            }
        }

        return response()->json([
            'status'   => '200',
            'message'  => 'Data found',
            'fav_list' => $data
        ], 200);
    }


    public function all_podcasts(Request $request)
    {
        $all_media = DB::table('podcast_media')->select('podcast_media.*', 'podcast_media_authors.name', 'user_podcast.id as user_podcast_id')->leftjoin('podcast_media_authors', 'podcast_media.author_id', '=', 'podcast_media_authors.id')->leftjoin('user_podcast', 'podcast_media.id', '=', 'user_podcast.podcast_id')->where('podcast_media.status', '1')->orderBy('created_at', 'DESC')->get();
        //medias
        if (count($all_media) > 0) {
            foreach ($all_media as $all_medias) {
                $result12 = substr($all_medias->attachment_name, 0, 5);
                if ($result12 == 'https') {
                    $attachment_file = $all_medias->attachment_name;
                } else {
                    $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $all_medias->attachment_name;
                }

                if ($all_medias->thumbnail == null || $all_medias->thumbnail == '') {
                    $thu_image = '';
                } else {
                    $thu_image = url('uploads/thumbnail/') . '/' . $all_medias->thumbnail;
                }
                $data[] = array(
                    'id'                     => $all_medias->id,
                    'title'                  => $all_medias->title,
                    'author'                 => $all_medias->name,
                    'duration'               => $all_medias->duration,
                    'featured'               => $all_medias->featured,
                    'featured_display_order' => $all_medias->featured_display_order,
                    'media'                  => $attachment_file,
                    'thumbnail'              => $thu_image,
                    'created_at'             => $all_medias->created_at,
                    'updated_at'             => $all_medias->updated_at,
                    'user_podcast_id'        => $all_medias->user_podcast_id
                );
            }

            $sortedArr = collect($data)->sortBy('created_at')->reverse()->values();


            return response()->json([
                'status'  => '200',
                'message' => 'Data found',
                'result'  => $sortedArr
            ], 200);
        }
    }
}
