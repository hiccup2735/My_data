<?php

namespace App\Http\Middleware;

use Closure;

class SetMysqlVersionInConfig
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        config(['global.current_mysql_version' => 5]);

        if($this->version('8')) {
            config(['global.current_mysql_version' => 8]);
        }
        return $next($request);
    }

    public function version($min)
    {
        $pdo = \DB::connection()->getPdo();
        $version = $pdo->query('select version()')->fetchColumn();
        preg_match("/^[0-9\.]+/", $version, $match);

        $version = $match[0];

        return (version_compare($version, $min) >= 0);
    }
}
