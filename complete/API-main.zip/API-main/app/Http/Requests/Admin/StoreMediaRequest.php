<?php

namespace App\Http\Requests\Admin;

use App\Models\Media;
use Auth;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;

class StoreMediaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return Auth::check() && Auth::user()->isSuperAdmin();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'ref_type' => 'required',
            'author_id' => 'required',
//            'shabad_id' => 'required',
            'title' => 'required',
            'type' => 'required',
        ];
        $type = Request::input('type');
        if($type == Media::YOUTUBE_TYPE) {
            $rules['youtube_url'] = 'required';
        } else if($type == Media::VIMEO_TYPE) {
            $rules['vimeo_url'] = 'required';
        } else if ($type == Media::IMAGE_TYPE) {
            $rules['podbean'] = 'required';
        } else if ($type == Media::VIDEO_TYPE) {
            $rules['attachment_name'] = 'required';
        } else if ($type == Media::AUDIO_TYPE) {
            $rules['attachment_name'] = 'required';
        }
        $thumbnail = Request::file('thumbnail');
        if($thumbnail) {
            $rules['thumbnail'] = 'image';
        }
        
        return $rules;
    }
}
