<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\VideoRepository;
use Response, Exception;
use Symfony\Component\HttpFoundation\Response as ResponseCode;

class VideoController extends Controller
{

	private $repository;

	function __construct(VideoRepository $repository)
	{
		$this->repository = $repository;
	}

    public function index(Request $request)
    {
        try {
            $videos = $this->repository->get($request);

            return $this->respond($videos);
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage());
        }
    }

	public function find($id)
	{
		try {
	    	$video = $this->repository->find($id);

	    	return Response::json([
				'status' => 'success',
				'data'=>$video
			]);
    	} catch (Exception $e) {
    		return Response::json([
				'status' => 'error',
				'message'=> $e->getMessage()
			], $e->getCode());
    	}
	}

    public function store(Request $request)
    {

    	$validatedData = $request->validate([
            'url' => 'required',
            'user_id' => 'required',
            'shabad_id' => 'required'
        ]);

    	try {

            $video = $this->repository->store($request);

            $video['youtube_video_url'] = $video->video_code;

            $video_id = explode("v=", $video->video_code);
            if (count($video_id) > 1) {
                $video_id = $video_id[1];
                $video['youtube_video_url'] = "https://www.youtube.com/embed/" . $video_id;
            }

            return Response::json([
                'status' => 'success',
                'data' => $video,
                'message' => 'Video successfully saved.'
 	           ]);
        } catch (Exception $e) {
            return Response::json([
                'status' => 'error',
                'message'=> $e->getMessage()
            ], ResponseCode::HTTP_UNPROCESSABLE_ENTITY);
        }
    }
    //Aakash starts here
    public function deleteVideo(Request $request){

        try {
            $video_id =$request->video_id;
            $status = $this->repository->deleteVideo($video_id);
            if($status){
                return Response::json([
                    'status' => 'success',
                    'data' => $status,
                    'message' => 'Audio successfully Deleted.'
                ]);
            }else{
                return Response::json([
                    'status' => 'error',
                    'data' => $status,
                    'message' => 'Audio Not Deleted Succesfully.'
                ]);
            }
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage());
        }
    }
}
