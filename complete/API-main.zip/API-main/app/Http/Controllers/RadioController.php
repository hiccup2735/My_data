<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Repositories\BlogRepository;
use Response, Exception;
use App\Models\Radio;
use App\User;
use Symfony\Component\HttpFoundation\Response as ResponseCode;
use App\Mail\ContentMail;
use App\Mail\UserContentMail;

use App\Mail\WelcomeMail;
use Illuminate\Support\Facades\Mail;

class RadioController extends Controller
{

    public function getRadio(Request $request){

        /*DB::statement(DB::raw("drop TABLE IF EXISTS radio"));
        DB::statement(DB::raw("
        CREATE TABLE IF NOT EXISTS radio (
          id int(11) NOT NULL,
          title varchar(255) CHARACTER SET utf8 NOT NULL,
          img varchar(255) CHARACTER SET utf8 NOT NULL,
          src varchar(255) CHARACTER SET utf8 NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        "
            ));
        DB::statement(DB::raw("ALTER TABLE radio ADD PRIMARY KEY (id);"));
        DB::statement(DB::raw("ALTER TABLE radio MODIFY id int(11) NOT NULL AUTO_INCREMENT;"));*/
        
        /*$check = Radio::get();
        foreach($check as $c){
            $c->delete();
        }
        DB::statement(DB::raw("INSERT INTO radio VALUES (1, 'Sri Harimandir Sahib', 'assets/Harmandir.jpg', 'http://live.sgpc.net:8090/;?1585525382957')"));
        ///////////////////////////////////////////////////////////////////DB::statement(DB::raw("INSERT INTO radio VALUES (2, 'Takhat Sri Keshgarh Sahib', 'assets/full.jpg', 'http://sgpc.net:8000/;nocache=889869')"));
        DB::statement(DB::raw("INSERT INTO radio VALUES (3, 'Gurdwara Dukh Niwaran Sahib', 'assets/DukhNiwaran.jpg', 'http://akalmultimedia.net:8000/GDNSLDH?hash=1585525755597.mp3')"));
        DB::statement(DB::raw("INSERT INTO radio VALUES (4, 'Dasmesh Darbar', 'assets/Dasmesh.jpg', 'http://s5.voscast.com:7316/;')"));
        DB::statement(DB::raw("INSERT INTO radio VALUES (5, 'Fremont', 'assets/freemont.jpg', 'http://s3.voscast.com:7408/;stream1585527824379/1')"));
        DB::statement(DB::raw("INSERT INTO radio VALUES (6, 'Takhat Sachkhand Sri Hazur Sahib', 'assets/Hazur.jpg', 'http://radio2.sikhnet.com:8038/live')"));
        DB::statement(DB::raw("INSERT INTO radio VALUES (7, 'Gurdwara Bangla Sahib', 'assets/Bangla.jpg', 'http://radio2.sikhnet.com:8050/live')"));*/
     

        $check = Radio::get();

        return Response::json([
            'status' => 'success',
            'data'=> $check
        ]);
    }

    /*public function sendMail(Request $request){
        $user = User::where('email', 'kojotmilos.mz@gmail.com')->first();
        Mail::to('dusanb994@gmail.com')->send(new WelcomeMail($user));

        return Response::json([
            'status' => 'success',
            'data'=> $user
        ]);
    }*/
}
