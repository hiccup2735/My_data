<?php

namespace App\Http\Controllers;

use App\Http\Controllers\ApiController;
use App\Repositories\TblMelodiesRepository;
use App\Transformers\Api\TblMelodyTransformer;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TblMelodiesController extends ApiController
{
	protected $repository;

	public function __construct(TblMelodiesRepository $repository)
	{
		$this->repository = $repository;
	}

    /**
     * get list of all the tbl authors.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function index(Request $request)
    {
    	$items = $this->repository->paginate($request);

    	if ($request->filled('paginate')) {

    		return $this->paginate($items, new TblMelodyTransformer, 'tbl_melodies');
    	}
    	return $this->get($items, new TblMelodyTransformer, 'tbl_melodies');
    }

}
