<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use JWTAuth, Validator;
use App\User;
use App\Repositories\UserRepository;
use DB;
class AuthController extends Controller
{
	use AuthenticatesUsers;

    private $repository;

    function __construct(UserRepository $repository)
    {
        $this->repository = $repository;
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email|max:255',
            'password'=> 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
	            'status' => 'error',
            	'validation_errors' => $validator->errors()
            ], 422);
        }

        $credentials = $this->credentials($request);
        $jwt_token = null;
        $credentials['is_active'] = true;

        try {
            if (!$jwt_token = JWTAuth::attempt($credentials)) {
                return response()->json([
	                'status' => 'error',
	                'message' => 'Invalid Email or Password',
	            ], 403);
            }
        } catch (JWTException $e) {
            return response()->json([
	            'status' => 'error',
            	'message' => 'could_not_create_token'
            ], 500);
        }

        $user = $this->guard()->user();

        $roles = $this->repository->setUserRoles($user);

        $user['roles'] = $roles;

        return response()->json([
            'data' => [
                'status' => 'success',
                'token' => $jwt_token,
                'user'  => $user
            ]
        ]);
    }

    public function loginWithSocialAccount(Request $request)
    {

        $email = $request->input('email');

        $user = User::where('email', $email)->first();

        if($user){
            $jwt_token = JWTAuth::fromUser($user);
        } else {
            // create a new user
            $user                  = new User;
            $user->name            = $request->input('name');
            $user->email           = $email;
            $user->role_id         = 2;
            $user->google_id       = $request->input('social_account_id');
            $user->photo_url       = $request->input('photo_url');
            $user->provider        = $request->input('provider');
            $user->is_active       = 1;
            $user->save();

            $jwt_token = JWTAuth::fromUser($user);
        }

        $roles = $this->repository->setUserRoles($user);
        $user['roles'] = $roles;

        return response()->json([
            'data' => [
                'status' => 'success',
                'token' => $jwt_token,
                'user'  => $user
            ]
        ]);
    }

    public function logout(Request $request)
    {
        try {
            JWTAuth::invalidate($request->token);

            return response()->json([
                'status' => 'success',
                'message' => 'User logged out successfully'
            ]);
        } catch (JWTException $exception) {
            return response()->json([
                'status' => 'error',
                'message' => 'Sorry, the user cannot be logged out'
            ], 500);
        }
    }

    public function isUserLoggedIn()
    {
        if (! $user = JWTAuth::parseToken()->authenticate()) {
            return response()->json([
                'status' => 'error',
                'message' => 'User not found'
            ], 401);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'User successfully found'
        ]);
    }
    
    public function user_check(Request $request){
        $email = $request->email;
        $user_count=DB::table('users')->where('email',$email)->where('google_id',null)->count();
        if($user_count=='1'){
            return response()->json([
            'data' => [
                'status' => 'success',
                'result'=>true
            ]
        ]);
        }else{
            return response()->json([
            'data' => [
                'status' => 'error',
                'result'=>false
            ]
        ]);
        }
    }
}
