<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Symfony\Component\HttpFoundation\Response;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    /**
     * Respond.
     *
     * @param array  $data
     * @param string $response_message
     * @param int    $statusCode
     *
     * @return JsonResponse
     */
    public function respond($data = [], $response_message = 'Success', $statusCode = Response::HTTP_OK)
    {

        $message = [
            'status' => true,
            'message' => $response_message,
            'data' => $data,
        ];
        return response()->json($message, $statusCode);
    }

    /**
     * Format error response in json.
     *
     * @param  $message: string of error message.
     * @param  $statusCode: integer error status code.
     * @return json.
     */
    public function getErrorResponse($message, $statusCode = Response::HTTP_NOT_FOUND)
    {
        $message = ($this->isJSON($message)) ? $this->getJSONMessage($message) : $message;
        $error = [
            'error' => true,
            'message' => $message
        ];

        return response()->json($error, $statusCode);
    }

    /**
     * Check if a string is json or not
     *
     * @param string
     * @return boolean
     */
    public function isJSON($string)
    {
       return is_string($string) && is_array(json_decode($string, true)) ? true : false;
    }

    /**
     * Find message message key from json string.
     *
     * @param $message : string
     * @return Mixed (string or json string)
     */
    private function getJSONMessage($message)
    {
        $msg = json_decode($message, true);
        if(isset($msg['message'])) {
            $message = $msg['message'];
        }

        return $message;
    }
}
