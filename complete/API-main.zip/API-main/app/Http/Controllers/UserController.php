<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Models\Permission;
use App\Models\Role;
use App\Http\Requests\Api\RegisterUserRequest;
use App\Repositories\UserRepository;
use Symfony\Component\HttpFoundation\Response as ResponseCode;
use Exception, Response;
use App\Mail\WelcomeMail;
use App\Mail\AdminWelcomeMail;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;

class UserController extends Controller
{
	protected $repository;

	public function __construct(UserRepository $repository)
	{
		$this->repository = $repository;
	}

	/**
	 * Get all users list
	 *
	 * @return Json
	 */
	public function getUsers()
	{
		$users = $this->repository->getUsers();

		return Response::json([
			'status' => 'success',
			'data' => $users
		]);
	}

	public function getUserById($id)
	{
		try {
			$user = User::findOrFail($id);

			return response()->json([
				'status' => 'success',
				'data' => $user
		    ]);
		} catch (Exception $e) {
			return response()->json([
				'status' => 'error',
		        'message' => $e->getMessage()
		    ], ResponseCode::HTTP_BAD_REQUEST);
		}
	}

	/**
	 * Register user
	 *
	 * @param  RegisterUserRequest  request params
	 * @param  User user model
	 * @return Json
	 */
    public function register(RegisterUserRequest $request, User $user)
    {
    	try {
			$user->setName($request->input('name'))
				->setEmail($request->input('email'))
				->setPassword($request->input('password'))
				->setState($request->input('state'))
				->setCity($request->input('city'))
				->setRole(2)
				->setCountry($request->input('country'))
				->setVerificationCode(str_random(20));


			$user = $this->repository->createUser($user);
            //dd(env('MAIL_HOST'));
			Mail::to($user['email'])->send(new WelcomeMail($user));

			$admin_emails = User::select('email')->whereIn('role_id', [3, 4])->pluck('email');

			if ($admin_emails) {
				Mail::to($admin_emails)->send(new AdminWelcomeMail($user));
			}


			return response()->json([
				'status' => 'success',
		        'message' => 'User successfully registerd.'
		    ]);

		} catch (Exception $e) {
			return response()->json([
				'status' => 'error',
		        'message' => $e->getMessage()
		    ], ResponseCode::HTTP_UNPROCESSABLE_ENTITY);
		}
    }

    /**
     * Verify user email
     *
     * @param  String  varification code
     * @return json
     */
    public function verifyUser($code)
    {
    	$userBuilder = User::where('verification_code', $code);

    	$user = $userBuilder->first();

    	$appUrl = env('FRONT_END_APP_URL', 'https://dev.khojgurbani.org') . "/login";

    	if (!$user) {
    		/*return response()->json([
				'status' => 'error',
		        'message' => 'Verification code is invalid.'
		    ], ResponseCode::HTTP_UNAUTHORIZED);*/

		    $msg = 'Verification code is invalid.';
		    return redirect($appUrl . '?message=' . $msg);
    	}

    	$isUserVarified = $this->repository->isUserVarified($user);
    	if ($isUserVarified) {
    		/*return response()->json([
				'status' => 'success',
		        'message' => 'User is already verified.'
		    ]);*/

		    $msg = 'User is already verified.';
		    return redirect($appUrl . '?message=' . $msg);
    	}

    	$userBuilder->update(['is_active' => 1,
    				   'email_verified_at' => Carbon::now()]);

    	/*return response()->json([
			'status' => 'success',
	        'message' => 'User successfully verified.'
	    ]);*/

	    $msg = 'User successfully verified.';
		return redirect($appUrl . '?message=' . $msg);
    }

    public function userPerm()
    {
    	$appUrl = env('FRONT_END_APP_URL', 'https://dev.khojgurbani.org') . "/my-account/user-permission";

		return redirect($appUrl);
    }

    /**
	 * Update user detail
	 *
	 * @param  Int user id
	 * @param  Request $request
	 * @return json
	 */
    public function update($id, Request $request)
    {

    	try {

    		$user = $this->repository->updateUser($id, $request);

	    	return response()->json([
				'status' => 'success',
				'data' => $user,
		        'message' => 'User updated successfully.'
		    ]);
    	} catch (Exception $e) {
    		return response()->json([
				'status' => 'error',
		        'message' => $e->getMessage()
		    ], ResponseCode::HTTP_BAD_REQUEST);
    	}
    }

    /**
     * Get permissions with roles
     *
     * @return json
     */
    public function getUserRolePermissions()
    {
    	$permission	= Permission::select('id', 'name')->get();

    	foreach ($permission as $key => $p) {
    	    
    		$roles = $p->roles();
    		$roleIds = $roles->pluck('role.id')->all();
            //echo "<pre>"; print_r($roleIds); die;
    		$p['role_ids'] = $roleIds;
    	}

    	return Response::json([
			'status' => 'success',
			'data' => $permission
		]);
    }

    public function saveUserRolePermissions(Request $request)
    {
    	$rolePermissions = $request->all();
         
    	foreach ($rolePermissions as $role => $permission) {
    		$role = Role::find($role);
            
    		if ($role) {
    			$role->permissions()->sync($permission);
    		}
    	}

    	return Response::json([
			'status' => 'success',
			'message' => 'User roles permissions successfully synced.'
		]);
    }
}
