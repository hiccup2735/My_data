<?php

namespace App\Http\Controllers;

use App\Http\Controllers\ApiController;
use App\Repositories\TblAuthorsRepository;
use App\Transformers\Api\TblAuthorTransformer;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TblAuthorsController extends ApiController
{
	protected $repository;

	public function __construct(TblAuthorsRepository $repository)
	{
		$this->repository = $repository;
	}

    /**
     * get list of all the tbl authors.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function index(Request $request)
    {
    	$items = $this->repository->paginate($request);

    	if ($request->filled('paginate')) {

    		return $this->paginate($items, new TblAuthorTransformer, 'tbl_authors');
    	}
    	return $this->get($items, new TblAuthorTransformer, 'tbl_authors');
    }

}
