<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller;
use League\Fractal\Manager;
use League\Fractal\Pagination\IlluminatePaginatorAdapter;
use League\Fractal\Resource\Collection;
use League\Fractal\Serializer\JsonApiSerializer;
use Symfony\Component\HttpFoundation\Response;

class ApiController extends Controller
{

	/**
     * Create a new apiController's instance.
     *
     * @return void
     */
	public function __construct()
	{
	}

    public function paginate($paginator, $transformer, $type)
    {
        $includes = request()->input('includes', []);
        $items = $paginator->getCollection();
        $fractal = fractal()
                   ->collection($items)
                   ->transformWith($transformer)
                   ->paginateWith(new IlluminatePaginatorAdapter($paginator))
                   ->serializeWith(new \League\Fractal\Serializer\JsonApiSerializer(url('api/v1')))
                   ->withResourceName($type);
        if($includes) {
            $fractal = $fractal->parseIncludes(explode(',', $includes));
        }

        return $fractal->toArray();
    }
    
    public function get($items, $transformer, $type)
    {
        return fractal()
                   ->collection($items)
                   ->transformWith($transformer)
                   ->serializeWith(new \League\Fractal\Serializer\JsonApiSerializer(url('api/v1')))
                   ->withResourceName($type)
                   // ->includeCharacters()
                   ->toArray();
    }

	public function getItem($data, $transformer, $type)
    {
        $includes = request()->input('includes', []);
        $item = fractal()
                   ->item($data)
                   ->transformWith($transformer)
                   ->serializeWith(new \League\Fractal\Serializer\JsonApiSerializer(url('api/v1')))
                   ->withResourceName($type);

        if($includes) {
            $item = $item->parseIncludes(explode(',', $includes));
        }

        return $item->toArray();
    }

    /**
     * Format error response in json.
     *
     * @param  $message: string of error message.
     * @param  $statusCode: integer error status code.
     * @return json.
     */
    public function getErrorResponse($message, $statusCode = Response::HTTP_NOT_FOUND)
    {
        $message = ($this->isJSON($message)) ? $this->getJSONMessage($message) : $message;
        $error = [
            'error' => true,
            'message' => $message
        ];

        return response()->json($error, $statusCode);
    }

    /**
     * Check if a string is json or not
     *
     * @param string
     * @return boolean
     */
    public function isJSON($string)
    {
       return is_string($string) && is_array(json_decode($string, true)) ? true : false;
    }

    /**
     * Find message message key from json string.
     *
     * @param $message : string
     * @return Mixed (string or json string)
     */
    private function getJSONMessage($message)
    {
        $msg = json_decode($message, true);
        if(isset($msg['message'])) {
            $message = $msg['message'];
        }

        return $message;
    }

    /**
     * Respond.
     *
     * @param array  $data
     * @param string $response_message
     * @param int    $statusCode
     *
     * @return JsonResponse
     */
    public function respond($data = [], $response_message = 'Success', $statusCode = Response::HTTP_OK)
    {

        $message = [
            'status' => true,
            'message' => $response_message,
            'data' => $data,
        ];
        return response()->json($message, $statusCode);
    }

    /**
     * send response of create item
     * 
     * @param  $data: array of data.
     * @return json format of data.
     */
    public function respondCreated($data = [])
    {
        return $this->respond($data, 'Success', Response::HTTP_CREATED);
    }

    /**
     * send response of deleted item
     * 
     * @param  $data: array of data.
     * @return json format of data.
     */
    public function respondDeleted($data = [])
    {
        return $this->respond($data, 'Success', Response::HTTP_NO_CONTENT);
    }
}

