<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\AdminController;
use App\Http\Requests\Admin\StoreSubcategoryRequest;
//use App\Http\Requests\Admin\StoreCategoryRequest;
use App\Http\Requests\Admin\UpdateSubcategoryRequest;
//use App\Http\Requests\Admin\UpdateCategoryRequest;
use App\Models\Subcategory;
//use App\Models\Category;
use App\Repositories\Admin\MediaSubcategoriesRepository;
//use App\Repositories\Admin\MediaCategoriesRepository;
use Exception;
use Illuminate\Http\Request;
use DB;
use Auth;
class MediaSubcategoriesController extends AdminController {

    protected $repository;

    public function __construct(MediaSubcategoriesRepository $repository) {
        $this->repository = $repository;
    }

    /**
     * get list of all the categories.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function index($category = null, Request $request) {
        $items = $this->repository->paginate($request);
        $category_list = DB::table('categories')->where('status','1')->get();
        
        
//        $category = $id;
        return view('admin.media-subcategories.index', [
            'items' => $items,
            'category' => $category,
            'category_list'=>$category_list
        ]);
    }

    public function store(StoreSubcategoryRequest $request, Subcategory $entity) {
        if ($request->file('image')) {
//            echo 'true';die;
            $file = $request->file('image');
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/subcategory/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
//             echo 'false';die;
            $image = "";
        }
        try {
            if(Auth::user()->id=='1'){
                $status_cat = '1';
            }else{
                $status_cat = $request->input('status');
            }
            $entity->setName($request->input('name'))
                    ->setDescription($request->input('description'))
                    ->setCategory($request->input('category_id'))
                    ->setImage($image)
                    ->setStatus($status_cat);
//           echo "<pre>";print_r($entity); die;
            $item = $this->repository->save($entity);
           
            return redirect()->route('admin.media.subcategories.index')
                            ->with('success', 'Sub-Category has been created sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.subcategories.index')
                            ->with('error', 'Sub-Category could not be created. Please try again.');
        }
    }

    public function update($category, UpdateSubcategoryRequest $request) {
        $category=Subcategory::where('id',$category)->first();
         if ($request->file('image')) {
//            echo 'true';die;
            $file = $request->file('image');
            $imageType = $file->getClientmimeType();
            $fileName = $file->getClientOriginalName();
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/subcategory/';
            $file->move($destinationPath, $fileNameUnique);
            $image = $fileNameUnique;
        } else {
//             echo 'false';die;
            $image = $category->image;
        }
        try {
            if(Auth::user()->id=='1'){
                $status_cat = '1';
            }else{
                $status_cat = $request->input('status');
            }
            $category->setName($request->input('name'))
                    ->setCategory($request->input('category_id'))
                    ->setDescription($request->input('description'))
                    ->setImage($image)
                    ->setStatus($status_cat);

            $item = $this->repository->update($category->getKey(), $category);
            return redirect()->route('admin.media.subcategories.index')
                            ->with('success', 'Sub-Category has been updated sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.subcategories.index')
                            ->with('error', 'Sub-Category could not be updated. Please try again.');
        }
    }

    /**
     * delete category
     *
     * @param  $entity: App\Models\Category
     * @return json response.
     */
    public function delete(Subcategory $entity,$id) {
        
        $entery_count=DB::table('subcategories')->where('id',$id)->count();
        if($entery_count>0){
            DB::table('subcategories')->where('id',$id)->delete();
            return redirect()->route('admin.media.subcategories.index')
                            ->with('success', 'Sub-Category has been deleted sucessfully!');
        }else{
             return redirect()->route('admin.media.subcategories.index')
                            ->with('error', 'Sub-Category could not be deleted. Please try again.');
        }
//        try {
//            $entity->delete();
//            
//        } catch (Exception $e) {
//            return redirect()->route('admin.media.subcategories.index')
//                            ->with('error', 'Category could not be deleted. Please try again.');
//        }
        return $this->respondDeleted([]);
    }

    /**
     * change status with previous status
     *     if previously status was active then mark as inactive and vice-versa
     *     
     * @param  $media: App\Models\Category
     * @return json response.
     */
    public function toggleStatus(Subcategory $category,$id) {
//        DB:table('subcategories')->where
        try {
            $item = $this->repository->toggleStatus($id);
            return redirect()->route('admin.media.subcategories.index')
                            ->with('success', 'Status has been updated sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.media.subcategories.index')
                            ->with('error', 'Status could not be updated!');
        }
    }

}
