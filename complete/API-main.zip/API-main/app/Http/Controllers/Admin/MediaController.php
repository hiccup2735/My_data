<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\AdminController;
use App\Http\Requests\Admin\StoreMediaRequest;
use App\Http\Requests\Admin\UpdateMediaRequest;
use App\Models\Media;
use App\Repositories\Admin\MediaAuthorsRepository;
use App\Repositories\Admin\MediaCategoriesRepository;
use App\Repositories\Admin\MediaRepository;
use App\Repositories\Admin\ScriptureRepository;
use App\Repositories\Admin\TagsRepository;
use DB;
use Exception;
use Illuminate\Http\Request;

class MediaController extends AdminController {

    protected $repository;
    protected $mediaAuthorRepo;
    protected $scriptureRepo;
    protected $tagsRepo;
    protected $mediaCategoriesRepo;

    public function __construct(MediaRepository $repository, MediaAuthorsRepository $mediaAuthorRepo, ScriptureRepository $scriptureRepo, TagsRepository $tagsRepo, MediaCategoriesRepository $mediaCategoriesRepo) {
        $this->repository = $repository;
        $this->mediaAuthorRepo = $mediaAuthorRepo;
        $this->scriptureRepo = $scriptureRepo;
        $this->tagsRepo = $tagsRepo;
        $this->mediaCategoriesRepo = $mediaCategoriesRepo;
    }

    /**
     * show media data in view.
     * 
     * @param  Request $request: Request class instance.
     * @return view.
     */
    public function index(Request $request) {
        $items = $this->repository->paginate($request);
        $authors = $this->mediaAuthorRepo->getList();
        $tags = $this->tagsRepo->getList();
        $categories = $this->mediaCategoriesRepo->getList();

        return view('admin.media.index', [
            'items' => $items,
            'authors' => $authors,
            'tags' => $tags,
            'categories' => $categories,
        ]);
    }

    /**
     * Show create media page.
     * 
     * @return html
     */
    public function create() {
        $authors = $this->mediaAuthorRepo->getList();
        $tags = $this->tagsRepo->getList();
        $categories = $this->mediaCategoriesRepo->getList();
        $subcats=DB::table('subcategories')->where('status','1')->pluck('name','id');
        $type = config('global.media.type'); 
        $feed = 'https://feed.podbean.com/khojgurbani/feed.xml';
        $feed_to_array = (array) simplexml_load_file($feed);
        $feddarrayData = json_decode(json_encode((array)$feed_to_array), TRUE);
        $final_feed_data = $feddarrayData['channel']['item'];
        foreach($final_feed_data as $final_feeds){
            $feed_data[] = array(
                'title'=>$final_feeds['title'],
                'date'=>$final_feeds['pubDate'],
                'media_data'=>$final_feeds['enclosure']['@attributes'],
            );
        }
        
        return view('admin.media.create', [
            'authors' => $authors,
            'tags' => $tags,
            'categories' => $categories,
            'subcategories' => $subcats,
            'type' => $type,
            'feed_data' => $feed_data
        ]);
    }

    /**
     * store media detail to database.
     * 
     * @param  StoreMediaRequest $request: request class for validate request data.
     * @param  Media             $entity: Media model instance
     * @return redirection.
     */
    public function store(StoreMediaRequest $request, Media $entity) {
         
        if (!empty($request->input('category_new'))) {
            $slug = str_slug($request->input('category_new'), '-');
            $category_id = DB::table('categories')->insertGetId([
                'slug' => $slug,
                'name' => $request->input('category_new'),
                'status' => '1'
            ]);
            $cat_array = array($category_id);
        }
        try { 
            DB::beginTransaction();
            $attachmentName = $this->repository->uploadFile($request->file('attachment_name')); 
            $thumbnailImageName = $this->repository->uploadFile($request->file('thumbnail'));
            $user = \Auth::user();
            if($request->input('type')=='IMAGE'){
                $attachmentName=$request->input('podbean');
            }
             if ($request->filled('subcategories')){
                 foreach($request->subcategories as $k=>$subCats){
                    $cat_datas[]=DB::select("select category_id from subcategories where id=$subCats");
                 }
                 foreach ($cat_datas as $cate){
                     $da[] = $cate[0]->category_id;
                 }
                 $subcategroy_cats = array_unique($da);
             }else{
                 $subcategroy_cats = [];
             }
            

            $entity->setAuthorId($request->input('author_id'))
                    ->setShabadId($request->input('shabad_id'))
                    ->setRefType($request->input('ref_type'))
                    ->setTitle($request->input('title'))
                    ->setDescription($request->input('description'))
                    ->setAttachmentName($attachmentName)
                    ->setThumbnail($thumbnailImageName)
                    ->setType($request->input('type'))
                    ->setStatus($request->input('status'))
                    ->setCreatedBy($user->getKey())
                    ->setUpdatedBy($user->getKey())
                    ->setYoutubeUrl($request->input('youtube_url'))
                    ->setVimeoUrl($request->input('vimeo_url'));
            $item = $this->repository->save($entity);
            
            if ($request->filled('subcategories')) {
                foreach($request->input('subcategories') as $subcats){
                    DB::table('media_subcategories')->insert([
                        'media_id'=>$item->id,
                        'subcategory_id'=>$subcats,
                    ]);
                }
            }
                
                
            if ($request->filled('categories') && empty($request->input('category_new'))) {
                 $sub_data_cats = array_merge($request->input('categories'), $subcategroy_cats);
                 $f_categories=array_unique($sub_data_cats);
                $item = $this->repository->assignCategories($item, $f_categories);
                foreach($request->input('categories') as $cats){
                    DB::table('media_categories')->insert([
                        'media_id'=>$item->id,
                        'category_id'=>$cats,
                    ]);
                }
                
            } else {
                $data_cats = array_merge($request->input('categories'), $cat_array);
                $sub_data_cats = array_merge($data_cats, $subcategroy_cats);
                 $f_categories=array_unique($sub_data_cats);
                $item = $this->repository->assignCategories($item, $f_categories);
                foreach($data_cats as $cats){
                    DB::table('media_categories')->insert([
                        'media_id'=>$item->id,
                        'category_id'=>$cats,
                    ]);
                }
            }

            if ($request->filled('tags')) {

                $item = $this->repository->assignTags($item, $request->input('tags'));
            }
            DB::commit();
            return redirect()->route('admin.media.index')
                            ->with('success', 'Media has been created sucessfully!');
        } catch (Exception $e) {
            DB::rollback();
            return redirect()->back()
                            ->with('error', 'Media could not be created. Please try again.');
        }
    }

    public function edit(Media $media) {
        $authors = $this->mediaAuthorRepo->getList();
        $tags = $this->tagsRepo->getList();

        $categories = $this->mediaCategoriesRepo->getList();
        $subcats=DB::table('subcategories')->where('status','1')->pluck('name','id');
        $shabadName = $this->scriptureRepo->getShabadNameById($media->getShabadId());
        $type = config('global.media.type');
        $feed = 'https://feed.podbean.com/khojgurbani/feed.xml';
        $feed_to_array = (array) simplexml_load_file($feed);
        $feddarrayData = json_decode(json_encode((array)$feed_to_array), TRUE);
        $final_feed_data = $feddarrayData['channel']['item'];
        foreach($final_feed_data as $final_feeds){
            $feed_data[] = array(
                'title'=>$final_feeds['title'],
                'date'=>$final_feeds['pubDate'],
                'media_data'=>$final_feeds['enclosure']['@attributes'],
            );
        }
        return view('admin.media.edit', [
            'item' => $media,
            'authors' => $authors,
            'tags' => $tags,
            'categories' => $categories,
            'shabad_name' => $shabadName,
            'type' => $type,
            'feed_data' => $feed_data,
            'subcategories' => $subcats,
        ]);
    }

    public function update(Media $media, UpdateMediaRequest $request) {
        try {
            DB::beginTransaction();
            $attachmentName = $thumbnailImageName = null;
            if ($media->isVideo() || $media->isAudio() || $media->isImage()) {
                $attachmentName = $media->getAttachmentName();
            }
            if ($request->hasFile('attachment_name')) {
                $attachmentName = $this->repository->uploadFile($request->file('attachment_name'), $attachmentName);
            }

            if ($request->hasFile('thumbnail')) {
                $thumbnailImageName = $this->repository->uploadFile($request->file('thumbnail'), $media->getThumbnail());
            }
            DB::table('media_categories')->where('media_id',$media->id)->delete();
            DB::table('media_subcategories')->where('media_id',$media->id)->delete();
            
            if ($request->filled('subcategories')){
                 foreach($request->subcategories as $k=>$subCats){
                    $cat_datas[]=DB::select("select category_id from subcategories where id=$subCats");
                 }
                 foreach ($cat_datas as $cate){
                     $da[] = $cate[0]->category_id;
                 }
                 $subcategroy_cats = array_unique($da);
             }else{
                 $subcategroy_cats = [];
             }
            
            $user = \Auth::user();
            $media->setAuthorId($request->input('author_id'))
                    ->setShabadId($request->input('shabad_id'))
                    ->setRefType($request->input('ref_type'))
                    ->setTitle($request->input('title'))
                    ->setDescription($request->input('description'))
                    ->setAttachmentName($attachmentName)
                    ->setThumbnail($thumbnailImageName)
                    ->setType($request->input('type'))
                    ->setStatus($request->input('status'))
                    ->setCreatedBy($user->getKey())
                    ->setUpdatedBy($user->getKey())
                    ->setYoutubeUrl($request->input('youtube_url'))
                    ->setVimeoUrl($request->input('vimeo_url'));
            $item = $this->repository->update($media->getKey(), $media);

            if ($request->filled('subcategories')) {
                foreach($request->input('subcategories') as $subcats){
                    DB::table('media_subcategories')->insert([
                        'media_id'=>$item->id,
                        'subcategory_id'=>$subcats,
                    ]);
                }
            }
                
                
            if ($request->filled('categories') && empty($request->input('category_new'))) {
                 $sub_data_cats = array_merge($request->input('categories'), $subcategroy_cats);
                 $f_categories=array_unique($sub_data_cats);
                $item = $this->repository->assignCategories($item, $f_categories);
                foreach($request->input('categories') as $cats){
                    DB::table('media_categories')->insert([
                        'media_id'=>$item->id,
                        'category_id'=>$cats,
                    ]);
                }
                
            } else {
                $data_cats = array_merge($request->input('categories'), $cat_array);
                $sub_data_cats = array_merge($data_cats, $subcategroy_cats);
                 $f_categories=array_unique($sub_data_cats);
                $item = $this->repository->assignCategories($item, $f_categories);
                foreach($data_cats as $cats){
                    DB::table('media_categories')->insert([
                        'media_id'=>$item->id,
                        'category_id'=>$cats,
                    ]);
                }
            }

            if ($request->filled('tags')) {

                $item = $this->repository->assignTags($item, $request->input('tags'));
            }
            DB::commit();
            return redirect()->route('admin.media.index')
                            ->with('success', 'Media has been updated sucessfully!');
        } catch (Exception $e) {
            DB::rollback();
            dd($e->getMessage());
            return redirect()->back()
                            ->with('error', 'Media could not be updated. Please try again.');
        }
    }

    /**
     * change status with previous status
     *     if previously status was active then mark as inactive and vice-versa
     *     
     * @param  $media: App\Models\Media
     * @return json response.
     */
    public function toggleStatus(Media $media) {
        try {

            $item = $this->repository->toggleStatus($media->getKey());
            return redirect()->back()
                            ->with('success', 'Media status has been updated sucessfully!');
        } catch (Exception $e) {
            return redirect()->back()
                            ->with('error', 'Media status could not be updated. Please try again.');
        }
    }

    /**
     * delete Media
     *
     * @param  $entity: App\Models\Media
     * @return json response.
     */
    public function delete(Media $entity, Request $request) {
        try {
            DB::beginTransaction();
            if (!$entity->canDelete($request->user())) {
                throw new Exception("You have not permission to delete this media", Response::HTTP_UNAUTHORIZED);
            }

            $categoryIds = $entity->categories->pluck('id')->all();
            $tagIds = $entity->tags->pluck('id')->all();

            $this->repository->detachCategories($entity->getKey(), $categoryIds);
            $this->repository->detachTags($entity->getKey(), $tagIds);

            if ($entity->isVideo() || $entity->isAudio() || $entity->isImage()) {
                $this->repository->deleteAttachment($entity->getAttachmentName());
            }

            if ($entity->isYouTube() || $entity->isVimeo()) {
                $this->repository->deleteAttachment($entity->getThumbnail());
            }

            // detach categories
            // detach tags
            // delete attachment image
            // delete thumbnail image
            // delete media

            $entity->delete();
            DB::commit();
            return redirect()->back()
                            ->with('success', 'Media has been deleted sucessfully!');
        } catch (Exception $e) {
            DB::rollback();
            return redirect()->back()
                            ->with('error', 'Media could not be deleted. Please try again.');
        }
    }

}
