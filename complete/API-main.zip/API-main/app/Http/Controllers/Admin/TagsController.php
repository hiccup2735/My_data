<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\AdminController;
use App\Http\Requests\Admin\StoreTagRequest;
use App\Http\Requests\Admin\UpdateTagRequest;
use App\Models\Tag;
use App\Repositories\Admin\TagsRepository;
use Illuminate\Http\Request;

class TagsController extends AdminController
{
    protected $repository;

	public function __construct(TagsRepository $repository)
	{
		$this->repository = $repository;
	}

	/**
     * get list of all the categories.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function index($item = null, Request $request)
    {
    	$items = $this->repository->paginate($request);

    	return view('admin.tags.index', [
    		'items' => $items,
            'item' => $item
    	]);
    }

    public function store(StoreTagRequest $request, Tag $entity)
    {
        try {
            
            $entity->setName($request->input('name'))
                ->setDescription($request->input('description'))
                ->setStatus($request->input('status'));

            $item = $this->repository->save($entity);
            return redirect()->route('admin.tags.index')
                            ->with('success','Tag has been created sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.tags.index')
                            ->with('error','Tag could not be created. Please try again.');
        }
    }

    public function update($item, UpdateTagRequest $request)
    {
        try {

            $item->setName($request->input('name'))
                ->setDescription($request->input('description'))
                ->setStatus((bool)$request->input('status'));

            $item = $this->repository->update($item->getKey(), $item);
            return redirect()->route('admin.tags.index')
                            ->with('success','Tag has been updated sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.tags.Tag')
                            ->with('error','Category could not be updated. Please try again.');
        }
    }

    /**
     * delete category
     *
     * @param  $entity: App\Models\Tag
     * @return json response.
     */
    public function delete(Tag $entity)
    {
        try {
            
            $entity->delete();
            return redirect()->route('admin.tags.index')
                            ->with('success','Tag has been deleted sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.tags.index')
                            ->with('error','Tag could not be deleted. Please try again.');
        }
        return $this->respondDeleted([]);
        
    }

    /**
     * change status with previous status
     *     if previously status was active then mark as inactive and vice-versa
     *     
     * @param  $media: App\Models\Tag
     * @return json response.
     */
    public function toggleStatus(Tag $item)
    {
        try {
            
            $item = $this->repository->toggleStatus($item->getKey());
            return redirect()->route('admin.tags.index')
                            ->with('success','Status has been updated sucessfully!');
        } catch (Exception $e) {
            return redirect()->route('admin.tags.index')
                            ->with('error','Status could not be updated!');
        }
    }
}
