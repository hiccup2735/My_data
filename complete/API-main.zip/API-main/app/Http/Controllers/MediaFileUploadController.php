<?php

namespace App\Http\Controllers;

use App\Helpers\AttachmentFile;
use App\Http\Controllers\ApiController;
use App\Repositories\MediaFileUploadsRepository;
use Carbon\Carbon;
use Illuminate\Http\Request;

class MediaFileUploadController extends ApiController
{
	public function __construct(MediaFileUploadsRepository $repository)
	{
		$this->repository = $repository;
	}

    /**
     * file upload in chunk.
     * 
     * @param  $request: Illuminate\Http\Request
     * @return json response.
     */
    public function fileChunkUpload(Request $request)
    {
    	$range = $request->header('Content-Range');
    	$rangeArr = explode(' ', $range);
    	$rangeArr = explode('/', $rangeArr[1]);
    	$uploadedChunk = explode('-', $rangeArr[0]);
    	
    	$totalSize = ($rangeArr[1]-1);
    	$uploadedChunk = $uploadedChunk[1];
    	$files = $request->file('files');

    	$chunk_size = config('global.uploads.media.file_upload_chunk_size_in_bytes');
    	$content = [];
    	
        try {

        	$uploadsDirectory = config('global.uploads.path');
        	$publicPath = public_path();
        	$uploadsFolder = $publicPath . DIRECTORY_SEPARATOR . $uploadsDirectory;

        	$file = $files[0];
           	$node = $this->repository->chunkUpload($file, $totalSize, $uploadsFolder);
            if($uploadedChunk >= $totalSize) {

            	// uploaded file path.
            	$uploadedFilePath = $uploadsFolder . DIRECTORY_SEPARATOR . $file->getClientOriginalName();

            	// file new path.
            	$mediaDirectoryFolder = config('global.uploads.media.path');
            	$timestamp = Carbon::now()->timestamp;
            	$filename = "$timestamp-".$file->getClientOriginalName();
            	$newFilePath = $publicPath . DIRECTORY_SEPARATOR . $mediaDirectoryFolder . DIRECTORY_SEPARATOR . $filename;

            	rename("{$uploadedFilePath}.part", $newFilePath);
            }

            
        } catch (Exception $e) {
            return response()->json(['error' => true, 'message' => $e->getMessage()], 400);
        }


        // send response when upload in progress.
        if($uploadedChunk < $totalSize) {
        	return response()->json([
				'success' => true, 
				'message' => 'File is upload is in progress.'
			], 200);
        }
        
        // send response to user when data successfully saved.
        return response()->json([
			'data' => [
				'file_name' => $filename
			],
			'success' => true, 
			'message' => 'File uploaded successfully.'
		], 200);
    }

    public function uploadSingleFile(Request $request)
    {
        $mediaDir = config('global.uploads.media.main_dir');
        $attachment = new AttachmentFile($request->file('file'), $mediaDir);
        $attachment->upload();

        if($attachment->isImage()) {
            $thumbWidth = config('global.uploads.media_sizes.thumbnail.width');
            $thumbHeight = config('global.uploads.media_sizes.thumbnail.height');
            $thumbLocation = config('global.uploads.media.thumb_dir');

            $mediumWidth = config('global.uploads.media_sizes.medium.width');
            $mediumHeight = config('global.uploads.media_sizes.medium.height');
            $mediumLocation = config('global.uploads.media.medium_dir');

            $largeWidth = config('global.uploads.media_sizes.large.width');
            $largeHeight = config('global.uploads.media_sizes.large.height');
            $largeLocation = config('global.uploads.media.large_dir');

            $attachment->generateCopy($thumbWidth, $thumbHeight, 25, 25, $thumbLocation)
                        ->generateCopy($mediumWidth, $mediumHeight, 25, 25, $mediumLocation)
                        ->generateCopy($largeWidth, $largeHeight, 25, 25, $largeLocation);
        }

        // send response to user when data successfully saved.
        return response()->json([
            'data' => [
                'file_name' => $attachment->getName()
            ],
            'success' => true, 
            'message' => 'File uploaded successfully.'
        ], 200);
    }
}
