<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Admin\AdminController;
use App\Repositories\Admin\MediaAuthorsRepository;
use App\Repositories\Admin\MediaCategoriesRepository;
use App\Repositories\Admin\MediaRepository;
use Illuminate\Http\Request;
use DB;

class FeaturedResourcesapiController extends Controller {

    protected $mediaRepo;
    protected $mediaAuthorRepo;
    protected $mediaCategoriesRepo;

    public function __construct(MediaRepository $mediaRepo, MediaAuthorsRepository $mediaAuthorRepo, MediaCategoriesRepository $mediaCategoriesRepo) {
        $this->mediaRepo = $mediaRepo;
        $this->mediaAuthorRepo = $mediaAuthorRepo;
        $this->mediaCategoriesRepo = $mediaCategoriesRepo;
    }

    /**
     * show featured items resources view.
     * 
     * @param  Request $request: Illuminate\Http\Request
     * @return html view.
     */
    public function listing(Request $request) {
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            $all_media = DB::table('media')->where('title', 'like', "%{$_GET['search']}%")->where('featured', '1')->where('status', '1')->get();
            $all_cats = DB::table('categories')->where('name', 'like', "%{$_GET['search']}%")->where('featured', '1')->where('status', '1')->get();
            $all_authors = DB::table('media_authors')->where('name', 'like', "%{$_GET['search']}%")->where('featured', '1')->where('status', '1')->get();
        } else {
            $all_media = DB::table('media')->where('featured','!=','0')->where('status', '1')->get();
            $all_cats = DB::table('categories')->where('status', '1')->get();
            $all_authors = DB::table('media_authors')->where('status', '1')->get();
        }

        //medias
        if (count($all_media) > 0) {
            foreach ($all_media as $all_medias) {
                if(isset($all_medias->author_id) && !empty($all_medias->author_id)){
                    $author_data=DB::table('media_authors')->where('id',$all_medias->author_id)->first();
                    $author_name = $author_data->name;
                }else{
                    $author_name = '';
                }
                $media_result[] = array(
                    'id' => $all_medias->id,
                    'title' => $all_medias->title,
                    'author' => $author_name,
                    'featured' => $all_medias->featured,
                    'featured_display_order' => $all_medias->featured_display_order,
                );
            }
        } else {
            $media_result = [];
        }
        //categories
        if (count($all_cats) > 0) {
            foreach ($all_cats as $all_cat) {
                $cat_result[] = array(
                    'id' => $all_cat->id,
                    'title' => $all_cat->name,
                    'featured' => $all_cat->featured,
                    'featured_display_order' => $all_cat->featured_display_order,
                );
            }
        } else {
            $cat_result = [];
        }
        //Authors
        if (count($all_authors) > 0) {
            foreach ($all_authors as $all_author) {
                $author_result[] = array(
                    'id' => $all_author->id,
                    'title' => $all_author->name,
                    'featured' => $all_author->featured,
                    'featured_display_order' => $all_author->featured_display_order,
                );
            }
        } else {
            $author_result = [];
        }

        return json_encode(array('success' => '200', 'message' => 'featured resource data', 'result' => array('media_result' => $media_result, 'cat_result' => $cat_result, 'author_result' => $author_result)));
    }

    //save featured media 
    public function save_featured_media(Request $request) {
        if ($request->input('featured_media_id') == '') {
            return json_encode(array('error' => '201', 'message' => 'Somthing went wrong'));
        }
        $media_ids = json_decode($request->input('featured_media_id'));

        DB::table('media')->update([
            'featured' => '',
            'featured_display_order' => '',
        ]);
        $a = 1;
        if (count($media_ids) > 0) {
            foreach ($media_ids as $media_id) {
                DB::table('media')->where('id', $media_id->media_id)->update([
                    'featured' => '1',
                    'featured_display_order' => $a,
                ]);
                $a++;
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'Please Select atleast one media.'));
        }
        return json_encode(array('success' => '200', 'message' => 'Selected media items are marked as featured. '));
    }
    
    //save prior media 
    public function save_prior_media(Request $request) {
        if ($request->input('featured_media_id') == '') {
            return json_encode(array('error' => '201', 'message' => 'Somthing went wrong'));
        }
        $media_ids = json_decode($request->input('featured_media_id'));
        if(isset($_GET['categories'])){
            $categoriesIds = $_GET['categories'];
            $all_medias=DB::table('media_categories')->where('category_id',$categoriesIds)->get();
            foreach($all_medias as $all_media){
                DB::table('media')->where('id',$all_media->media_id)->update([
                    'priority_status' => '',
                    'priority_order_status' => '',
                ]);
            }
        }
        
        if(isset($_GET['subcategories'])){
            $subcategoriesIds = $_GET['subcategories'];
            $all_medias=DB::table('media_subcategories')->where('subcategory_id',$subcategoriesIds)->get();
            foreach($all_medias as $all_media){
                DB::table('media')->where('id',$all_media->media_id)->update([
                    'priority_status' => '',
                    'priority_order_status' => '',
                ]);
            }
        }
        
        
//        DB::table('media')->update([
//            'priority_status' => '',
//            'priority_order_status' => '',
//        ]);
        $a = 1;
        if (count($media_ids) > 0) {
            foreach ($media_ids as $media_id) {
                DB::table('media')->where('id', $media_id->media_id)->update([
                    'priority_status' => '1',
                    'priority_order_status' => $a,
                ]);
                $a++;
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'Please Select atleast one media.'));
        }
        return json_encode(array('success' => '200', 'message' => 'Selected media items are marked as featured. '));
    }
    
    //save prior media 
    public function save_prior_podmedia(Request $request) {
        if ($request->input('featured_media_id') == '') {
            return json_encode(array('error' => '201', 'message' => 'Somthing went wrong'));
        }
        $media_ids = json_decode($request->input('featured_media_id'));
        if(isset($_GET['categories'])){
            $categoriesIds = $_GET['categories'];
            $all_medias=DB::table('podcast_media_categories')->where('category_id',$categoriesIds)->get();
            foreach($all_medias as $all_media){
                DB::table('podcast_media')->where('id',$all_media->media_id)->update([
                    'priority_status' => '',
                    'priority_order_status' => '',
                ]);
            }
        }
        
        if(isset($_GET['subcategories'])){
            $subcategoriesIds = $_GET['subcategories'];
            $all_medias=DB::table('podcast_media_subcategories')->where('subcategory_id',$subcategoriesIds)->get();
            foreach($all_medias as $all_media){
                DB::table('podcast_media')->where('id',$all_media->media_id)->update([
                    'priority_status' => '',
                    'priority_order_status' => '',
                ]);
            }
        }
        
        
//        DB::table('media')->update([
//            'priority_status' => '',
//            'priority_order_status' => '',
//        ]);
        $a = 1;
        if (count($media_ids) > 0) {
            foreach ($media_ids as $media_id) {
                DB::table('podcast_media')->where('id', $media_id->media_id)->update([
                    'priority_status' => '1',
                    'priority_order_status' => $a,
                ]);
                $a++;
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'Please Select atleast one media.'));
        }
        return json_encode(array('success' => '200', 'message' => 'Selected media items are marked as featured. '));
    }
    
    //save featured category 
    public function save_featured_category(Request $request) {
        if ($request->input('featured_category_id') == '') {
            return json_encode(array('error' => '201', 'message' => 'Somthing went wrong'));
        }
        $media_ids = json_decode($request->input('featured_category_id'));

        DB::table('categories')->update([
            'featured' => '',
            'featured_display_order' => '',
        ]);
        $a = 1;
        if (count($media_ids) > 0) {
            foreach ($media_ids as $media_id) {
                DB::table('categories')->where('id', $media_id->cat_id)->update([
                    'featured' => '1',
                    'featured_display_order' => $a,
                ]);
                $a++;
            }
        } else {
            return json_encode(array('error' => '201', 'message' => 'Please Select atleast one category.'));
        }
        return json_encode(array('success' => '200', 'message' => 'Selected category items are marked as featured. '));
    }

    //save featured author 
    public function save_featured_author(Request $request) {
        if ($request->input('featured_author_id') == '') {
            return json_encode(array('error' => '201', 'message' => 'Somthing went wrong'));
        }
        $media_ids = json_decode($request->input('featured_author_id'));

        DB::table('media_authors')->update([
            'featured' => '',
            'featured_display_order' => '',
        ]);
        $a = 1;
        if (count($media_ids) > 0) {
            foreach ($media_ids as $media_id) {
                DB::table('media_authors')->where('id', $media_id->author_id)->update([
                    'featured' => '1',
                    'featured_display_order' => $a,
                ]);
                $a++;
            }
        } else {
            return json_encode(array('error' => '201', 'message' => 'Please Select atleast one Author.'));
        }
        return json_encode(array('success' => '200', 'message' => 'Selected authors are marked as featured. '));
    }

    ////////// Podcast Functions START /////////////////////
    public function podcast_listing(Request $request) {
        $all_media = DB::table('podcast_media')->where('status', '1')->get();
        $all_cats = DB::table('podcast_categories')->where('status', '1')->get();
        $all_authors = DB::table('podcast_media_authors')->where('status', '1')->get();
        //medias
        if (count($all_media) > 0) {
            foreach ($all_media as $all_medias) {
                $result12 = substr($all_medias->attachment_name, 0, 5);
                    if ($result12 == 'https') {
                        $attachment_file = $all_medias->attachment_name;
                    } else {
                        $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $all_medias->attachment_name;
                    }
                    
                    if ($all_medias->thumbnail == null || $all_medias->thumbnail == '') {
                        $thu_image = '';
                    } else {
                        $thu_image = url('uploads/thumbnail/') . '/' . $all_medias->thumbnail;
                    }
                $media_result[] = array(
                    'id' => $all_medias->id,
                    'title' => $all_medias->title,
                    'featured' => $all_medias->featured,
                    'featured_display_order' => $all_medias->featured_display_order,
                    'media' => $attachment_file,
                    'thumbnail' => $thu_image,
                );
            }
        } else {
            $media_result = [];
        }
        //categories
        if (count($all_cats) > 0) {
            foreach ($all_cats as $all_cat) {
                if ($all_cat->image == null || $all_cat->image == '') {
                    $category_image = '';
                } else {
                    $category_image = url('uploads/podcast_category/') . '/' . $all_cat->image;
                }
                $sub_pod_count = DB::table('podcast_subcategories')->where('category_id', $all_cat->id)->where('status', '1')->count();
                if ($sub_pod_count > 0) {
                    $sub_pod_data1 = DB::table('podcast_subcategories')->where('category_id', $all_cat->id)->where('status', '1')->get();
                    foreach ($sub_pod_data1 as $item) {
                        if ($item->image == null || $item->image == '') {
                            $category_image = '';
                        } else {
                            $category_image = url('uploads/podcast_category/') . '/' . $item->image;
                        }
                        $sub_pod_data[] = array(
                            'id' => $item->id,
                            'name' => $item->name, 
                            'status' => $item->status,
                            'attachment_name' => $category_image,
                            'category_id' => $item->category_id,
                        );
                    }
                } else {
                    $sub_pod_data = [];
                }
                $cat_result[] = array(
                    'id' => $all_cat->id,
                    'title' => $all_cat->name,
                    'description' => $all_cat->description,
                    'category_image' => $category_image,
                    'featured' => $all_cat->featured,
                    'featured_display_order' => $all_cat->featured_display_order,
                    'podcast_subcats' => $sub_pod_data
                );
            }
        } else {
            $cat_result = [];
        }
        //Authors
        if (count($all_authors) > 0) {
            foreach ($all_authors as $all_author) {
                $author_result[] = array(
                    'id' => $all_author->id,
                    'title' => $all_author->name,
                    'featured' => $all_author->featured,
                    'featured_display_order' => $all_author->featured_display_order,
                );
            }
        } else {
            $author_result = [];
        }

        return json_encode(array('success' => '200', 'message' => 'featured podcast data', 'result' => array('media_result' => $media_result, 'cat_result' => $cat_result, 'author_result' => $author_result)));
    }

    //save Podcast media 
    public function save_podcast_media(Request $request) {
        if ($request->input('featured_media_id') == '') {
            return json_encode(array('error' => '201', 'message' => 'Somthing went wrong'));
        }
        $media_ids = json_decode($request->input('featured_media_id'));

        DB::table('podcast_media')->update([
            'featured' => '',
            'featured_display_order' => '',
        ]);
        $a = 1;
        if (count($media_ids) > 0) {
            foreach ($media_ids as $media_id) {
                DB::table('podcast_media')->where('id', $media_id->media_id)->update([
                    'featured' => '1',
                    'featured_display_order' => $a,
                ]);
                $a++;
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'Please Select atleast one media.'));
        }
        return json_encode(array('success' => '200', 'message' => 'Selected media items are marked as featured. '));
    }

    //save Podcast category 
    public function save_podcast_category(Request $request) {
        if ($request->input('featured_category_id') == '') {
            return json_encode(array('error' => '201', 'message' => 'Somthing went wrong'));
        }
        $media_ids = json_decode($request->input('featured_category_id'));

        DB::table('podcast_categories')->update([
            'featured' => '',
            'featured_display_order' => '',
        ]);
        $a = 1;
        if (count($media_ids) > 0) {
            foreach ($media_ids as $media_id) {
                DB::table('podcast_categories')->where('id', $media_id->cat_id)->update([
                    'featured' => '1',
                    'featured_display_order' => $a,
                ]);
                $a++;
            }
        } else {
            return json_encode(array('error' => '201', 'message' => 'Please Select atleast one category.'));
        }
        return json_encode(array('success' => '200', 'message' => 'Selected category items are marked as featured. '));
    }

    //save Podcast author 
    public function save_podcast_author(Request $request) {
        if ($request->input('featured_author_id') == '') {
            return json_encode(array('error' => '201', 'message' => 'Somthing went wrong'));
        }
        $media_ids = json_decode($request->input('featured_author_id'));

        DB::table('podcast_media')->update([
            'featured' => '',
            'featured_display_order' => '',
        ]);
        $a = 1;
        if (count($media_ids) > 0) {
            foreach ($media_ids as $media_id) {
                DB::table('podcast_media')->where('id', $media_id->author_id)->update([
                    'featured' => '1',
                    'featured_display_order' => $a,
                ]);
                $a++;
            }
        } else {
            return json_encode(array('error' => '201', 'message' => 'Please Select atleast one Author.'));
        }
        return json_encode(array('success' => '200', 'message' => 'Selected authors are marked as featured. '));
    }

    /////////// Podcast Functions END   /////////////////////
}
