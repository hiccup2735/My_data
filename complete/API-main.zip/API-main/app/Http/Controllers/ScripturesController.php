<?php

namespace App\Http\Controllers;

use App\Http\Controllers\ApiController;
use App\Repositories\ScriptureAdvanceSearchRepository;
use App\Repositories\ScriptureRepository;
use App\Transformers\Api\AdvancedScriptureTransformer;
use Illuminate\Http\Request;
use DB;
use App\Models\Scripture;

class ScripturesController extends ApiController
{
    
    protected $repository;
    protected $advanceSearchRepository;
    
    public function __construct(ScriptureRepository $repository, ScriptureAdvanceSearchRepository $advanceSearchRepository)
    {
        $this->repository              = $repository;
        $this->advanceSearchRepository = $advanceSearchRepository;
    }

    public function mediaAdvancedSearch(Request $request){
        $items = $this->advanceSearchRepository->mediaAdvancedSearch($request);
            
        return response()->json($items);
    }

    public function mediaAdvancedSearchWeb(Request $request){
        $items = $this->advanceSearchRepository->mediaAdvancedSearchWeb($request);
            
        return response()->json($items);
    }
    
    public function advancedSearch(Request $request)
    {
        //        $items = $this->advanceSearchRepository->advancedSearch($request);
        //        return $this->paginate($items, new AdvancedScriptureTransformer, 'scriptures');
        if ($_GET['content'] != 'audio') {
            
            $items = $this->advanceSearchRepository->advancedSearch($request);
            
            foreach ($items as $key => $value) {
                
                $PageID            = DB::table('tblscripture')->select('Page')->where('ShabadID', $value->ShabadID)->min('Page');
                $items[$key]->Page = $PageID;
                
            }
            //dd($items);die;
            return response()->json($this->paginate($items, new AdvancedScriptureTransformer, 'scriptures'));
        } else {
            //            $request->input('content') = 'gurbani';
            // DB::enableQueryLog();
            $items            = $this->advanceSearchRepository->advancedSearch($request);
            foreach ($items as $key => $value) {
                
                $PageID            = DB::table('tblscripture')->select('Page')->where('ShabadID', $value->ShabadID)->min('Page');
                $items[$key]->Page = $PageID;
                
            }
            //dd(DB::getQueryLog());die;
            //dd($items);die;
            $get_shabd_medias = array();
            foreach ($items as $k => $item) {
                $shabad_count = DB::table('media')->where('shabad_id', $item['shabadID'])->count();
                if ($shabad_count == 0) {
                    $items[$k]['data_m'] = array();
                } else {
                    $sbad_id = $item['ShabadID'];
                    //                    echo $item['shabadID']; die;
                    //                    echo "<pre>"; print_r($item['ShabadID']); die;
                    //                    $get_shabd_medias = DB::table('media')->where('shabad_id',$item['shabadID'])->get();
                    @$authorid = $_GET['audio_author_id'];
                    if (isset($authorid)) {
                        $sql = "select * from media where shabad_id=$sbad_id AND tag_id='2' AND author_id=$authorid";
                    } else {
                        $sql = "select * from media where shabad_id=$sbad_id AND tag_id='2'";
                    }
                    $get_shabd_medias = DB::select($sql);
                    //                    echo "<pre>"; print_r($get_shabd_medias); die;
                    foreach ($get_shabd_medias as $yy => $shabad_gets) {
                        $result12   = substr($shabad_gets->attachment_name, 0, 5);
                        $autho_data = DB::table('media_authors')->where('id', $shabad_gets->author_id)->first();
                        if (isset($autho_data) && !empty($autho_data)) {
                            $author_data_name = $autho_data->name;
                        } else {
                            $author_data_name = '';
                        }
                        if ($result12 == 'https') {
                            $attachment_file = $shabad_gets->attachment_name;
                        } else {
                            $attachment_file = url('uploads/media/') . $shabad_gets->attachment_name;
                        }
                        $get_shabd_medias[$yy]->att_n     = $attachment_file;
                        $get_shabd_medias[$yy]->auth_name = $author_data_name;
                    }
                }
                $c = collect($get_shabd_medias);
                $sorted = $c->sortBy('auth_name');
                //$items[$k]['ScriptureRomanEnglish'] = $items[$k]['title'];
                $items[$k]['data_m'] = $sorted->values()->toArray();
                /*if (empty($items[$k]['data_m'])) {
                    unset($items[$k]);
                }*/
                
            }
        }
        //            echo "<pre>"; print_r($items); die;
        if ($request->res == "media") {
            return response()->json($items);
        } else {
            return response()->json($this->paginate($items, new AdvancedScriptureTransformer, 'scriptures'));
        }
        
        
        
        $data          = DB::table('media')->where('tag_id', '=', 2)->where('title', 'LIKE', '%' . $_GET['search_keyword'] . '%')->paginate(25);
        $tbl_scripture = DB::table('tblscripture')->where('ScriptureRomanEnglish', 'LIKE', '%' . $_GET['search_keyword'] . '%')->paginate(25);
        
        
        foreach ($tbl_scripture as $k => $tbl_scriptures) {
            $shabad_count = DB::table('media')->where('shabad_id', $tbl_scriptures->id)->where('type', '!=', 'YOUTUBE')->count();
            if ($shabad_count == '0') {
                unset($tbl_scripture[$k]);
            }
        }
        $shabad_count = array();
        $shabad_get   = array();
        foreach ($tbl_scripture as $kk => $tbl_scripturess) {
            $shabad_get = DB::table('media')->where('shabad_id', $tbl_scripturess->id)->get();
            //echo "<pre>"; print_r($shabad_get); die;
            foreach ($shabad_get as $yy => $shabad_gets) {
                $result12   = substr($shabad_gets->attachment_name, 0, 5);
                $autho_data = DB::table('media_authors')->where('id', $shabad_gets->author_id)->first();
                if (isset($autho_data) && !empty($autho_data)) {
                    $author_data_name = $autho_data->name;
                } else {
                    $author_data_name = '';
                }
                if ($result12 == 'https') {
                    $attachment_file = $shabad_gets->attachment_name;
                } else {
                    $attachment_file = url('uploads/media/') . $shabad_gets->attachment_name;
                }
                $shabad_get[$yy]->att_n     = $attachment_file;
                $shabad_get[$yy]->auth_name = $author_data_name;
            }
            //                $tbl_scripture[$kk]->media_sid=$shabad_gets->id;
            //                    $tbl_scripture[$kk]->attachment_file=$attachment_file;
            //                    $tbl_scripture[$kk]->title=$shabad_gets->title;
            $tbl_scripture[$kk]->data_m = $shabad_get;
        }
        //echo "<pre>"; print_r($tbl_scripture); die;
        //            foreach($data as $k=>$datas){
        //                $data[$k]->att_url = url('/uploads/media/'.$datas->attachment_name);
        //            }
        //$items =$data;
        $items = $tbl_scripture;
        return response()->json($items);
    }
    
    //echo "<pre>";print_r($items); die;
}
