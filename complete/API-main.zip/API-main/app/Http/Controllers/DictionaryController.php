<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Dictionary;
use Response;

class DictionaryController extends Controller
{

	function __construct()
	{
	}

	/**
	 * Get dictionary words match with search value
	 */
	public function getDictionaryWords(Request $request)
	{
		$selectedLang = $request->get('lang');
		$searchedVal = $request->get('value');

		$selectedLangField = "engl_proun";
		if ($selectedLang == 'gurmukhi') {
			$selectedLangField = "word";
		}

		$data = Dictionary::Where($selectedLangField, 'like', $searchedVal . '%')
					->whereNotNull($selectedLangField)
					->where($selectedLangField, '!=', "")
					->orderBy($selectedLangField, 'asc')
					->pluck($selectedLangField)
					->take(10);

		return Response::json([
			'status' => 'success',
			'data' => $data,
		]);
	}

	/**
	 * Get single word detail
	 */
	public function getSingleWordDetail(Request $request)
	{
		$selectedLang = $request->get('lang');
		$searchedVal = $request->get('value');

		$selectedLangField = "engl_proun";
		if ($selectedLang == 'gurmukhi') {
			$selectedLangField = "word";
		}

		$data = Dictionary::Where($selectedLangField, $searchedVal)
					->first();

		return Response::json([
			'status' => 'success',
			'data' => $data,
		]);
	}
}