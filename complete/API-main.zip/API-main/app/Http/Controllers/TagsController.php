<?php

namespace App\Http\Controllers;

use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\ApiController;
use App\Http\Requests\Api\CreateTagRequest;
use App\Http\Requests\Api\UpdateTagRequest;
use App\Models\Tag;
use App\Repositories\TagsRepository;
use App\Transformers\Api\TagTransformer;
use Illuminate\Http\Request;
use DB;
class TagsController extends ApiController 
{
	protected $repository;

	public function __construct(TagsRepository $repository)
	{
		$this->repository = $repository;
	}

    /**
     * get list of all the tags.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function index(Request $request)
    {
    	$items = $this->repository->paginate($request);

    	return $this->paginate($items, new TagTransformer, 'tags');
    }

    /**
     * create tag
     *
     * @param  $request: App\Http\Requests\Api\CreateTagRequest
     * @param  $entity: App\Models\Tag
     * @return json response.
     */
    public function store(CreateTagRequest $request, Tag $entity)
    {
        try {

        	$entity->setName($request->input('name'))
        		->setDescription($request->input('description'))
        		->setStatus((bool)$request->input('status'));

        	$item = $this->repository->save($entity);
        	return $this->getItem($item, new TagTransformer, 'tags');
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    /**
     * Update tag
     *
     * @param  $entity: App\Models\Tag
     * @param  $request: App\Http\Requests\Api\UpdateTagRequest
     * @return json response.
     */
    public function update(Tag $entity, UpdateTagRequest $request)
    {
        try {

        	$entity->setName($request->input('name'))
        		->setDescription($request->input('description'))
        		->setStatus((bool)$request->input('status'));

        	$item = $this->repository->update($entity->getKey(), $entity);
        	return $this->getItem($item, new TagTransformer, 'tags');
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    /**
     * delete tag
     *
     * @param  $entity: App\Models\Tag
     * @return json response.
     */
    public function delete(Tag $entity)
    {
    	$entity->delete();
        return $this->respondDeleted([]);
    }
    
    //////////// Tag Management START \\\\\\\\\\\\\\\\\
    //Add tag function START
    public function add(Request $request){
        $name = $request->name;
        $podcast_cat_count = DB::table('tags')->where('name', $name)->count();
        if ($podcast_cat_count > 0) {
            return json_encode(array('success' => '201', 'message' => 'Name with this already exist. Please try with new one.'));
        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('tags')->insert([
                'name' => $name,
                'slug' => $slug,
                'status' => '1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'New tag created successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }
    //Add tag function END
    
    //Edit Tag function START
    public function edit_tag(Request $request, $id) {
        $podcast_detail = DB::table('tags')->where('id', $id)->first();
        $name = $request->name;
        $podcast_cat_count = DB::table('tags')->where('id','!=',$id)->where('name', $name)->count();
        if ($podcast_cat_count > 0) {
            return json_encode(array('success' => '201', 'message' => 'Name with this already exist. Please try with new one.'));
        }
        if ($name != null) {
            $slug = str_slug($name, '-');
            DB::table('tags')->where('id', $id)->update([
                'name' => $name,
                'slug' => $slug,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            return json_encode(array('success' => '200', 'message' => 'Tag has been updated successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'Name is required'));
        }
    }
    //Edit Tag function END
    
    //Update Tag Status START
    public function update_tag_status(Request $request, $id) {
        $status = $request->status;
        $podcast_cat_check = DB::table('tags')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1' || $status == '0') {
                DB::table('tags')->where('id', $id)->update([
                    'status' => $status
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            } else {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No tag Exist with this detail'));
        }
    }
    //Update Tag Status END
    
    //delete Tag START
    public function delete_tag(Request $request,$id){
        $podcast_cat_check = DB::table('tags')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('tags')->where('id',$id)->delete();
            DB::table('media_tags')->where('tag_id',$id)->delete();
            return json_encode(array('success' => '200', 'message' => 'Tag has been deleted successfully.'));
        }else{
            return json_encode(array('success' => '201', 'message' => 'No tag Exist with this detail'));
        }
    }
    //delete Tag END
    
    //List media author START
    public function tags_list(Request $request) {
        $items = DB::table('tags')->get();

        if (count($items) > 0) {
            foreach ($items as $item) {
                
                $data[] = array(
                    'id' => $item->id,
                    'name' => $item->name,
                    'status' => $item->status
                );
            }
        } else {
            $data = [];
        }
        return json_encode(array('success' => '200', 'message' => 'Tags List', 'result' => $data));
    }

    //List media author END
    
    //////////// Tag Management START \\\\\\\\\\\\\\\\\
}
