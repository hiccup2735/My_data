<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\AudioRepository;
use Response, Exception;
use DB;

class AudioController extends Controller
{
    private $repository;

	function __construct(AudioRepository $repository)
	{
		$this->repository = $repository;
	}

	public function index(Request $request)
    {
        try {
            $audio = $this->repository->get($request);

            return $this->respond($audio);
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage());
        }
    }

    public function getSingers(Request $request)
    {
        try {
            $singers = $this->repository->getSingers($request);

            return $this->respond($singers);
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage());
        }
    }
    public function deleteAudio(Request $request){

        try {
            $audio_id =$request->audio_id;
            $status = $this->repository->deleteAudio($audio_id);
            if($status){
                return Response::json([
                    'status' => 'success',
                    'data' => $status,
                    'message' => 'Audio successfully Deleted.'
                ]);
            }else{
                return Response::json([
                    'status' => 'error',
                    'data' => $status,
                    'message' => 'Audio Not Deleted Succesfully.'
                ]);
            }
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage());
        }
    }
    //Created function to delete audio from media Aakash
    public function rejectAudio(Request $request){
        $media_id = $request->media_id;
		$status = DB::table('media')->where('id',$media_id)->delete();
        if($status){
            return Response::json([
                'status' => 'success',
                'data' => $status,
                'message' => 'Audio successfully Deleted.'
            ]);
        }else{
            return Response::json([
                'status' => 'error',
                'data' => $status,
                'message' => 'Audio Not Deleted Succesfully.'
            ]);
        }
    }
    //Aakash end here
}
