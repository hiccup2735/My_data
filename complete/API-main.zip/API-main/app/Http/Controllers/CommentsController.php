<?php

namespace App\Http\Controllers;

use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\ApiController;
use App\Http\Requests\Api\CreateCommentRequest;
use App\Models\Comment;
use App\Repositories\CommentsRepository;
use App\Transformers\Api\CommentTransformer;
use Illuminate\Http\Request;
use Exception;
use DB;

class CommentsController extends ApiController
{
	protected $repository;

	public function __construct(CommentsRepository $repository)
	{
		$this->repository = $repository;
	}

    /**
     * get list of all the comments.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function index(Request $request)
    {
        
    	$items = $this->repository->paginate($request);

    	return $this->paginate($items, new CommentTransformer, 'comments');
    }

    /**
     * get list of all the comments.
     *
     * @param  $request: Illuminate\Http\Request
     * @return json response
     */
    public function getItems(Request $request)
    {
    	$items = $this->repository->get($request);

    	return $this->get($items, new CommentTransformer, 'comments');
    }


    public function update(Request $request){
        try {
            $comment = Comment::with('user')->find($request->comment_id);

            $comment['comment_text'] = $request->comment_text;
            $comment->save();
            return response()->json(array('data' => $comment), 200);
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    /**
     * create comment for post.
     *
     * @param  $request: App\Http\Requests\Api\CreateCommentRequest
     * @param  $entity: App\Models\Comment
     * @return json response.
     */
    public function create(CreateCommentRequest $request, Comment $entity)
    {
        try {
        
        	$userId = null;
            $user = $request->user();
        	if($user) {
        		$userId = $user->getKey();
            }
            
            if($user->is_block){
                return $this->getErrorResponse('User blocked.', Response::HTTP_UNPROCESSABLE_ENTITY);
            }
			
			$blog_details = DB::table('news')->where('news_title', urldecode($request->input('post_id')))->first();
			$news_id = !empty($blog_details) ?  (int) $blog_details->news_id : 0;
			
        	$entity->setCommentAuthorId($userId)
        		->setCommentText($request->input('message'))
        		->setCommentDate(now()->timestamp)
        		->setCommentPostId($news_id);
           // echo $request->input('auto_approve'); die;
            // if user is super admin then mark comment as auto approve.
            if($user && $user->isSuperAdmin()) {
                
                $entity->setCommentApprove(true);
                $entity->setDeleteApprove('0');
            }
            
            if($request->input('auto_approve')=='1'){
                $entity->setCommentApprove(true);
                $entity->setDeleteApprove('0');
            }
            
            if($user && $user->role_id=='3') {
                $entity->setCommentApprove(true);
                $entity->setDeleteApprove('0');
            }
            $entity->setDeleteApprove('0');
            // "<pre>"; print_r($user); die;
        	$item = $this->repository->save($entity);
        	return $this->getItem($item, new CommentTransformer, 'comments');
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    public function changeStatus($comment, $status)
    {
        try {

            $item = $this->repository->updateStatus($comment->getKey(), $status);

            return $this->getItem($item, new CommentTransformer, 'comments');
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    public function getCommentList(Request $request)
    {
       
        $comments = $this->repository->getAllComments($request);
        $message = [
            'status' => true,
            'message' => 'Success',
            'data' => $comments,
        ];
        return response()->json($message);
    }
}
