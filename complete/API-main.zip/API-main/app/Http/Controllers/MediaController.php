<?php

namespace App\Http\Controllers;

use SimpleXMLElement;
use Illuminate\Support\Facades\Response as Download;
use App\Http\Controllers\ApiController;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Requests\Api\CreateMediaRequest;
use App\Models\Media;
use App\Repositories\MediaAuthorsRepository;
use App\Repositories\MediaRepository;
use App\Transformers\Api\MediaTransformer;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use Exception;
use DB;
use Mail;
use Illuminate\Support\Facades\Input;
use App\Helpers\BunnySignedUrl;
use CloudFrontUrlSigner;
use App\Helpers\BunnyCDNStorage;

class MediaController extends ApiController
{

    protected $repository;
    protected $mediaAuthorRepository;

    public function __construct(MediaRepository $repository, MediaAuthorsRepository $mediaAuthorRepository)
    {
        $this->repository = $repository;
        $this->mediaAuthorRepository = $mediaAuthorRepository;
    }

    public function index(Request $request)
    {

        $items = $this->repository->paginate($request);
        if (count($items) > 0) {
            $items = $items;
            $result = $this->paginate($items, new MediaTransformer, 'media');
        } else {
            // $items =[];
            $result = [];
        }

        return $result;
    }

    public function getFeaturedItems(Request $request)
    {

        //        $items = $this->repository->paginateFeatured($request);
        //        return $this->paginate($items, new MediaTransformer, 'media');
        if ($_GET['type'] == 'AUDIO') {
            $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->where('media.featured', '1')->orderBy('featured_display_order', 'asc')->paginate(10);
            if (count($items) > 0) {
                foreach ($items as $item) {
                    $result12 = substr($item->attachment_name, 0, 5);
                    if ($result12 == 'https') {
                        $attachment_file = $item->attachment_name;
                    } else {
                        $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                    }
                    if ($item->image != null) {
                        $thumb = url('uploads/author/') . '/' . $item->image;
                    } else {
                        $thumb = '';
                    }
                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'type' => $item->type,
                        'duration' => $item->duration,
                        'attachment_name' => $attachment_file,
                        'img' => $thumb,
                        'author_name' => $item->name
                    );
                }
            } else {
                $data = [];
            }


            return json_encode(array('featured_media' => $data));
            //           return $this->paginate($items, new MediaTransformer, 'media');
        }
    }

    public function category_media(Request $request, $id)
    {
        //        die('hi');
        $cat_medias = DB::table('media_categories')->where('category_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('media')->where('id', $cat_media->media_id)->where('status', '1')->first();
            }
            $itemd_data = array_filter($items);

            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {

                    if ($item->attachment_name == null || $item->attachment_name == '') {
                        $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $media_url = url('uploads/media/') . '/' . $item->attachment_name;
                        } else {
                            $media_url = $item->attachment_name;
                        }
                    }

                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'type' => $item->type,
                        'status' => $item->status,
                        'duration' => $item->duration,
                        'attachment_name' => $media_url,
                    );
                }
            } else {
                $data = [];
            }
        } else {
            $data = [];
        }


        //            echo "<pre>"; print_r($items); die;
        return json_encode(array('category_media' => $data));
    }

    public function subcategory_media(Request $request, $id)
    {
        //        die('hi');
        $cat_medias = DB::table('podcast_media_subcategories')->where('subcategory_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('podcast_media')->where('id', $cat_media->media_id)->where('status', '1')->first();
            }
            $itemd_data = array_filter($items);

            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {

                    if ($item->attachment_name == null || $item->attachment_name == '') {
                        $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $media_url = url('uploads/podcast_media/') . '/' . $item->attachment_name;
                        } else {
                            $media_url = $item->attachment_name;
                        }
                    }

                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'description' => $item->description,
                        'type' => $item->type,
                        'status' => $item->status,
                        'duration' => $item->duration,
                        'attachment_name' => $media_url,
                    );
                }
            } else {
                $data = [];
            }
        } else {

            $cat_medias12 = DB::table('podcast_media_categories')->where('category_id', $id)->get();
            //echo "<pre>";print_r($cat_medias); die;
            if (count($cat_medias12) > 0) {
                foreach ($cat_medias12 as $cat_media) {
                    $items[] = DB::table('podcast_media')->where('id', $cat_media->media_id)->where('status', '1')->first();
                }
                $itemd_data = array_filter($items);

                if (count($itemd_data) > 0) {
                    foreach ($itemd_data as $item) {

                        if ($item->attachment_name == null || $item->attachment_name == '') {
                            $media_url = '';
                        } else {
                            if ($item->type == 'AUDIO') {
                                $media_url = url('uploads/podcast_media/') . '/' . $item->attachment_name;
                            } else {
                                $media_url = $item->attachment_name;
                            }
                        }

                        $data[] = array(
                            'id' => $item->id,
                            'title' => $item->title,
                            'description' => $item->description,
                            'type' => $item->type,
                            'status' => $item->status,
                            'duration' => $item->duration,
                            'attachment_name' => $media_url,
                        );
                    }
                } else {
                    $data = [];
                }
            } else {

                $data = [];
            }
        }


        //            echo "<pre>"; print_r($items); die;
        return json_encode(array('subcategory_media' => $data));
    }

    public function resource_subcategory_media(Request $request, $id)
    {
        //        die('hi');
        $cat_medias = DB::table('media_subcategories')->where('subcategory_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('media')->where('id', $cat_media->media_id)->where('status', '1')->first();
            }
            $itemd_data = array_filter($items);

            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {

                    if ($item->attachment_name == null || $item->attachment_name == '') {
                        $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $result_str = substr($item->attachment_name, 0, 8);
                            if ($result_str == 'https://') {
                                $media_url = $item->attachment_name;
                            } else {
                                $media_url = url('uploads/media/') . '/' . $item->attachment_name;
                            }
                        } else {
                            $media_url = $item->attachment_name;
                        }
                    }

                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'type' => $item->type,
                        'status' => $item->status,
                        'duration' => $item->duration,
                        'featured' => $item->featured,
                        'featured_display_order' => $item->featured_display_order,
                        'attachment_name' => $media_url,
                    );
                }
            } else {
                $data = [];
            }
        } else {
            $data = [];
        }


        //            echo "<pre>"; print_r($items); die;
        return json_encode(array('subcategory_media' => $data));
    }

    public function resource_subcategory_media_new(Request $request, $id) {
//        die('hi');
        $cat_medias = DB::table('media_subcategories')->where('subcategory_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('media')->where('id', $cat_media->media_id)->where('status','1')->first();
            }
            $itemd_data = array_filter($items);

            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {

                    $media_author = DB::table('media_authors')
                    ->where('id',$item->author_id)
                    ->first();

                    if ($item->attachment_name == null || $item->attachment_name == '') {
                    $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $result_str = substr($item->attachment_name, 0, 8);
                            if($result_str=='https://'){
                                $media_url = $item->attachment_name;
                            }else{
                                $media_url = url('uploads/media/') . '/' . $item->attachment_name;
                            }

                        } else {
                            $media_url = $item->attachment_name;
                        }

                        if($media_author->image == '') {
                            $author_image = '';
                        } else {
                            $author_image = url('uploads/author/'.$media_author->image);
                        }
                    }

                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'type' => $item->type,
                        'status' => $item->status,
                        'duration' => $item->duration,
                        'featured' => $item->featured,
                        'featured_display_order' => $item->featured_display_order,
                        'priority_status' => $item->priority_status,
                        'priority_order_status' => $item->priority_order_status,
                        'attachment_name' => $media_url,
                        'author_image' => $author_image,
                    );

                }
            } else {
                $data = [];
            }
        } else {
            $data = [];
        }
        $dataSorted = [];
        $cntdata = count($data);
        if($cntdata){
            for($q = 0; $q < $cntdata; $q++){
                $index = 0;
                $min = $data[0];
                foreach($data as $key => $dat){
                    if($dat["priority_order_status"] < $min["priority_order_status"]){
                        $min = $dat;
                        $index = $key;
                    }
                }
                array_push($dataSorted, $min);
                array_splice($data, $index, 1);
            }

        }

//            echo "<pre>"; print_r($items); die;
        return json_encode(array('subcategory_media' => $dataSorted));
    }

    public function resource_category_media_new(Request $request, $id)
    {
        //        die('hi');
        $cat_medias = DB::table('media_categories')->where('category_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('media')->where('id', $cat_media->media_id)->where('status', '1')->first();
            }
            $itemd_data = array_filter($items);

            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {

                    $media_author = DB::table('media_authors')
                        ->where('id', $item->author_id)
                        ->first();

                    if ($item->attachment_name == null || $item->attachment_name == '') {
                        $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $result_str = substr($item->attachment_name, 0, 8);
                            if ($result_str == 'https://') {
                                $media_url = $item->attachment_name;
                            } else {
                                $media_url = url('uploads/media/') . '/' . $item->attachment_name;
                            }
                        } else {
                            $media_url = $item->attachment_name;
                        }

                        if ($media_author->image == '') {
                            $author_image = '';
                        } else {
                            $author_image = url('uploads/author/' . $media_author->image);
                        }
                    }

                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'type' => $item->type,
                        'status' => $item->status,
                        'duration' => $item->duration,
                        'featured' => $item->featured,
                        'featured_display_order' => $item->featured_display_order,
                        'priority_status' => $item->priority_status,
                        'priority_order_status' => $item->priority_order_status,
                        'attachment_name' => $media_url,
                        'author_image' => $author_image,
                        'author_name' => $media_author->name,
                    );
                }
            } else {
                $data = [];
            }
        } else {
            $data = [];
        }
        $dataSorted = [];
        $cntdata = count($data);
        if ($cntdata) {
            for ($q = 0; $q < $cntdata; $q++) {
                $data[$q]["author_name_without_bhai"] = strtolower(substr($data[$q]["author_name"], 0, 5)) == "bhai " ? substr($data[$q]["author_name"], 5) : $data[$q]["author_name"];
            }
            for ($q = 0; $q < $cntdata; $q++) {
                $index = 0;
                $min = $data[0];

                foreach ($data as $key => $dat) {
                    if (strcmp($dat["author_name_without_bhai"], $min["author_name_without_bhai"]) < 0) {
                        $min = $dat;
                        $index = $key;
                    }
                }
                array_push($dataSorted, $min);
                array_splice($data, $index, 1);
            }
        }



        //            echo "<pre>"; print_r($items); die;
        return json_encode(array('category_media' => $dataSorted));
    }


    public function resource_subcategory_podmedia_new(Request $request, $id)
    {
        //        die('hi');
        $cat_medias = DB::table('podcast_media_subcategories')->where('subcategory_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('podcast_media')->where('id', $cat_media->media_id)->where('status', '1')->first();
            }
            $itemd_data = array_filter($items);

            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {

                    if ($item->attachment_name == null || $item->attachment_name == '') {
                        $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $result_str = substr($item->attachment_name, 0, 8);
                            if ($result_str == 'https://') {
                                $media_url = $item->attachment_name;
                            } else {
                                $media_url = url('uploads/podcast_media/') . '/' . $item->attachment_name;
                            }
                        } else {
                            $media_url = $item->attachment_name;
                        }
                    }

                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'type' => $item->type,
                        'status' => $item->status,
                        'duration' => $item->duration,
                        'featured' => $item->featured,
                        'featured_display_order' => $item->featured_display_order,
                        'priority_status' => $item->priority_status,
                        'priority_order_status' => $item->priority_order_status,
                        'attachment_name' => $media_url,
                    );
                }
            } else {
                $data = [];
            }
        } else {
            $data = [];
        }


        //            echo "<pre>"; print_r($items); die;
        return json_encode(array('subcategory_podmedia' => $data));
    }

    public function resource_category_podmedia_new(Request $request, $id)
    {
        //        die('hi');
        $cat_medias = DB::table('podcast_media_categories')->where('category_id', $id)->get();
        //echo "<pre>";print_r($cat_medias); die;
        if (count($cat_medias) > 0) {
            foreach ($cat_medias as $cat_media) {
                $items[] = DB::table('podcast_media')->select('podcast_media.*', 'user_podcast.id as user_podcast_id')->leftjoin('user_podcast', 'podcast_media.id', '=', 'user_podcast.podcast_id')->where('podcast_media.id', $cat_media->media_id)->where('status', '1')->first();
            }
            $itemd_data = array_filter($items);
            if (count($itemd_data) > 0) {
                foreach ($itemd_data as $item) {

                    if ($item->attachment_name == null || $item->attachment_name == '') {
                        $media_url = '';
                    } else {
                        if ($item->type == 'AUDIO') {
                            $result_str = substr($item->attachment_name, 0, 8);
                            if ($result_str == 'https://') {
                                $media_url = $item->attachment_name;
                            } else {
                                $media_url = url('uploads/podcast_media/') . '/' . $item->attachment_name;
                            }
                        } else {
                            $media_url = $item->attachment_name;
                        }
                    }
                    if ($item->thumbnail == null || $item->thumbnail == '') {
                        $thu_image = '';
                    } else {
                        $thu_image = url('uploads/thumbnail/') . '/' . $item->thumbnail;
                    }

                    $data[] = array(
                        'id' => $item->id,
                        'title' => $item->title,
                        'description' => $item->description,
                        'type' => $item->type,
                        'status' => $item->status,
                        'duration' => $item->duration,
                        'featured' => $item->featured,
                        'featured_display_order' => $item->featured_display_order,
                        'priority_status' => $item->priority_status,
                        'priority_order_status' => $item->priority_order_status,
                        'attachment_name' => $media_url,
                        'thumbnail' => $thu_image,
                        'created_at' => $item->created_at,
                        'user_podcast_id' => $item->user_podcast_id,
                        'language' => $item->language

                    );
                }
            } else {
                $data = [];
            }
        } else {
            $data = [];
        }

        $sortedArr = collect($data)->sortBy('created_at')->reverse()->values();

        //            echo "<pre>"; print_r($items); die;
        return response()->json([
            'status'  => '200',
            'message' => 'Data found',
            'result'  => $sortedArr
        ], 200);
    }

    public function media_play(Request $request)
    {
        $media_id = $request->media_id;
        $user_id = $request->user_id;
        $machine_id = $request->machine_id;
        $view_date = $request->view_date;
        if ($media_id == '' || $machine_id == '' || $view_date == '') {
            return json_encode(array('error' => true));
        }
//      $media_user_null = DB::table('media_play')->where('machine_id', $machine_id)->where('media_id', $media_id)->whereNull('user_id')->get();
        $media_get_data = DB::table('media')/*->select('media.*', 'media_tags.tag_id')->leftjoin('media_tags', 'media_tags.media_id', '=', 'media.id')*/->where('id', $media_id)->first();

/*
        $tag_id = DB::table('media_tags')->where('media_id', $media_get_data->id)->first();
        if (!$tag_id || $tag_id->tag_id != 2) return json_encode(array('success' => true));
*/
        if (!$media_get_data || $media_get_data->tag_id != 2) return json_encode(array('success' => true));

        DB::table('media_play')->insert([
            'media_id' => $media_id,
            'user_id' => $user_id,
            'machine_id' => $machine_id,
            'view_date' => $view_date,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        return json_encode(array('success' => true));
    }

    /**
     * create tag
     *
     * @param  $request: App\Http\Requests\Api\CreateTagRequest
     * @param  $entity: App\Models\Tag
     * @return json response.
     */
    public function store(CreateMediaRequest $request, Media $entity)
    {
        try {
            $authorId = $request->input('author_id');
            if ($authorId && !is_int($authorId)) {
                $author = $this->mediaAuthorRepository->storeAuthor($authorId);
                $authorId = $author->getKey();
            }

            $user = $request->user();
            $status = (bool) $request->input('status');

            if ($user->isSuperAdmin()) {
                $status = true;
            }
            $request['includes'] = 'categories,tags';
            $userId = $request->user()->id;
            $entity->setAuthorId($authorId)
                ->setShabadId($request->input('shabad_id'))
                ->setRefType($request->input('ref_type'))
                ->setTitle($request->input('title'))
                ->setDescription($request->input('description'))
                ->setAttachmentName($request->input('attachment_name'))
                ->setAttachmentMimeType($request->input('attachment_mime_type'))
                ->setType($request->input('type'))
                ->setStatus($status)
                ->setCreatedBy($userId)
                ->setUpdatedBy($userId);

            $item = $this->repository->save($entity);

            if ($request->filled('category_ids')) {

                $item = $this->repository->assignCategories($item, $request->input('category_ids'));
            }

            if ($request->filled('tag_ids')) {

                $item = $this->repository->assignTags($item, $request->input('tag_ids'));
            }
            return $this->getItem($item, new MediaTransformer, 'media');
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    /**
     * change status with previous status
     *     if previously status was active then mark as inactive and vice-versa
     *
     * @param  $media: App\Models\Media
     * @return json response.
     */
    public function toggleStatus(Media $media)
    {
        try {

            $item = $this->repository->toggleStatus($media->getKey());
            return $this->getItem($item, new MediaTransformer, 'media');
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    /**
     * delete category
     *
     * @param  $entity: App\Models\Media
     * @return json response.
     */
    public function delete(Media $entity, Request $request)
    {
        try {

            if (!$entity->canDelete($request->user())) {
                throw new Exception("You have not permission to delete this media", Response::HTTP_UNAUTHORIZED);
            }

            $entity->delete();
            return $this->respondDeleted([]);
        } catch (Exception $e) {
            return $this->getErrorResponse($e->getMessage(), Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }

    //podcast list START
    public function podcast(Request $request)
    {
        $feed = 'https://feed.podbean.com/khojgurbani/feed.xml';
        $feed_to_array = (array) simplexml_load_file($feed);
        $feddarrayData = json_decode(json_encode((array) $feed_to_array), TRUE);
        $final_feed_data = $feddarrayData['channel']['item'];

        foreach ($final_feed_data as $final_feeds) {
            $data[] = array(
                'title' => $final_feeds['title'],
                'date' => $final_feeds['pubDate'],
                'media_data' => $final_feeds['enclosure']['@attributes'],
            );
        }
        return json_encode(array('status' => '200', 'message' => 'podcast list', 'result' => $data));
    }

    //podcast list END
    //podcast index START
    public function podcast_index(Request $request) {
        $data =array();
        $final_feeds_count = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->count();
        if ($final_feeds_count > 0) {
			
			$media_data = array();
			$final_feeds = DB::table('podcast_media')->where('today_approval', '1')->where('language', 'e')->orderBy('id', 'desc')->first();
			if(!empty($final_feeds))
			{
				$shabad_id = $final_feeds->shabad_id;
//				$status = $this->getCommentrybyshabadID($shabad_id);
	
				$result12 = substr($final_feeds->attachment_name, 0, 5);
				if ($result12 == 'https') {
					$attachment_file = $final_feeds->attachment_name;
				} else {
					$attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
				}
	
                if ($final_feeds->thumbnail == null || $final_feeds->thumbnail == '') {
                    $thu_image = '';
                } else {
                    $thu_image = url('uploads/thumbnail/') . '/' . $final_feeds->thumbnail;
                }
	
				$pageID = DB::table('tblscripture')->select('Page')->where('ShabadID', $shabad_id)->min('Page');
	
				 //s3 ends here
				$media_data = array(
					'id' => $final_feeds->id,
					'title' => $final_feeds->title,
					'description' => $final_feeds->description,
					'englishPodcastSrc' => $attachment_file,
					'updated_at' =>$final_feeds->updated_at,
					'created_at' =>$final_feeds->created_at,
					'duration' => $final_feeds->duration,
					'time' => $final_feeds->duration,
	//				'commentry_desc'=>$status,
					'commentry_status'=>true,
					'ShabadID' => $shabad_id,
					'page_id' => $pageID,
					'image' => $thu_image
				);
			}
			
			$final_feeds = DB::table('podcast_media')->where('today_approval', '1')->where('language', 'p')->orderBy('id', 'desc')->first();
			if(!empty($final_feeds))
			{
				$shabad_id = $final_feeds->shabad_id;
		//		$status = $this->getCommentrybyshabadID($shabad_id);
	
				$result12 = substr($final_feeds->attachment_name, 0, 5);
				if ($result12 == 'https') {
					$attachment_file = $final_feeds->attachment_name;
				} else {
					$attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
				}
	
                if ($final_feeds->thumbnail == null || $final_feeds->thumbnail == '') {
                    $thu_image = '';
                } else {
                    $thu_image = url('uploads/thumbnail/') . '/' . $final_feeds->thumbnail;
                }
	
				$pageID = DB::table('tblscripture')->select('Page')->where('ShabadID', $shabad_id)->min('Page');
				
				 //s3 ends here
				$media_data = array_merge($media_data, array(
					'p_id' => $final_feeds->id,
					'p_title' => $final_feeds->title,
					'p_description' => $final_feeds->description,
					'punjabiPodcardSrc' => $attachment_file,
					'p_updated_at' =>$final_feeds->updated_at,
					'p_created_at' =>$final_feeds->created_at,
					'p_duration' => $final_feeds->duration,
					'p_time' => $final_feeds->duration,
//					'p_commentry_desc'=>$status,
					'p_commentry_status'=>true,
					'p_ShabadID' => $shabad_id,
					'p_page_id' => $pageID,
					'p_image' => $thu_image
				));
			}
			$data[] = $media_data;
			
			
			
			/*$final_feeds_details = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->get();
			foreach($final_feeds_details as $final_feeds)
			{
				$shabad_id = $final_feeds->shabad_id;
				$status = $this->getCommentrybyshabadID($shabad_id);
	
				$result12 = substr($final_feeds->attachment_name, 0, 5);
				if ($result12 == 'https') {
					$attachment_file = $final_feeds->attachment_name;
				} else {
					$attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
				}
	
				//$englishPodcastSrc = $punjabiPodcardSrc = '';
				//if($final_feeds->language=='e') $englishPodcastSrc = $attachment_file;
				//if($final_feeds->language=='p') $punjabiPodcardSrc = $attachment_file;
				 //s3 ends here
				$media_data = array_merge($media_data, array(
					'id' => $final_feeds->id,
					'title' => $final_feeds->title,
					'description' => $final_feeds->description,
					'punjabiPodcardSrc' => $punjabiPodcardSrc,
					'englishPodcastSrc' => $englishPodcastSrc,
					'updated_at' =>$final_feeds->updated_at,
					'created_at' =>$final_feeds->created_at,
					'duration' => $final_feeds->duration,
					'time' => $final_feeds->duration,
					'commentry_desc'=>$status,
					'commentry_status'=>true
				));
			}*/
			
			
			
			
			
			
			
			
			
			
			
			
			
		
            /*$final_feeds = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->first();
			
            $shabad_id = $final_feeds->shabad_id;
            $status = $this->getCommentrybyshabadID($shabad_id);

            $result12 = substr($final_feeds->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $attachment_file = $final_feeds->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
            }
//             //s3 starts here
//             $exists = Storage::disk('s3archive')->exists($final_feeds->attachment_name);
//
//             if($exists){
//              $attachment_file = Storage::disk('s3archive')->url($final_feeds->attachment_name);
//             }else{
//                 $attachment_file = $final_feeds->attachment_name;
//             }

			$englishPodcastSrc = $punjabiPodcardSrc = '';
			if($final_feeds->language=='e') $englishPodcastSrc = $attachment_file;
			if($final_feeds->language=='p') $punjabiPodcardSrc = $attachment_file;
             //s3 ends here
            $data[] = array(
                'id' => $final_feeds->id,
                'title' => $final_feeds->title,
                'description' => $final_feeds->description,
                //'media_data' => $attachment_file,
				'punjabiPodcardSrc' => $punjabiPodcardSrc,
				'englishPodcastSrc' => $englishPodcastSrc,
                'updated_at' =>$final_feeds->updated_at,
                'created_at' =>$final_feeds->created_at,
                'duration' => $final_feeds->duration,
                'time' => $final_feeds->duration,
                'commentry_desc'=>$status,
                'commentry_status'=>true
            );*/
        } else {
            $final_feeds = DB::table('podcast_media')->orderBy('id', 'desc')->first();
            $shabad_id = $final_feeds->shabad_id;
  //          $status = $this->getCommentrybyshabadID($shabad_id);

            $result12 = substr($final_feeds->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $attachment_file = $final_feeds->attachment_name;
            } else {
                $attachment_file = $category_image = url('uploads/podcast_media/') . '/' . $final_feeds->attachment_name;
            }
             //s3 starts here
             $exists = Storage::disk('s3archive')->exists($final_feeds->attachment_name);

             if($exists){
              $attachment_file = Storage::disk('s3archive')->url($final_feeds->attachment_name);
             }else{
                 $attachment_file = $final_feeds->attachment_name;
             }
			 
			$englishPodcastSrc = $punjabiPodcardSrc = '';
			if($final_feeds->language=='e') $englishPodcastSrc = $attachment_file;
			if($final_feeds->language=='p') $punjabiPodcardSrc = $attachment_file;
             //s3 ends here
			 
			$pageID = DB::table('tblscripture')->select('Page')->where('ShabadID', $shabad_id)->min('Page');
			 
			 
            $data[] = array(
                'id' => $final_feeds->id,
                'title' => $final_feeds->title,
                'description' => $final_feeds->description,
                //'media_data' => $attachment_file,
				'punjabiPodcardSrc' => $punjabiPodcardSrc,
				'englishPodcastSrc' => $englishPodcastSrc,
                'updated_at' =>$final_feeds->updated_at,
                'created_at' =>$final_feeds->created_at,
                'time' => $final_feeds->duration,
                'duration' => $final_feeds->duration,
//                'commentry_status'=>$status,
				'ShabadID' => $shabad_id,
				'page_id' => $pageID,
				'image' => $final_feeds->thumbnail
            );
        }


        return json_encode(array('status' => '200', 'message' => 'Today Podcast', 'result' => $data));
    }

    public function getCommentrybyshabadID($shabad_id = null)
    {
        @$commentry =  DB::table('commentaries')->where('shabad_id', $shabad_id)->orderBy('id', 'desc')->first()->commentary;
        if (isset($commentry)) {
            return $commentry;
        } else {
            return false;
        }
    }

    //podcast index END
    //latest archive START
    public function latest_archive()
    {
        $data = array();
        $last_media_podcast = DB::table('podcast_media')->orderBy('id', 'desc')->first();
        $last_5_archive_c = DB::table('podcast_media')->where('today_approval', '0')->count();
        if ($last_5_archive_c > 0) {
            $last_5_archives = DB::table('podcast_media')->where('today_approval', '0')->orderBy('id', 'desc')->take(5)->get();
            foreach ($last_5_archives as $last_5_archive) {
                //s3 starts here
                $exists = Storage::disk('s3')->exists($last_5_archive->attachment_name);

                if ($exists) {
                    $archiveName = Storage::disk('s3')->url($last_5_archive->attachment_name);
                } else {
                    $archiveName = $last_5_archive->attachment_name;
                }
                //ends here
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $archiveName,
                    'time' => '00:50:29'
                );
            }
        } else {
            $last_5_archives = DB::table('podcast_media')->where('today_approval', '0')->orderBy('id', 'desc')->take(5)->get();
            foreach ($last_5_archives as $last_5_archive) {
                $exists = Storage::disk('s3')->exists($last_5_archive->attachment_name);

                if ($exists) {
                    $archiveName = Storage::disk('s3')->url($last_5_archive->attachment_name);
                } else {
                    $archiveName = $last_5_archive->attachment_name;
                }
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $archiveName,
                    'time' => '00:50:29'
                );
            }
        }


        return json_encode(array('status' => '200', 'message' => 'Last 5 Archive', 'result' => $data));
    }

    //latest archive END
    //all archive START
    public function all_archive()
    {
        $last_media_podcast = DB::table('podcast_media')->orderBy('id', 'desc')->first();
        $last_5_archive_c = DB::table('podcast_media')->where('id', '!=', $last_media_podcast->id)->orderBy('id', 'desc')->count();
        if ($last_5_archive_c > 0) {
            $last_5_archives = DB::table('podcast_media')->where('id', '!=', $last_media_podcast->id)->orderBy('id', 'desc')->get();
            foreach ($last_5_archives as $last_5_archive) {
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $last_5_archive->attachment_name,
                    'time' => '00:50:29'
                );
            }
        } else {
            $last_5_archives = DB::table('podcast_media')->where('id', '!=', $last_media_podcast->id)->orderBy('id', 'desc')->get();
            foreach ($last_5_archives as $last_5_archive) {
                $data[] = array(
                    'id' => $last_5_archive->id,
                    'title' => $last_5_archive->title,
                    'media_data' => $last_5_archive->attachment_name,
                    'time' => '00:50:29'
                );
            }
        }


        return json_encode(array('status' => '200', 'message' => 'All Archives', 'result' => $data));
    }

    //all archive END
    //podcast list START
    public function podcast_list(Request $request) {

        $feed = 'https://feed.podbean.com/khojgurbani/feed.xml';
        $feed_to_array = (array) simplexml_load_file($feed);
        $feddarrayData = json_decode(json_encode((array) $feed_to_array), TRUE);
        $final_feed_data = $feddarrayData['channel']['item'];
        //        echo "<pre>"; print_r($final_feed_data); die;
        foreach ($final_feed_data as $final_feeds) {
            $description1 = "In this episode, Chetandeep Singh presents his understanding of the shabad " . "'" . $final_feeds['title'] . "'" . " followed by a discussion and Q&A with the panelists of Khoj Gurbani.";

            $description2 = "KhojGurbani is an online platform with a mission to make the Guru Granth Sahib accessible to and exciting for the common Sikh, who wants to read Gurbani but does not have the tools and a support network to do so. While KhojGurbani will engage Sikhs globally in discussion on specific sections of Guru Granth Sahib every week, it will also spearhead the development of a crowdsourced commentary and a new idiomatic English translation.";

            $visit = "Visit http://www.khojgurbani.org/ for more information";
            $today_podcast_first = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->first();
            if ($today_podcast_first->attachment_name == $final_feeds['enclosure']['@attributes']['url']) {
                $today_approval = '1';
            } else {
                $today_approval = '0';
            }
            $datas[] = array(
                'title' => $final_feeds['title'],
                'date' => $final_feeds['pubDate'],
                'media_data' => $final_feeds['enclosure']['@attributes'],
                'description1' => $description1,
                'description2' => $description2,
                'visit' => $visit,
                'date' => $final_feeds['pubDate'],
                'today_approva' => $today_approval,
            );
        }
        $a = 1;

        if (isset($_GET['search']) && !empty($_GET['search'])) {

            $datas = DB::table('podcast_media')->where('title', 'LIKE', '%' . $_GET['search'] . '%')->where('description', 'LIKE', '%' . $_GET['search'] . '%')->get();
            //            foreach ($datas as $ke => $datass) {
            //                if ((strpos($datass['description1'], ucfirst($_GET['search'])) == 0 && strpos($datass['description1'], $_GET['search']) == 0) && (strpos($datass['title'], ucfirst($_GET['search'])) == 0 && strpos($datass['title'], $_GET['search']) == 0) && (strpos($datass['description2'], ucfirst($_GET['search'])) == 0 && strpos($datass['description2'], $_GET['search']) == 0)) {
            //                    unset($datas[$ke]);
            //                }
            //            }
            foreach ($datas as $ke => $datass) {
                $result12 = substr($datass->attachment_name, 0, 5);
                if ($result12 == 'https') {
                    $attachment_file = $datass->attachment_name;
                } else {
                    $attachment_file =  url('uploads/podcast_media/') . $datass->attachment_name;
                }
                $data[] = array(
                    'id' => $datass->id,
                    'title' => $datass->title,
                    'media' => $attachment_file,
                    'description1' => $datass->description,
                    'description2' => $datass->description,
                    'visit' => $datass['visit'],
                    'date' => $datass->created_at,
                    'today_approval' => $datass->today_approval,
                );
            }
            return json_encode(array('status' => '200', 'message' => 'podcast list', 'result' => $data));
        }
        //        echo "<pre>";
        //        print_r($datas);
        //        die;

        if (count($datas) > 0) {
            foreach ($datas as $ke => $datass) {
                $today_podcast_first = DB::table('podcast_media')->where('today_approval', '1')->orderBy('id', 'desc')->first();
                if ($today_podcast_first->attachment_name == $datass['media_data']['url']) {
                    $today_approval = '1';
                } else {
                    $today_approval = '0';
                }
                $title = $datass['title'];
                $media = $datass['media_data']['url'];
                $data[] = array(
                    'id' => $a,
                    'title' => $title,
                    'media' => $media,
                    'description1' => $datass['description1'],
                    'description2' => $datass['description2'],
                    'visit' => $datass['visit'],
                    'date' => $datass['date'],
                    'today_approval' => $today_approval,
                );
                $a++;
            }
        } else {
            $data = [];
        }
        //        echo "<pre>"; print_r($descr1); die;
        return json_encode(array('status' => '200', 'message' => 'podcast list', 'result' => $data));
    }

    //podcast list END
    //Recenty played function START
    public function recently_played(Request $request)
    {
        if ($request->user_id == '' || $request->user_id == null) {
            $recent_media_count = DB::table('media_play')->where('machine_id', $request->machine_id)->count();
            if ($recent_media_count > 0) {
                $recent_media = DB::table('media_play')->where('machine_id', $request->machine_id)->orderBy('updated_at', 'desc')->get()->unique('media_id')->reverse();
                foreach ($recent_media as $recent_medias) {
                    $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->where('media.id', $recent_medias->media_id)->get();
                    foreach ($items as $item) {
                        $result12 = substr($item->attachment_name, 0, 5);
                        if ($result12 == 'https') {
                            $attachment_file = $item->attachment_name;
                        } else {
                            $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        }
                        if ($item->image != null) {
                            $thumb = url('uploads/author/') . '/' . $item->image;
                        } else {
                            $thumb = '';
                        }
                        $data[] = array(
                            'id' => $item->id,
                            'title' => $item->title,
                            'type' => $item->type,
                            'duration' => $item->duration,
                            'attachment_name' => $attachment_file,
                            'img' => $thumb,
                            'tag_id' => $item->tag_id,
                            'author_name' => $item->name
                        );
                    }
                }
            } else {
                $data = [];
            }
        } else {
            $recent_media_count = DB::table('media_play')->where('user_id', $request->user_id)->count();
            if ($recent_media_count > 0) {
                $recent_media = DB::table('media_play')->where('user_id', $request->user_id)->orderBy('updated_at', 'desc')->get()->unique('media_id')->reverse();
                foreach ($recent_media as $recent_medias) {
                    $items = DB::table('media')->select('media.*', 'media_authors.image', 'media_authors.name')->leftjoin('media_authors', 'media.author_id', '=', 'media_authors.id')->where('media.id', $recent_medias->media_id)->get();
                    foreach ($items as $item) {
                        $result12 = substr($item->attachment_name, 0, 5);
                        if ($result12 == 'https') {
                            $attachment_file = $item->attachment_name;
                        } else {
                            $attachment_file = $category_image = url('uploads/media/') . '/' . $item->attachment_name;
                        }
                        if ($item->image != null) {
                            $thumb = url('uploads/author/') . '/' . $item->image;
                        } else {
                            $thumb = '';
                        }
                        $data[] = array(
                            'id' => $item->id,
                            'title' => $item->title,
                            'type' => $item->type,
                            'duration' => $item->duration,
                            'attachment_name' => $attachment_file,
                            'img' => $thumb,
                            'tag_id' => $item->tag_id,
                            'author_name' => $item->name
                        );
                    }
                }
            } else {
                $data = [];
            }
        }
        return json_encode(array('recently_played' => $data));
    }

    //Recenty played function END
    //new Aakash
    // public function featured_artist_gurbani(Request $request, $id)
    // {
    //     $sql ='select * from tblscripture t where exists (select 1 from translation t1 where t.id = t1.scriptureid and sahibsinghpunjabi is not null)';
    //    $items = DB::select($sql);
    //     if(count($items)>0){
    //         foreach ($items as $item => $value) {
    //             $data = array(
    //                 'id'=>$value->id,
    //                 'Scripture'=>$value->Scripture,
    //                 'ScriptureOriginal'=>$value->ScriptureOriginal,
    //                 'InfoID'=>$value->InfoID,
    //                 'MelodyID'=>$value->MelodyID,
    //                 'AuthorID'=>$value->AuthorID,
    //                 'Page'=>DB::table('tblscripture')->select('Page')->where('ShabadID', $value->ShabadID)->min('Page');,
    //                 'Line'=>$value->Line,
    //                 'Section'=>$value->Section,
    //                 'ScriptureRoman'=>$value->ScriptureRoman,
    //                 'ScriptureRomanEnglish'=>$value->ScriptureRomanEnglish,
    //                 'ScriptureVowel'=>$value->ScriptureVowel,
    //                 'ShabadID'=>$value->ShabadID,
    //             );

    //            }
    //     }else{
    //         $data=array();
    //     }


    //     return json_encode(array('status' => '200', 'message' => 'featured artist gurbaani', 'result' => $data));
    // }

    //New Aakash end here
    //featured artist gurbaani START
    public function featured_artist_gurbani(Request $request, $id)
    {

		$all_medias_unsorted = DB::table('media_dm as m1')
							   ->select('m1.id','m1.title','m1.duration','m1.author as author_name','m1.author as author_description', 
							   'm1.attachment_name','m1.image as author_image', 'm1.shabad_id','m1.page','m1.scripture_id','m1.Scripture','m1.ScriptureRomanEnglish')
            ->where('author_id', $id)
				->whereNotIn('id', DB::table('media_subcategories')->pluck('media_id'))
							   ->orderBy('title')
							   ->get();
//							   ->unique('title');

		$data = array_values(json_decode(json_encode($all_medias_unsorted), true));

        return json_encode(array('status' => '200', 'message' => 'featured artist gurbaani', 'result' => $data));

    }

    //featured artist gurbaani END
    //Add today
    public function add_today()
    {

        $url = $_GET['url'];
        $title = $_GET['title'];
        $podcast_exist = DB::table('podcast_media')->where('attachment_name', $url)->count();
        if ($podcast_exist > 0) {
            DB::table('podcast_media')->where('attachment_name', '!=', $url)->update([
                'today_approval' => '0'
            ]);
            DB::table('podcast_media')->where('attachment_name', $url)->update([
                'today_approval' => '1'
            ]);
        } else {
            DB::table('podcast_media')->update([
                'today_approval' => '0'
            ]);
            DB::table('podcast_media')->insert([
                //                'author_id' => Auth::user()->id,
                'shabad_id' => '1',

                'title' => $title,
                'attachment_name' => $url,
                'type' => 'IMAGE',
                'today_approval' => '1',
                'status' => '1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }
        return json_encode(array('status' => '200', 'message' => 'Podcast Media as been marked for today successfully.'));
    }

    public function updatePodcastStatus()
    {
        $id = $_GET['id'];
		$podcast_media_details = DB::table('podcast_media')->where('id', $id)->first();
		if(!empty($podcast_media_details))
		{
        	DB::table('podcast_media')->where('id', $id)->update(['today_approval' => '1']);
			$lang = $podcast_media_details->language;
			DB::table('podcast_media')->where('id', '!=', $id)->where('language', $lang)->update(['today_approval' => '0']);
		}
		/*
		DB::table('podcast_media')->where('id', $id)->update(['today_approval' => '1'
		DB::table('podcast_media')->where('id', '!=', $id)->update([
            'today_approval' => '0'
        ]);*/
        return json_encode(array('status' => '200', 'message' => 'Podcast Media status updated successfully.'));
    }

    ///////////// Media Management APIs ///////////////////////
    //Add media START
    public function podcast_add(Request $request)
    {
        //        $author_id = $request->author_id;
        $shabad_id = $request->shabad_id;
        $language = $request->language;
        $ref_type = $request->ref_type;
        $title = $request->title;
        $description = $request->description;
        $type = $request->type; //AUDIO,YOUTUBE,IMAGE
        $youtube_url = $request->youtube_url;
        $podbean_url = $request->podbean_url;
        $external_url = $request->external_url;
        if ($type == 'AUDIO') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ", "_", $fileNameO);

                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/podcast_media/';
                //                 Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                // die;
                $file->move($destinationPath, $fileNameUnique);
                $image = $fileNameUnique;
            } else {
                return json_encode(array('success' => '201', 'message' => 'MP3 File is required'));
            }
        } elseif ($type == 'IMAGE') {
            if ($podbean_url == '') {
                return json_encode(array('success' => '201', 'message' => 'Podbean URL is required'));
            }
            $image = $podbean_url;
        } elseif ($type == 'YOUTUBE') {
            if ($youtube_url == '') {
                return json_encode(array('success' => '201', 'message' => 'Youtube URL is required'));
            }
            $image = $youtube_url;
        } elseif ($type == 'EXTERNAL') {
            if ($external_url == '') {
                return json_encode(array('success' => '201', 'message' => 'External URL is required'));
            }
            $image = $external_url;
        } elseif ($type == 'S3') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ", "_", $fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';
                // $file->move($destinationPath, $fileNameUnique);
                //add to s3
                Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));

                $fileNameUnique12 = Storage::disk('s3santhya')->url($fileNameUnique);
                $fileNameUnique12 = "https://khojpodcast.s3.us-east-2.amazonaws.com/" . $fileNameUnique;
                //end s3
                $image = $fileNameUnique12;
            } else {
                return json_encode(array('success' => '201', 'message' => 'MP3 File is required'));
            }
        }


        if ($title == '') {
            return json_encode(array('success' => '201', 'message' => 'Title is required'));
        }

        //        if ($description == '') {
        //            return json_encode(array('success' => '201', 'message' => 'Descriprtion is required'));
        //        }


        if ($request->file('thumbnail')) {
            $file = $request->file('thumbnail');
            $imageType = $file->getClientmimeType();
            $fileNameO = $file->getClientOriginalName();
            $fileName = str_replace(" ", "_", $fileNameO);

            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/thumbnail/';
            $file->move($destinationPath, $fileNameUnique);
            $imagethumb = $fileNameUnique;
        } else {
            $imagethumb = '';
        }

        //            $slug = str_slug($title, '-');
        if (isset($shabad_id) && !empty($shabad_id)) {
            $podcast_media_cou = DB::table('podcast_media')->where('shabad_id', $shabad_id)->where('language', $language)->count();
            if ($podcast_media_cou > 0) {
                DB::table('podcast_media')->where('shabad_id', $shabad_id)->update([
                    'over_right' => '0'
                ]);
            }
        }
        $media_id = DB::table('podcast_media')->insertGetId([
            'title' => $title,
            'language' => $language,
            'description' => $description,
            'thumbnail' => $imagethumb,
            'shabad_id' => $shabad_id,
            'tag_id' => $request->tag_id,
            'type' => $type,
            'duration' => $request->duration,
            'attachment_name' => $image,
            'status' => '1',
            'today_approval' => '0',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        if ($request->tag_id) {
            DB::table('podcast_media_tags')->insert([
                'media_id' => $media_id,
                'tag_id' => $request->tag_id,
            ]);
        }

        if ($request->input('category')) {
            $all_cats = json_decode($request->input('category'));
            foreach ($all_cats as $all_cat) {
                DB::table('podcast_media_categories')->insertGetId([
                    'media_id' => $media_id,
                    'category_id' => $all_cat->cat_id
                ]);
            }
        }

        if ($request->new_category != null) {
            $slug = str_slug($request->new_category, '-');
            $new_cat_id = DB::table('podcast_categories')->insertGetId([
                'slug' => $slug,
                'name' => $request->new_category,
                'status' => '1'
            ]);

            DB::table('podcast_media_categories')->insertGetId([
                'media_id' => $media_id,
                'category_id' => $new_cat_id
            ]);
        }

        if ($request->input('sub_category')) {
            $all_subcats = json_decode($request->input('sub_category'));
            foreach ($all_subcats as $all_subcat) {
                $subcats_data = DB::table('podcast_subcategories')->where('id', $all_subcat->sub_cat_id)->first();
                DB::table('podcast_media_subcategories')->insertGetId([
                    'media_id' => $media_id,
                    'subcategory_id' => $all_subcat->sub_cat_id
                ]);
                DB::table('podcast_media_categories')->insertGetId([
                    'media_id' => $media_id,
                    'category_id' => $subcats_data->category_id
                ]);
            }
        }

        return json_encode(array('success' => '200', 'message' => 'New media created successfully.'));
    }

    //Add media END
    //update approval status
    public function updateApprovalStatus(Request $request)
    {
        if ($request->media_id && $request->status) {
            $media_id = $request->media_id;
            $status = $request->status;

            $result =  DB::table('media')->where('id', $media_id)->update([
                'media_approve' => $status
            ]);
            if ($result) {
                return json_encode(array('success' => '200', 'message' => 'Status updated successfully'));
            } else {
                return json_encode(array('error' => '404', 'message' => 'Status not updated'));
            }
        } else {
            return json_encode(array('error' => '404', 'message' => 'Status not updated'));
        }
    }
    //update approval status end
    //Api to send seach by title
    public function searchMediaByTitle(Request $request)
    {
        $data = array();
        $keyword = $request->keyword;
        if ($keyword) {
            $data = DB::table('media')->where('title', 'like', '%' . $keyword . '%')->where('media_approve', '=', '1')->get();
            if (count($data) > 0) {

                return json_encode(array('success' => '200', 'media_data' => $data));
            } else {
                return json_encode(array('error' => '404', 'media_data' => $data, 'message' => 'No media found'));
            }
        } else {
            return json_encode(array('error' => '404', 'media_data' => $data, 'message' => 'No media found'));
        }
    }
    //api end
    //Add media START
    public function add(Request $request)
    {

        $userid = $request->user_id;
        @$approvedUser = DB::table('users')->where('id', $userid)->get()->first()->auto_approve;
        $tag_id = $request->tag_id;
        $author_id = $request->author_id;
        $shabad_id = $request->shabad_id;
        $ref_type = $request->ref_type;
        $title = $request->title;
        $type = $request->type; //AUDIO,YOUTUBE,IMAGE
        $youtube_url = $request->youtube_url;
        $podbean_url = $request->podbean_url;
        $external_url = $request->external_url;
        $media_exist = DB::table('media')->where('title', $title)->where('user_id', $userid)->count();
		$fileNameUnique12 = '';
        if ($media_exist > 0) {
            // $title = $title . '_' . strtotime(date('Y-m-d'));
            /*return json_encode(array('success' => '201', 'message' => 'Media with title already exist. Please try with new one.'));*/
        }
        if ($type == 'AUDIO') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ", "_", $fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';
                $file->move($destinationPath, $fileNameUnique);

                $image = $fileNameUnique;
            } else {
                return json_encode(array('success' => '201', 'message' => 'MP3 File is required'));
            }
        } elseif ($type == 'IMAGE') {
            if ($podbean_url == '') {
                return json_encode(array('success' => '201', 'message' => 'Podbean URL is required'));
            }
            $image = $podbean_url;
        } elseif ($type == 'YOUTUBE') {
            if ($youtube_url == '') {
                return json_encode(array('success' => '201', 'message' => 'Youtube URL is required'));
            }
            $image = $youtube_url;
        } elseif ($type == 'EXTERNAL') {
            if ($external_url == '') {
                return json_encode(array('success' => '201', 'message' => 'External URL is required'));
            }
            $image = $external_url;
        } elseif ($type == 'S3') {
            if ($request->file('attachment_name')) {
                // return [
                //     config('app.bunny_cdn_api_access_key')
                // ];
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ", "_", $fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';
                // $file->move($destinationPath, $fileNameUnique);
                //add to s3
                $folder = 'Kirtan';
                if ($tag_id == 1) {
                    Storage::disk('s3santhya')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                    $fileNameUnique12 = Storage::disk('s3santhya')->url($fileNameUnique);
                    $folder = 'Santheya';
                }
                else if ($tag_id == 2) {
                    Storage::disk('s3kirtan')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                    $fileNameUnique12 = Storage::disk('s3kirtan')->url($fileNameUnique);
                    $folder = 'Kirtan';
                }
                else if ($tag_id == 4) {
                    Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                    $fileNameUnique12 = Storage::disk('s3')->url($fileNameUnique);
                    $folder = 'Kirtan';
                }
                else if ($tag_id == 15) {
                    Storage::disk('s3katha')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                    $fileNameUnique12 = Storage::disk('s3katha')->url($fileNameUnique);
                    $folder = 'Katha';
                }
                //end s3
                $image = $fileNameUnique12;
                $bunnyCDNStorage = new BunnyCDNStorage(config('app.bunny_cdn_storage_zone_name'), config('app.bunny_cdn_api_access_key'));
                $image = $bunnyCDNStorage->uploadFile($file, "/".config('app.bunny_cdn_storage_zone_name') . "/".$folder."/".$fileNameUnique);
                $image = config('app.bunny_cdn_alias_url').$folder.'/'.$fileNameUnique;
            } else {
                return json_encode(array('success' => '201', 'message' => 'MP3 File is required'));
            }
        }


        if ($title == '') {
            return json_encode(array('success' => '201', 'message' => 'Title is required'));
        }

        if ($author_id == '') {
            return json_encode(array('success' => '201', 'message' => 'Author is required'));
        }

        //check if the user is approved

        //end check
        if ($approvedUser == 0) {
            $approved = 0;
            // $admin_emails = DB::table('users')->select(['email as email'])->whereIn('role_id', [3,4])->pluck('email')->toArray();
            // Mail::to($admin_emails)->send(new ContentMail('media'));
        } else {
            $approved = 1;
        }
        //            $slug = str_slug($title, '-');
        $media_id = DB::table('media')->insertGetId([
            'title' => $title,
            'user_id' => $userid,
            'author_id' => $author_id,
            'shabad_id' => $shabad_id,
            'tag_id' => $request->tag_id,
            'type' => $type,
            'attachment_name' => $image,
			'attachment_name_aws' => $fileNameUnique12,
            'status' => '1',
            'duration' => $request->duration,
            'media_approve' => $approved,
            'created_at' => date('Y-m-d H:i:s'),
            'created_by' => $userid,
            'updated_by' => $userid
        ]);

        if ($request->tag_id) {
            DB::table('media_tags')->insert([
                'media_id' => $media_id,
                'tag_id' => $request->tag_id,
            ]);
        }

        if ($request->input('category')) {
            $all_cats = json_decode($request->input('category'));
            foreach ($all_cats as $all_cat) {
                DB::table('media_categories')->insertGetId([
                    'media_id' => $media_id,
                    'category_id' => $all_cat->cat_id
                ]);
            }
        }

        if ($request->new_category != null) {
            $slug = str_slug($request->new_category, '-');
            $new_cat_id = DB::table('categories')->insertGetId([
                'slug' => $slug,
                'name' => $request->new_category,
                'status' => '1'
            ]);

            DB::table('media_categories')->insertGetId([
                'media_id' => $media_id,
                'category_id' => $new_cat_id
            ]);
        }

        if ($request->input('sub_category')) {
            $all_subcats = json_decode($request->input('sub_category'));
            foreach ($all_subcats as $all_subcat) {
                $subcats_data = DB::table('subcategories')->where('id', $all_subcat->sub_cat_id)->first();
                DB::table('media_subcategories')->insertGetId([
                    'media_id' => $media_id,
                    'subcategory_id' => $all_subcat->sub_cat_id
                ]);
                $cat_exist = DB::table('media_categories')->where('media_id', $media_id)->where('category_id', $subcats_data->category_id)->count();
                if ($cat_exist == 0) {
                    DB::table('media_categories')->insertGetId([
                        'media_id' => $media_id,
                        'category_id' => $subcats_data->category_id
                    ]);
                }
            }
        }

        return json_encode(array('success' => '200', 'message' => 'New media created successfully.'));
    }

    //Add media END
    //Media listing API START
    public function media_list(Request $request)
    {
        if ($request->q) {
            if ($request->whole_word == 'yes') {
                $medias = DB::table('media')
                    ->where('title', $request->q)
                    ->orderBy('id', 'DESC')
                    ->paginate(30);
            } else {
                $medias = DB::table('media')
                    ->where('title', 'LIKE', '%' . $request->q . '%')
                    ->orWhere('id', 'LIKE', '%' . $request->q . '%')
                    ->orderBy('id', 'DESC')
                    ->paginate(30);
            }
        } else {
            $medias = DB::table('media')->orderBy('id', 'DESC')->paginate(30);
        }
        $all_cats_media = [];
        $all_categories_media = '';
        //        $data432 = static::get();
        if (count($medias) > 0) {

            foreach ($medias as $k => $media) {
                $author_data12 = DB::select("select * from media_authors where id='$media->author_id' LIMIT 1");
                @$pageID = DB::table('tblscripture')->select('Page')->where('ShabadID', $media->shabad_id)->min('Page');
                $medias[$k]->pageID = $pageID;
                if (isset($author_data12) && !empty($author_data12)) {
                    $author_data_name = $author_data12[0]->name;
                } else {
                    $author_data_name = '';
                }
                $author_tags_count = DB::table('media_tags')->where('media_id', $media->id)->count();
                if ($author_tags_count > 0) {
                    //                die('here');
                    $author_tags = DB::table('media_tags')->where('media_id', $media->id)->first();
                    $tags_data = DB::table('tags')->where('id', $author_tags->tag_id)->first();
                } else {
                    //                die('ff');
                    $author_tags = [];
                    $tags_data = [];
                }

                $all_media_cats = DB::table('categories')
                    ->leftjoin('media_categories', 'media_categories.category_id', '=', 'categories.id')
                    ->select('categories.name')
                    ->where('media_categories.media_id', '=', $media->id)
                    ->get();

                $all_media_subcats = DB::table('subcategories')
                    ->leftjoin('media_subcategories', 'media_subcategories.subcategory_id', '=', 'subcategories.id')
                    ->select('subcategories.name')
                    ->where('media_subcategories.media_id', '=', $media->id)
                    ->get();
                $all_cats_media = [];
                $all_subcats_media = [];
                if (count($all_media_cats) > 0) {
                    foreach ($all_media_cats as $all_media_cat) {
                        $all_cats_media[] = $all_media_cat->name;
                    }
                    $all_categories_media = implode(',', $all_cats_media);
                    $all_comma_cats = rtrim($all_categories_media, ',');
                } else {
                    $all_comma_cats = [];
                }

                if (count($all_media_subcats) > 0) {
                    foreach ($all_media_subcats as $all_media_subcat) {
                        $all_subcats_media[] = $all_media_subcat->name;
                    }
                    $all_subcategories_media = implode(',', $all_subcats_media);
                    $all_comma_subcats = rtrim($all_subcategories_media, ',');
                } else {
                    $all_comma_subcats = [];
                }
                $type = $media->type;
                if ($type == 'IMAGE') {
                    $image = $media->attachment_name;
                } elseif ($type == 'YOUTUBE') {
                    $image = $media->attachment_name;
                } elseif ($type == 'EXTERNAL') {
                    $image = $media->attachment_name;
                } elseif ($type == 'AUDIO') {
                    $image = url('uploads/media/') . '/' . $media->attachment_name;
                    //                     $tagName = $tags_data->name;
                    //                    if($tagName=='Kirtan'){
                    //                        $exists = Storage::disk('s3kirtan')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3kirtan')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }
                    //                    if($tagName=='Santhiya'){
                    //                        $exists = Storage::disk('s3santhya')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3santhya')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }
                    //                    if($tagName=='Podcast'){
                    //                        $exists = Storage::disk('s3')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }
                    //                    if($tagName=='Katha'){
                    //                        $exists = Storage::disk('s3katha')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3katha')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }

                } elseif ($type == 'S3') {
                    $image = $media->attachment_name;
                }
                if (isset($tags_data->name) && !empty($tags_data->name)) {
                    $medias[$k]->author_name = $author_data_name;
                    $medias[$k]->attachment_name = $image;
                    $medias[$k]->media_categories = $all_comma_cats;
                    $medias[$k]->media_subcategories = $all_comma_subcats;
                    $medias[$k]->media_tag = $tags_data->name;
                    //                    $data12[] = array(
                    //                        'id' => $media->id,
                    //                        'shabad_id' => $media->shabad_id,
                    //                        'title' => $media->title,
                    //                        'type' => $media->type,
                    //                        'duration' => $media->duration,
                    //                        'status' => $media->status,
                    //                        'author_name' => $author_data_name,
                    //                        'attachment_name' => $image,
                    //                        'media_categories' => $all_comma_cats,
                    //                        'media_subcategories' => $all_comma_subcats,
                    //                        'media_tag' => $tags_data->name
                    //                    );
                } else {
                    //                    $data12[] = array(
                    //                        'id' => $media->id,
                    //                        'shabad_id' => $media->shabad_id,
                    //                        'title' => $media->title,
                    //                        'type' => $media->type,
                    //                        'status' => $media->status,
                    //                        'author_name' => $author_data_name,
                    //                        'duration' => $media->duration,
                    //                        'attachment_name' => $image,
                    //                        'media_categories' => $all_comma_cats,
                    //                        'media_subcategories' => $all_comma_subcats,
                    //                        'media_tag' => ''
                    //                    );
                    $medias[$k]->author_name = $author_data_name;
                    $medias[$k]->attachment_name = $image;
                    $medias[$k]->media_categories = $all_comma_cats;
                    $medias[$k]->media_subcategories = $all_comma_subcats;
                    $medias[$k]->media_tag = '';
                }
            }

            //echo "<pre>"; print_r($data); die;
            //                $paginate = 10;
            //                $page = Input::get('page', 1);
            //                    $offSet = ($page * $paginate) - $paginate;
            //                    $itemsForCurrentPage = array_slice($data, $offSet, $paginate, true);
            //                    $result = new \Illuminate\Pagination\LengthAwarePaginator($itemsForCurrentPage, count($data), $paginate, $page);
            //                    $result = $result->toArray();
            //                    $result = $result;
            //                    $data=$result;

            // whatever is the result of your query that you wish to paginate.
            //$data = [];

            // The total number of items. If the `$items` has all the data, you can do something like this:
            //$totalItems = count($data12);

            // How many items do you want to display.
            //$perPage = 5;
            //
            //// The index page.
            //$currentPage = 1;
            //
            //$data = new \Illuminate\Pagination\LengthAwarePaginator($data12, $totalItems, $perPage, $currentPage);

            //                    foreach($data11 as $data11s){
            //                        $data[] = (object)$data11s;
            //                    }
            //die('hh');
        } else {
            $medias = ['data' => array()];
        }
        //        return json_encode($data11,JSON_PRETTY_PRINT);

        return json_encode(array('status' => '200', 'message' => 'Media List', 'result' => $medias));
    }

    //Media listing API END
    //Media listing API START
    public function podcast_media_list(Request $request)
    {
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            //            $medias = DB::table('podcast_media')->where('title','LIKE','%'.$_GET['search'].'%')->where('description','LIKE','%'.$_GET['search'].'%')->get();
            $search_string = $_GET['search'];
            $medias = DB::select("SELECT *  FROM `podcast_media` WHERE `title` LIKE '%$search_string%' OR `description` LIKE '%$search_string%' ");

            // print_r($medias); die;
        } else {
//            $medias = DB::table('podcast_media')->get()->toArray();
			  $medias = DB::table('podcast_media')->orderBy('id', 'desc')->limit(10)->get()->toArray();        
        }

        $all_cats_media = [];
        $all_categories_media = '';
        //        echo "<pre>"; print_r($medias); die;
        foreach ($medias as $key => $media) {
            //            $author_data=DB::table('media_authors')->where('id',$media->author_id)->first();
            //            $author_tags=DB::table('media_tags')->where('media_id',$media->id)->first();
            //            echo "<pre>"; print_r($author_tags); die;
            //            $tags_data=DB::table('tags')->where('id',$author_tags->tag_id)->first();
            $all_media_cats = DB::table('podcast_categories')
                ->leftjoin('podcast_media_categories', 'podcast_media_categories.category_id', '=', 'podcast_categories.id')
                ->select('podcast_categories.name')
                ->where('podcast_media_categories.media_id', '=', $media->id)
                ->get();
            //            echo "<pre>"; print_r($author_tags); die;
            $all_cats_media = [];
            if (count($all_media_cats) > 0) {
                foreach ($all_media_cats as $all_media_cat) {
                    $all_cats_media[] = $all_media_cat->name;
                }
                $all_categories_media = implode(',', $all_cats_media);
                $all_comma_cats = rtrim($all_categories_media, ',');
            } else {
                $all_comma_cats = [];
            }

            ///////////////////////////////
            $all_media_subcats = DB::table('podcast_subcategories')
                ->leftjoin('podcast_media_subcategories', 'podcast_media_subcategories.subcategory_id', '=', 'podcast_subcategories.id')
                ->select('podcast_subcategories.name')
                ->where('podcast_media_subcategories.media_id', '=', $media->id)
                ->get();
            //            echo "<pre>"; print_r($author_tags); die;
            $all_subcats_media = [];
            if (count($all_media_subcats) > 0) {
                foreach ($all_media_subcats as $all_media_subcat) {
                    $all_subcats_media[] = $all_media_subcat->name;
                }
                $all_subcategories_media = implode(',', $all_subcats_media);
                $all_comma_subcats = rtrim($all_subcategories_media, ',');
            } else {
                $all_comma_subcats = [];
            }


            $type = $media->type;
            if ($type == 'IMAGE') {
                $image_a = $media->attachment_name;
            } elseif ($type == 'YOUTUBE') {
                $image_a = $media->attachment_name;
            } elseif ($type == 'EXTERNAL') {
                $image_a = $media->attachment_name;
            } elseif ($type == 'AUDIO') {
                $image_a = url('uploads/podcast_media/') . '/' . $media->attachment_name;
                //will uncomment this afterward as still all files are on localhost
                //                    $exists = Storage::disk('s3')->exists($media->attachment_name);
                //
                //                   if($exists){
                //                    $image = Storage::disk('s3')->url($media->attachment_name);
                //                   }

            } elseif ($type == 'S3') {
                $image_a = $media->attachment_name;
            }
            if ($media->thumbnail == null || $media->thumbnail == '') {
                $thumbnail_pod = '';
            } else {
                $thumbnail_pod = url('uploads/thumbnail/') . '/' . $media->thumbnail;
            }
            //            $data[] = array(
            //                'id' => $media->id,
            //                'type' => $media->type,
            //                'shabad_id' => $media->shabad_id,
            //                'description' => $media->description,
            //                'language' => $media->language,
            //                'title' => $media->title,
            //                'duration' => $media->duration,
            //                'thumbnail_pod' => $thumbnail_pod,
            //                'status' => $media->status,
            //                'today_approval' => $media->today_approval,
            //                'attachment_name' => $image_a,
            //                'media_categories' => $all_comma_cats,
            //                'media_subcategories' => $all_comma_subcats,
            ////                'media_tag'=>$tags_data->name
            //            );
            $medias[$key]->thumbnail_pod = $thumbnail_pod;
            $medias[$key]->attachment_name = $image_a;
            $medias[$key]->media_categories = $all_comma_cats;
            $medias[$key]->media_subcategories = $all_comma_subcats;
            if (isset($tags_data->name) && !empty($tags_data->name)) {
                $medias[$key]->media_tag = $tags_data->name;
            } else {
                $medias[$key]->media_tag = '';
            }
        }

        return json_encode(array('status' => '200', 'message' => 'Podcast Media List', 'result' => $medias));
    }

    public function media_list_noduration(Request $request)
    {
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            //            $medias = DB::table('podcast_media')->where('title','LIKE','%'.$_GET['search'].'%')->where('description','LIKE','%'.$_GET['search'].'%')->get();
            $search_string = $_GET['search'];
            $medias = DB::select("SELECT *  FROM `podcast_media` WHERE `title` LIKE '%$search_string%' OR `description` LIKE '%$search_string%' ");

            // print_r($medias); die;
        } else {

            $medias = DB::table('media')->whereNull('duration')->take(300)->get();
            //             echo "<pre>"; print_r($medias); die;
        }

        //        $all_cats_media = [];
        //        $all_categories_media = '';
        //        echo "<pre>"; print_r($medias); die;
        if (count($medias) == '0') {
            $data = [];
            return json_encode(array('status' => '200', 'message' => 'Podcast Media List', 'result' => $data));
        }
        foreach ($medias as $key => $media) {
            //            $author_data=DB::table('media_authors')->where('id',$media->author_id)->first();
            //            $author_tags=DB::table('media_tags')->where('media_id',$media->id)->first();
            //            echo "<pre>"; print_r($author_tags); die;
            //            $tags_data=DB::table('tags')->where('id',$author_tags->tag_id)->first();
            //            $all_media_cats = DB::table('podcast_categories')
            //                    ->leftjoin('podcast_media_categories', 'podcast_media_categories.category_id', '=', 'podcast_categories.id')
            //                    ->select('podcast_categories.name')
            //                    ->where('podcast_media_categories.media_id', '=', $media->id)
            //                    ->get();
            //            echo "<pre>"; print_r($author_tags); die;
            //            $all_cats_media = [];
            //            if (count($all_media_cats) > 0) {
            //                foreach ($all_media_cats as $all_media_cat) {
            //                    $all_cats_media[] = $all_media_cat->name;
            //                }
            //                $all_categories_media = implode(',', $all_cats_media);
            //                $all_comma_cats = rtrim($all_categories_media, ',');
            //            } else {
            //                $all_comma_cats = [];
            //            }

            ///////////////////////////////
            //            $all_media_subcats = DB::table('podcast_subcategories')
            //                    ->leftjoin('podcast_media_subcategories', 'podcast_media_subcategories.subcategory_id', '=', 'podcast_subcategories.id')
            //                    ->select('podcast_subcategories.name')
            //                    ->where('podcast_media_subcategories.media_id', '=', $media->id)
            //                    ->get();
            ////            echo "<pre>"; print_r($author_tags); die;
            //            $all_subcats_media = [];
            //            if (count($all_media_subcats) > 0) {
            //                foreach ($all_media_subcats as $all_media_subcat) {
            //                    $all_subcats_media[] = $all_media_subcat->name;
            //                }
            //                $all_subcategories_media = implode(',', $all_subcats_media);
            //                $all_comma_subcats = rtrim($all_subcategories_media, ',');
            //            } else {
            //                $all_comma_subcats = [];
            //            }


            $type = $media->type;
            if ($type == 'IMAGE') {
                $image_a = $media->attachment_name;
            } elseif ($type == 'YOUTUBE') {
                $image_a = $media->attachment_name;
            } elseif ($type == 'EXTERNAL') {
                $image_a = $media->attachment_name;
            }
            if ($type == 'AUDIO') {
                $image_a = url('uploads/podcast_media/') . '/' . $media->attachment_name;
            } else {
                $image_a = $media->attachment_name;
            }

            $result12 = substr($media->attachment_name, 0, 5);
            if ($result12 == 'https') {
                $image_a = $media->attachment_name;
            } else {
                $image_a = url('uploads/media/') . '/' . $media->attachment_name;
            }
            if ($media->thumbnail == null || $media->thumbnail == '') {
                $thumbnail_pod = '';
            } else {
                $thumbnail_pod = url('uploads/thumbnail/') . '/' . $media->thumbnail;
            }
            $data[] = array(
                'id' => $media->id,
                //                'type' => $media->type,
                //                'shabad_id' => $media->shabad_id,
                //                'description' => $media->description,
                //                'language' => $media->language,
                //                'title' => $media->title,
                'duration' => $media->duration,
                //                'thumbnail_pod' => $thumbnail_pod,
                //                'status' => $media->status,
                //                'today_approval' => $media->today_approval,
                'attachment_name' => $image_a,
                //                'media_categories' => $all_comma_cats,
                //                'media_subcategories' => $all_comma_subcats,
                //                'media_tag'=>$tags_data->name
            );
            //                $medias[$key]->thumbnail_pod = $thumbnail_pod;
            //                $medias[$key]->attachment_name = $image_a;
            //                $medias[$key]->media_categories = $all_comma_cats;
            //                $medias[$key]->media_subcategories = $all_comma_subcats;
            //                if(isset($tags_data->name) && !empty($tags_data->name)){
            //                $medias[$key]->media_tag = $tags_data->name;
            //                }else{
            //                    $medias[$key]->media_tag = '';
            //                }
        }
        return json_encode(array('status' => '200', 'message' => 'Podcast Media List', 'result' => $data));
    }

    public function media_duration_update(Request $request)
    {
        $all_medias = json_decode($request->input('media'));

        if (isset($all_medias) && !empty($all_medias)) {
            foreach ($all_medias as $all_media) {
                DB::table('media')
                    ->where('id', $all_media->id)
                    ->update(['duration' => $all_media->duration]);
            }

            return json_encode(array('status' => '200', 'message' => 'Media duration has been updated'));
        } else {
            return json_encode(array('status' => '201', 'message' => 'Something went wrong'));
        }
    }

    //Media listing API END
    //update Media Author status START
    public function update_podcast_status_media(Request $request, $id)
    {
        $status = $request->status;
        $podcast_cat_check = DB::table('podcast_media')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1') {
                DB::table('podcast_media')->where('id', $id)->update([
                    'status' => $status
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if ($status == '0') {
                DB::table('podcast_media')->where('id', $id)->update([
                    'status' => $status
                ]);
                DB::table('podcast_media')->where('id', $id)->update([
                    'status' => $status,
                    'featured' => '0',
                    'featured_display_order' => NULL
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if ($status != '0' || $status != '1') {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No media Exist with this detail'));
        }
    }

    //update Media Author status END
    //Update media START
    public function update_media(Request $request, $id)
    {
        $tag_id = $request->tag_id;
        $get_last_media = DB::table('media')->where('id', $id)->first();
        $author_id = $request->author_id;
        $shabad_id = $request->shabad_id;
        $ref_type = $request->ref_type;
        $title = $request->title;
        $type = $request->type; //AUDIO,YOUTUBE,IMAGE
        $youtube_url = $request->youtube_url;
        $podbean_url = $request->podbean_url;
        $external_url = $request->external_url;
        $media_exist = DB::table('media')->where('id', '!=', $id)->where('title', $title)->where('author_id', $author_id)->count();
        if ($media_exist > 0) {
            return json_encode(array('success' => '201', 'message' => 'Media with title already exist. Please try with new one.'));
        }

        if ($type == 'AUDIO') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ", "_", $fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';
                $file->move($destinationPath, $fileNameUnique);

                //                if($tag_id==1){
                //                    Storage::disk('s3santhya')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                //               }
                //               if($tag_id==2){
                //                   Storage::disk('s3kirtan')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                //               }
                //               if($tag_id==4){
                //                   Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                //                }
                //               if($tag_id==15){
                //                   Storage::disk('s3katha')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                //               }

                $image = $fileNameUnique;
            } else {
                $image = $get_last_media->attachment_name;
            }
        } elseif ($type == 'IMAGE') {
            if ($podbean_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $podbean_url;
            }
        } elseif ($type == 'YOUTUBE') {
            if ($youtube_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $youtube_url;
            }
        } elseif ($type == 'EXTERNAL') {
            if ($external_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $external_url;
            }
        } elseif ($type == 'S3') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ", "_", $fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';
                //$file->move($destinationPath, $fileNameUnique);

                if ($tag_id == 1) {
                    Storage::disk('s3santhya')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                    $fileNameUnique12 = Storage::disk('s3santhya')->url($fileNameUnique);
                }
                if ($tag_id == 2) {
                    Storage::disk('s3kirtan')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                    $fileNameUnique12 = Storage::disk('s3kirtan')->url($fileNameUnique);
                }
                if ($tag_id == 4) {
                    Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                    $fileNameUnique12 = Storage::disk('s3')->url($fileNameUnique);
                }
                if ($tag_id == 15) {
                    Storage::disk('s3katha')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                    $fileNameUnique12 = Storage::disk('s3katha')->url($fileNameUnique);
                }

                $image = $fileNameUnique12;
            } else {
                $image = $get_last_media->attachment_name;
            }
        }


        if ($title == null) {
            return json_encode(array('success' => '201', 'message' => 'Title is required'));
        }

        if ($author_id == null) {
            return json_encode(array('success' => '201', 'message' => 'Author is required'));
        }


        //            $slug = str_slug($title, '-');
        //echo $get_last_media; die;
        DB::table('media')->where('id', $id)->update([
            'title' => $title,
            'author_id' => $author_id,
            'shabad_id' => $shabad_id,
            'tag_id' => $request->tag_id,
            'type' => $type,
            'duration' => $request->duration,
            'attachment_name' => $image,
            'status' => '1',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        DB::table('media_tags')->where('media_id', $id)->delete();
        DB::table('media_categories')->where('media_id', $id)->delete();
        DB::table('media_subcategories')->where('media_id', $id)->delete();

        if ($request->tag_id) {
            DB::table('media_tags')->insert([
                'media_id' => $id,
                'tag_id' => $request->tag_id,
            ]);
        }

        if ($request->input('category')) {
            $all_cats = json_decode($request->input('category'));
            foreach ($all_cats as $all_cat) {
                DB::table('media_categories')->insertGetId([
                    'media_id' => $id,
                    'category_id' => $all_cat->cat_id
                ]);
            }
        }

        if ($request->new_category != null) {
            $slug = str_slug($request->new_category, '-');
            $new_cat_id = DB::table('categories')->insertGetId([
                'slug' => $slug,
                'name' => $request->new_category,
                'status' => '1'
            ]);

            DB::table('media_categories')->insertGetId([
                'media_id' => $id,
                'category_id' => $new_cat_id
            ]);
        }

        if ($request->input('sub_category')) {
            $all_subcats = json_decode($request->input('sub_category'));
            foreach ($all_subcats as $all_subcat) {
                $subcats_data = DB::table('subcategories')->where('id', $all_subcat->sub_cat_id)->first();
                DB::table('media_subcategories')->insertGetId([
                    'media_id' => $id,
                    'subcategory_id' => $all_subcat->sub_cat_id
                ]);

                $cat_exist = DB::table('media_categories')->where('media_id', $id)->where('category_id', $subcats_data->category_id)->count();
                if ($cat_exist == 0) {
                    DB::table('media_categories')->insertGetId([
                        'media_id' => $id,
                        'category_id' => $subcats_data->category_id
                    ]);
                }

                //                    DB::table('media_categories')->insertGetId([
                //                        'media_id' => $id,
                //                        'category_id' => $subcats_data->category_id
                //                            ]
                //                    );
            }
        }

        return json_encode(array('success' => '200', 'message' => 'New media updated successfully.'));
    }

    //Update media END

    //Update media START
    public function update_podcast_media(Request $request, $id)
    {
        $get_last_media = DB::table('podcast_media')->where('id', $id)->first();
        $author_id = $request->author_id;
        $shabad_id = $request->shabad_id;
        $language = $request->language;
        $ref_type = $request->ref_type;
        $title = $request->title;
        $type = $request->type; //AUDIO,YOUTUBE,IMAGE
        $youtube_url = $request->youtube_url;
        $podbean_url = $request->podbean_url;
        $external_url = $request->external_url;
        $description = $request->description;
        $media_exist = DB::table('podcast_media')->where('id', '!=', $id)->where('title', $title)->count();
        if ($media_exist > 0) {
            return json_encode(array('success' => '201', 'message' => 'Media with title already exist. Please try with new one.'));
        }

        if ($type == 'AUDIO') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ", "_", $fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';

                //                Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                $file->move($destinationPath, $fileNameUnique);
                $image = $fileNameUnique;
            } else {
                $image = $get_last_media->attachment_name;
            }
        } elseif ($type == 'IMAGE') {
            if ($podbean_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $podbean_url;
            }
        } elseif ($type == 'YOUTUBE') {
            if ($youtube_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $youtube_url;
            }
        } elseif ($type == 'EXTERNAL') {
            if ($external_url == '') {
                $image = $get_last_media->attachment_name;
            } else {
                $image = $external_url;
            }
        } elseif ($type == 'S3') {
            if ($request->file('attachment_name')) {
                $file = $request->file('attachment_name');
                $imageType = $file->getClientmimeType();
                $fileNameO = $file->getClientOriginalName();
                $fileName = str_replace(" ", "_", $fileNameO);
                $fileNameUnique = time() . '_' . $fileName;
                $destinationPath = public_path() . '/uploads/media/';

                Storage::disk('s3')->put($fileNameUnique, fopen($request->file('attachment_name'), 'r+'));
                $fileNameUnique12 = Storage::disk('s3')->url($fileNameUnique);
                //$file->move($destinationPath, $fileNameUnique);
                $image = $fileNameUnique12;
            } else {
                $image = $get_last_media->attachment_name;
            }
        }


        if ($title == null) {
            return json_encode(array('success' => '201', 'message' => 'Title is required'));
        }

        //        if ($description == '') {
        //            return json_encode(array('success' => '201', 'message' => 'Descriprtion is required'));
        //        }
        if ($request->file('thumbnail')) {
            $file = $request->file('thumbnail');
            $imageType = $file->getClientmimeType();
            $fileNameO = $file->getClientOriginalName();
            $fileName = str_replace(" ", "_", $fileNameO);
            $fileNameUnique = time() . '_' . $fileName;
            $destinationPath = public_path() . '/uploads/thumbnail/';
            $file->move($destinationPath, $fileNameUnique);
            $imagethumb = $fileNameUnique;
        } else {
            $imagethumb = $get_last_media->thumbnail;
        }

        //            $slug = str_slug($title, '-');
        //echo $get_last_media; die;

        if (isset($shabad_id) && !empty($shabad_id)) {
            $podcast_media_cou = DB::table('podcast_media')->where('id', '!=', $id)->where('shabad_id', $shabad_id)->where('language', $language)->count();
            if ($podcast_media_cou > 0) {
                DB::table('podcast_media')->where('shabad_id', $shabad_id)->update([
                    'over_right' => '0'
                ]);
            }
        }

        DB::table('podcast_media')->where('id', $id)->update([
            'title' => $title,
            'description' => $description,
            'language' => $language,
            'thumbnail' => $imagethumb,
            'shabad_id' => $shabad_id,
            'tag_id' => $request->tag_id,
            'duration' => $request->duration,
            'type' => $type,
            'attachment_name' => $image,
            'status' => '1',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        DB::table('podcast_media_tags')->where('media_id', $id)->delete();
        DB::table('podcast_media_categories')->where('media_id', $id)->delete();
        DB::table('podcast_media_subcategories')->where('media_id', $id)->delete();

        if ($request->tag_id) {
            DB::table('podcast_media_tags')->insert([
                'media_id' => $id,
                'tag_id' => $request->tag_id,
            ]);
        }

        if ($request->input('category')) {
            $all_cats = json_decode($request->input('category'));
            foreach ($all_cats as $all_cat) {
                DB::table('podcast_media_categories')->insertGetId([
                    'media_id' => $id,
                    'category_id' => $all_cat->cat_id
                ]);
            }
        }

        if ($request->new_category != null) {
            $slug = str_slug($request->new_category, '-');
            $new_cat_id = DB::table('podcast_categories')->insertGetId([
                'slug' => $slug,
                'name' => $request->new_category,
                'status' => '1'
            ]);

            DB::table('podcast_media_subcategories')->insertGetId([
                'media_id' => $id,
                'category_id' => $new_cat_id
            ]);
        }

        if ($request->input('sub_category')) {
            $all_subcats = json_decode($request->input('sub_category'));
            foreach ($all_subcats as $all_subcat) {
                $subcats_data = DB::table('podcast_subcategories')->where('id', $all_subcat->sub_cat_id)->first();
                DB::table('podcast_media_subcategories')->insertGetId([
                    'media_id' => $id,
                    'subcategory_id' => $all_subcat->sub_cat_id
                ]);

                $cat_exist = DB::table('podcast_media_categories')->where('media_id', $id)->where('category_id', $subcats_data->category_id)->count();
                if ($cat_exist == 0) {
                    DB::table('podcast_media_categories')->insertGetId([
                        'media_id' => $id,
                        'category_id' => $subcats_data->category_id
                    ]);
                }

                //                    DB::table('media_categories')->insertGetId([
                //                        'media_id' => $id,
                //                        'category_id' => $subcats_data->category_id
                //                            ]
                //                    );
            }
        }

        return json_encode(array('success' => '200', 'message' => 'New media updated successfully.'));
    }

    //Update media END
    //update Media Author status START
    public function update_status_media(Request $request, $id)
    {
        $status = $request->status;
        $podcast_cat_check = DB::table('media')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            if ($status == '1') {
                DB::table('media')->where('id', $id)->update([
                    'status' => $status
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if ($status == '0') {
                DB::table('media')->where('id', $id)->update([
                    'status' => $status
                ]);
                DB::table('media')->where('id', $id)->update([
                    'status' => $status,
                    'featured' => '0',
                    'featured_display_order' => NULL
                ]);
                return json_encode(array('success' => '200', 'message' => 'Status has been updated successfully'));
            }
            if ($status != '0' || $status != '1') {
                return json_encode(array('success' => '201', 'message' => 'Somthing went wrong'));
            }
        } else {
            return json_encode(array('success' => '201', 'message' => 'No media Exist with this detail'));
        }
    }

    //update Media Author status END
    //delete media author START
    public function delete_media(Request $request, $id)
    {
        $podcast_cat_check = DB::table('media')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('media')->where('id', $id)->delete();
            //            DB::table('media_tags')->where('media_id', $id)->delete();
            DB::table('media_categories')->where('media_id', $id)->delete();
            DB::table('media_subcategories')->where('media_id', $id)->delete();
            return json_encode(array('success' => '200', 'message' => 'Media author has been deleted successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'No author Exist with this detail'));
        }
    }

    //delete media author END
    //delete media author START
    public function delete_podcast_media(Request $request, $id)
    {
        $podcast_cat_check = DB::table('podcast_media')->where('id', $id)->count();
        if ($podcast_cat_check > 0) {
            DB::table('podcast_media')->where('id', $id)->delete();
            //            DB::table('media_tags')->where('media_id',$id)->delete();
            DB::table('podcast_media_categories')->where('media_id', $id)->delete();
            DB::table('podcast_media_subcategories')->where('media_id', $id)->delete();
            return json_encode(array('success' => '200', 'message' => 'Podcast Media has been deleted successfully.'));
        } else {
            return json_encode(array('success' => '201', 'message' => 'No podcast media Exist with this detail'));
        }
    }

    //delete media author END
    //Get media audit list START
    public function popular_tracks(Request $request)
    {
        $data = array();

		$all_medias_unsorted = DB::select('SELECT id, shabad_id, title, name as author, type, duration,attachment_name_aws as attachment_name,play_count,user_media_id
										, page, 1 as is_media, image, author_id FROM popular_songs_dm order by pid desc');
		
		$data = array_values(json_decode(json_encode($all_medias_unsorted), true));

        return json_encode(array('success' => '200', 'message' => 'Popular Tracks', 'result' => $data));
        }

    public function mediaCount()
    {
        $totalPlayCount = DB::table("media")->sum('play_count');
        //episode Count
        $feed = 'https://feed.podbean.com/khojgurbani/feed.xml';
        $feed_to_array = (array) simplexml_load_file($feed);
        $feddarrayData = json_decode(json_encode((array) $feed_to_array), TRUE);
        $final_feed_data = $feddarrayData['channel']['item'];
        $podbeanCount = count($final_feed_data);
        //Episode count end
        $dataArray = array(
            'play_count' => $totalPlayCount,
            'podbean_count' => $podbeanCount
        );
        return json_encode($dataArray);
    }
    public function audit_list(Request $request)
    {
        $media_distinct_count_check = DB::table('media_play')
            ->select(['media_id as media_id'])
            ->groupBy('media_id')
            //                                        ->havingRaw('COUNT(media_id) > ?', [1])
            ->pluck('media_id');

        $all_medias = DB::table('media')->where('media_approve', '=', '1')->whereIn('id', $media_distinct_count_check)->paginate(60);

        if (count($all_medias) > 0) {
            foreach ($all_medias as $k => $all_media) {
                if ($all_media->attachment_name == null || $all_media->attachment_name == '') {
                    $media_url = '';
                } else {
                    if ($all_media->type == 'AUDIO') {
                        $media_url = url('uploads/media/') . '/' . $all_media->attachment_name;
                    } else {
                        $media_url = $all_media->attachment_name;
                    }
                }
                $media_distinct_count = DB::table('media_play')->where('media_id', $all_media->id)->count();
                @$pageID = DB::table('tblscripture')->select('Page')->where('ShabadID', $all_media->shabad_id)->min('Page');

                //   echo "<pre>";
                //     print_r($pageID);die;
                //                $result [] = array(
                //                    'media_id' => $all_media->id,
                //                    'media_title' => $all_media->title,
                //                    'media_url' => $media_url,
                //                    'media_start_date' => $all_media->play_start_date,
                //                    'media_start_time' => $all_media->play_start_time,
                //                    'media_last_date' => $all_media->play_last_date,
                //                    'media_last_time' => $all_media->play_last_time,
                //                    'media_distinct_count' => $media_distinct_count,
                //                );
                $all_medias[$k]->page_id = $pageID;
                $all_medias[$k]->media_url = $media_url;
                $all_medias[$k]->media_distinct_count = $media_distinct_count;
            }

            $all_medias->setCollection(
                collect(
                    collect($all_medias->items())->sortByDesc('media_distinct_count')
                )->values()
            );
        } else {
            $result = [];
        }

        return json_encode(array('status' => '200', 'message' => 'Media Audit List', 'result' => $all_medias));
    }


    //shabad data START
    public function shabad_data(Request $request, $id)
    {
        $medias = DB::table('podcast_media')->where('shabad_id', $id)->where('over_right', '1')->get();
        $all_cats_media = [];
        $all_categories_media = '';
        $data = array();
        //        echo "<pre>"; print_r($medias); die;
        foreach ($medias as $media) {
            //            $author_data=DB::table('media_authors')->where('id',$media->author_id)->first();
            //            $author_tags=DB::table('media_tags')->where('media_id',$media->id)->first();
            //            echo "<pre>"; print_r($author_tags); die;
            //            $tags_data=DB::table('tags')->where('id',$author_tags->tag_id)->first();
            $all_media_cats = DB::table('podcast_categories')
                ->leftjoin('podcast_media_categories', 'podcast_media_categories.category_id', '=', 'podcast_categories.id')
                ->select('podcast_categories.name')
                ->where('podcast_media_categories.media_id', '=', $media->id)
                ->get();
            //            echo "<pre>"; print_r($author_tags); die;
            $all_cats_media = [];
            if (count($all_media_cats) > 0) {
                foreach ($all_media_cats as $all_media_cat) {
                    $all_cats_media[] = $all_media_cat->name;
                }
                $all_categories_media = implode(',', $all_cats_media);
                $all_comma_cats = rtrim($all_categories_media, ',');
            } else {
                $all_comma_cats = [];
            }

            ///////////////////////////////
            $all_media_subcats = DB::table('podcast_subcategories')
                ->leftjoin('podcast_media_subcategories', 'podcast_media_subcategories.subcategory_id', '=', 'podcast_subcategories.id')
                ->select('podcast_subcategories.name')
                ->where('podcast_media_subcategories.media_id', '=', $media->id)
                ->get();
            //            echo "<pre>"; print_r($author_tags); die;
            $all_subcats_media = [];
            if (count($all_media_subcats) > 0) {
                foreach ($all_media_subcats as $all_media_subcat) {
                    $all_subcats_media[] = $all_media_subcat->name;
                }
                $all_subcategories_media = implode(',', $all_subcats_media);
                $all_comma_subcats = rtrim($all_subcategories_media, ',');
            } else {
                $all_comma_subcats = [];
            }


            $type = $media->type;
            if ($type == 'IMAGE') {
                $image_a = $media->attachment_name;
            } elseif ($type == 'YOUTUBE') {
                $image_a = $media->attachment_name;
            } elseif ($type == 'EXTERNAL') {
                $image_a = $media->attachment_name;
            } elseif ($type == 'AUDIO') {
                $image_a = url('uploads/podcast_media/') . '/' . $media->attachment_name;
            } elseif ($type == 'S3') {
                $image_a = $media->attachment_name;
            }
            if ($media->thumbnail == null || $media->thumbnail == '') {
                $thumbnail_pod = '';
            } else {
                $thumbnail_pod = url('uploads/thumbnail/') . '/' . $media->thumbnail;
            }
            $data[] = array(
                'id' => $media->id,
                'type' => $media->type,
                'description' => $media->description,
                'shabad_id' => $media->shabad_id,
                'language' => $media->language,
                'title' => $media->title,
                'duration' => $media->duration,
                'thumbnail_pod' => $thumbnail_pod,
                'status' => $media->status,
                'today_approval' => $media->today_approval,
                'attachment_name' => $image_a,
                'media_categories' => $all_comma_cats,
                'media_subcategories' => $all_comma_subcats,
                //                'media_tag'=>$tags_data->name
            );
        }
        return json_encode(array('status' => '200', 'message' => 'Podcast Media List', 'result' => $data));
    }
    //shabad data END

    public function subs(Request $request)
    {
        $email = $request->email;
        $ip    = $_SERVER['REMOTE_ADDR'];

        $subs_count = DB::table('subscribers')->where('email', $email)->count();

        if ($subs_count > 0) {
            return json_encode(array('status' => '201', 'message' => 'You have already subscribed'));
        } else {
            DB::table('subscribers')->insert([
                'email' => $email,
                'ip'    => $ip,
                'date'  => date('Y-m-d H:i:s')
            ]);

            $payload = array(
                'email'  => $email,
                'status' => 'subscribed'
            );

            $test = $this->syncMailchimp($payload);

            echo "<pre>";
            print_r($test);
            echo "</pre>";

            return json_encode(array('status' => '200', 'message' => 'You have subscribed successfully.'));
        }
    }

    function syncMailchimp($data)
    {
        $apiKey = '5caf53c2693a6479966f356744486552-us4';
        $listId = '3cc5e2458b';

        $memberId = md5(strtolower($data['email']));
        $dataCenter = substr($apiKey, strpos($apiKey, '-') + 1);
        $url = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . $listId . '/members/' . $memberId;

        $json = json_encode([
            'email_address' => $data['email'],
            'status'        => $data['status'], // "subscribed","unsubscribed","cleaned","pending"
        ]);

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_USERPWD, 'user:' . $apiKey);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return $httpCode;
    }

    //Get latest archive START
    public function archive_latest(Request $request)
    {
        $medias = DB::table('podcast_media')->orderBy('id', 'desc')->take(5)->get();
        $all_cats_media = [];
        $all_categories_media = '';
        //        $data432 = static::get();
        if (count($medias) > 0) {

            foreach ($medias as $k => $media) {
                $author_data12 = DB::select("select * from podcast_media_authors where id='$media->author_id' LIMIT 1");
                if (isset($author_data12) && !empty($author_data12)) {
                    $author_data_name = $author_data12[0]->name;
                } else {
                    $author_data_name = '';
                }
                $author_tags_count = DB::table('podcast_media_tags')->where('media_id', $media->id)->count();
                if ($author_tags_count > 0) {
                    //                die('here');
                    $author_tags = DB::table('podcast_media_tags')->where('media_id', $media->id)->first();
                    $tags_data = DB::table('tags')->where('id', $author_tags->tag_id)->first();
                } else {
                    //                die('ff');
                    $author_tags = [];
                    $tags_data = [];
                }

                $all_media_cats = DB::table('categories')
                    ->leftjoin('podcast_media_categories', 'podcast_media_categories.category_id', '=', 'categories.id')
                    ->select('categories.name')
                    ->where('podcast_media_categories.media_id', '=', $media->id)
                    ->get();

                $all_media_subcats = DB::table('subcategories')
                    ->leftjoin('podcast_media_subcategories', 'podcast_media_subcategories.subcategory_id', '=', 'subcategories.id')
                    ->select('subcategories.name')
                    ->where('podcast_media_subcategories.media_id', '=', $media->id)
                    ->get();
                $all_cats_media = [];
                $all_subcats_media = [];
                if (count($all_media_cats) > 0) {
                    foreach ($all_media_cats as $all_media_cat) {
                        $all_cats_media[] = $all_media_cat->name;
                    }
                    $all_categories_media = implode(',', $all_cats_media);
                    $all_comma_cats = rtrim($all_categories_media, ',');
                } else {
                    $all_comma_cats = [];
                }

                if (count($all_media_subcats) > 0) {
                    foreach ($all_media_subcats as $all_media_subcat) {
                        $all_subcats_media[] = $all_media_subcat->name;
                    }
                    $all_subcategories_media = implode(',', $all_subcats_media);
                    $all_comma_subcats = rtrim($all_subcategories_media, ',');
                } else {
                    $all_comma_subcats = [];
                }
                $type = $media->type;
                if ($type == 'IMAGE') {
                    $image = $media->attachment_name;
                } elseif ($type == 'YOUTUBE') {
                    $image = $media->attachment_name;
                } elseif ($type == 'EXTERNAL') {
                    $image = $media->attachment_name;
                } elseif ($type == 'AUDIO') {
                    $image = url('uploads/podcast_media/') . '/' . $media->attachment_name;
                    //                     $tagName = $tags_data->name;
                    //                    if($tagName=='Kirtan'){
                    //                        $exists = Storage::disk('s3kirtan')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3kirtan')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }
                    //                    if($tagName=='Santhiya'){
                    //                        $exists = Storage::disk('s3santhya')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3santhya')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }
                    //                    if($tagName=='Podcast'){
                    //                        $exists = Storage::disk('s3')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }
                    //                    if($tagName=='Katha'){
                    //                        $exists = Storage::disk('s3katha')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3katha')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }

                } elseif ($type == 'S3') {
                    $image = $media->attachment_name;
                }
                if (isset($tags_data->name) && !empty($tags_data->name)) {
                    $medias[$k]->author_name = $author_data_name;
                    $medias[$k]->attachment_name = $image;
                    $medias[$k]->media_categories = $all_comma_cats;
                    $medias[$k]->media_subcategories = $all_comma_subcats;
                    $medias[$k]->media_tag = $tags_data->name;
                    //                    $data12[] = array(
                    //                        'id' => $media->id,
                    //                        'shabad_id' => $media->shabad_id,
                    //                        'title' => $media->title,
                    //                        'type' => $media->type,
                    //                        'duration' => $media->duration,
                    //                        'status' => $media->status,
                    //                        'author_name' => $author_data_name,
                    //                        'attachment_name' => $image,
                    //                        'media_categories' => $all_comma_cats,
                    //                        'media_subcategories' => $all_comma_subcats,
                    //                        'media_tag' => $tags_data->name
                    //                    );
                } else {
                    //                    $data12[] = array(
                    //                        'id' => $media->id,
                    //                        'shabad_id' => $media->shabad_id,
                    //                        'title' => $media->title,
                    //                        'type' => $media->type,
                    //                        'status' => $media->status,
                    //                        'author_name' => $author_data_name,
                    //                        'duration' => $media->duration,
                    //                        'attachment_name' => $image,
                    //                        'media_categories' => $all_comma_cats,
                    //                        'media_subcategories' => $all_comma_subcats,
                    //                        'media_tag' => ''
                    //                    );
                    $medias[$k]->author_name = $author_data_name;
                    $medias[$k]->attachment_name = $image;
                    $medias[$k]->media_categories = $all_comma_cats;
                    $medias[$k]->media_subcategories = $all_comma_subcats;
                    $medias[$k]->media_tag = '';
                }
            }

            //echo "<pre>"; print_r($data); die;
            //                $paginate = 10;
            //                $page = Input::get('page', 1);
            //                    $offSet = ($page * $paginate) - $paginate;
            //                    $itemsForCurrentPage = array_slice($data, $offSet, $paginate, true);
            //                    $result = new \Illuminate\Pagination\LengthAwarePaginator($itemsForCurrentPage, count($data), $paginate, $page);
            //                    $result = $result->toArray();
            //                    $result = $result;
            //                    $data=$result;

            // whatever is the result of your query that you wish to paginate.
            //$data = [];

            // The total number of items. If the `$items` has all the data, you can do something like this:
            //$totalItems = count($data12);

            // How many items do you want to display.
            //$perPage = 5;
            //
            //// The index page.
            //$currentPage = 1;
            //
            //$data = new \Illuminate\Pagination\LengthAwarePaginator($data12, $totalItems, $perPage, $currentPage);

            //                    foreach($data11 as $data11s){
            //                        $data[] = (object)$data11s;
            //                    }
            //die('hh');
        } else {
            $medias = [];
        }
        //        return json_encode($data11,JSON_PRETTY_PRINT);

        return json_encode(array('status' => '200', 'message' => 'Archive data', 'result' => $medias));
        //        return json_encode(array('status' => '200', 'message' => 'Archive data','result'=>$archive_data));
    }

    //get all unapproved medias
    public function getUnapprovedMedia()
    {
        $unapprovedData = DB::table('media')
            ->join('users', 'users.id', '=', 'media.user_id')
            ->select('media.id as media_id', 'title', 'description', 'media.tag_id', 'type', 'shabad_id', 'media.updated_at', 'users.name')->where('media_approve', '=', '0')->get();
        if (count($unapprovedData) > 0) {
            foreach ($unapprovedData as $key => $value) {
                @$pageID = DB::table('tblscripture')->select('Page')->where('ShabadID', $value->shabad_id)->min('Page');
                $unapprovedData[$key]->page_id = $pageID;
            }
            $data = $unapprovedData;
        } else {
            $data = array();
        }
        return json_encode(array('status' => '200', 'message' => 'UnapprovedMedia', 'result' => $data));
    }
    //get approved medias
    //Download audio from s3
    public function download_config(Request $request)
    {
        $mediaID = $request->media_id;
        @$mediaName =  DB::table('media')->where('id', $mediaID)->get()->first()->attachment_name;
        @$tagId =  DB::table('media')->where('id', $mediaID)->get()->first()->tag_id;
        $arr = explode("/", $mediaName);
        @$detectBucket = $arr[2];
        $detectArray = explode('.', $detectBucket);
        @$bucketName = $detectArray[0];

        /*
       if($bucketName=='khojkirtan'){
        $diskname = 's3kirtan';
        }elseif($bucketName=='khojsantheya'){
        $diskname = 's3santhya';
       }elseif($bucketName=='khojkatha'){
        $diskname = 's3katha';
       }else{
        $diskname = false;;
       }
*/
        $folder = 'Kirtan';
        if ($tagId == 2) {
            $diskname = 's3kirtan';
            $folder = 'Kirtan';
        } elseif ($tagId == 1) {
            $diskname = 's3santhya';
            $folder = 'Santheya';
        } elseif ($tagId == 15) {
            $diskname = 's3katha';
            $folder = 'Katha';
        } else {
            $diskname = false;;
        }

        $lastIndex = count($arr) - 1;
        $last = $arr[$lastIndex];
        if ($diskname != false) {
            // $tempFile = tempnam(sys_get_temp_dir(), $last);
            // copy(config('app.bunny_cdn_alias_url').$folder.'/'.$last, $tempFile);
            // return response()->download($tempFile, $last);

            return Storage::disk($diskname)->download($last);
            //return json_encode(array('status' => '200', 'message' => 'File started Downloading'));
        } else {
            return json_encode(array('status' => '404', 'message' => 'File Not found'));
        }
    }
    //end download

    public function get_archive_all(Request $request)
    {
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            $search_string = $_GET['search'];
            //            $medias = DB::table('podcast_media')->where('name', 'like', "%{$_GET['search']}%")->orderBy('id','desc')->paginate(30);
            $medias = DB::select("SELECT *  FROM `podcast_media` WHERE `title` LIKE '%$search_string%' OR `description` LIKE '%$search_string%' ");
        } else {
            $medias = DB::table('podcast_media')->orderBy('id', 'desc')->paginate(30);
        }

        $all_cats_media = [];
        $all_categories_media = '';
        //        $data432 = static::get();
        if (count($medias) > 0) {

            foreach ($medias as $k => $media) {
                $author_data12 = DB::select("select * from podcast_media_authors where id='$media->author_id' LIMIT 1");
                if (isset($author_data12) && !empty($author_data12)) {
                    $author_data_name = $author_data12[0]->name;
                } else {
                    $author_data_name = '';
                }
                $author_tags_count = DB::table('podcast_media_tags')->where('media_id', $media->id)->count();
                if ($author_tags_count > 0) {
                    //                die('here');
                    $author_tags = DB::table('podcast_media_tags')->where('media_id', $media->id)->first();
                    $tags_data = DB::table('tags')->where('id', $author_tags->tag_id)->first();
                } else {
                    //                die('ff');
                    $author_tags = [];
                    $tags_data = [];
                }

                $all_media_cats = DB::table('categories')
                    ->leftjoin('podcast_media_categories', 'podcast_media_categories.category_id', '=', 'categories.id')
                    ->select('categories.name')
                    ->where('podcast_media_categories.media_id', '=', $media->id)
                    ->get();

                $all_media_subcats = DB::table('subcategories')
                    ->leftjoin('podcast_media_subcategories', 'podcast_media_subcategories.subcategory_id', '=', 'subcategories.id')
                    ->select('subcategories.name')
                    ->where('podcast_media_subcategories.media_id', '=', $media->id)
                    ->get();
                $all_cats_media = [];
                $all_subcats_media = [];
                if (count($all_media_cats) > 0) {
                    foreach ($all_media_cats as $all_media_cat) {
                        $all_cats_media[] = $all_media_cat->name;
                    }
                    $all_categories_media = implode(',', $all_cats_media);
                    $all_comma_cats = rtrim($all_categories_media, ',');
                } else {
                    $all_comma_cats = [];
                }

                if (count($all_media_subcats) > 0) {
                    foreach ($all_media_subcats as $all_media_subcat) {
                        $all_subcats_media[] = $all_media_subcat->name;
                    }
                    $all_subcategories_media = implode(',', $all_subcats_media);
                    $all_comma_subcats = rtrim($all_subcategories_media, ',');
                } else {
                    $all_comma_subcats = [];
                }
                $type = $media->type;
                if ($type == 'IMAGE') {
                    $image = $media->attachment_name;
                } elseif ($type == 'YOUTUBE') {
                    $image = $media->attachment_name;
                } elseif ($type == 'EXTERNAL') {
                    $image = $media->attachment_name;
                } elseif ($type == 'AUDIO') {
                    $image = url('uploads/podcast_media/') . '/' . $media->attachment_name;
                    //                     $tagName = $tags_data->name;
                    //                    if($tagName=='Kirtan'){
                    //                        $exists = Storage::disk('s3kirtan')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3kirtan')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }
                    //                    if($tagName=='Santhiya'){
                    //                        $exists = Storage::disk('s3santhya')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3santhya')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }
                    //                    if($tagName=='Podcast'){
                    //                        $exists = Storage::disk('s3')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }
                    //                    if($tagName=='Katha'){
                    //                        $exists = Storage::disk('s3katha')->exists($media->attachment_name);
                    //                        if($exists){
                    //                            $image = Storage::disk('s3katha')->url($media->attachment_name);
                    //                        }
                    //
                    //                    }

                } elseif ($type == 'S3') {
                    $image = $media->attachment_name;
                }
                if (isset($tags_data->name) && !empty($tags_data->name)) {
                    $medias[$k]->author_name = $author_data_name;
                    $medias[$k]->attachment_name = $image;
                    $medias[$k]->media_categories = $all_comma_cats;
                    $medias[$k]->media_subcategories = $all_comma_subcats;
                    $medias[$k]->media_tag = $tags_data->name;
                    //                    $data12[] = array(
                    //                        'id' => $media->id,
                    //                        'shabad_id' => $media->shabad_id,
                    //                        'title' => $media->title,
                    //                        'type' => $media->type,
                    //                        'duration' => $media->duration,
                    //                        'status' => $media->status,
                    //                        'author_name' => $author_data_name,
                    //                        'attachment_name' => $image,
                    //                        'media_categories' => $all_comma_cats,
                    //                        'media_subcategories' => $all_comma_subcats,
                    //                        'media_tag' => $tags_data->name
                    //                    );
                } else {
                    //                    $data12[] = array(
                    //                        'id' => $media->id,
                    //                        'shabad_id' => $media->shabad_id,
                    //                        'title' => $media->title,
                    //                        'type' => $media->type,
                    //                        'status' => $media->status,
                    //                        'author_name' => $author_data_name,
                    //                        'duration' => $media->duration,
                    //                        'attachment_name' => $image,
                    //                        'media_categories' => $all_comma_cats,
                    //                        'media_subcategories' => $all_comma_subcats,
                    //                        'media_tag' => ''
                    //                    );
                    $medias[$k]->author_name = $author_data_name;
                    $medias[$k]->attachment_name = $image;
                    $medias[$k]->media_categories = $all_comma_cats;
                    $medias[$k]->media_subcategories = $all_comma_subcats;
                    $medias[$k]->media_tag = '';
                }
            }

            //echo "<pre>"; print_r($data); die;
            //                $paginate = 10;
            //                $page = Input::get('page', 1);
            //                    $offSet = ($page * $paginate) - $paginate;
            //                    $itemsForCurrentPage = array_slice($data, $offSet, $paginate, true);
            //                    $result = new \Illuminate\Pagination\LengthAwarePaginator($itemsForCurrentPage, count($data), $paginate, $page);
            //                    $result = $result->toArray();
            //                    $result = $result;
            //                    $data=$result;

            // whatever is the result of your query that you wish to paginate.
            //$data = [];

            // The total number of items. If the `$items` has all the data, you can do something like this:
            //$totalItems = count($data12);

            // How many items do you want to display.
            //$perPage = 5;
            //
            //// The index page.
            //$currentPage = 1;
            //
            //$data = new \Illuminate\Pagination\LengthAwarePaginator($data12, $totalItems, $perPage, $currentPage);

            //                    foreach($data11 as $data11s){
            //                        $data[] = (object)$data11s;
            //                    }
            //die('hh');
        } else {
            $medias = [];
        }
        //        return json_encode($data11,JSON_PRETTY_PRINT);

        return json_encode(array('status' => '200', 'message' => 'Archive data', 'result' => $medias));
        //        return json_encode(array('status' => '200', 'message' => 'Archive data','result'=>$archive_data));
    }

    ///////////// Media Management APIs ///////////////////////
}
