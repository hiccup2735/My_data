<?php

namespace App\Presenters;

use App\Models\Media;
use Laracasts\Presenter\Presenter;

class MediaPresenter extends Presenter
{

    /**
     * set media title.
     * 
     * @return string of title.
     */
    public function title()
    {
    	return $this->entity->getTitle();
    }

    /**
     * format author name.
     * 
     * @return string of author name.
     */
    public function author_name()
    {
        $author = $this->entity->author;
        if(!$author) {
            return '--';
        }
        return $author->getName();
    }

    public function categoriesHtml()
    {
        $categories = $this->entity->categories;
        if($categories->isEmpty()) {
            return '--';
        }
        $html = "";
        foreach ($categories as $key => $category) {
            $html .= '<span class="badge badge-info">'.$category->getName().'</span>&nbsp;';
        }
        return $html;
    }

    public function tagsHtml()
    {
        $tags = $this->entity->tags;
        if($tags->isEmpty()) {
            return '--';
        }
        $html = "";
        foreach ($tags as $key => $tag) {
            $html .= '<span class="badge badge-info">'.$tag->getName().'</span>&nbsp;';
        }
        return $html;
    }

    /**
     * format author name.
     * 
     * @return string of author name.
     */
    public function ref_type()
    {
        $refType = $this->entity->ref_type;
                $refTypes = config('global.media.ref_type');
        return $refTypes[$refType] ?? '--';
    }

    /**
     * get link for change status.
     * 
     * @return html for status link
     */
    public function statusLink()
    {
    	$status = $this->entity->getStatus();
        $iconClass = "fa-times";
        if($status) {
   		   $iconClass = "fa-check";
    	}
    	$route = route('admin.media.toggle-status', $this->entity->getKey());
    	$link = "<a href='$route'><i class='fa $iconClass'></i></a>";
    	return $link;
    }

    /**
     * get link to delete service.
     * 
     * @return html for delete link
     */
    public function deleteLink()
    {
    	$route = route('admin.media.delete', $this->entity->getKey());
    	$html = "<a href='#' class='delete-link btn btn-danger'><i class='fa fa-trash'></i></a>";
    	$html .= "<form action='$route' method='post' class='delete-form' data-confirm='Do you really want to delete this Media?'>";
    		$html .= "<input type='hidden' name='_method' value='DELETE'>";
    		$html .= "<input type='hidden' name='_token' value='".csrf_token()."'>";
    	$html .= "</form>";
    	return $html;
    }

    /**
     * get link to delete service.
     * 
     * @return html for delete link
     */
    public function editLink()
    {
    	$route = route('admin.media.edit', $this->entity->getKey());
    	$html = "<a href='$route' class='btn btn-primary fa fa-edit'></a>";
    	return $html;
    }

    public function thumbnail()
    {
        $type = $this->entity->getType();
        $attachment = $this->entity->getThumbnail();
        if($type == Media::IMAGE_TYPE) {
            $attachment = $this->entity->getAttachmentName();
        }
        $uploadsDir = config('global.uploads.media.path');
        $thumbDir = config('global.uploads.media.thumb_dir');
        if($attachment) {
            $path = $uploadsDir . DIRECTORY_SEPARATOR . $thumbDir . DIRECTORY_SEPARATOR;
            return url("$path$attachment");
        }
        $imagesDir = config('global.images.path');
        $placeholderName = config('global.images.placeholder_name');
        $path = $imagesDir . DIRECTORY_SEPARATOR . $placeholderName;
        return url("$path");
    }
}
