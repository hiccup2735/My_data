<?php

namespace App\Presenters;

use League\Fractal\TransformerAbstract as FractalTransfomerAbstract;
use League\Fractal\Resource\ResourceInterface;
use League\Fractal\Scope;

abstract class TransformerAbstract extends FractalTransfomerAbstract
{   

    private $availableSparseFieldsets = [];
    private $sparseFieldsets = [];

    public function parseSparseFieldsets($includeName, array $fields = [], $previous = null)
    {
        
        $this->availableSparseFieldsets = $fields;

        if (!is_null($previous)) {
            $this->availableSparseFieldsets = $previous;
        }
        if (array_key_exists($includeName, $this->availableSparseFieldsets)) {
            $this->sparseFieldsets = $this->availableSparseFieldsets[$includeName];
        }
    }

    protected function callIncludeMethod(Scope $scope, $includeName, $data)
    {
        $resource = parent::callIncludeMethod($scope, $includeName, $data);

        if ($resource && array_key_exists($includeName, $this->availableSparseFieldsets)) {

            $resource->getTransformer()->parseSparseFieldsets($includeName,
                    $this->availableSparseFieldsets[$includeName], 
                    $this->availableSparseFieldsets
                );
        }
        return $resource;
    }


    protected function applySparseFieldsets(array $data)
    {

        $appliedData = [
            'id' => $data['id'],
        ];
        
        if (count($this->sparseFieldsets) > 0) {
            foreach ($this->sparseFieldsets as $key) {
                
                if (isset($data[$key])) {
                    $appliedData[$key] = $data[$key];
                }
            }

            return $appliedData;
        }

        return $data;
    }
}