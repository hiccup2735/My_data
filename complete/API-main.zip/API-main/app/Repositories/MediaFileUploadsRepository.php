<?php

namespace App\Repositories;

use App\Models\Media;
use App\Repositories\Repository;
use Illuminate\Http\Request;

class MediaFileUploadsRepository extends Repository
{
	protected $model;

	public function __construct(Media $model)
	{
		$this->model = $model;
	}

	/**
     *  upload and save attachment.
     */
    public function chunkUpload($file, $totalSize, $directoryPath)
    {

        $error = [];
        
        // $file = $request->file('file');
        $hasError = $file->getError();
        $filePath = $directoryPath . DIRECTORY_SEPARATOR . $file->getClientOriginalName();
        // $current_chunk = $request->get('_chunkNumber');
        // $totalSize = $request->get('_totalSize');
        
        // Open temp file
        if (!$out = @fopen("{$filePath}.part", $totalSize ? "ab" : "wb")) {
            $error = ["code" => 102, "message" => "102: Failed to open output stream."];
        }

        if ($file) {
            if ($hasError) {
                $errorMessage = $file->getErrorMessage();
                $error = ["code" => 103, "message" => "103: " . $errorMessage ];
            }

            $temp_path = $file->getPathName();
            if (!$in = @fopen($temp_path, "rb")) {
                $error = ["code" => 101, "message" => "101: Failed to open input stream."];
            }
        } else {
            if (!$in = @fopen("php://input", "rb")) {
                $error = ["code" => 101, "message" => "101: Failed to open input stream."];
            }
        }

        if ($error) {
            // return \Response::json($error, 500);
            throw new \Exception($error['message'], $error['code']);
            // return false;
        }

        while ($buff = fread($in, 4096)) {
            fwrite($out, $buff);
        }

        @fclose($out);
        @fclose($in);

        return true;
    }
}

