<?php

namespace App\Repositories\Admin;

use App\Models\Tag;
use App\Repositories\Admin\AdminRepository;

class TagsRepository extends AdminRepository
{
	protected $model;

	public function __construct(Tag $model)
	{
		$this->model = $model;
	}

	public function getList()
	{
		$builder = $this->model->where('status', true);
		return $builder->pluck('name', 'id');
	}

	public function setDataPayload($entity)
	{
		return [
			'name' => $entity->getName(),
			'description' => $entity->getDescription(),
			'status' => (bool)$entity->getStatus(),
		];
	}
}