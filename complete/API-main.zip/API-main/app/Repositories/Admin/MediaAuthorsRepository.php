<?php

namespace App\Repositories\Admin;

use App\Models\MediaAuthor;
use App\Repositories\Admin\AdminRepository;

class MediaAuthorsRepository extends AdminRepository
{
	protected $model;

	public function __construct(MediaAuthor $model)
	{
		$this->model = $model;
	}

	public function getList()
	{
		return $this->model->where('status', true)
						->pluck('name', 'id')
						->all();
	}

	public function getAuthorPaginateList($request)
	{
		$builder = $this->model->where('status', true)
							->selectRaw("id, name as text");

        return $builder->paginate($request->input('limit', 10));
	}

	public function getFeaturedAuthorList()
    {
        $builder = $this->model->where('featured', true)->orderBy('featured_display_order','asc');
        return $builder->pluck('name', 'id')->all();
    }

    /**
     * mark media as featured.
     * 
     * @param  $mediaIds: array of media ids.
     * @return boolean true.
     */
    public function markAsFeatured($mediaIds = [])
    {
        $builder = MediaAuthor::where('featured', 1);
        $builder->update(['featured' => false, 'featured_display_order'=> null]);

        foreach ($mediaIds as $key => $id) {
            $item = MediaAuthor::findOrFail($id);
            $item->featured = true;
            $item->featured_display_order = $key+1;
            $item->save();
        }

        return true;
    }

	public function setDataPayload($entity)
	{
		return [
			'name' => $entity->getName(),
			'image' => $entity->getImage(),
			'status' => (bool)$entity->getStatus(),
		];
	}
}