<?php

namespace App\Repositories\Admin;

use App\Repositories\Repository;

class AdminRepository extends Repository
{
	
	/**
     * toggle media status.
     * 
     * @param  $id: integer of media id.
     * @return App\Models\Media
     */
    public function toggleStatus($id)
    {
        $item = $this->model->findOrFail($id);
        $item->status = !$item->status;
        $item->save();
        return $item;
    }
}