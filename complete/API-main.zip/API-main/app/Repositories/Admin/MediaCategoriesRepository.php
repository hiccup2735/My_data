<?php

namespace App\Repositories\Admin;

use App\Models\Category;
use App\Repositories\Admin\AdminRepository;

class MediaCategoriesRepository extends AdminRepository
{
	protected $model;

	public function __construct(Category $model)
	{
		$this->model = $model;
//                print_r($this->model ); die;
	}

	public function getList()
	{
		$builder = $this->model->where('status', true);
		return $builder->pluck('name', 'id');
	}

	public function getCategoriesPaginateList($request)
	{
		$builder = $this->model->where('status', true)
							->selectRaw("id, name as text");

        return $builder->paginate($request->input('limit', 10));
	}

	public function getFeaturedCategoriesList()
    {
        $builder = $this->model->where('featured', true)
        					->orderBy('featured_display_order', 'ASC');
        return $builder->pluck('name', 'id')->all();
    }

    /**
     * mark media as featured.
     * 
     * @param  $categoryIds: array of media ids.
     * @return boolean true.
     */
    public function markAsFeatured($categoryIds = [])
    {
        $builder = Category::where('featured', 1);
        $builder->update(['featured' => false, 'featured_display_order'=> null]);

        foreach ($categoryIds as $key => $id) {
            $item = Category::findOrFail($id);
            $item->featured = true;
            $item->featured_display_order = $key+1;
            $item->save();
        }

        return true;
    }

	public function setDataPayload($entity)
	{
		return [
			'name' => $entity->getName(),
			'description' => $entity->getDescription(),
			'image' => $entity->getimage(),
			'status' => (bool)$entity->getStatus(),
		];
	}
}