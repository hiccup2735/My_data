<?php

namespace App\Repositories;

use App\Models\Media;
use App\Models\MediaTracking;
use Carbon\Carbon;
use Illuminate\Http\Request;

class MediaTrackingsRepository extends Repository
{
	protected $model;


	public function __construct(MediaTracking $model)
	{
		$this->model = $model;
	}

	/**
	 * get recently played media list.
	 * 
	 * @param  $request: Illuminate\Http\Request
	 * @return collection of App\Models\Media
	 */
	public function getRecentlyAccessedMedia(Request $request)
	{
		$tableName = (new MediaTracking)->getTable();
		$mediaTableName = (new Media)->getTable();
		$user = $request->user();
		$builder = Media::join("$tableName as trackings", function($join) use($mediaTableName) {
						$join->on('trackings.media_id', '=', "$mediaTableName.id");
					});
		$builder = $builder->where('trackings.user_id', $user->getKey());

		$builder = $builder->groupBy('media_id')
						->orderBy('trackings.last_accessed', 'DESC');

		return $builder->paginate($request->input('limit', 10));
	}

	/**
	 * set payload of data.
	 *
	 * @param  $item: App\Models\Comment
	 * @return array of data.
	 */
	public function setDataPayload($item)
	{
		$lastAccessed = Carbon::now();

		if($item->getLastAccessed()) {
			$lastAccessed = $item->getLastAccessed();
		}
		return [
			'media_id' 			=> $item->getMediaId(),
			'user_id' 			=> $item->getUserId(),
			'last_accessed' 	=> $lastAccessed
		];
	}
}

