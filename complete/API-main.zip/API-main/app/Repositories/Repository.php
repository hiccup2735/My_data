<?php

namespace App\Repositories;

use App\Models\AppModel;
use Illuminate\Http\Request;

class Repository
{
	protected $model;

	/**
	 * get list of comments.
	 *
	 * @param  $request: Illuminate\Http\Request
	 * @return collection of App\Models\Comment
	 */
	public function paginate(Request $request)
	{
		$builder = $this->model;
		$builder = $builder->filter($request->all())
						->sortable();
		return $builder->paginate($request->input('limit', 10));
	}
	
	/**
	 * get list of comments.
	 *
	 * @param  $request: Illuminate\Http\Request
	 * @return collection of App\Models\Comment
	 */
	public function get(Request $request)
	{
		$builder = $this->model;
		$builder = $builder->filter($request->all());

		if($request->filled('limit')) {
			$builder = $builder->take($request->input('limit'));
		}

		return $builder->sortable()->get();
	}
	
	public function save($item)
	{
		$data = $this->setDataPayload($item);

		$model = $this->model;
		$model->fill($data);
		$model->save();
		return $model;
	}

	/**
	 * update data to existing record.
	 * 
	 * @param  $id: integer id.
	 * @param  $item: Eloquent model object
	 * @return Eloquent model object.
	 */
	public function update($id, $item)
	{
		$data = $this->setDataPayload($item);

		$model = $this->model->find($id);
		$model->fill($data);
		$model->save();
		return $model;
	}

	public function setDataPayload($item)
	{
		return $item->toArray();
	}
}