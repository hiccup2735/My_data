<?php

namespace App\Repositories;

use App\Models\TblMelody;
use Illuminate\Http\Request;

class TblMelodiesRepository extends Repository
{
	protected $model;


	public function __construct(TblMelody $model)
	{
		$this->model = $model;
	}

	/**
	 * get list of tbl Authors.
	 *
	 * @param  $request: Illuminate\Http\Request
	 * @return collection of App\Models\TblMelody
	 */
	public function paginate(Request $request)
	{
		$builder = $this->model;
		
		if($request->filled('melody')) {

			$builder = $builder->where('Melody', 'LIKE', "%".$request->input('melody')."%");
		}

		if($request->filled('melody_gurmukhi')) {

			$builder = $builder->where('MelodyGurmukhi', 'LIKE', "%".$request->input('melody_gurmukhi')."%");
		}

		$builder = $builder->sortable();
		if($request->filled('paginate')) {

			return $builder->paginate($request->input('limit', 10));
		}
		return $builder->get();
	}

	/**
	 * set payload of data.
	 *
	 * @param  $item: App\Models\Comment
	 * @return array of data.
	 */
	public function setDataPayload($item)
	{

		return [
			'Melody' 			=> $item->getMelody(),
			'MelodyGurmukhi' 	=> $item->getMelodyGurmukhi(),
			'MelodyDescription' => $item->getMelodyDescription()
		];
	}
}

