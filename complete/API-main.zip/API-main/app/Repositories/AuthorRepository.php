<?php

namespace App\Repositories;

use App\Models\Authors;

class AuthorRepository extends Repository
{

	protected $model;

	function __construct(Authors $model)
	{
		$this->model = $model;
	}

	/**
	 * Get translation authors
	 */
	public function getTranslationAuthors() {
		$authors = $this->model
						// ->where('Active', 1)
						->get();

		return $authors;
	}

	public function updateActiveStatus($id, $status)
	{
		$author = $this->model->findOrFail($id);

		$author->update(['Active' => $status]);

		return true;
	}

	public function markAllNonDefault()
	{
		$builder = (new Authors)->getQuery();
		$builder->update(['Default' => 0]);
		return true;
	}

	public function markDefaultById($id)
	{
		$author = Authors::findOrFail($id);
		$author->setDefault(1);
		$author->save();
		return $author;
	}
}