<?php

namespace App\Repositories;

use App\Repositories\Repository;
use App\User;
use Exception;
use Hash;
use Illuminate\Http\Request;

class ChangePasswordRepository extends Repository
{
	
	protected $model;

	public function __construct(User $model)
	{
		$this->model = $model;
	}

	/**
	 * change the password
	 * 
	 * @param  integer $id: integer of user id.
	 * @param  Request $request
	 * @return $user
	 */
	public function changePassword($id, Request $request)
	{
		$user = $this->model->find($id);
		if(!Hash::check($request->input('old_password'), $user->password)) {
			throw new Exception("Your password does not match with old password. Please try again with correct password.", 422);
        }
		
		$password = $request->input('password');
		//$user->setPassword(bcrypt($password))->save();
		$user->password = bcrypt($password);
        $user->save();

		return $user;
	}
}
