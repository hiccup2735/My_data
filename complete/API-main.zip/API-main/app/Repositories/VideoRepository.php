<?php

namespace App\Repositories;

use App\Models\Video;
use Exception;

class VideoRepository extends Repository
{
	public function get($request)
	{
		$builder = Video::with(['user' => function($q) {
			$q->select('id', 'name');
		}]);

		if ($request->has('approved')) {
			$builder = $builder->where('approved', $request->get('approved'));
		}

		$limit = 50;
		if ($request->has('limit')) {
			$limit = $request->get('limit');
		}

		if ($request->has('paginate') && $request->get('paginate')) {
			$videos = $builder->paginate($limit);
		} else {
			$videos = $builder->get();
		}

		foreach ($videos as $key => $video) {
			if ($video->shabad_id) {
		    	$video['shabad_page'] = ShabadRepository::getShabadPage($video->shabad_id);
		   	}
		}

		return $videos;
	}

	public function store($request)
	{
		$video = new Video();

		$video->video_code = $request->input('url');
		$video->user_id_fk = $request->input('user_id');
		$video->shabad_id = $request->input('shabad_id');
		$video->disscusion = $request->input('disscusion');
		$video->priority = 0;
		$video->approved = 0;
		$video->changetime = now();

		if (!$video->save()) {
			throw new Exception("Video not successfully saved", 422);
		}

		return $video;
	}

	public function find($id)
	{
		$video = Video::where('id', $id)
	    			->first();

	    if (!$video) {
    		throw new Exception("Video not found", 404);
    	}

	   	return $video;
	}
	public function deleteVideo($id=null){
		$status = Video::where('id',$id)->delete();
		if($status){
			return true;
		}else{
			return false;
		}
	}
}