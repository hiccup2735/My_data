<?php

namespace App\Repositories;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoriesRepository extends Repository
{
	protected $model;


	public function __construct(Category $model)
	{
		$this->model = $model;
//                print_r($this->model); die;
	}

	/**
	 * get list of comments.
	 *
	 * @param  $request: Illuminate\Http\Request
	 * @return collection of App\Models\Comment
	 */
	public function paginateFeaturedItems(Request $request)
	{
		$builder = $this->model;
		$builder = $builder->filter($request->all());

		$builder = $builder->where('featured', true)
                        ->whereNotNull('featured_display_order')
                        ->orderBy('featured_display_order', 'ASC');
		return $builder->paginate($request->input('limit', 10));
	}

	/**
	 * set payload of data.
	 *
	 * @param  $item: App\Models\Comment
	 * @return array of data.
	 */
	public function setDataPayload($item)
	{

		return [
			'name' 			=> $item->getName(),
			'image' 			=> $item->getImage(),
			'description' 	=> $item->getDescription(),
			'status' 		=> $item->getStatus()
		];
	}
}

