<?php

namespace App\Repositories;

use App\Models\Tag;
use Illuminate\Http\Request;

class TagsRepository extends Repository
{
	protected $model;


	public function __construct(Tag $model)
	{
		$this->model = $model;
	}

	/**
	 * set payload of data.
	 *
	 * @param  $item: App\Models\Comment
	 * @return array of data.
	 */
	public function setDataPayload($item)
	{

		return [
			'name' 			=> $item->getName(),
			'description' 	=> $item->getDescription(),
			'status' 		=> $item->getStatus()
		];
	}
}

