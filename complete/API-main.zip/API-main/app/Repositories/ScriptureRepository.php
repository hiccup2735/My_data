<?php

namespace App\Repositories;

use App\Helpers\AdvancedSearch;
use App\Models\Scripture;
use App\Models\Shabad;
use Illuminate\Http\Request;

class ScriptureRepository extends Repository
{
    protected $model;

    public function __construct(Scripture $model)
    {
        $this->model = $model;
    }

    /**
     * Get scripture pages for single shabad
     */
    public function getScripturePagesForShabad($shabadPageId)
    {
        getPagesAgain:

        $minScriptureIdForShabad = Scripture::where('page', $shabadPageId)->min('id');
        $maxScriptureIdForShabad = Scripture::where('page', $shabadPageId)->max('id');

        $pages = Shabad::whereBetween('scriptureid_from', [$minScriptureIdForShabad, $maxScriptureIdForShabad])
                        ->pluck('id');

        //if shabad id not have page then get prev shabad pages
        if ($pages->isEmpty()) {
            $shabadPageId = $shabadPageId - 1;
            goto getPagesAgain;
        }

        return $pages;
    }

    public function advancedSearch(Request $request)
    {
        $builder = $this->model;
        $builder = $this->buildSearchQuery($builder, $request);

        return $builder->paginate($request->input('limit', 10));
    }

    private function buildSearchQuery($builder, Request $request)
    {

        $searchOption = $request->input('search_option');
        $keyword      = $request->input('search_keyword');
        
        if(!$searchOption || !$keyword) {
            return $builder;
        }


        $language = $request->input('language');
        $query = "";

        if(in_array($language, ['roman', 'english'])) {

            $engAdvSearchObj = new AdvancedSearch($searchOption, 'ScriptureRomanEnglish', $keyword);
            $engAdvSearchObj->buildQuery();
            $engQuery = $engAdvSearchObj->getQuery();

            $romanAdvSearchObj = new AdvancedSearch($searchOption, 'ScriptureRoman', $keyword);
            $romanAdvSearchObj->buildQuery();
            $romanQuery = $romanAdvSearchObj->getQuery();

            $query = "($engQuery OR $romanQuery)";
        } else if($language == 'gurmukhi') {
            $simpleAdvSearchObj = new AdvancedSearch($searchOption, 'Scripture', $keyword);
            $simpleAdvSearchObj->buildQuery();
            $simpleQuery = $simpleAdvSearchObj->getQuery();

            $vowalAdvSearchObj = new AdvancedSearch($searchOption, 'ScriptureVowel', $keyword);
            $vowalAdvSearchObj->buildQuery();
            $vowalQuery = $vowalAdvSearchObj->getQuery();

            $query = "($simpleQuery OR $vowalQuery)";
        } else {
            $advSearchObj = new AdvancedSearch($searchOption, 'ScriptureVowel', $keyword);
            $advSearchObj->buildQuery();
            $query = $advSearchObj->getQuery();
        }

        $builder = $builder->whereRaw($query);
        dd($builder->toSql());
        return $builder;
    }
}
