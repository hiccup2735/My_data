<?php

namespace App\Repositories;

use DB;
use App\Helpers\AdvancedSearch;
use App\Models\Audio;
use App\Models\Katha;
use App\Models\Media;
use App\Models\MediaAuthor;
use App\Models\QnaAnswer;
use App\Models\QnaComment;
use App\Models\QnaQuestion;
use App\Models\QnaQuestions;
use App\Models\QnaTagQuestionRelation;
use App\Models\Scripture;
use App\Models\Shabad;
use App\Models\Singer;
use App\Models\Translation;
use App\Models\TranslationAuthor;
use App\Models\Wiki;
use Illuminate\Http\Request;

class ScriptureAdvanceSearchRepository extends Repository
{
	protected $model;
	protected $translationAuthorModel;

	public function __construct(
		Scripture $model,
		TranslationAuthor $translationAuthorModel
	) {
		$this->model = $model;
		$this->translationAuthorModel = $translationAuthorModel;
	}

	public function mediaAdvancedSearch(Request $request)
	{
		$keyword = $request->input('search_keyword');
		$language = $request->input('language');
		$searchOption = $request->input('search_option');

		if ($keyword) {

			DB::statement(DB::raw("drop TEMPORARY TABLE IF EXISTS scripture"));

			$q1 = $this->getAdvQuery($searchOption, "Scripture", $keyword);
			if (in_array($language, ['roman', 'english'])) {
				$engQuery = $this->getAdvQuery($searchOption, "ScriptureRomanEnglish", $keyword);
				$romanQuery = $this->getAdvQuery($searchOption, "ScriptureRoman", $keyword);
				$q1 = "(($engQuery) OR ($romanQuery))";
			} else if ($language == 'gurmukhi') {
				$simpleQuery = $this->getAdvQuery($searchOption, "Scripture", $keyword);
				$vowalQuery = $this->getAdvQuery($searchOption, "ScriptureVowel", $keyword);
				$q1 = "(($simpleQuery) OR ($vowalQuery))";
			} else {
				$q1 = $this->getAdvQuery($searchOption, 'ScriptureVowel', $keyword);
			}
			DB::statement(DB::raw("CREATE TEMPORARY TABLE IF NOT EXISTS scripture AS 
				
				SELECT * FROM `tblscripture` 
				where " . $q1 . ""));

			DB::statement(DB::raw("UPDATE scripture SET Page = (SELECT MIN(Page)
											FROM tblscripture
											WHERE tblscripture.ShabadID = scripture.ShabadID)"));

			$items = DB::table('scripture')->join('media', 'media.shabad_id', '=', 'scripture.ShabadID')->join('media_authors', 'media_authors.id', '=', 'media.author_id')
				->leftJoin('tblauthor', 'scripture.AuthorID', 'tblauthor.id')->leftJoin('tblmelody', 'scripture.MelodyID', 'tblmelody.id');

			if ($request->input('audio_author_id')) $items = $items->where('media_authors.id', $request->input('audio_author_id'));
			if ($request->input('raag')) $items = $items->where('tblmelody.id', $request->input('raag'));

			$items = $items->where('media.tag_id', 2)/*->offset(0)->limit(25)*/
				->select('media.id as id', 'media_authors.image', 'media.attachment_name_aws as attachment_name', 'scripture.ShabadID', 'scripture.id as scriptureId', 'scripture.Page', 'scripture.Scripture', 'scripture.ScriptureRoman', 'scripture.ScriptureRomanEnglish', 'scripture.MelodyID', 'tblmelody.Melody', 'scripture.AuthorID', 'tblauthor.Author', 'scripture.Page', 'media.title', 'media.duration', 'media_authors.name', 'media.author_id as author_id')
				->where('media_authors.status','1')
				->groupBy('id')
				->get();

			foreach ($items as $item) {
				$item->is_media = 1;
				if ($item->image != null) {
					$item->image = url('uploads/author/') . '/' . $item->image;
				}
			}
			return $items;
		}
		if ($request->input('audio_author_id')) {
			$items = DB::table('tblscripture as scripture')
				->join('media', 'media.shabad_id', '=', 'scripture.ShabadID')
				->join('media_authors', 'media_authors.id', '=', 'media.author_id')
				->join('tblauthor', 'scripture.AuthorID', 'tblauthor.id')
				->join('tblmelody', 'scripture.MelodyID', 'tblmelody.id');

			$items = $items->where('media_authors.id', $request->input('audio_author_id'));
			if ($request->input('raag')) $items = $items->where('tblmelody.id', $request->input('raag'));

			$items = $items->where('media.tag_id', 2)/*->offset(0)->limit(25)*/
				->select('media.id as media_id', 'media_authors.image', 'media.attachment_name_aws as attachment_name', 'scripture.ShabadID', 'scripture.id', 'scripture.Page', 'scripture.Scripture', 'scripture.ScriptureRoman', 'scripture.ScriptureRomanEnglish', 'scripture.MelodyID', 'tblmelody.Melody', 'scripture.AuthorID', 'tblauthor.Author', 'scripture.Page', 'media.title', 'media.duration', 'media_authors.name')
				->where('media_authors.status','1')
				->groupBy('media_id')
				->get();

			foreach ($items as $item) {
				$item->is_media = 1;
				if ($item->image != null) {
					$item->image = url('uploads/author/') . '/' . $item->image;
				}
			}

			return $items;
		}
		return 0;
	}

	public function mediaAdvancedSearchWeb(Request $request)
	{
		$keyword = $request->input('search_keyword');
		$language = $request->input('language');
		$searchOption = $request->input('search_option');

		if ($keyword) {

			DB::statement(DB::raw("drop TEMPORARY TABLE IF EXISTS scripture"));

			$q1 = $this->getAdvQuery($searchOption, "Scripture", $keyword);
			if (in_array($language, ['roman', 'english'])) {
				$engQuery = $this->getAdvQuery($searchOption, "ScriptureRomanEnglish", $keyword);
				$romanQuery = $this->getAdvQuery($searchOption, "ScriptureRoman", $keyword);
				$q1 = "(($engQuery) OR ($romanQuery))";
			} else if ($language == 'gurmukhi') {
				$simpleQuery = $this->getAdvQuery($searchOption, "Scripture", $keyword);
				$vowalQuery = $this->getAdvQuery($searchOption, "ScriptureVowel", $keyword);
				$q1 = "(($simpleQuery) OR ($vowalQuery))";
			} else {
				$q1 = $this->getAdvQuery($searchOption, 'ScriptureVowel', $keyword);
			}
			DB::statement(DB::raw("CREATE TEMPORARY TABLE IF NOT EXISTS scripture AS 
				
				SELECT * FROM `tblscripture` 
				where " . $q1 . ""));

			DB::statement(DB::raw("UPDATE scripture SET Page = (SELECT MIN(Page)
											FROM tblscripture
											WHERE tblscripture.ShabadID = scripture.ShabadID)"));

			$items = DB::table('scripture')->join('media', 'media.shabad_id', '=', 'scripture.ShabadID')->join('media_authors', 'media_authors.id', '=', 'media.author_id')
				->leftJoin('tblauthor', 'scripture.AuthorID', 'tblauthor.id')->leftJoin('tblmelody', 'scripture.MelodyID', 'tblmelody.id');

			if ($request->input('audio_author_id')) $items = $items->where('media_authors.id', $request->input('audio_author_id'));
			if ($request->input('raag')) $items = $items->where('tblmelody.id', $request->input('raag'));

			$items = $items->where('media.tag_id', 2)/*->offset(0)->limit(25)*/
				->select('media.id as id', 'media_authors.image', 'media.attachment_name', 'scripture.ShabadID', 'scripture.id as scriptureId', 'scripture.Page', 'scripture.Scripture', 'scripture.ScriptureRoman', 'scripture.ScriptureRomanEnglish', 'scripture.MelodyID', 'tblmelody.Melody', 'scripture.AuthorID', 'tblauthor.Author', 'scripture.Page', 'media.title', 'media.duration', 'media_authors.name', 'media.author_id as author_id')
				->where('media_authors.status','1')
				->groupBy('id')
				->get();

			foreach ($items as $item) {
				$item->is_media = 1;
				if ($item->image != null) {
					$item->image = url('uploads/author/') . '/' . $item->image;
				}
			}
			return $items;
		}
		if ($request->input('audio_author_id')) {
			$items = DB::table('tblscripture as scripture')
				->join('media', 'media.shabad_id', '=', 'scripture.ShabadID')
				->join('media_authors', 'media_authors.id', '=', 'media.author_id')
				->join('tblauthor', 'scripture.AuthorID', 'tblauthor.id')
				->join('tblmelody', 'scripture.MelodyID', 'tblmelody.id');

			$items = $items->where('media_authors.id', $request->input('audio_author_id'));
			if ($request->input('raag')) $items = $items->where('tblmelody.id', $request->input('raag'));

			$items = $items->where('media.tag_id', 2)/*->offset(0)->limit(25)*/
				->select('media.id as media_id', 'media_authors.image', 'media.attachment_name', 'scripture.ShabadID', 'scripture.id', 'scripture.Page', 'scripture.Scripture', 'scripture.ScriptureRoman', 'scripture.ScriptureRomanEnglish', 'scripture.MelodyID', 'tblmelody.Melody', 'scripture.AuthorID', 'tblauthor.Author', 'scripture.Page', 'media.title', 'media.duration', 'media_authors.name')
				->groupBy('media_id')
				->get();

			foreach ($items as $item) {
				$item->is_media = 1;
				if ($item->image != null) {
					$item->image = url('uploads/author/') . '/' . $item->image;
				}
			}

			return $items;
		}
		return 0;
	}
	public function advancedSearch(Request $request)
	{
		$builder = $this->model->filter($request->all());

		$builder = $builder->with(['author', 'melody']);

		if (!$request->filled('content')) {
			return $builder->paginate($request->input('limit', 10));
		}
		switch ($request->input('content')) {
			case 'gurbani':

				$builder = $this->buildGurbaniSearchQuery($builder, $request);
				break;
			case 'teeka':
			case 'english-translation':

				$builder = $this->buildTeekaSearchQuery($builder, $request);
				break; // end case 'teeka', 'english-translation'
			case 'commentary':
				// indicator = 2
				$builder = $this->buildCommentarySearchQueryNew($builder, $request);
				break;
			case 'working-translation':
				$builder = $this->buildCommentarySearchQuery($builder, $request);
			case 'qna':
				$builder = $this->buildQnaSearchQuery($builder, $request);
				break;
			case 'audio':
				$builder = $this->buildAudioSearchQueryNew($builder, $request);
				//$builder = $this->buildAudioSearchQuery($builder, $request);
				//                            $builder = $this->buildGurbaniSearchQuery($builder, $request);
				break;
			default:
				break;
		}

		return $builder->paginate($request->input('limit', 10));
	}
	public function buildAudioSearchQueryNew($builder, Request $request)
	{
		//Aakash start here
		//case 1 aakash
		if ($request->res == "media") {
			$tableName = (new Scripture)->getTable();
			$searchOption = $request->input('search_option');
			$language = $request->input('language');
			$keyword = $request->input('search_keyword');
			$authorID = $request->input('audio_author_id');
			$type = 'S3';
			$builder->join("media",  function ($j) use ($tableName) {
				$j->on('media.shabad_id', '=', "$tableName.ShabadID");
			});
			$builder->leftJoin("media_authors",  function ($j) use ($tableName) {
				$j->on('media_authors.id', '=', "media.author_id");
			});
			// $indicator = "1";
			// if($request->input('content') == 'commentary') {
			// 	$indicator = "2";
			// }
			//$builder->where('media.title','like','%'.$keyword.'%');
			if (!empty($authorID)) {
				$builder->where('media.author_id', '=', $authorID);
			}
			$builder->where('media.tag_id', '=', 2)->whereNotNull('media.shabad_id');
			// $builder->where('media.shabad_id','=',"$tableName.ShabadID");
			//$builder->where('media.type','=',$type);
			// if($searchOption && $keyword) {
			// 	$query = $this->getAdvQuery($searchOption, "comm.commentary", $keyword);
			// 	$builder = $builder->whereRaw($query);
			// }

			$builder->groupBy("$tableName.ShabadID");
			/*if($language == 'english' && $keyword) {
				//12feb commented aakash
				//$q1 = $this->getAdvQuery($searchOption, "media.title", $keyword);
				//end commentedX
				if(in_array($language, ['roman', 'english'])){
					// $field = "ScriptureRomanEnglish";
					
					$mediaQuery = $this->getAdvQuery($searchOption, "media.title", $keyword);
					$engQuery = $this->getAdvQuery($searchOption, "ScriptureRomanEnglish", $keyword);
					$romanQuery = $this->getAdvQuery($searchOption, "ScriptureRoman", $keyword);
					$q1 = "($mediaQuery) AND (($engQuery) OR ($romanQuery))";
					// echo $q1;die;
				} else if ($language == 'gurmukhi') {
					$simpleQuery = $this->getAdvQuery($searchOption, "Scripture", $keyword);
					$vowalQuery = $this->getAdvQuery($searchOption, "ScriptureVowel", $keyword);
					$q1 = "($simpleQuery) OR ($vowalQuery)";
				} else {
					$q1 = $this->getAdvQuery($searchOption, 'ScriptureVowel', $keyword);
				}
				$builder->whereRaw("$q1");

			} else*/
			if ($keyword) {

				$q1 = $this->getAdvQuery($searchOption, "Scripture", $keyword);
				if (in_array($language, ['roman', 'english'])) {
					// $field = "ScriptureRomanEnglish";
					$engQuery = $this->getAdvQuery($searchOption, "ScriptureRomanEnglish", $keyword);
					$romanQuery = $this->getAdvQuery($searchOption, "ScriptureRoman", $keyword);
					$q1 = "(($engQuery) OR ($romanQuery))";
				} else if ($language == 'gurmukhi') {
					$simpleQuery = $this->getAdvQuery($searchOption, "Scripture", $keyword);
					$vowalQuery = $this->getAdvQuery($searchOption, "ScriptureVowel", $keyword);
					$q1 = "(($simpleQuery) OR ($vowalQuery))";
				} else {
					$q1 = $this->getAdvQuery($searchOption, 'ScriptureVowel', $keyword);
				}
				$builder->whereRaw("$q1");
				//Start 
				// $query = "";
				// if(in_array($language, ['roman', 'english'])) {

				// 	$engQuery = $this->getAdvQuery($searchOption, 'ScriptureRomanEnglish', $keyword);
				// 	$romanQuery = $this->getAdvQuery($searchOption, 'ScriptureRoman', $keyword);
				// 	$query = "($engQuery OR $romanQuery)";
				// } else if($language == 'gurmukhi') {

				// 	$simpleQuery = $this->getAdvQuery($searchOption, 'Scripture', $keyword);
				// 	$vowalQuery = $this->getAdvQuery($searchOption, 'ScriptureVowel', $keyword);
				// 	$query = "($simpleQuery OR $vowalQuery)";
				// } else {
				// 	$query = $this->getAdvQuery($searchOption, 'ScriptureVowel', $keyword);
				// }
				// dd($query);
				//$builder = $builder->whereRaw($query);
				//End
			}
			$builder->selectRaw("$tableName.*, media.*,media_authors.name");
		} else { //case two aakash
			$tableName = (new Scripture)->getTable();
			$language = $request->input('language');
			$searchOption = $request->input('search_option');
			$keyword = $request->input('search_keyword');

			$mediaTableName = (new Media)->getTable();
			$singerTableName = (new MediaAuthor)->getTable();

			$builder->join("$mediaTableName as audio", function ($j) use ($tableName) {
				$j->on('audio.shabad_id', '=', "$tableName.ShabadID")
					->where('audio.type', 'S3');
			});

			$builder->join("$singerTableName as singer", function ($j) {
				$j->on('singer.id', '=', 'audio.author_id');
			});
			//$builder->where('audio.title','like','%'.$keyword.'%');

			if ($request->filled('audio_author_id')) {

				$builder->where('singer.id', $request->input('audio_author_id'));
			}
			if ($language == 'english' && $keyword) {

				$q1 = $this->getAdvQuery($searchOption, "audio.title", $keyword);
				$builder->whereRaw("$q1");
			} else if ($keyword) {

				$q1 = $this->getAdvQuery($searchOption, "Scripture", $keyword);
				if ($language == "roman") {
					// $field = "ScriptureRomanEnglish";
					$engQuery = $this->getAdvQuery($searchOption, "ScriptureRomanEnglish", $keyword);
					$romanQuery = $this->getAdvQuery($searchOption, "ScriptureRoman", $keyword);
					$q1 = "(($engQuery) OR ($romanQuery))";
				} else if ($language == 'gurmukhi') {
					$simpleQuery = $this->getAdvQuery($searchOption, "Scripture", $keyword);
					$vowalQuery = $this->getAdvQuery($searchOption, "ScriptureVowel", $keyword);
					$q1 = "(($simpleQuery) OR ($vowalQuery))";
				}
				$builder->whereRaw("$q1");
			}

			$builder->selectRaw("$tableName.*, audio.title as shabadtitle, singer.name as singer_name")
				->groupBy("audio.id");
		}

		return $builder;
		//Aakash end here



	}

	/**
	 * build query for audio search,
	 *
	 * @param  $builder: Illuminate\Database\Query\Builder
	 * @param  $request:Illuminate\Http\Request
	 * @return Illuminate\Database\Query\Builder
	 */
	public function buildAudioSearchQuery($builder, Request $request)
	{
		$tableName = (new Scripture)->getTable();
		$language = $request->input('language');
		$searchOption = $request->input('search_option');
		$keyword = $request->input('search_keyword');

		$mediaTableName = (new Media)->getTable();
		$singerTableName = (new MediaAuthor)->getTable();

		$builder->join("$mediaTableName as audio", function ($j) use ($tableName) {
			$j->on('audio.shabad_id', '=', "$tableName.ShabadID")
				->where('audio.type', 'S3');
		});

		$builder->join("$singerTableName as singer", function ($j) {
			$j->on('singer.id', '=', 'audio.author_id');
		});
		$builder->where('audio.title', 'like', '%' . $keyword . '%');

		if ($request->filled('audio_author_id')) {

			$builder->where('singer.id', $request->input('audio_author_id'));
		}

		/*$audioTableName = (new Audio)->getTable();
		$kathaTableName = (new Katha)->getTable();
		$singerTableName = (new Singer)->getTable();
		$builder2 = clone $builder;

		$builder->join("$audioTableName as audio", function($j) use($tableName) {
			$j->on('audio.shabad_id', '=', "$tableName.ShabadID");
		});

		$builder->join("$singerTableName as singer", function($j) {
			$j->on('singer.singer_id', '=', 'audio.singer_id');
		});

		$builder2->join("$kathaTableName as katha", function($j) use($tableName) {
			$j->on('katha.shabad_id', '=', "$tableName.ShabadID");
		});

		$builder2->join("$singerTableName as singer", function($j) {
			$j->on('singer.singer_id', '=', 'katha.singer_id');
		});*/

		// if($language == 'english' && $keyword) {

		// 	$q1 = $this->getAdvQuery($searchOption, "audio.title", $keyword);
		// 	$builder->whereRaw("$q1");

		// } else if($keyword) {

		// 	$q1 = $this->getAdvQuery($searchOption, "Scripture", $keyword);
		// 	if($language == "roman"){
		// 		// $field = "ScriptureRomanEnglish";
		// 		$engQuery = $this->getAdvQuery($searchOption, "ScriptureRomanEnglish", $keyword);
		// 		$romanQuery = $this->getAdvQuery($searchOption, "ScriptureRoman", $keyword);
		// 		$q1 = "($engQuery) OR ($romanQuery)";
		// 	} else if ($language == 'gurmukhi') {
		// 		$simpleQuery = $this->getAdvQuery($searchOption, "Scripture", $keyword);
		// 		$vowalQuery = $this->getAdvQuery($searchOption, "ScriptureVowel", $keyword);
		// 		$q1 = "($simpleQuery) OR ($vowalQuery)";
		// 	}
		// 	$builder->whereRaw("$q1");
		// }

		$builder->selectRaw("$tableName.*, audio.title as shabadtitle, singer.name as singer_name")
			->groupBy("audio.id");

		return $builder;
	}

	public function buildQnaSearchQuery($builder, Request $request)
	{
		$tableName = (new Scripture)->getTable();
		$qnaQuestionTableName = (new QnaQuestion)->getTable();
		$qnaAnsTableName = (new QnaAnswer)->getTable();
		$qnaCommentTableName = (new QnaComment)->getTable();
		$questionTagRelation = (new QnaTagQuestionRelation)->getTable();


		$searchOption = $request->input('search_option');
		$keyword = $request->input('search_keyword');

		$builder->join("$qnaQuestionTableName as qnaQuestions",  function ($j) use ($tableName) {
			$j->on('qnaQuestions.shabad_id', '=', "$tableName.ShabadID");
		});

		$builder->leftJoin("$qnaAnsTableName as qnaAns",  function ($j) {
			$j->on('qnaAns.question_id', '=', "qnaQuestions.id");
		});

		$builder->leftJoin("$qnaCommentTableName as qnaComment",  function ($j) {
			$j->on('qnaComment.parent_question_id', '=', "qnaQuestions.id");
		});

		if ($request->filled('tag')) {
			$builder->join("$questionTagRelation as qtr",  function ($j) {
				$j->on('qtr.question_id_fk', '=', "qnaQuestions.id");
			})
				->where('qtr.tag_id_fk', $request->input('tag'));
		}

		$q1 = $this->getAdvQuery($searchOption, "qnaQuestions.title", $keyword);
		$q2 = $this->getAdvQuery($searchOption, "qnaQuestions.details", $keyword);
		$q3 = $this->getAdvQuery($searchOption, "qnaAns.details", $keyword);
		$q4 = $this->getAdvQuery($searchOption, "qnaComment.details", $keyword);

		$builder = $builder->whereRaw("(($q1) OR ($q2) OR ($q3) OR ($q4))")
			->groupBy('qnaQuestions.id');

		$builder = $builder->selectRaw("$tableName.*, qnaQuestions.title, qnaQuestions.id as question_id, qnaQuestions.details");
		return $builder;
	}

	public function buildCommentarySearchQuery($builder, Request $request)
	{
		$tableName = (new Scripture)->getTable();
		$wikiTableName = (new Wiki)->getTable();
		$searchOption = $request->input('search_option');
		$keyword = $request->input('search_keyword');

		$builder->join("$wikiTableName as wiki",  function ($j) use ($tableName) {
			$j->on('wiki.shabad_id', '=', "$tableName.ShabadID");
		});

		$indicator = "1";
		if ($request->input('content') == 'commentary') {
			$indicator = "2";
		}
		$builder->where('wiki.indicator', $indicator);

		if ($searchOption && $keyword) {
			$query = $this->getAdvQuery($searchOption, "wiki.details", $keyword);
			$builder = $builder->whereRaw($query);
		}

		$builder->groupBy("$tableName.ShabadID");
		$builder->selectRaw("$tableName.*, wiki.details");
		return $builder;
	}

	//search commentry using advanced search
	public function buildCommentarySearchQueryNew($builder, Request $request)
	{
		$tableName = (new Scripture)->getTable();
		$searchOption = $request->input('search_option');
		$keyword = $request->input('search_keyword');

		$builder->leftJoin("commentaries as comm",  function ($j) use ($tableName) {
			$j->on('comm.shabad_id', '=', "$tableName.ShabadID");
		});

		// $indicator = "1";
		// if($request->input('content') == 'commentary') {
		// 	$indicator = "2";
		// }
		$builder->where('comm.commentary', 'like', '%' . $keyword . '%');
		// if($searchOption && $keyword) {
		// 	$query = $this->getAdvQuery($searchOption, "comm.commentary", $keyword);
		// 	$builder = $builder->whereRaw($query);
		// }

		$builder->groupBy("$tableName.ShabadID");
		$builder->selectRaw("$tableName.*, comm.commentary");
		return $builder;
	}
	/**
	 * create query for teeka and english-translation search
	 *
	 * @param  $builder: Illuminate\Database\Eloquent\Builder
	 * @param  $request: Illuminate\Http\Request
	 * @return Illuminate\Database\Eloquent\Builder
	 */
	private function buildTeekaSearchQuery($builder, Request $request)
	{
		$tableName = (new Scripture)->getTable();
		$translationTableName = (new Translation)->getTable();
		$translationAuthorId = $request->input('translation_author', 1);
		$item = $this->translationAuthorModel->findOrFail($translationAuthorId);
		$referredColumnName = $item->getReferredColumn();

		$builder = $builder->join("$translationTableName as t", function ($j) use ($tableName) {
			$j->on('t.ScriptureID', '=', "$tableName.id");
		});
		$searchOption = $request->input('search_option');
		$keyword = $request->input('search_keyword');
		if ($searchOption && $keyword) {
			$query = $this->getAdvQuery($searchOption, "t.$referredColumnName", $keyword);
			$builder = $builder->whereRaw($query);
		}

		$builder->selectRaw("$tableName.*, t.$referredColumnName");
		return $builder;
	}

	/**
	 * create query for gurbani search
	 *
	 * @param  $builder: Illuminate\Database\Eloquent\Builder
	 * @param  $request: Illuminate\Http\Request
	 * @return Illuminate\Database\Eloquent\Builder
	 */
	private function buildGurbaniSearchQuery($builder, Request $request)
	{

		$searchOption = $request->input('search_option');
		$keyword = $request->input('search_keyword');
		if (!$searchOption || !$keyword) {
			return $builder;
		}

		$language = $request->input('language');
		$query = "";
		if (in_array($language, ['roman', 'english'])) {

			$engQuery = $this->getAdvQuery($searchOption, 'ScriptureRomanEnglish', $keyword);
			$romanQuery = $this->getAdvQuery($searchOption, 'ScriptureRoman', $keyword);
			$query = "(($engQuery OR $romanQuery))";
		} else if ($language == 'gurmukhi') {

			$simpleQuery = $this->getAdvQuery($searchOption, 'Scripture', $keyword);
			$vowalQuery = $this->getAdvQuery($searchOption, 'ScriptureVowel', $keyword);
			$query = "(($simpleQuery OR $vowalQuery))";
		} else {
			$query = $this->getAdvQuery($searchOption, 'ScriptureVowel', $keyword);
		}
		// dd($query);
		$builder = $builder->whereRaw($query);

		return $builder;
	}

	/**
	 * get advanced query on the basis of search option.
	 *
	 * @param  $searchOption: integer of search option.
	 * @param  $field: string of database table field column name.
	 * @param  $keyword: string of searched keyword.
	 * @return string of query.
	 */
	private function getAdvQuery($searchOption, $field, $keyword)
	{
		$advSearchObj = new AdvancedSearch($searchOption, $field, $keyword);
		$advSearchObj->buildQuery();
		return $advSearchObj->getQuery();
	}
}
