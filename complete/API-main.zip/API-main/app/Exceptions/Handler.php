<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\HttpFoundation\Response;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        \Illuminate\Auth\AuthenticationException::class,
        \Illuminate\Auth\Access\AuthorizationException::class,
        \Symfony\Component\HttpKernel\Exception\HttpException::class,
        \Illuminate\Database\Eloquent\ModelNotFoundException::class,
        \Illuminate\Session\TokenMismatchException::class,
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @param  \Exception  $exception
     * @return void
     */
    public function report(Exception $exception)
    {
        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $exception
     * @return \Illuminate\Http\Response
     */
    public function render($request, Exception $e)
    {
        if($request->header('accept') != "application/json") {
            return parent::render($request, $e);
        }

        $errors = [];
        //HttpExceptionInterface inheritor throws an error, it ignores its status code
        if($e instanceof \Symfony\Component\HttpKernel\Exception\HttpExceptionInterface){
            $errorCode = $e->getStatusCode();
            $errorMessage = $e->getMessage();
            if (empty($errorMessage)) $errorMessage = \Illuminate\Http\Response::$statusTexts[$errorCode];
        } else if($e instanceof \Illuminate\Http\Exception\HttpResponseException){ // json response error.
            $errorResponse = $e->getResponse();
            $errors = json_decode($errorResponse->getContent(), true);
            $errorCode = $errorResponse->getStatusCode();
            $errorMessage = \Illuminate\Http\Response::$statusTexts[$errorCode];
        } else if($e instanceof \Illuminate\Validation\ValidationException){ // json response error.

            $errors = $e->errors();
            $errorCode = Response::HTTP_UNPROCESSABLE_ENTITY;
            $errorMessage = \Illuminate\Http\Response::$statusTexts[$errorCode];
        } else if($e instanceof \Illuminate\Database\Eloquent\ModelNotFoundException){ // json response error.

            $errorCode = Response::HTTP_UNPROCESSABLE_ENTITY;
            $errorMessage = "Invalid ID.";
        } else {
            $errorCode = $e->getCode();
            $errorMessage = $e->getMessage();
        }
        $error = [
            'message' => $errorMessage?$errorMessage:"Server Fail",
            'code'=>$errorCode,
        ];
        if($errors) {
            $error['errors'] = $errors;
        }
        if (env('APP_DEBUG')) {
            $error['trace'] = $e->getTrace();
        }
        if ($error['code']>200 && $error['code']<600) {
            return $this->jsonResponse($error,$error['code']);
        } else {
            return $this->jsonResponse($error);
        }
    }

    /**
     * Convert an authentication exception into an unauthenticated response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Illuminate\Auth\AuthenticationException  $exception
     * @return \Illuminate\Http\Response
     */
    protected function unauthenticated($request, AuthenticationException $exception)
    {
        if ($request->expectsJson()) {
            return response()->json(['error' => 'Unauthenticated.'], 401);
        }
        $guard = array_get($exception->guards(), 0);

        switch ($guard) {
          case 'admin':
            $login = 'admin.login.index';
            break;
          default:
            $login = 'login';
            break;
        }

        return redirect()->guest(route($login));
    }

    /**
     * Returns json response.
     *
     * @param array|null $payload
     * @param int $statusCode
     * @return \Illuminate\Http\JsonResponse
     */
    protected function jsonResponse(array $payload=null, $statusCode=400)
    {
        $payload = $payload ?: [];
        return response()->json($payload, $statusCode);
    }
}
