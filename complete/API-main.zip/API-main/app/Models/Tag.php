<?php

namespace App\Models;

use App\Models\AppModel;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Kyslik\ColumnSortable\Sortable;
use Laracasts\Presenter\PresentableTrait;

class Tag extends AppModel
{
    use HasSlug, Sortable, PresentableTrait;

    protected $presenter = '\App\Presenters\TagPresenter';

    protected $table = 'tags';

    protected $fillable = ['slug', 'name', 'description', 'status'];

    public $sortable = ['id', 'name', 'status'];

    /**
     * set string fields for filtering 
     * @var array
     */
    protected $likeFilterFields = ['name'];

    /**
     * set boolean fields for filtering 
     * @var array
     */
    protected $boolFilterFields = ['status'];

    /**
     * Get the options for generating the slug.
     */
    public function getSlugOptions() : SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('name')
            ->saveSlugsTo('slug');
    }

    /**
     * Get all of the tags for the post.
     */
    public function media()
    {
        return $this->morphToMany(Media::class, 'mediable');
    }
    
    /**
     * @return mixed
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * @param mixed $name
     *
     * @return self
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $description
     *
     * @return self
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $status
     *
     * @return self
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }
}
