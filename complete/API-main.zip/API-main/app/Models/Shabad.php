<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Shabad extends Model
{
	/**
	 * The table associated with the model
	 */
    protected $table = "shabad";

    /**
     * Get the scriptures that associated with shabad
     */
    public function scriptures()
    {
    	return $this->hasMany(Scripture::class, 'ShabadID');
    }

    /**
     * Get the santhya that associated with shabad
     */
    public function santhya()
    {
        return $this->hasMany(Santhya::class, 'shabad_id');
    }

    /**
     * Get the audio that associated with shabad
     */
    public function audio()
    {
        return $this->hasMany(Audio::class, 'shabad_id');
    }

    /**
     * Get the katha that associated with shabad
     */
    public function katha()
    {
        return $this->hasMany(Katha::class, 'shabad_id');
    }

    /**
     * Get the video that associated with shabad
     */
    public function video()
    {
        return $this->hasMany(Video::class, 'shabad_id');
    }

     /**
     * Get the blog that associated with shabad
     */
    public function blog()
    {
        return $this->hasMany(Blog::class, 'news_shabad');
    }
}
