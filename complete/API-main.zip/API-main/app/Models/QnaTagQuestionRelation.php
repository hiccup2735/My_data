<?php

namespace App\Models;

use App\Models\AppModel;

class QnaTagQuestionRelation extends AppModel
{
    protected $table = 'qna_tag_question_relation';

    public $timestamps = false;
}
