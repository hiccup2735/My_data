<?php

namespace App\Models;

use App\Models\AppModel;

class QnaQuestion extends AppModel
{
    protected $table = 'qna_questions';

    protected $fillable = [
    	'title', 'details', 'shabad_id', 'user_id', 'type', 'question_total_likes', 
    	'question_total_dislikes', 'question_total_followers', 'question_total_answers', 
    	'question_total_comments', 'status', 'approved'
    ];

    public $timestamps = false;
}
