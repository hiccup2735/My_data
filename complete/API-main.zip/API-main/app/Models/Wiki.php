<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Wiki extends AppModel
{
    protected $table = 'wiki';
}
