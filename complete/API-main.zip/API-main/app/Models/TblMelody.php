<?php

namespace App\Models;

use App\Models\AppModel;

class TblMelody extends AppModel
{

    protected $table = 'tblmelody';

    protected $fillable = ['Melody', 'MelodyGurmukhi', 'MelodyDescription'];

    public $sortable = ['id', 'Melody', 'MelodyGurmukhi', 'MelodyDescription'];

    /**
     * set string fields for filtering 
     * @var array
     */
    protected $likeFilterFields = ['Melody', 'MelodyGurmukhi'];

    /**
     * @param mixed $Author
     *
     * @return self
     */
    public function setMelody($melody)
    {
        $this->Melody = $melody;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getMelody()
    {
        return $this->Melody;
    }

    /**
     * @param mixed $MelodyGurmukhi
     *
     * @return self
     */
    public function setMelodyGurmukhi($melodyGurmukhi)
    {
        $this->MelodyGurmukhi = $melodyGurmukhi;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getMelodyGurmukhi()
    {
        return $this->MelodyGurmukhi;
    }

    /**
     * @param mixed $MelodyDescription
     *
     * @return self
     */
    public function setMelodyDescription($melodyDescription)
    {
        $this->MelodyDescription = $melodyDescription;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getMelodyDescription()
    {
        return $this->MelodyDescription;
    }
}
