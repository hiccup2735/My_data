<?php

namespace App\Models;

use App\Models\AppModel;
use App\User;

class Comment extends AppModel
{
    /**
	 * The table associated with the model
	 */
    protected $table = "comments";

    public $timestamps = false;

    protected $fillable = ['comment_author_id', 'comment_text', 'comment_date', 'comment_post_id', 'comment_approve','delete_approve'];
    
    public $sortable = ['comment_id', 'comment_author_id', 'comment_post_id', 'comment_date', 'comment_approve','delete_approve'];

    /**
     * set string fields for filtering 
     * @var array
     */
    protected $likeFilterFields = ['comment_text'];

    /**
     * set boolean fields for filtering 
     * @var array
     */
    protected $boolFilterFields = ['comment_approve'];

    /**
     * Set table primary key
     */
    protected $primaryKey = 'comment_id';

    /**
     * Get the users that belongs to comment
     */
    public function user()
    {
    	return $this->belongsTo(User::class, 'comment_author_id');
    }

    /**
     * @param mixed $comment_author_id
     *
     * @return self
     */
    public function setCommentAuthorId($comment_author_id = null)
    {
        $this->comment_author_id = (int)$comment_author_id;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCommentAuthorId()
    {
        return $this->comment_author_id;
    }

    /**
     * @param mixed $comment_text
     *
     * @return self
     */
    public function setCommentText($comment_text)
    {
        $this->comment_text = $comment_text;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCommentText()
    {
        return $this->comment_text;
    }

    /**
     * @param mixed $comment_date
     *
     * @return self
     */
    public function setCommentDate($comment_date)
    {
        $this->comment_date = $comment_date;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCommentDate()
    {
        return $this->comment_date;
    }

    /**
     * @param mixed $comment_post_id
     *
     * @return self
     */
    public function setCommentPostId($comment_post_id)
    {
        $this->comment_post_id = $comment_post_id;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCommentPostId()
    {
        return $this->comment_post_id;
    }

    /**
     * @param mixed $comment_approve
     *
     * @return self
     */
    public function setCommentApprove($comment_approve)
    {
        $this->comment_approve = $comment_approve;

        return $this;
    }
    public function setDeleteApprove($delete_approve)
    {
        $this->delete_approve = $delete_approve;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCommentApprove()
    {
        return $this->comment_approve;
    }
    
    public function getDeleteApprove()
    {
        return $this->delete_approve;
    }
}
