<?php

namespace App\Models;

use App\Models\AppModel;

class TblAuthor extends AppModel
{

    protected $table = 'tblauthor';

    protected $fillable = ['Author', 'AuthorGurmukhi', 'AuthorDescription'];

    public $sortable = ['id', 'Author', 'AuthorGurmukhi', 'AuthorDescription'];

    /**
     * set string fields for filtering 
     * @var array
     */
    protected $likeFilterFields = ['Author', 'AuthorGurmukhi'];

    /**
     * @param mixed $Author
     *
     * @return self
     */
    public function setAuthor($author)
    {
        $this->Author = $author;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getAuthor()
    {
        return $this->Author;
    }

    /**
     * @param mixed $AuthorGurmukhi
     *
     * @return self
     */
    public function setAuthorGurmukhi($authorGurmukhi)
    {
        $this->AuthorGurmukhi = $authorGurmukhi;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getAuthorGurmukhi()
    {
        return $this->AuthorGurmukhi;
    }

    /**
     * @param mixed $AuthorDescription
     *
     * @return self
     */
    public function setAuthorDescription($authorDescription)
    {
        $this->AuthorDescription = $authorDescription;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getAuthorDescription()
    {
        return $this->AuthorDescription;
    }
}
