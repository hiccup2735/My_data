<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    /**
	 * The table associated with the model
	 */
    protected $table = "role";

    public function permissions() {
       // die('hh');
	   return $this->belongsToMany(Permission::class, 'role_permissions', 'role_id', 'permission_id');
	}
}
