<?php

namespace App\Models;

use App\Models\AppModel;
use App\Models\Category;
use App\Models\MediaAuthor;
use App\Models\Tag;
use App\User;
use Laracasts\Presenter\PresentableTrait;

class Media extends AppModel
{
    use PresentableTrait;

    protected $presenter = '\App\Presenters\MediaPresenter';

    protected $table = 'media';

    protected $fillable = [
        'author_id', 'shabad_id','podbean', 'ref_type', 
        'title', 'description', 'attachment_name', 'thumbnail',
        'attachment_mime_type', 'type', 'status', 'featured', 'featured_display_order',
        'created_by', 'updated_by'
    ];

    const POST_REF_TYPE = 'POST';
    const RESOURCE_REF_TYPE = 'RESOURCE';

    const IMAGE_TYPE = 'IMAGE';
    const VIDEO_TYPE = 'VIDEO';
    const YOUTUBE_TYPE = 'YOUTUBE';
    const VIMEO_TYPE = 'VIMEO';
    const AUDIO_TYPE = 'AUDIO';

    public $sortable = [
            'id', 'author_id', 'shabad_id', 'ref_type', 'title', 
            'type', 'status', 'featured', 'featured_display_order'
        ];

    /**
     * set string fields for filtering 
     * @var array
     */
    protected $likeFilterFields = ['title'];

    /**
     * set boolean fields for filtering 
     * @var array
     */
    protected $boolFilterFields = ['status', 'featured'];

    public $youtube_url;
    public $vimeo_url;
    
    /**
     * Get all of the categories that are assigned this media.
     */
    public function author()
    {
        return $this->belongsTo(MediaAuthor::class, 'author_id', 'id');
    }

    /**
     * Get all of the categories that are assigned this media.
     */
    public function created_by_user()
    {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    /**
     * Get all of the categories that are assigned this media.
     */
    public function categories()
    {
        return $this->morphedByMany(Category::class, 'mediables');
    }

    /**
     * Get all of the videos that are assigned this media.
     */
    public function tags()
    {
        return $this->morphedByMany(Tag::class, 'mediables');
    }

    /**
     * @param mixed $author_id
     *
     * @return self
     */
    public function setAuthorId($author_id)
    {
        $this->author_id = $author_id;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getAuthorId()
    {
        return $this->author_id;
    }

    /**
     * @param mixed $shabad_id
     *
     * @return self
     */
    public function setShabadId($shabad_id)
    {
        $this->shabad_id = $shabad_id;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getShabadId()
    {
        return $this->shabad_id;
    }
    
    /**
     * @param mixed $ref_type
     *
     * @return self
     */
    public function setRefType($ref_type)
    {
        $this->ref_type = $ref_type;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRefType()
    {
        return $this->ref_type;
    }

    /**
     * @param mixed $title
     *
     * @return self
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTitle()
    {
        return $this->title;
    }
    
//    public function setPodbean($podbean)
//    {
//        $this->podbean = $podbean;
//
//        return $this;
//    }
//
//    /**
//     * @return mixed
//     */
//    public function getPodbean()
//    {
//        return $this->podbean;
//    }

    /**
     * @param mixed $description
     *
     * @return self
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $attachment_name
     *
     * @return self
     */
    public function setAttachmentName($attachment_name)
    {
        $this->attachment_name = $attachment_name;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getAttachmentName()
    {
        return $this->attachment_name;
    }

    /**
     * @param mixed $attachment_mime_type
     *
     * @return self
     */
    public function setAttachmentMimeType($attachment_mime_type)
    {
        $this->attachment_mime_type = $attachment_mime_type;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getAttachmentMimeType()
    {
        return $this->attachment_mime_type;
    }

    /**
     * @param mixed $type
     *
     * @return self
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @param mixed $status
     *
     * @return self
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $created_by
     *
     * @return self
     */
    public function setCreatedBy($created_by)
    {
        $this->created_by = $created_by;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCreatedBy()
    {
        return $this->created_by;
    }

    /**
     * @param mixed $updated_by
     *
     * @return self
     */
    public function setUpdatedBy($updated_by)
    {
        $this->updated_by = $updated_by;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getUpdatedBy()
    {
        return $this->updated_by;
    }

    /**
     * get attachment file url.
     * 
     * @return string of file url.
     */
    public function getAttachmentUrl()
    {
        $url = null;
        $mediaDir = config('global.uploads.media.path');
        $directory = public_path() . DIRECTORY_SEPARATOR . $mediaDir;
        switch ($this->getType()) {
            case self::IMAGE_TYPE:
                $file = $directory.DIRECTORY_SEPARATOR.$this->getAttachmentName();
                if(!\File::exists($file)) {
                    return null;
                }
                $url = url($mediaDir.DIRECTORY_SEPARATOR.$this->getAttachmentName());
                break;
            
            case self::VIDEO_TYPE:
                $file = $directory.DIRECTORY_SEPARATOR.$this->getAttachmentName();
                if(!\File::exists($file)) {
                    return null;
                }
                $url = url($mediaDir.DIRECTORY_SEPARATOR.$this->getAttachmentName());
                break;
            case self::YOUTUBE_TYPE:
                $url = $this->getAttachmentName();
                break;
            case self::VIMEO_TYPE:
                $url = $this->getAttachmentName();
                break;
            case self::AUDIO_TYPE:
                $file = $directory.DIRECTORY_SEPARATOR.$this->getAttachmentName();
                if(!\File::exists($file)) {
                    return null;
                }
                $url = url($mediaDir.DIRECTORY_SEPARATOR.$this->getAttachmentName());
                break;
        }
        return $url;
    }

    /**
     * add filtering.
     *
     * @param  $builder: query builder.
     * @param  $filters: array of filters.
     * @return query builder.
     */
    public function scopeFilter($builder, $filters = [])
    {
        if(!$filters) {
            return $builder;
        }
        $tableName = $this->getTable();
        $defaultFillableFields = $this->fillable;
        foreach ($filters as $field => $value) {
            if(in_array($field, $this->boolFilterFields) && $value != null) {
                $builder->where($field, (bool)$value);
                continue;
            }

            if(!in_array($field, $defaultFillableFields) || !$value) {
                continue;
            }

            if(in_array($field, $this->likeFilterFields)) {
                $builder->where($tableName.'.'.$field, 'LIKE', "%$value%");
            } else if(is_array($value)) {

                $builder->whereIn($field, $value);
            } else {
                $builder->where($field, $value);
            }
        }

        $categoryIds = $filters['category_ids'] ?? [];
        $tagIds = $filters['tag_ids'] ?? [];
        if($categoryIds) {
            $builder = $builder->whereHas('categories', function($q) use($categoryIds) {
                $q->whereIn('mediables_id', explode(',', $categoryIds));
            });
        }

        if($tagIds) {
            $builder = $builder->whereHas('tags', function($q) use($tagIds) {
                $q->whereIn('mediables_id', explode(',', $tagIds));
            });
        }

        $user = request()->user();
        // if user is not logged in then return only active media.
        if(!$user) {
            $builder = $builder->where('status', true);
            return $builder;
        }

        if($user->isUser()) {
            $builder = $builder->where(function($q) use($user) {
                $q->where('status', true)
                    ->orWhere('created_by', $user->id);
            });
        }
        return $builder;
    }

    /**
     * @return mixed
     */
    public function getCreatedAt($format = 'Y-m-d H:i:s')
    {
        return $this->created_at->format($format);
    }

    /**
     * @return mixed
     */
    public function getUpdatedAt($format = 'Y-m-d H:i:s')
    {
        return $this->updated_at->format($format);
    }

    /**
     * check that requested user has permission to delete media or not.
     * 
     * @param  $user: App\User
     * @return boolean(true/false)
     */
    public function canDelete($user)
    {
        if($user->isSuperAdmin()) {
            return true;
        }

        if($user->id == $this->getCreatedBy()) {
            return true;
        }
        return false;
    }

    /**
     * @param mixed $youtube_url
     *
     * @return self
     */
    public function setYoutubeUrl($youtube_url)
    {
        $this->youtube_url = $youtube_url;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getYoutubeUrl()
    {
        return $this->youtube_url;
    }

    /**
     * @param mixed $vimeo_url
     *
     * @return self
     */
    public function setVimeoUrl($vimeo_url)
    {
        $this->vimeo_url = $vimeo_url;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getVimeoUrl()
    {
        return $this->vimeo_url;
    }

    /**
     * @param mixed $thumbnail
     *
     * @return self
     */
    public function setThumbnail($thumbnail = null)
    {
        $this->thumbnail = $thumbnail;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getThumbnail()
    {
        return $this->thumbnail;
    }

    public function isVideo()
    {
        return $this->getType() == self::VIDEO_TYPE;
    }

    public function isAudio()
    {
        return $this->getType() == self::AUDIO_TYPE;
    }

    public function isYouTube()
    {
        return $this->getType() == self::YOUTUBE_TYPE;
    }

    public function isVimeo()
    {
        return $this->getType() == self::VIMEO_TYPE;
    }

    public function isImage()
    {
        return $this->getType() == self::IMAGE_TYPE;
    }

    /**
     * @param mixed $featured
     *
     * @return self
     */
    public function setFeatured($featured)
    {
        $this->featured = $featured;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getFeatured()
    {
        return $this->featured;
    }

    /**
     * @param mixed $featured_display_order
     *
     * @return self
     */
    public function setFeaturedDisplayOrder($featured_display_order)
    {
        $this->featured_display_order = $featured_display_order;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getFeaturedDisplayOrder()
    {
        return $this->featured_display_order;
    }
}
