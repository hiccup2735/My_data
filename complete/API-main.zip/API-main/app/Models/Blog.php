<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    /**
	 * The table associated with the model
	 */
    protected $table = "news";

    public $timestamps = false;

    protected $fillable = ['news_title', 'news_text', 'news_author', 'news_date', 'news_shabad', 'image', 'is_approved'];

    /**
     * Set table primary key
     */
    protected $primaryKey = 'news_id';

    /**
     * Get the comments that associated with blogs
     */
    public function comments()
    {
    	return $this->hasMany(Comment::class, 'comment_post_id', 'news_id');
    }

    /**
     * @param mixed $news_title
     *
     * @return self
     */
    public function setNewsTitle($news_title)
    {
        $this->news_title = $news_title;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNewsTitle()
    {
        return $this->news_title;
    }

    /**
     * @param mixed $news_text
     *
     * @return self
     */
    public function setNewsText($news_text)
    {
        $this->news_text = $news_text;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNewsText()
    {
        return $this->news_text;
    }

    /**
     * @param mixed $news_author
     *
     * @return self
     */
    public function setNewsAuthor($news_author)
    {
        $this->news_author = $news_author;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNewsAuthor()
    {
        return $this->news_author;
    }

    /**
     * @param mixed $news_date
     *
     * @return self
     */
    public function setNewsDate($news_date)
    {
        $this->news_date = $news_date;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNewsDate()
    {
        return $this->news_date;
    }

    /**
     * @param mixed $news_shabad
     *
     * @return self
     */
    public function setNewsShabad($news_shabad)
    {
        $this->news_shabad = $news_shabad;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNewsShabad()
    {
        return $this->news_shabad;
    }

    /**
     * @param mixed $image
     *
     * @return self
     */
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param mixed $is_approved
     *
     * @return self
     */
    public function setIsApproved($is_approved)
    {
        $this->is_approved = $is_approved;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIsApproved()
    {
        return $this->is_approved;
    }
}
