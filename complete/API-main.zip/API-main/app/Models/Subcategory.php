<?php

namespace App\Models;

use App\Models\AppModel;
use App\Models\Media;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;
use Laracasts\Presenter\PresentableTrait;
use Kyslik\ColumnSortable\Sortable;

class Subcategory extends AppModel
{
	use HasSlug, PresentableTrait, Sortable;

    protected $presenter = '\App\Presenters\SubcategoryPresenter';

    protected $table = 'subcategories';

    protected $fillable = ['slug','category_id', 'name','image', 'description', 'status', 'featured', 'featured_display_order'];

    /**
     * set string fields for filtering 
     * @var array
     */
    protected $likeFilterFields = ['name'];

    /**
     * set boolean fields for filtering 
     * @var array
     */
    protected $boolFilterFields = ['status', 'featured'];
    
    public $sortable = ['id',
                        'name',
                        'image',
                        'status',
                        'featured',
                        'featured_display_order'];

    /**
     * Get the options for generating the slug.
     */
    public function getSlugOptions() : SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('name')
            ->saveSlugsTo('slug');
    }

    /**
     * Get all of the tags for the post.
     */
    public function media()
    {
        return $this->morphToMany(Media::class, 'mediable');
    }

    /**
     * @return mixed
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * @param mixed $name
     *
     * @return self
     */
    
    public function setCategory($category_id)
    {
        $this->category_id = $category_id;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCategory()
    {
        return $this->category_id;
    }
    
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $description
     *
     * @return self
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $status
     *
     * @return self
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }
    
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $featured
     *
     * @return self
     */
    public function setFeatured($featured)
    {
        $this->featured = $featured;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getFeatured()
    {
        return $this->featured;
    }

    /**
     * @param mixed $featured_display_order
     *
     * @return self
     */
    public function setFeaturedDisplayOrder($featured_display_order)
    {
        $this->featured_display_order = $featured_display_order;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getFeaturedDisplayOrder()
    {
        return $this->featured_display_order;
    }
}
