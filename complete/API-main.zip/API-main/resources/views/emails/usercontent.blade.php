<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>::KhojGurbani::</title>
        <meta name="viewport" content="width=device-width">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
       <style type="text/css">
            body{font-family: 'Roboto', sans-serif;font-weight: 500;}   
            a{text-decoration:none;}
            @media only screen and (max-width: 550px), screen and (max-device-width: 550px) {
                body[yahoo] .buttonwrapper { background-color: transparent !important; }
                body[yahoo] .button { padding: 0 !important; }
                body[yahoo] .button a { background-color: #c6a519; padding: 15px 25px !important; }
            }
        </style>
    </head>
    <body bgcolor="#e1e1e1" style="margin: 0; padding: 0;" yahoo="fix">      
        <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; width: 100%; max-width: 600px;margin:40px auto;" class="content">
            <tbody style="box-shadow: 0px 0px 10px #ccc;">          
            <tr>
                <td bgcolor="#000" style="padding:18px 0px;border-bottom:1px solid #ece4e4;">
                    <img src="{{ asset('images/logo.png') }}" style="display:block;margin:0 auto;width:150px;">
                </td>
            </tr>
            
            <tr>
                <td align="left" bgcolor="#ffffff" style="padding:15px 20px;color:#9c9c9c;line-height:20px;font-size:17px;text-align:center; "> 
                    <span>Waheguru Ji Ka Khalsa</span><br>          
                    <span>Waheguru Ji Ke Fateh</span>           
                </td>
            </tr>

<tr>
              <td bgcolor="#f2f2f2" style="padding:15px 20px;color:#000000;line-height:20px;font-size:12px;text-align:center;" >
                @switch($type)
                    @case('commentary')
                        <strong>A Commentary is subject for your approval.</strong>
                        <span>Commentary is started at this link: <a href="{{ $url }}">Click Here </a></span>
                        @break
                    @case('comment')
                        <span>Comment is started at this link: <a href="{{ $url }}">Click Here </a></span>
                        @break
                    @case('blog')
                        <span>Blog is started at this link: <a href="{{ $url }}">Click Here </a></span>
                        @break
                    @default
                            <strong></strong>
                @endswitch
              </td>
            </tr>
            <tr>
                <td bgcolor="#f2f2f2" style="padding:8px 20px;color:#000000;line-height:20px;font-size:12px;text-align:center;">
                    <span>Please review and add your feedback.</span>
                </td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FBFBFB" style="padding:15px 10px 15px 10px;color:#9c9c9c;font-size:12px;">
                   <span>© 2020 - KhojGurbani. All rights reserved.</span><br><br>
                   <span>The KhojGurbani Team</span>
                </td>
            </tr>            
            </tbody>
        </table>        
    </body>
</html>