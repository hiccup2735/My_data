<table cellpadding="0" cellspacing="0" border="0" width="100%">
    <tr>
        <td width="70%" style="color:#fff; height:30px; vertical-align: middle;font-family: Helvetica,Arial,sans-serif;font-size: 14px;font-weight: normal;line-height: 20px;text-align: center;">
        	{{ trans('mailer.footer_messages.all_right_reserved_text') }}
        </td>
    </tr>
</table>