<!DOCTYPE html>
<html>
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body>
	<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; width: 100%; max-width: 600px;margin:40px auto;" class="content">
		<tbody style="box-shadow: 0px 0px 10px #ccc;">			
			<tr>
                <td bgcolor="#000" style="padding:18px 0px;border-bottom:1px solid #ece4e4;">
                    <img src="{{ asset('images/logo.png') }}" style="display:block;margin:0 auto;width:150px;">
                </td>
            </tr>
			
            <tr>
                <td align="left" bgcolor="#ffffff" style="padding:15px 20px;color:#9c9c9c;line-height:20px;font-size:17px;text-align:center; ">	
                    <span>Waheguru Ji Ka Khalsa</span><br>			
                    <span>Waheguru Ji Ke Fateh</span>			
                </td>
            </tr>
			<tr>
				<td style="padding-left: 20px">					
					<p>Hi {{title_case($user['name'])}},</p>
					<p>You are receiving this email because we  received a password reset request for your account.</p>
					<p>To Reset your password <a href="https://www.khojgurbani.org/reset-password/{{$token}}">click here</a>.</p>
				</td>
			</tr>
			<tr>
                <td style="padding: 20px 20px 0px 20px;">
                    <p style="margin: 5px 0;">
                        <strong>Thanks,</strong>
                    </p>
                </td>
            </tr>
            <tr>
                <td style="padding: 0px 20px 10px 20px;">
                    <p style="margin: 5px 0;">
                        <strong>The KhojGurbani Team</strong>
                    </p>
                </td>
            </tr>
		</tbody>
	</table>    
</body>

</html>