@extends('admin.layouts.app', ['title' => 'Create Media'])

@section('contents')
<div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="{{ route('admin.dashboard') }}">Dashboard</a>
        </li>
        <li class="breadcrumb-item">
            <a href="{{ route('admin.media.index') }}">Media</a>
        </li>
        <li class="breadcrumb-item active">Create</li>
    </ol>
    <div class="text-left mb-3">
        Create Media
    </div>
    <form action="{{ route('admin.media.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        @include('admin.media.partials.form')

        <button type="submit" name="login" class="btn btn-primary">
            Save
        </button>
        <a href="{{ route('admin.media.index') }}" class="btn btn-default">
            Cancel
        </a>
    </form>
    <!--	<div class="card mb-3">
                    <div class="card-header">
                            Create Media
                    </div>
                    <div class="card-body">
                            
                    </div>
            </div>-->
</div>
@endsection
