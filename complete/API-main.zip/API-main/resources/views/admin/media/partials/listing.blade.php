<div @if(!isset($_GET['title'])) style="display: none;" @endif>
      <!--<div class="card-header">
              <i class="fas fa-table"></i> Media Listing
              <div class="pull-right">
                      <a href="{{ route('admin.media.create') }}" class="btn btn-primary">
                              <i class="fas fa-plus"></i>
                              Add
                      </a>
              </div>
      </div>-->
      <div class="text-right" style="overflow: hidden;">
        <a href="{{ route('admin.media.create') }}" class="btn btn-primary">
            <i class="fas fa-plus"></i>
            Add
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-borderless" id="dataTable" width="100%" cellspacing="0">
                <colgroup>
                    <col width="5%">
                    <col width="10%">
                    <col width="10%">
                    <col width="30%">
                    <col width="15%">
                    <col width="15%">
                    <col width="7%">
                    <col width="8%">
                </colgroup>
                <thead>
                    <tr>
                        <th>@sortablelink('id', 'ID', [],  ['rel' => 'ID'])</th>
                        <th>Author Name</th>
                        <th>Media</th>
                        <th>@sortablelink('title', 'Title', [],  ['rel' => 'Title'])</th>
                        <th>Categories</th>
                        <th>Tags</th>
                        <th>@sortablelink('status', 'Status', [],  ['rel' => 'Status'])</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @php 
                    $lastid = null;
                    $rowclass = '#e9ecef';
                    @endphp
                    @forelse($items as $item)
                    
                    @php 
                    //if userid changed from last iteration, store new userid and change color
                    if ($lastid !== $item->id)
                    {
                       $lastid =$item->id;
                       if ($rowclass == '#e9ecef') $rowclass = 'white';
                       else $rowclass = '#e9ecef';
                    }
                   @endphp
                   <tr style="background-color: {{$rowclass}}">
                        <td>{{ $item->id }}</td>
                        <td>{{ $item->present()->author_name }}</td>
                        <?php if($item->type=='AUDIO'){ ?>
                        <td>
                             <audio controls>
                                <source src="{{asset('uploads/media/'.$item->attachment_name)}}" type="audio/ogg">
                                <source src="{{asset('uploads/media/'.$item->attachment_name)}}" type="audio/mpeg">
                              </audio> 
                        </td>
                        <?php } ?>
                        <?php if($item->type=='IMAGE'){ ?>
                        <td>
                            <audio controls>
                                <source src="{{$item->attachment_name}}" type="audio/ogg">
                                <source src="{{$item->attachment_name}}" type="audio/mpeg">
                              </audio> 
                        </td>
                        <?php } ?>
                        <td>{{ $item->present()->title }}</td>
                        <td>{!! $item->present()->categoriesHtml !!}</td>
                        <td>{!! $item->present()->tagsHtml !!}</td>
                        <td style="text-align: center;">{!! $item->present()->statusLink !!}</td>
                        <td>
                            {!! $item->present()->editLink !!}
                            &nbsp;
                            {!! $item->present()->deleteLink !!}
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5">No Record Found.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        {{ $items->appends(\Request::all())->links() }}
    </div>
</div>