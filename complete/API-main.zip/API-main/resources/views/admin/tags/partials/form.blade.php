<?php
	$name = \Request::old('name');
	$description = \Request::old('description');
	$status = \Request::old('status');
	$formUrl = route('admin.tags.store');
	$heading = '<i class="fas fa-plus"></i> Add Tag';
	if($item) {
		$formUrl = route('admin.tags.update', $item->getKey());
		$name = \Request::old('name', $item->getName());
		$description = \Request::old('description', $item->getDescription());
		$status = \Request::old('status', $item->getStatus());
		$heading = '<i class="fas fa-edit"></i> Edit Tag';
	}
	$isChecked = $status ? "checked" : null;
        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$last_parts = explode("/", $actual_link); 
?>
<div id="categoryAddForm" @if(!is_numeric(end($last_parts))) style="display: none;" @endif>
<div class="text-left mb-3">
        {!! $heading !!}
    </div>
<form action="{{ $formUrl }}" method="POST">
		@csrf
		<div class="form-group">
			<div class="form-row">
				<div class="col-md-12">
					<div class="form-label-group">
						<input type="text" 
							id="name" 
							name="name" 
							class="form-control" 
							placeholder="Name" 
							autofocus="autofocus"
							value="{{ $name }}">
						
						<label for="name">name</label>
						@if( $errors->has('name'))
	                        <div class="alert alert-danger">{{ $errors->first('name') }}</div>
							
	                    @endif
					</div>
				</div>
			</div>
		</div>
<!--		<div class="form-group">
			<div class="form-row">
				<div class="col-md-12">
					<div class="form-label-group">
						<textarea name="description" rows="2" class="form-control" placeholder="Description">{{ $description }}</textarea>
					</div>
				</div>
			</div>
		</div>-->
		<div class="form-group">
                <div class="checkbox">
                    <label>
                        <input type="hidden" name="status" value="1" checked="">
                        <!--Status-->
                    </label>
                </div>
            </div>
		<button type="submit" 
            name="login"
            class="btn btn-primary">
        	
        	Save
       	</button>
		<a href="{{ route('admin.tags.index') }}" class="btn btn-default">Cancel</a>
	</form>     
<!--<div class="card-body">
	
</div>-->
</div>