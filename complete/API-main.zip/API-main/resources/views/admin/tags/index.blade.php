@extends('admin.layouts.app', ['title' => 'Tags'])

@section('contents')
<div class="container-fluid">

	<!-- Breadcrumbs-->
	<ol class="breadcrumb">
		<li class="breadcrumb-item">
			<a href="{{ route('admin.dashboard') }}">Dashboard</a>
		</li>
		<li class="breadcrumb-item active">Tags</li>
	</ol>
        @include('admin.tags.partials.form')
        
        @include('admin.tags.partials.listing')
	
<!--	<div class="card mb-3">
		
	</div>-->
</div>
@endsection
