<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Khoj Gurbani - {{ $title }}</title>

    <!-- Custom fonts for this template-->
    <link href="{{ asset('css/admin/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/admin/select2.min.css') }}" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="{{ asset('css/admin/sb-admin.min.css') }}" rel="stylesheet">
        <!-- Bootstrap core JavaScript-->
    <script src="{{ asset('js/admin/jquery.min.js') }}" defer></script>
    <script src="{{ asset('js/admin/bootstrap.bundle.min.js') }}" defer></script>

    <!-- Core plugin JavaScript-->
    <script src="{{ asset('js/admin/jquery-easing/jquery.easing.min.js') }}" defer></script>

</head>

<body id="page-top">

    @include('admin.layouts.partials.header')

    <div id="wrapper">

        <!-- Sidebar -->
        @include('admin.layouts.partials.sidebar')
        

        <div id="content-wrapper">

            @include('admin.layouts.partials.flash-message')

            @yield('contents')
            <!-- /.container-fluid -->

            <!-- Sticky Footer -->
            @include('admin.layouts.partials.footer')

        </div>
        <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <!-- <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div> -->

    <!-- Custom scripts for all pages-->
    <script src="{{ asset('js/admin/sb-admin.min.js') }}" defer></script>
    <script src="{{ asset('js/admin/select2.min.js') }}" defer></script>
    <script src="{{ asset('js/admin/custom.js') }}" defer></script>
   
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" defer></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" defer></script>
    @yield('scripts')
</body>

</html>
