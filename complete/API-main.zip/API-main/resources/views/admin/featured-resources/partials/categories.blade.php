<div class="card-header">
	<i class="fas fa-table"></i> Featured Categories
</div>
<div class="card-body">
	<form action="{{ route('admin.store.featured.resources.categories.list') }}" method="POST" enctype="multipart/form-data">
		@csrf
		<div class="form-group">
			<div class="form-row">
				<div class="col-md-12">
					<div class="form-label-group">
						<div class="form-select2-container">
							<select name="categories[]" 
									class="form-control categories-dd-list"
									data-url="{{ route('admin.featured.resources.categories.list') }}" multiple="true">

								@foreach($featuredCategories as $categoryId => $categoryName)
									<option value="{{ $categoryId }}" selected="selected">{{ $categoryName }}</option>
								@endforeach
								
							</select>
						</div>
					</div>
				</div>
			</div>
		</div>
		<button type="submit" name="login" class="btn btn-primary">
        	Save
       	</button>
		<a href="{{ route('admin.featured.resources.index') }}" class="btn btn-default">
			Cancel
		</a>
	</form>
	<div>
	</div>
</div>