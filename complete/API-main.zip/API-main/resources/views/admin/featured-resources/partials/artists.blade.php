
<div class="card-header">
    <i class="fas fa-table"></i> Featured Artists
</div>

@foreach($featuredAuthor as $artistId => $artistTitle)
@php 
$data_order[] = $artistId;
@endphp
@endforeach

@php 
$imp_data=implode(',',$data_order);
@endphp

<div class="card-body">
    <form action="{{ route('admin.store.featured.resources.authors.list') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <div class="form-row">
                <div class="col-md-12">
                    <div class="form-label-group">
                        <div class="form-select2-container select2 sortable">
                            <select name="authors[]" 
                                    class="form-control artists-dd-list select2 sortable"
                                    data-url="{{ route('admin.featured.resources.authors.list') }}" multiple="true" data-order={{$imp_data}}>
                                
                                @foreach($featuredAuthor as $artistId => $artistTitle)
                                <option value="{{ $artistId }}" selected="selected">{{ $artistTitle }}</option>
                                @endforeach

                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <button type="submit" name="login" class="btn btn-primary">
            Save
       	</button>
        <a href="{{ route('admin.featured.resources.index') }}" class="btn btn-default">
            Cancel
        </a>
    </form>
    <div>
    </div>
</div>