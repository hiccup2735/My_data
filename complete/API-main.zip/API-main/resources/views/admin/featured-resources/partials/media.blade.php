<div class="card-header">
    <i class="fas fa-table"></i> Featured Media
</div>
<div class="card-body">
    <form action="{{ route('admin.store.featured.resources.media.list') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <div class="form-row">
                <div class="col-md-12">
                    <div class="form-label-group">
                        <div class="form-select2-container">
                            <select name="media[]" 
                                    class="form-control media-dd-list"
                                    data-url="{{ route('admin.featured.resources.media.list') }}" multiple="true">

                                @foreach($featuredMedia as $key => $media)
<!--                                <option value="<?php //$media->id ; ?>" selected="selected"><?php //$media->title  ?> - (<?php //$media->author->name  ?>)</option>-->
                                <option value="{{$key}}" selected="selected">{{ $media }}</option>
                                @endforeach

                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <button type="submit" name="login" class="btn btn-primary">
            Save
       	</button>
        <a href="{{ route('admin.featured.resources.index') }}" class="btn btn-default">
            Cancel
        </a>
    </form>
    <div>
    </div>
</div>