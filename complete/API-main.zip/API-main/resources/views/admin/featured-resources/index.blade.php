@extends('admin.layouts.app', ['title' => 'Featured Resources'])

@section('contents')
<div class="container-fluid">

	<!-- Breadcrumbs-->
	<ol class="breadcrumb">
		<li class="breadcrumb-item">
			<a href="{{ route('admin.dashboard') }}">Dashboard</a>
		</li>
		<li class="breadcrumb-item active">Featured Resources</li>
	</ol>

	<div class="card mb-12">
		@include('admin.featured-resources.partials.media')
	</div>
	<div class="card mb-12">
		@include('admin.featured-resources.partials.artists')
	</div>

	<div class="card mb-12">
		@include('admin.featured-resources.partials.categories')
	</div>
</div>
@endsection

@section('scripts')
<script src="{{ asset('js/admin/jquery-ui.min.js') }}" defer></script>
<link href="{{ asset('css/admin/tokenize2.min.css') }}" rel="stylesheet">
<script src="{{ asset('js/admin/tokenize2.js') }}" defer></script>
<script src="{{ asset('js/admin/featured-resources.js') }}" defer></script>
@endsection
