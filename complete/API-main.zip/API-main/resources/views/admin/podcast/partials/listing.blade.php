<!--<div class="text-right" style="overflow: hidden;">
<button type="button" id="CategoryMediaListing" class="btn btn-primary">Add</button>
</div>-->
<!--<div class="card-header">
	<i class="fas fa-table"></i> Category Listing
        
</div>-->
<div class="">

            <table id="media_category_listing_datatable1" class="table table-striped table-borderless" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Media</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $today_podcast=DB::table('podcast_media')->where('today_approval','1')->count();
            ?>
            
             <!--If today podcast exist START-->
            @if($today_podcast>0)
            @php 
            $a=1; 
            $today_podcast_first=DB::table('podcast_media')->where('today_approval','1')->orderBy('id','desc')->first();
            @endphp
            @foreach($items as $feed_datas)
            
            <tr>
                <td>{{ $feed_datas['_id'] }}</td>
                <td>{{ $feed_datas['title'] }}</td>
                <td>
                    <audio controls>
                        <source src="{{$feed_datas['media_data']['url']}}" type="audio/ogg">
                        <source src="{{$feed_datas['media_data']['url']}}" type="audio/mpeg">
                    </audio> 
                </td>
                @if($today_podcast_first->attachment_name==$feed_datas['media_data']['url'])
                <td style="width: 20%;"><a href="{{url('admin/podcast-list/remove-today/')}}" class="btn btn-success">Click To Unmark</a></td>
                @else
<!--                <td style="width: 30%;"><p style="color: red;">Only 1 podcast can be assigned</p></td>-->
                <td style="width: 20%;"><a href="{{url('admin/podcast-list/today/'.$feed_datas['_id'].'/'.$feed_datas['title'].'?url='.$feed_datas['media_data']['url'])}}" class="btn btn-info">Click to mark as today</a></td>
                @endif
                
                
            </tr>
            @php $a++; @endphp
            @endforeach
            <!--If today podcast exist END-->
            @else
            <!--If no today podcast exist START-->
            @php $a=1; 
            @endphp
            @foreach($items as $feed_datas)
            
            <tr>
                <td>{{ $feed_datas['_id'] }}</td>
                <td>{{ $feed_datas['title'] }}</td>
                <td>
                    <audio controls>
                        <source src="{{$feed_datas['media_data']['url']}}" type="audio/ogg">
                        <source src="{{$feed_datas['media_data']['url']}}" type="audio/mpeg">
                    </audio> 
                </td>
                <td style="width: 20%;"><a href="{{url('admin/podcast-list/today/'.$feed_datas['_id'].'/'.$feed_datas['title'].'?url='.$feed_datas['media_data']['url'])}}" class="btn btn-info">Click to mark as today</a></td>
                
            </tr>
            @php $a++; @endphp
            @endforeach
            <!--If no today podcast exist END-->
            @endif
            
            
           
            
            
            
            
            
        </tbody>
    </table>
	</div>
