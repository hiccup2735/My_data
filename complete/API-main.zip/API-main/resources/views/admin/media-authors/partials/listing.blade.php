
<div class="text-right" style="overflow: hidden;">
<button type="button" id="CategoryMediaListing" class="btn btn-primary">Add</button>
</div>
<div class="card-body">
    <div class="">
<!--        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>@sortablelink('id', 'ID', [],  ['rel' => 'ID'])</th>
                    <th>@sortablelink('name', 'Name', [],  ['rel' => 'Author Name'])</th>
                    <th>Image</th>
                    <th>@sortablelink('status', 'Status', [],  ['rel' => 'Author Status'])</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($items as $item)
                <tr>
                    <td>{{ $item->id }}</td>
                    <td>{{ $item->present()->name }}</td>
                    <td>
                        @if($item->present()->image!='')
                        <img src="{{asset('uploads/author/'.$item->present()->image)}}" width="50" height="50">
                        @else
                        N/A
                        @endif
                    </td>
                    <td>{!! $item->present()->statusLink !!}</td>
                    <td>
                        {!! $item->present()->editLink !!}
                        &nbsp;
                        {!! $item->present()->deleteLink !!}
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="5">No Record Found.</td>
                </tr>
                @endforelse
            </tbody>
        </table>-->
        
        <table id="media_category_listing_datatable" class="table table-striped table-borderless" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Image</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($items as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->present()->name }}</td>
                <td>
                    @if($item->present()->image!='')
                    <img src="{{asset('uploads/author/'.$item->present()->image)}}" width="50" height="50">
                    @else
                    N/A
                    @endif
                </td>
                <td>{!! $item->present()->statusLink !!}</td>
                <td>
                    {!! $item->present()->editLink !!}
                    &nbsp;
                    {!! $item->present()->deleteLink !!}
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    </div>
</div>