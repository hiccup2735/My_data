@extends('admin.layouts.app', ['title' => 'Dashboard'])

@section('contents')
<div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
        <!-- <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
        </li> -->
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>

    <h1 class="display-1">Welcome to home page</h1>
</div>
@endsection
