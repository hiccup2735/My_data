<?php
$name = \Request::old('name');
$description = \Request::old('description');
$status = \Request::old('status');
$formUrl = route('admin.media.subcategories.store');
$heading = '<i class="fas fa-plus"></i> Add Sub Category';
$data=collect(request()->segments())->last();
if(is_numeric($data)){
     $category=\App\Models\Subcategory::where('id',$data)->first();
//     echo "<pre>"; print_r($category); die;
}else{
$category='';
}
if ($category) {
//    echo "<pre>";print_r($category->getStatus()); die;
    $formUrl = route('admin.media.subcategories.update', $category->getKey());
    $name = \Request::old('name', $category->getName());
    $category_id = \Request::old('category', $category->getCategory());
    $description = \Request::old('description', $category->getDescription());
    $status = \Request::old('status', $category->getStatus());
    $heading = '<i class="fas fa-edit"></i> Edit Category';
}
$isChecked = $status ? "checked" : null;
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$last_parts = explode("/", $actual_link); 
?>
<div id="categoryAddForm" @if(!is_numeric(end($last_parts))) style="display: none;" @endif>
     <div class="text-left mb-3">
        {!! $heading !!}
    </div>
     <form action="{{ $formUrl }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <div class="form-row">
                <div class="col-md-12">
                    <div class="form-label-group">
                        <input type="text" 
                               id="name" 
                               name="name" 
                               class="form-control" 
                               placeholder="Name" 
                               autofocus="autofocus"
                               value="{{ $name }}">

                        <label for="name">name</label>
                        @if( $errors->has('name'))
                        <div class="alert alert-danger">{{ $errors->first('name') }}</div>

                        @endif
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="form-row">
                <div class="col-md-12">
                    <div class="form-label-group">
                        <select name="category_id" required="" class="form-control">
                            <option value="">Category</option>
                            @foreach($category_list as $category_lists)
                            <option value="{{$category_lists->id}}" @if(isset($category_id) && $category_id==$category_lists->id) selected @endif>{{$category_lists->name}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
        </div>
        
<!--        <div class="form-group">
            <div class="form-row">
                <div class="col-md-12">
                    <div class="form-label-group">
                        <textarea name="description" rows="2" class="form-control" placeholder="Description">{{ $description }}</textarea>
                    </div>
                </div>
            </div>
        </div>-->
        <div class="form-group">
            <div class="form-row">
                <div class="col-md-12">
                    <div class="form-label-group">
                        <label for="category_image_id" class="btn btn-success btn-block btn-outlined col-sm-4">Select Sub-Category Image</label>
                        <input type="file" id="category_image_id" name="image" style="display: none;"  accept="image/x-png,image/gif,image/jpeg" >
<!--                        <input type="file" name="image">-->
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="checkbox">
                <label>
                    <input type="checkbox" name="status" value="1" {{ $isChecked }}>
                    Status
                </label>
            </div>
        </div>
        <button type="submit" 
                name="login"
                class="btn btn-primary">

            Save
       	</button>
        <a href="{{ route('admin.media.subcategories.index') }}" class="btn btn-default">Cancel</a>
    </form>

     </div>