<?php

return[
	'header' => [
		'app_name' => 'Khoj Gurbani',
	],
	'footer_messages' => [	
		'all_right_reserved_text' => 'Khoj Gurbani 2019. All Rights Reserved'
	]
];